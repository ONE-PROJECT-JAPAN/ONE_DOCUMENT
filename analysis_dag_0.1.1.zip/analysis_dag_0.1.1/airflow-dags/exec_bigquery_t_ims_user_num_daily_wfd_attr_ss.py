import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from airflow import DAG
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
from common_ims.bqsync import redshift_to_bigquery
import pendulum

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_IMS_USER_NUM_DAILY_WFD_ATTR_SS'
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
local_tz = pendulum.timezone("Asia/Tokyo")

default_args = {
    'start_date': datetime(2021,1,1,7,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id=f'exec_bigquery_{BIGQUERY_TABLE_NAME.lower()}',
    default_args=default_args,
    description=f'{BIGQUERY_TABLE_NAME}構築',
    schedule_interval='30 7 * * *',
    catchup=False
)

#
# 前提テーブル構築チェック
#
check_tables = (
    ('T_WFD_USER_ATTR',            'send_bigquery_idrp',              'done_all_task_for_check',  30),  # 毎日07時00分(JST)
    ('send_bigquery_is',           'send_bigquery_is',                'done_all_task_for_check',  30),  # 毎日07時00分(JST)
    ('M_IS_NX_ATTRIBUTE',          'exec_bigquery_m_is_nx_attribute', 'done_all_task_for_check',  20),  # 毎日07時10分(JST)
    ('send_bigquery_bb',           'send_bigquery_bb',                'done_all_task_for_check',  10),  # 毎日07時20分(JST)
    ('send_bigquery_kk',           'send_bigquery_kk',                'done_all_task_for_check',  30),  # 毎日07時00分(JST)
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=7200,      #120分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

#
# BigQueryテーブル操作
#
with dag:
    delete_t_ims_user_num_daily_wfd_attr_ss =  bigquery_executor(
        dag=dag,
        group_id='delete_t_ims_user_num_daily_wfd_attr_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table=BIGQUERY_TABLE_NAME,
        execute_query=f'sql/bigquery/execute/DEL__{BIGQUERY_TABLE_NAME}.sql',
        is_table_update_mng=False
    )

    redshift_to_bigquery_t_ims_user_num_daily_wfd_attr_ss = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_ims_user_num_daily_wfd_attr_ss',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_ims_user_num_daily_wfd_attr_ss.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table=BIGQUERY_TABLE_NAME,
        write_disposition='WRITE_APPEND',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

check_tasks >> delete_t_ims_user_num_daily_wfd_attr_ss >> redshift_to_bigquery_t_ims_user_num_daily_wfd_attr_ss >> done_all_task_for_check
