from typing import Dict, List
from datetime import datetime, timedelta, timezone
import json
from airflow import DAG
from airflow.models import Variable
from airflow.providers.amazon.aws.operators.batch import AwsBatchOperator

batch_config = json.loads(Variable.get("batch_config"))

QUEUE_DEFAULT = 'default'
QUEUE_DATACLEANSING = 'datacleansing'

def create_operator(dag: DAG, task_id: str, job_name: str, queue: str, command: List[str] = [], environment: Dict[str, str] = {}) -> AwsBatchOperator:
    return AwsBatchOperator(
        task_id=task_id,
        dag=dag,
        job_name=f"{job_name}{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}",
        job_definition=f"{batch_config['job_definition_name_prefix']}{job_name}",
        job_queue=f"{batch_config['job_queue_name_prefix']}{queue}",
        overrides={
            'command': command,
            'environment': [{"name": k, "value": v} for k, v in environment.items()],
        },
    )
