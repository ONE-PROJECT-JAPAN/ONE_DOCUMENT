#######################################################################################################
# ユーティリティ定義
#######################################################################################################

import os
import logging
from boto3 import Session
from common_ims.common_util import convUTC2JST
from common_ims.common_util import delete_files
from common_ims.common_util import move_file_s3_to_s3_by_full_control

# 転送元拡張子
FILE_EXTENTION_ORG = """000.gz"""

# 転送先拡張子
FILE_EXTENTION_DEST = """.tsv.gz"""

def move_file_s3_to_s3(
    s3_org_bucket, 
    s3_dest_bucket, 
    s3_org_path, 
    s3_dest_path,
    next_execution_date):
    """
    指定されたPrefixから1ファイル取得し、拡張子を変更し、別バケットに転送

    Parameters:
    ----------
    s3_org_bucket : 
        転送元のバケット
    s3_dest_bucket : 
        転送先のバケット
    s3_org_path : 
        転送元のパス
    s3_dest_path : 
        転送先のパス
    next_execution_date : 
        実行日付
    Returns:
    ----------
    なし
    """
    s3client = Session().client('s3')

    try:
        # 日付からYYYYMMDDを取得
        exe_date = convUTC2JST(next_execution_date, "%Y%m%d")
        # Prefixに日付埋める
        s3_org_prefix = s3_org_path.format(exe_date)
        response = s3client.list_objects_v2(Bucket=s3_org_bucket, Prefix=s3_org_prefix)

        # 処理対象ファイル有無チェック（recv）
        if 'Contents' not in response:
            logging.error(f'*** trial_api_util move_file_s3_to_s3 {s3_org_prefix}にファイルなし')
            raise Exception('ファイルが存在しません。')
            
        if 'Contents' in response:
            keys = [i['Key'] for i in response['Contents']]
            logging.info(f'*** trial_api_util move_file_s3_to_s3 keys: {keys}')
            
            # 最新のファイルのみ転送
            s3_org_key = keys.pop(len(keys) - 1)
            logging.info(f'*** trial_api_util move_file_s3_to_s3 s3_org_key: {s3_org_key}')

            # ファイル名取得のため、分割
            path_file_arr = os.path.split(s3_org_key)

            # ファイル名
            file_name = path_file_arr[1]

            # 拡張子変更
            file_name_tmp = file_name.replace(FILE_EXTENTION_ORG, FILE_EXTENTION_DEST)
            s3_dest_key = s3_dest_path.format(exe_date, file_name_tmp)
            logging.info(f'*** trial_api_util move_file_s3_to_s3 s3_dest_key: {s3_dest_key}')
            
            # ファイル移動(フル権限付与)
            move_file_s3_to_s3_by_full_control(s3client, s3_org_bucket, s3_dest_bucket, s3_org_key, s3_dest_key)
            
            # 残っている不要なファイル削除
            delete_files(s3client, s3_org_bucket, keys)
    except Exception as e:
        # 異常終了時
        logging.error(f'*** trial_api_util move_file_s3_to_s3')
        raise e
