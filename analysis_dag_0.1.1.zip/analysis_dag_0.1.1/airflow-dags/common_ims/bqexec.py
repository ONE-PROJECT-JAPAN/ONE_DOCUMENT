"""BigQuery上での蓄積テーブル、スナップショットテーブルの構築"""
from airflow import DAG
from airflow.utils.task_group import TaskGroup
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator


def bigquery_executor(
    dag: DAG,
    group_id: str,
    bigquery_dataset: str,
    bigquery_table: str,
    execute_query: str,
    is_table_update_mng: bool = True,
) -> TaskGroup:
    """
    BigQuery上での蓄積テーブル、スナップショットテーブルの構築

    Parameters
    ----------
    dag : DAG
        DAG
    group_id : str
        タスクグループID
    bigquery_dataset: str
        データセット名
    bigquery_table: str
        構築テーブル名
    execute_query: str
        実行SQL
    is_table_update_mng: bool
        管理テーブル更新要否

    Returns
    -------
    tg : TaskGroup
        タスクグループ
    """
    with TaskGroup(group_id=group_id) as tg:

        bigquery_execute_query = BigQueryExecuteQueryOperator(
            dag=dag,
            task_id='bigquery_execute_query',
            sql=execute_query,
            params={
                'dataset_name': bigquery_dataset,
            },
            use_legacy_sql=False,
        )

        bigquery_execute_query

        # 管理テーブル更新
        if is_table_update_mng:
            append_t_ims_table_update_mng = BigQueryExecuteQueryOperator(
                dag=dag,
                task_id='append_t_ims_table_update_mng',
                sql='sql/ims/merge_t_ims_table_update_mng.sql',
                params={
                    'dataset_name': bigquery_dataset,
                    'table_name': bigquery_table
                },
                use_legacy_sql=False,
            )
    
            bigquery_execute_query >> append_t_ims_table_update_mng

    return tg
