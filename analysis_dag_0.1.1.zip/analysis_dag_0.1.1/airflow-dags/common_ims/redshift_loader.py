import json
import base64
import logging
import socket
from airflow.models import Variable
from botocore.session import Session
from botocore.config import Config


def invoke_redshift_loader(ds, **kwargs):
    """Redshift Loader を使用して S3 バケットから Redshift のテーブルへファイルをロードする。

    """
    redshift_loader_function_name = Variable.get('redshift_loader_function_name', None)
    default_source_s3_bucket = Variable.get('datastore_s3_bucket_name', None)
    default_target_db_schema = Variable.get('redshift_ims_schema_name', None)

    session = Session()
    client = session.create_client('lambda', config=Config(read_timeout=920, retries = {'max_attempts': 0}))
    
    # HACK: prevent NAT Gateway from dropping connection that remains idle for more than 350 seconds.
    # https://docs.aws.amazon.com/vpc/latest/userguide/nat-gateway-troubleshooting.html#nat-gateway-troubleshooting-timeout
    hs = client._endpoint.http_session
    hs._socket_options.append((socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1))
    hs._socket_options.append((socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 60))
    hs._socket_options.append((socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10))
    hs._socket_options.append((socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 10))
    
    payload = {
        "system_id":            kwargs['redshift_loader_system_id'],
        "table_name":           kwargs['redshift_loader_table_name'],
        "date":                 kwargs['redshift_loader_date'],
        "format":               kwargs['redshift_loader_format'],
        "skip_rows":            kwargs.get('redshift_loader_skip_rows'),
        "move_completed_files": kwargs.get('redshift_loader_move_completed_files'),
        "source_s3_bucket":     kwargs.get('source_s3_bucket', default_source_s3_bucket),
        "target_db_schema":     kwargs.get('redshift_loader_schema_name', default_target_db_schema),
        "target_db_table_name": kwargs.get('redshift_loader_target_table_name'),
        "accumulation":         kwargs.get('redshift_loader_accumulation')
    }
    response = client.invoke(
        FunctionName=redshift_loader_function_name,
        InvocationType='RequestResponse',
        LogType='Tail',
        Payload=json.dumps(payload)
    )

    if 'FunctionError' in response:
        err = response['FunctionError']
        logging.error(err)
        if 'LogResult' in response:
            result = base64.b64decode(response['LogResult']).decode()
            logging.error(result)
        raise ValueError(err)

    result = base64.b64decode(response['LogResult'])
    logging.info(result)

