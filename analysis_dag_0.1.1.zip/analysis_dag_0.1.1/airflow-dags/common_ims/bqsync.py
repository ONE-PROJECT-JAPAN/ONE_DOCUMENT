from airflow import DAG
from airflow.utils.task_group import TaskGroup
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.providers.google.cloud.transfers.s3_to_gcs import S3ToGCSOperator
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import GCSToBigQueryOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
from airflow.models import Variable

GCS_BUCKET_NAME = Variable.get('atlas_airflow_datastore_gcs_bucket_name')
S3_OUTPUT_FOLDER = 'outbox/send/atlas'

def redshift_to_bigquery(
    dag: DAG,
    group_id: str,
    aws_conn_id: str,
    gcp_conn_id: str,
    s3_bucket_name: str,
    redshift_conn_id: str,
    redshift_role_arn: str,
    redshift_select_sql: str,
    bigquery_dataset: str,
    bigquery_table: str,
    write_disposition: str = 'WRITE_TRUNCATE',
    is_table_update_mng: bool = True,
    bigquery_additional_sql: str = None
) -> TaskGroup:
    """
    Redshiftアンロード～BigQueryロードを行うタスクグループの作成

    Parameters
    ----------
    dag : DAG
        DAG
    group_id : str
        タスクグループID
    aws_conn_id : str
        AWS接続ID
    gcp_conn_id : str
        GCP接続ID
    s3_bucket_name : str
        S3バケット名
    redshift_conn_id : str
        Redshift接続ID
    redshift_role_arn : str
        ARN
    redshift_select_sql : str
        アンロード用SQLファイル
    bigquery_dataset : str
        BigQueryデータセット名
    bigquery_table : str
        ロード対象テーブル
    write_disposition : str
        テーブル更新方法
    is_table_update_mng: bool
        管理テーブル更新要否
    bigquery_additional_sql: str
        追加実行SQL

    Returns
    -------
    tg : TaskGroup
        タスクグループ
    """
    filename_prefix  = f'{group_id}_{{{{ts_nodash}}}}'
    s3_full_prefix = f'{S3_OUTPUT_FOLDER}/{bigquery_dataset}/bqsync/{bigquery_table}/{filename_prefix}'
    gcs_full_prefix = f'{S3_OUTPUT_FOLDER}/{bigquery_dataset}/bqsync/{bigquery_table}/{filename_prefix}'

    with TaskGroup(group_id=group_id) as tg:
        # アンロード
        redshift_to_s3 = PostgresOperator(
            dag=dag,
            task_id='redshift_to_s3',
            postgres_conn_id=redshift_conn_id,
            params={
                's3_bucket_name' : s3_bucket_name,
                's3_full_prefix': f'{S3_OUTPUT_FOLDER}/{bigquery_dataset}/bqsync/{bigquery_table}/{group_id}_',
                'redshift_role_arn': redshift_role_arn
            },
            sql=redshift_select_sql
        )

        # S3 to GCS
        s3_to_gcs = S3ToGCSOperator(
            dag=dag,
            task_id='s3_to_gcs',
            aws_conn_id=aws_conn_id,
            bucket=s3_bucket_name,
            prefix=s3_full_prefix,
            dest_gcs_conn_id=gcp_conn_id,
            dest_gcs=f'gs://{GCS_BUCKET_NAME}/',
            replace=True
        )

        # BigQueryロード
        gcs_to_bigquery = GCSToBigQueryOperator(
            dag=dag,
            task_id='gcs_to_bigquery',
            google_cloud_storage_conn_id=gcp_conn_id,
            bigquery_conn_id=gcp_conn_id,
            bucket=GCS_BUCKET_NAME,
            source_objects=[f'{gcs_full_prefix}*'],
            destination_project_dataset_table=f'{bigquery_dataset}.{bigquery_table}',
            source_format='CSV',
            compression ='GZIP',
            write_disposition=write_disposition,
            create_disposition='CREATE_NEVER',
            schema_object=f'table_schema/{bigquery_dataset}/{bigquery_table}.json',
            allow_quoted_newlines=True,
            ignore_unknown_values=True,
        )

        redshift_to_s3 >> s3_to_gcs >> gcs_to_bigquery 

        # 転送完了ファイル削除 (S3)
        cleanup_s3 = S3DeleteObjectsOperator(
            dag=dag,
            task_id='cleanup_s3',
            aws_conn_id=aws_conn_id,
            bucket=s3_bucket_name,
            prefix=s3_full_prefix,
        )

        gcs_to_bigquery >> cleanup_s3

        # 転送完了ファイル削除 (GCS)
        cleanup_gcs = GCSDeleteObjectsOperator(
            dag=dag,
            task_id='cleanup_gcs',
            gcp_conn_id=gcp_conn_id,
            bucket_name=GCS_BUCKET_NAME,
            prefix=gcs_full_prefix,
        )
        
        gcs_to_bigquery >> cleanup_gcs

        # 管理テーブル更新
        if is_table_update_mng:
            append_t_ims_table_update_mng = BigQueryExecuteQueryOperator(
                dag=dag,
                task_id='append_t_ims_table_update_mng',
                sql='sql/ims/merge_t_ims_table_update_mng.sql',
                params={
                    'dataset_name': bigquery_dataset,
                    'table_name': bigquery_table
                },
                use_legacy_sql=False,
            )
    
            gcs_to_bigquery >> append_t_ims_table_update_mng

        if bigquery_additional_sql:
            bigquery_additional_execute_query = BigQueryExecuteQueryOperator(
                dag=dag,
                task_id=f'bigquery_additional_execute_query',
                sql=bigquery_additional_sql,
                use_legacy_sql=False,
                params={'dataset_name': bigquery_dataset}
            )
    
            gcs_to_bigquery >> bigquery_additional_execute_query

    return tg

