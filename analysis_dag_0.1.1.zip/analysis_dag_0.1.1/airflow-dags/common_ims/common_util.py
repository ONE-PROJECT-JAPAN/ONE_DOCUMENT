#######################################################################################################
# ユーティリティ定義
#######################################################################################################

import os
from datetime import datetime
from pytz import timezone
from boto3 import Session
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
import boto3
import logging

# UTCからJSTに変換する処理
# exe_dt：変換する日時
# output_format：変換する日時のフォーマット

def convUTC2JST(exe_dt, output_format):
    ts_jst = exe_dt.astimezone(timezone('Asia/Tokyo'))
    return datetime.strftime(ts_jst, output_format)


# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# RedshiftのIAM ロール
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')


def load_table(s3_copy_file_prefix, table_name, accum_key, sort_key, table_cols, copy_opt):
    """
    ロード処理（一時テーブルを作成し、蓄積処理を行う）

    Parameters:
    ----------
    s3_copy_file_prefix : 
        ロードするファイルPrefix
    table_name : 
        テーブル名
    accum_key : 
        蓄積キー
    sort_key : 
        ソートキー
    table_cols : 
        テーブルカラム
    copy_opt : 
        COPYコマンドのオプション

    Returns:
    ----------
    なし
    """
    conn = None
    cursor = None
    try:
        logging.info(f'*** common_util load_table table_name :{table_name}  s3_copy_file_prefix: {s3_copy_file_prefix}')

        # DB 接続
        conn = PostgresHook(postgres_conn_id='redshift_default').get_conn()
        cursor = conn.cursor()
        
        # ロード用の一時テーブルを作成
        query_temp_create_table = f"""CREATE TEMPORARY TABLE TEMP_{table_name} AS 
            SELECT * from {REDSHIFT_SCHEMA}.{table_name} limit 0"""
        
        # ロード
        query_copy_temp_table = f"""
            COPY TEMP_{table_name} FROM 's3://{S3_BUCKET_NAME}/{s3_copy_file_prefix}' CREDENTIALS 'aws_iam_role={REDSHIFT_DEFAULT_ROLE_ARN}' {copy_opt};
        """
        
        # 同一キーのデータを削除
        query_original_delete = f"""DELETE FROM {REDSHIFT_SCHEMA}.{table_name} WHERE ({accum_key}) IN (
            SELECT DISTINCT {accum_key} FROM TEMP_{table_name})"""
        
        # 一時テーブルから本テーブルにデータ追加（万が一同一蓄積キーのデータが届いた場合は一つのみ登録）
        query_original_insert = f"""
            INSERT INTO {REDSHIFT_SCHEMA}.{table_name} 
            SELECT 
                {table_cols} 
            FROM (
                    SELECT ROW_NUMBER() over(partition by {accum_key} order by {sort_key}) as rownum, * from TEMP_{table_name}
                ) WHERE rownum = 1"""
        
        # 一時テーブル作成
        logging.info(f'*** common_util load_table query_temp_create_table: {query_temp_create_table}')
        cursor.execute(query_temp_create_table)
        
        # 一時テーブルへロード
        logging.info(f'*** common_util load_table query_copy_temp_table: {query_copy_temp_table}')
        cursor.execute(query_copy_temp_table)
        
        # 蓄積キーにてデータ削除
        logging.info(f'*** common_util load_table query_original_delete: {query_original_delete}')
        cursor.execute(query_original_delete)
        
        # 一時テーブルからデータ追加（蓄積キー重複対応）
        logging.info(f'*** common_util load_table query_original_insert: {query_original_insert}')
        cursor.execute(query_original_insert)
        
        conn.commit()
    except Exception as e:
        logging.error(f'*** common_util load_table Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()


def move_files(file_list, org_path, dest_path, error_stop):
    """
    指定のパスから指定のパスにファイルを移す（複数ファイル）

    Parameters:
    ----------
    file_list : 
        退避対象のファイルリスト
    org_path : 
        移動元のパス
    dest_path : 
        移動先のパス
    error_stop : 
        退避時にエラーの場合の挙動（True：異常終了/False：正常終了）
    Returns:
    ----------
    なし
    """
    logging.info(f'*** move_files org_path: {org_path} dest_path: {dest_path}')
    
    # ファイルリストが空の場合は処理しない
    if not file_list:
        logging.error(f'*** common_util move_files file_list: {str(file_list)}')
        raise Exception(f'common_util ファイルリストが空のため、異常終了')
    # 対象ファイル
    for key_path in file_list:
        file_pair = os.path.split(key_path)
        org_key = os.path.join(org_path, file_pair[1])
        dest_key = os.path.join(dest_path, file_pair[1])
        
        try:
            move_file_one(dest_key, org_key)
        except Exception as e:
            # 例外発生時に中断する場合
            if error_stop:
                logging.error(f'*** common_util move_files Exception: {str(e)}')
                raise e
            # 失敗しても例外は無視する
            logging.warning(f'*** common_util move_files Exception: {str(e)}')
            continue


def move_file_one(dest_key, org_key):
    """
    S3の1ファイルを移動

    Parameters:
    ----------
    dest_key : 
        移動元のパス
    org_key : 
        移動先のパス
    Returns:
    ----------
    なし
    """
    s3client = Session().client('s3')
    s3client.copy_object(Bucket=S3_BUCKET_NAME, Key=dest_key, CopySource={'Bucket': S3_BUCKET_NAME, 'Key': org_key})
    s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=org_key)


def s3_to_redshift_accum_duplicate_key(
        s3_input_path, 
        s3_archive_path, 
        table_name, 
        file_prefix_date, 
        accum_key, sort_key, 
        table_cols, copy_opt, 
        file_move_error_stop):
    """
    Redshistへの差分蓄積処理（蓄積キー重複）

    Parameters:
    ----------
    s3_input_path:
        ロードするシステムのファイルパス
    s3_archive_path : 
        退避するシステムのファイルパス
    table_name : 
        テーブル名
    file_prefix_date : 
        処理日付
    accum_key : 
        蓄積キー
    sort_key : 
        ソートキー
    table_cols : 
        テーブルカラム
    copy_opt : 
        COPYコマンドのオプション
    file_move_error_stop : 
        退避時にエラーの場合の挙動（True：異常終了/False：正常終了）
    """
    s3client = Session().client('s3')

    # ロード対象ファイル
    keys = None
    
    move_file_flag = True
    
    # 処理対象テーブル
    logging.info(f'*** common_util s3_to_redshift_accum_duplicate_key table_name: {table_name}')
    s3_copy_file_prefix = f'{s3_input_path}{table_name}_{file_prefix_date}'
    logging.info(f'*** common_util s3_to_redshift_accum_duplicate_key s3_copy_file_prefix: {s3_copy_file_prefix}')
    try:
        response = s3client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_copy_file_prefix)
        
        # 処理対象ファイル有無チェック（recv）
        if 'Contents' not in response:
            logging.info(f'*** common_util s3_to_redshift_accum_duplicate_key {s3_copy_file_prefix}にファイルなし')
            
            # recvに存在しない場合、cmpも確認
            s3_copy_file_prefix = f'{s3_archive_path}{table_name}_{file_prefix_date}'
            response = s3client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_copy_file_prefix)
            
            # cmpのCOPY時には処理後ファイル移動しない
            move_file_flag = False
            
            # 処理対象ファイル有無チェック（cmp）
            if 'Contents' not in response:
                logging.error(f'*** common_util s3_to_redshift_accum_duplicate_key {s3_copy_file_prefix}にファイルなし')
                raise Exception(f'対象のファイルが存在しない')

        if 'Contents' in response:
            keys = [i['Key'] for i in response['Contents']]
            logging.info(f'*** common_util s3_to_redshift_accum_duplicate_key keys: {keys}')

            # ロード処理
            load_table(s3_copy_file_prefix, table_name, accum_key, sort_key, table_cols, copy_opt)
            
            logging.info(f'*** common_util s3_to_redshift_accum_duplicate_key move_file_flag: {move_file_flag}')
            if move_file_flag :
                # ファイル退避（正常終了&recv）
                move_files(keys, s3_input_path, s3_archive_path, file_move_error_stop)
    except Exception as e:
        # 異常終了時にはファイル退避しない
        logging.error(f'*** common_util s3_to_redshift_accum_duplicate_key prefix: {s3_copy_file_prefix}')
        raise e

def delete_files(s3client, s3_bucket, keys):
    """
    S3のファイルを削除

    Parameters:
    ----------
    s3client : 
        S3クライアント
    s3_bucket : 
        バケット
    keys : 
        削除するファイルパス配列
    Returns:
    ----------
    なし
    """
    for key in keys:
        s3client.delete_object(Bucket=s3_bucket, Key=key)


def move_file_s3_to_s3_by_full_control(
    s3client,
    s3_org_bucket, 
    s3_dest_bucket, 
    org_key, 
    dest_key):
    """
    S3の1ファイルを指定のバケットに移動（フル権限付与）

    Parameters:
    ----------
    s3client : 
        S3クライアント
    s3_org_bucket : 
        移動元のバケット
    s3_dest_bucket : 
        移動先のバケット
    org_key : 
        移動元のパス
    dest_key : 
        移動先のパス
    Returns:
    ----------
    なし
    """
    logging.info(f'*** common_util move_file_s3_to_s3_by_full_control s3_org_bucket:{s3_org_bucket}  org_key: {org_key}')
    logging.info(f'*** common_util move_file_s3_to_s3_by_full_control s3_dest_bucket:{s3_dest_bucket} dest_key: {dest_key}')
    
    s3client.copy_object(ACL='bucket-owner-full-control', Bucket=s3_dest_bucket, Key=dest_key, CopySource={'Bucket': s3_org_bucket, 'Key': org_key})
    
    # 削除
    s3client.delete_object(Bucket=s3_org_bucket, Key=org_key)
