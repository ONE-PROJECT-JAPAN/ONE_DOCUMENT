from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
import os
import requests
import base64
import json
import logging
from math import ceil
from psycopg2 import extras

REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')
NILINK_URL = Variable.get('nilink_url')
NILINK_CLIENT_ID = Variable.get('nilink_client_id')
NILINK_CLIENT_SECRET = Variable.get('nilink_client_secret')

NLINK_API_USERID_LIMIT = 1000

def get_work_table_rec_count(p_conn) -> int:
    """
    1.3) W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID件数取得
    """
    query = f'SELECT COUNT(*) AS ALL_CNT FROM {REDSHIFT_SCHEMA}.W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID'
    logging.info(query)
    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchone()
        result = recs[0]

    return result


def get_nikkei_member_no_list(p_conn) -> list:
    """
    1.4) シリアルIDがNULLである日経ID内部会員番号取得
    """
    query = f'SELECT NIKKEI_ID_INTERNAL_MEMBER_NO FROM {REDSHIFT_SCHEMA}.W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID WHERE SERIAL_ID IS NULL;'
    logging.info(query)
    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchall()

        nikkei_member_no_list = []
        for rec in recs:
            nikkei_member_no_list.append(rec[0])

    return nikkei_member_no_list


def create_temp_table(p_conn) -> None:
    """
    1.5) 一時テーブル作成
    """
    query = """CREATE LOCAL TEMPORARY TABLE USER_SERIAL_ID_EXT
               (
                    NIKKEI_ID_INTERNAL_MEMBER_NO BIGINT
                   ,SERIAL_ID                    VARCHAR(40)
               )"""

    with p_conn.cursor() as cursor:
        cursor.execute(query)


def get_request_params(p_nikkei_member_no_list: list) -> list:
    """
    日経ID WebAPIリクエストパラメータ作成
    get_nikkei_member_no_list関数で取得した日経内部会員番号を1,000件毎(APIに渡せる上限)に分割して配列に格納する
    """
    list_len = len(p_nikkei_member_no_list)
    result = []
    sp = 0
    ep = NLINK_API_USERID_LIMIT if list_len > NLINK_API_USERID_LIMIT else list_len
    for i in range(ceil(list_len/NLINK_API_USERID_LIMIT)):
        result.append(p_nikkei_member_no_list[sp:ep])
        sp = ep
        tmp_ep = ep + NLINK_API_USERID_LIMIT
        ep = tmp_ep if list_len > tmp_ep else list_len

    return result


def load_temp_table(p_conn, p_insert_list: list) -> None:
    """
    日経ID APIから取得した結果を一時テーブルに格納する
    """
    insert_list = []    
    for param in p_insert_list:
        t = (param[0],param[1])
        insert_list.append(t)

    with p_conn.cursor() as cursor:
        extras.execute_values(cursor, "INSERT INTO USER_SERIAL_ID_EXT values %s", insert_list)


def update_w_kk_v_trial_campaign_apply_serial_id(p_conn) -> None:
    """
    お試し施策適用VIEW（シリアルID版）ワーク更新
    """
    query = f"""
    UPDATE {REDSHIFT_SCHEMA}.W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID W
    SET
        SERIAL_ID = TMP.SERIAL_ID
    FROM
        USER_SERIAL_ID_EXT TMP
    WHERE
        W.NIKKEI_ID_INTERNAL_MEMBER_NO = TMP.NIKKEI_ID_INTERNAL_MEMBER_NO
    AND TMP.SERIAL_ID IS NOT NULL
    AND W.SERIAL_ID IS NULL
    """
    logging.info(f'*** update_w_kk_v_trial_campaign_apply_serial_id query: {query}')
    with p_conn.cursor() as cursor:
        cursor.execute(query)


def delete_t_kk_v_trial_campaign_apply_serial_id(p_conn) -> None:
    """
    1.8) お試し施策適用VIEW（シリアルID版）削除
    """
    query = f"""DELETE FROM {REDSHIFT_SCHEMA}.T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID;"""
    logging.info(query)

    with p_conn.cursor() as cursor:
        cursor.execute(query)


def insert_t_kk_v_trial_campaign_apply_serial_id(p_conn) -> None:
    """
    1.9) お試し施策適用VIEW（シリアルID版）挿入
    """
    query = f"""
    INSERT INTO {REDSHIFT_SCHEMA}.T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID
    (
         TRIAL_CAMPAIGN_MANAGEMENT_NO
        ,TRIAL_CAMPAIGN_NAME_INTERNAL
        ,TRIAL_CAMPAIGN_NAME_EXTERNAL
        ,NIKKEI_ID_INTERNAL_MEMBER_NO
        ,SERIAL_ID
        ,CONTRACT_NO
        ,TRIAL_ACTIVATE_DETAIL_NO
        ,RP_ID
        ,SERVICE_ID
        ,PLAN_ID
        ,TRIAL_NO
        ,ACTIVATE_DATETIME
        ,TRIAL_END_ESTIMATE_DATETIME
        ,TRIAL_END_CHARGE_DATETIME
        ,TRIAL_END_PLAN_ID
        ,TRIAL_END_REASON
        ,REMAINING_DAYS
        ,TRIAL_END_DATETIME
        ,CURRENT_PLAN_ID
        ,INS_BATCH_ID
        ,INS_DT_TM
        ,UPD_BATCH_ID
        ,UPD_DT_TM
    )
    SELECT
         TRIAL_CAMPAIGN_MANAGEMENT_NO
        ,TRIAL_CAMPAIGN_NAME_INTERNAL
        ,TRIAL_CAMPAIGN_NAME_EXTERNAL
        ,NIKKEI_ID_INTERNAL_MEMBER_NO
        ,SERIAL_ID
        ,CONTRACT_NO
        ,TRIAL_ACTIVATE_DETAIL_NO
        ,RP_ID
        ,SERVICE_ID
        ,PLAN_ID
        ,TRIAL_NO
        ,ACTIVATE_DATETIME
        ,TRIAL_END_ESTIMATE_DATETIME
        ,TRIAL_END_CHARGE_DATETIME
        ,TRIAL_END_PLAN_ID
        ,TRIAL_END_REASON
        ,REMAINING_DAYS
        ,TRIAL_END_DATETIME
        ,CURRENT_PLAN_ID
        ,'{{ dag.dag_id }}'
        ,CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())
        ,'{{ dag.dag_id }}'
        ,CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())
    FROM
        {REDSHIFT_SCHEMA}.W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID
    """
    logging.info(query)

    with p_conn.cursor() as cursor:
        cursor.execute(query)


def main_trial_campaign(**context) -> None:
    """
    主処理
    """
    conn = None

    try:

        conn = PostgresHook(postgres_conn_id='redshift_default').get_conn()

        # お試し施策適用VIEW（シリアルID版）ワークが0件であれば終了
        work_table_rec_count = get_work_table_rec_count(conn)
        if work_table_rec_count == 0:
            logging.info('*** お試し施策適用VIEW（シリアルID版）ワークが0件であれば終了')
            return

        # シリアルIDが取得出来なかった日経内部会員番号が0件であれば終了
        nikkei_member_no_list = get_nikkei_member_no_list(conn)
        if not nikkei_member_no_list:
            logging.info('*** シリアルIDが取得出来なかった日経内部会員番号が0件であれば終了')
            return

        create_temp_table(conn)

        request_params = get_request_params(nikkei_member_no_list)

        insert_list = get_serialid(request_params)

        load_temp_table(conn, insert_list)

        update_w_kk_v_trial_campaign_apply_serial_id(conn)

        delete_t_kk_v_trial_campaign_apply_serial_id(conn)

        insert_t_kk_v_trial_campaign_apply_serial_id(conn)

        conn.commit()

    except Exception as e:
        logging.error(f'*** replace_t_kk_v_trial_campaign_apply_serial_id Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e

    finally:
        if conn is not None:
            conn.close()

def get_serialid(p_request_params: list) -> list:
    """
    日経ID APIを用いて日経内部会員番号をシリアルIDに変換する
    Parameters
    ----------
    p_request_params: list
      APIに渡すパラメータ（日経内部会員番号）のリスト
    Returns
    -------
    insert_list: list
      シリアルIDのリスト
    """
    url = f'{NILINK_URL}/api/1.0/user/serialid'
    authorization = base64.b64encode(f'{NILINK_CLIENT_ID}:{NILINK_CLIENT_SECRET}'.encode()).decode()
    headers = {
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': f'Basic {authorization}'
    }

    try:
        insert_list = []
        for param in p_request_params:
            data = f'{{"scope":"family.user.serialid","user_no":[{",".join(map(str, param))}]}}'
            response_json = requests.post(url, headers=headers, data=data)
            response_list = response_json.json()
            for response in response_list:
                record = (response['user_no'], response['user_serial_id'])
                insert_list.append(record)

    except Exception as e:
        logging.error('*** get_serialid HTTPステータスコードが200ではない為、異常終了します。')
        raise e
    return insert_list
