from airflow.models import Variable
from datetime import timezone
import json
import requests

webhook_url = Variable.get('slack_webhook_url', None)


def notify_failure(status):
    if not webhook_url:
        return
    
    dag = status['dag']
    run = status['dag_run']
    taskinst = status['task_instance']
    exception = status['exception']
    payload = {
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"Airflow DAG failed"
                }
            },
            {
                "type": "section",
                "fields": [
                    {
                        "type": "mrkdwn",
                        "text": f"*DAG ID:*\n{dag.dag_id}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*DAG file path:*\n{dag.filepath}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Run ID:*\n{run.run_id}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Execution date:*\n{run.execution_date}"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Task ID:*\n{taskinst.task_id} (<{taskinst.log_url}|Link>)"
                    },
                    {
                        "type": "mrkdwn",
                        "text": f"*Exception:*\n{exception}"
                    }
                ]
            }
        ]
    }
    requests.post(webhook_url, json.dumps(payload))
