import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from common_ims.bqexec import bigquery_executor
from common_ims.bqsync import redshift_to_bigquery
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_is', # DAG名
    default_args=default_args,
    description='購読センターシステム(IS)のBigQuery連携',
    schedule_interval='0 7 * * *', # 毎日7時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# 購読センターシステム(IS)のデータ構築

check_impr_is_to_ims_1 = ExternalTaskSensor(
    task_id='check_impr_is_to_ims_1',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=20), # 6時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3600,      #60分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    移行テーブル
    """
    redshift_to_bigquery_m_is_nx_migration = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_migration',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_migration.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_MIGRATION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    RP利用状態テーブル
    """
    redshift_to_bigquery_m_is_nx_rp_registration = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_rp_registration',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_rp_registration.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_RP_REGISTRATION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    居住国マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_country = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_country',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_country.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_COUNTRY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    職業マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_occupation = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_occupation',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_occupation.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_OCCUPATION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    業種マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_business = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_business',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_business.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_BUSINESS',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    職種マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_job = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_job',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_job.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_JOB',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    役職マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_position = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_position',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_position.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_POSITION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    オープン化ユーザID管理テーブル
    """
    redshift_to_bigquery_m_is_ox_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_ox_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_ox_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_OX_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    興味関心項目マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_interest = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_interest',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_interest.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_INTEREST',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    法人属性テーブル
    """
    redshift_to_bigquery_m_is_nx_user_company = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_user_company',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_user_company.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_USER_COMPANY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ストアトークンテーブル
    """
    redshift_to_bigquery_m_is_nx_user_store_token = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_user_store_token',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_user_store_token.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_USER_STORE_TOKEN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    住所マスタテーブル
    """
    redshift_to_bigquery_m_is_mm_address = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_address',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_address.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_ADDRESS',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    共通属性テーブル(IF)
    """
    redshift_to_bigquery_m_is_nx_attribute_if = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_attribute_if',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_attribute_if.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_ATTRIBUTE_IF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ユーザ付属情報管理テーブルデータロード
    """
    redshift_to_bigquery_m_is_nx_user_attachment = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_nx_user_attachment',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_nx_user_attachment.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_USER_ATTACHMENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    コードマスタテーブルデータロード
    """
    redshift_to_bigquery_m_is_mm_code = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_code',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_code.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_CODE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    新聞購読状況マスタテーブルデータロード
    """
    redshift_to_bigquery_m_is_mm_subscription = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_is_mm_subscription',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_is_mm_subscription.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_MM_SUBSCRIPTION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    バックエンド認証テーブル
    """
    redshift_to_bigquery_t_is_t_backend_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_is_t_backend_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_is_t_backend_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_IS_T_BACKEND_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_m_ims_open_user_id = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_ims_open_user_id',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IMS_OPEN_USER_ID',
        execute_query='sql/bigquery/execute/UPD__M_IMS_OPEN_USER_ID.sql'
    )

    bq_update_m_is_nx_attribute_if_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_is_nx_attribute_if_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_ATTRIBUTE_IF_ACCUM',
        execute_query='sql/bigquery/execute/UPD__M_IS_NX_ATTRIBUTE_IF_ACCUM.sql'
    )

    bq_update_m_is_nx_user_attachment_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_is_nx_user_attachment_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_USER_ATTACHMENT_ACCUM',
        execute_query='sql/bigquery/execute/UPD__M_IS_NX_USER_ATTACHMENT_ACCUM.sql'
    )

    bq_update_t_ims_user_num_daily_rp_status_ss = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_ims_user_num_daily_rp_status_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_IMS_USER_NUM_DAILY_RP_STATUS_SS',
        execute_query='sql/bigquery/execute/UPD__T_IMS_USER_NUM_DAILY_RP_STATUS_SS.sql'
    )

    bq_update_m_is_nx_rp_registration_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_is_nx_rp_registration_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_IS_NX_RP_REGISTRATION_ACCUM',
        execute_query='sql/bigquery/execute/UPD__M_IS_NX_RP_REGISTRATION_ACCUM.sql'
    )

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_attribute_if >> bq_update_m_is_nx_attribute_if_accum >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_migration >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_rp_registration >> bq_update_m_is_nx_rp_registration_accum >> bq_update_t_ims_user_num_daily_rp_status_ss >> done_all_task_for_check 
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_user_attachment >> bq_update_m_is_nx_user_attachment_accum >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_code >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_country >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_occupation >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_business >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_job >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_position >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_ox_user >> bq_update_m_ims_open_user_id >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_subscription >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_interest >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_user_company >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_nx_user_store_token >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_m_is_mm_address >> done_all_task_for_check
check_impr_is_to_ims_1 >> redshift_to_bigquery_t_is_t_backend_user >> done_all_task_for_check
