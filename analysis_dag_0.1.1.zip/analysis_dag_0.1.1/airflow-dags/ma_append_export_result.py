import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from boto3 import Session
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_append_export_result', # DAG名
    default_args=default_args,
    description='MA抽出結果取込処理',
    schedule_interval='*/10 8-15 * * *', # 毎日 8:00～15:50(JST) 10分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

REDSHIFT_CONN_ID = 'redshift_default'                       # RedshiftのコネクションID
DB_SCHEMA = Variable.get('redshift_ims_schema_name')        # DBスキーマ名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')   # S3のバケット名
S3_ROLE_ARN = Variable.get('redshift_default_role_arn')     # S3のrole
S3_PREFIX = f"""app/ma/mail/"""                             # ファイルパス

#######################################################################################################
# データ構築処理
#######################################################################################################

def load_from_s3(**context):
    """
    抽出結果ファイルのロード処理

    Parameters
    ----------
    context : dict
        コンテキスト変数
    """
    next_execution_date = context['next_execution_date']
    file_prefix_date = convUTC2JST(next_execution_date, "%Y%m%d")

    load_path_prefix = f"""{S3_PREFIX}T_MA_EXPORT_INFO_{file_prefix_date}/"""
    logging.info(f'*** ロード対象ファイルパス: {load_path_prefix}')

    s3client = Session().client('s3')
    response = s3client.list_objects(Bucket=S3_BUCKET_NAME, Prefix=load_path_prefix)
    keys = None
    if 'Contents' in response:
        keys = [content['Key'] for content in response['Contents']]
    
    logging.info(f'*** ロード対象ファイル: {str(keys)}')
    
    if keys is None:
        logging.info(f'*** 取込対象ファイルが存在しないため、処理を終了します。')
        return

    conn = None
    cursor = None
    try:
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        cursor = conn.cursor()
        load_error_cnt = 0
        file_cnt = 0
        
        # 一時テーブルに取得したファイル分繰り返し処理
        for s3_path in keys:
            # 一時テーブルの連番用
            file_cnt = file_cnt + 1
            
            # ファイル単位でコミット
            try:
                # 一時テーブルを作成
                query_create_table = f"""CREATE TEMPORARY TABLE TEMP_T_MA_EXPORT_INFO_{str(file_cnt)} AS SELECT * FROM {DB_SCHEMA}.T_MA_EXPORT_INFO limit 0"""
                logging.info(f'*** load_from_s3 query_create_table: {query_create_table}')
                cursor.execute(query_create_table)

                query_copy = f"""COPY TEMP_T_MA_EXPORT_INFO_{str(file_cnt)}
                    FROM 's3://{S3_BUCKET_NAME}/{s3_path}' 
                    IAM_ROLE '{S3_ROLE_ARN}'
                    FORMAT as csv 
                    DELIMITER '\t'
                    GZIP
                    QUOTE '\"'"""
                logging.info(f'*** load_from_s3 query_copy: {query_copy}')
                cursor.execute(query_copy)
                
                # すでにロード済みのデータを削除する（2重ロード考慮）
                query_delete_samedata = f"""DELETE FROM {DB_SCHEMA}.T_MA_EXPORT_INFO WHERE (EXPORT_ID, CAMPAIGN_ID, EXPORT_DATE) IN (SELECT EXPORT_ID, CAMPAIGN_ID, EXPORT_DATE FROM TEMP_T_MA_EXPORT_INFO_{str(file_cnt)})"""
                logging.info(f'*** load_from_s3 query_delete_samedata: {query_delete_samedata}')
                cursor.execute(query_delete_samedata)
                
                # 一時テーブルのデータを本テーブルに追加
                query_insert = f"""INSERT INTO {DB_SCHEMA}.T_MA_EXPORT_INFO SELECT * FROM TEMP_T_MA_EXPORT_INFO_{str(file_cnt)}"""
                logging.info(f'*** load_from_s3 query_insert: {query_insert}')
                cursor.execute(query_insert)
                
                # コミット
                conn.commit()
            except Exception as e_copy:
                logging.error(f'*** {s3_path} ロード処理に失敗しました。: {str(e_copy)}')
                conn.rollback()
                # ロードの例外はつぶしてエラー件数のみを知らせる、S3のファイルを削除しない
                load_error_cnt += 1
                # エラーとなったS3ファイルは削除せず、次のファイルロード処理を実施
                continue
                
            # s3ファイル削除
            s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=s3_path)
            logging.info(f'*** s3ファイル削除しました。 {s3_path}')
        
        # ロード処理でエラーがあった場合、タスクをエラーとする
        if load_error_cnt > 0:
            raise Exception(f'***  {load_error_cnt} ファイルのロード処理に失敗しました。')
    except Exception as e:
        logging.error(f'*** 異常終了しました。: {str(e)}')
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

s3_to_redshift_t_ma_export_info = PythonOperator (
    task_id='s3_to_redshift_t_ma_export_info',
    provide_context=True,
    python_callable=load_from_s3,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_ma_export_info
