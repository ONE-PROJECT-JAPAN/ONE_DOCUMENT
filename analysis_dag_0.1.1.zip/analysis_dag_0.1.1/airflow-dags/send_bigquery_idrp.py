import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_idrp', # DAG名
    default_args=default_args,
    description='IDRPシステム(IDRP)のBigQuery連携',
    schedule_interval='0 7 * * *', # 毎日07時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)
####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# IDRPシステム(IDRP)のデータ構築

check_impr_idrp_to_ims = ExternalTaskSensor(
    task_id='check_impr_idrp_to_ims',
    external_dag_id='impr_idrp_to_ims',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=80), # 05時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=20), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    日経ビジネススクール会員属性ワーク
    """
    redshift_to_bigquery_w_ba_user_attr = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_ba_user_attr',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_ba_user_attr.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_BA_USER_ATTR',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    日経BIZGATE会員属性ワーク
    """
    redshift_to_bigquery_w_nbg_user_attr = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_nbg_user_attr',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_nbg_user_attr.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_NBG_USER_ATTR',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    NIKKEI STYLE会員属性ワーク
    """
    redshift_to_bigquery_w_li_user_attr = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_li_user_attr',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_li_user_attr.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_LI_USER_ATTR',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )
    
    """
    日経ウーマノミクス会員属性データ蓄積
    """
    redshift_to_bigquery_t_wfd_user_attr = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_wfd_user_attr',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_wfd_user_attr.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_WFD_USER_ATTR',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_ba_user_attr = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_ba_user_attr',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BA_USER_ATTR',
        execute_query='sql/bigquery/execute/UPD__T_BA_USER_ATTR.sql'
    )

    bq_update_t_li_user_attr = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_li_user_attr',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_LI_USER_ATTR',
        execute_query='sql/bigquery/execute/UPD__T_LI_USER_ATTR.sql'
    )

    bq_update_t_nbg_user_attr = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_nbg_user_attr',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_NBG_USER_ATTR',
        execute_query='sql/bigquery/execute/UPD__T_NBG_USER_ATTR.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_idrp_to_ims ] >> redshift_to_bigquery_w_ba_user_attr >> bq_update_t_ba_user_attr >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_idrp_to_ims ] >> redshift_to_bigquery_t_wfd_user_attr >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_idrp_to_ims ] >> redshift_to_bigquery_w_nbg_user_attr >> bq_update_t_nbg_user_attr >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_idrp_to_ims ] >> redshift_to_bigquery_w_li_user_attr >> bq_update_t_li_user_attr >> done_all_task_for_check
