import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.operators.check_operator import CheckOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from common_ims import batch
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,9,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_cm_prod_delivery', # DAG名
    default_args=default_args,
    description='ClickM@iler本番配信連携処理',
    schedule_interval='0 9,11,13,16 * * * ', # 毎日 9:00, 11:00, 13:00, 16:00(JST)
    catchup=False,
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# 環境変数:DBスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# 配信対象件数取得SQL
SQL_GET_CNT = f"""
    SELECT
        count(*)
    FROM
        {DB_SCHEMA}.W_TEMP_CM_PROD_DELIVERY
    """

# 配信対象施策件数取得SQL
SQL_GET_CNT_PLAN_LIST = f"""
    SELECT
        count(*)
    FROM
        {DB_SCHEMA}.W_TEMP_PLAN_LIST_DELIVERY
    """

# 配信対象施策件数取得SQL
SQL_GET_PLAN_LIST = f"""
    SELECT
        PLAN_ID
    FROM {DB_SCHEMA}.W_TEMP_PLAN_LIST_DELIVERY
    """

# 基本情報件数取得SQL
SQL_GET_CNT_BASIC_SET_MNG = f"""
    SELECT
        count(*)
    FROM
        {DB_SCHEMA}.W_TEMP_BASIC_SET_MNG
    """

# 本番配信対象件数取得SQL(件数が並べるため1件のみ取得)
SQL_GET_CNT_DELIVERY_LIST = f"""
    SELECT
        PLAN_ID
        , count(*)
    FROM
        {DB_SCHEMA}.W_TEMP_DELIVERY_LIST
    WHERE
        FLAG_PROD_TEST = 'PROD'
    GROUP BY
        PLAN_ID 
    ORDER BY
        2 
    limit 1
    """

# テスト配信データ追加SQL
SQL_INSERT_TEST_DELIVERY_LIST = f"""
    INSERT INTO
        {DB_SCHEMA}.W_TEMP_DELIVERY_LIST
    (
        FLAG_PROD_TEST
        , SERVICE_NO
        , PLAN_ID
        , EMAIL
        , NAME
        , URL1
        , DELETE_FLG
    ) 
    SELECT 
        DISTINCT
        'TEST' as FLAG_PROD_TEST
        , '7' as SERVICE_NO
        , TEST.PLAN_ID as PLAN_ID
        , TEST.EMAIL as EMAIL
        , CRM.VALUE1 as NAME
        , CRM.VALUE4 as URL1
        , '0' as DELETE_FLG 
    FROM 
        {DB_SCHEMA}.T_IMS_PLAN_TEST_DELIVERY_EMAIL AS TEST
        CROSS JOIN {DB_SCHEMA}.M_CRM_CODE CRM
    WHERE 
        TEST.PLAN_ID = %s
        AND TEST.PLAN_CLASS_CD IN ('1', '3')
        AND CRM.MASTER_TYPE = 'MST520'
        AND CRM.MASTER_GRP_TYPE = 'GCRM520'
        AND CRM.YUKO_FLG = '1'
        AND TEST.EMAIL NOT IN (
            SELECT PROD.EMAIL
            FROM
                {DB_SCHEMA}.W_TEMP_CM_PROD_DELIVERY AS PROD
            WHERE
                PROD.PLAN_ID = %s AND TEST.EMAIL = PROD.EMAIL)
    """

#######################################################################################################
# 前提チェック
#######################################################################################################

# TGML見積り件数洗替（定期実行）

check_tgml_job = CheckOperator(
    task_id='check_tgml_job',
    conn_id=REDSHIFT_CONN_ID,
    sql=f"""
        SELECT
            count(1) = 0 as result
        FROM
            {DB_SCHEMA}.W_IMS_TGML_DAILY_FOR_CHECK_{{{{ convUTC2JST(next_execution_date, "%Y%m%d") }}}}""",
    retries=6,
    retry_delay=timedelta(minutes=10),
    dag=dag
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 本番配信ワークデータ取得

replace_w_temp_cm_prod_delivery = PostgresOperator(
    task_id='replace_w_temp_cm_prod_delivery',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ma/replace_w_temp_cm_prod_delivery.sql',
    autocommit=False,
    dag=dag
)

# 配信データの有無確認

def get_delivery_count(**context):
    hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
    
    # 配信対象件数有無確認
    for record in hook.get_records(SQL_GET_CNT):
        logging.info(f'*** get_delivery_count : {str(record[0])}')
        if record[0] >= 1:
            return True
    return False
    
check_exist_delivery_data = ShortCircuitOperator(
    task_id='check_exist_delivery_data',
    python_callable=get_delivery_count,
    provide_context=True,
    dag=dag
)

# 配信対象データ取得

replace_w_temp_plan_list_delivery = PostgresOperator(
    task_id='replace_w_temp_plan_list_delivery',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ma/replace_w_temp_plan_list_delivery.sql',
    autocommit=False,
    dag=dag
)

# テスト配信対象データ取得

def append_test_delivery_list(**context):
    conn = None
    cursor = None
    try:
        hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
        conn = hook.get_conn()
        cursor = conn.cursor()
        for record_plan in hook.get_records(SQL_GET_PLAN_LIST):
            logging.info(f'*** append_test_delivery_list record_plan : {str(record_plan)}')
            plan_id = record_plan[0]
            
            # SQL実行：テスト配信分のINSERT
            cursor.execute(SQL_INSERT_TEST_DELIVERY_LIST, (plan_id, plan_id))
        conn.commit()
    except Exception as e:
        logging.error(f'*** append_test_delivery_list Exception e : {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

append_w_temp_delivery_list_for_test = PythonOperator(
    task_id='append_w_temp_delivery_list_for_test',
    python_callable=append_test_delivery_list,
    provide_context=True,
    dag=dag
)

# 配信対象データの整合性チェック

def check_delivery_basic_data(**context):
    hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
    cnt_plan_list = 0
    cnt_basic_set = 0
    cnt_honban_delivery = 0
    
    # 管理情報（配信対象施策件数）有無確認
    for record_plan in hook.get_records(SQL_GET_CNT_PLAN_LIST):
        logging.info(f'*** check_delivery_basic_data cnt_plan_list : {str(record_plan[0])}')
        cnt_plan_list = record_plan[0]

    # 基本情報件数有無確認
    for record_basic in hook.get_records(SQL_GET_CNT_BASIC_SET_MNG):
        logging.info(f'*** check_delivery_basic_data cnt_basic_set : {str(record_basic[0])}')
        cnt_basic_set = record_basic[0]

    # 本番配信対象件数有無確認(施策中１つでも0件があるとNG)
    for record_delivery in hook.get_records(SQL_GET_CNT_DELIVERY_LIST):
        logging.info(f'*** check_delivery_basic_data cnt_honban_delivery : {str(record_delivery)}')
        cnt_honban_delivery = record_delivery[1]

    # 基本情報0件 管理情報0件 本番配信対象件数0件
    if cnt_basic_set == 0 and cnt_plan_list == 0 and cnt_honban_delivery == 0:
        # 連携データなし
        logging.info('*** check_delivery_basic_data : 連携データなし')
        # 後続処理スキップさせる
        return False

    # 連携データあり（チェックOK）
    if cnt_basic_set > 0 and cnt_plan_list > 0 and cnt_honban_delivery > 0:
        logging.info('*** check_delivery_basic_data : 連携データあり')
        return True

    # 上記以外は異常終了のため、例外を返却
    logging.error('*** check_delivery_basic_data : データの整合性NG')
    raise Exception

check_delivery_basic_data_task = ShortCircuitOperator(
     task_id='check_delivery_basic_data_task',
     python_callable=check_delivery_basic_data,
     provide_context=True,
     dag=dag
)

# バッチ_本番配信連携処理

call_batch_delivery = batch.create_operator(
    dag=dag,
    task_id="call_batch_delivery",
    job_name="delivery-clickmailer",
    queue=batch.QUEUE_DEFAULT,
    command=[
        "deliver.py" # スクリプト名
    ],
    environment={
        "REDSHIFT_SCHEMA": DB_SCHEMA
    }
)

# ワークテーブルの削除処理（バッチ処理正常終了時のみ実施、異常終了時には原因調査のためワークテーブルを削除しない）

delete_w_temp_plan_list_delivery = PostgresOperator(
    task_id='delete_w_temp_plan_list_delivery',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ma/delete_w_temp_plan_list_delivery.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_tgml_job >> replace_w_temp_cm_prod_delivery >> check_exist_delivery_data >> replace_w_temp_plan_list_delivery >> append_w_temp_delivery_list_for_test >> check_delivery_basic_data_task >> call_batch_delivery >> delete_w_temp_plan_list_delivery
