import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,5,14,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='exec_bigquery_t_crm_cmk_num_monthly_ss', # DAG名
    default_args=default_args,
    description='チャンネルマーケッツ登録数月別スナップショット',
    schedule_interval='0 14 5 * *', # 月次5日 14:00(JST)
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_CRM_CMK_NUM_MONTHLY_SS'


#
# BigQueryテーブル操作
#
with dag:
    append_t_crm_cmk_num_monthly_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_crm_cmk_num_monthly_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table=BIGQUERY_TABLE_NAME,
        execute_query='sql/bigquery/execute/UPD__T_CRM_CMK_NUM_MONTHLY_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

append_t_crm_cmk_num_monthly_ss >> done_all_task_for_check
