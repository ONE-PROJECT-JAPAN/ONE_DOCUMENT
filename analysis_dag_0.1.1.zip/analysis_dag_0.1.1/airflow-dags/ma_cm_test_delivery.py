import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.models import Variable
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from common_ims.notification import notify_failure
from common_ims import batch
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,9,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_cm_test_delivery', # DAG名
    default_args=default_args,
    description='ClickM@ilerテスト配信連携処理',
    schedule_interval='*/2 9-22 * * *', # 毎日 9:00～22:58(JST) 2分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

# テスト配信対象件数取得SQL
SQL_GET_CNT = f"""
    SELECT
        count(*)
    FROM
        {REDSHIFT_SCHEMA}.W_TEMP_CM_TEST_DELIVERY
    """

#######################################################################################################
# データ構築処理
#######################################################################################################

# テスト配信ワークデータ取得

replace_w_temp_cm_test_delivery = PostgresOperator(
    task_id='replace_w_temp_cm_test_delivery',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ma/replace_w_temp_cm_test_delivery.sql',
    autocommit=False,
    dag=dag
)

# テスト配信データの有無確認

def get_test_delivery_count(**context):
    hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
    
    # 配信対象件数有無確認
    for record in hook.get_records(SQL_GET_CNT):
        logging.info(f'*** get_test_delivery_count : {str(record[0])}')
        if record[0] >= 1:
            return True
    return False
    
check_exist_test_delivery_data = ShortCircuitOperator(
    task_id='check_exist_test_delivery_data',
    python_callable=get_test_delivery_count,
    provide_context=True,
    dag=dag
)

# バッチ_テスト配信連携処理

call_batch_test_delivery = batch.create_operator(
    dag=dag,
    task_id="call_batch_test_delivery",
    job_name="delivery-clickmailer",
    queue=batch.QUEUE_DEFAULT,
    command=[
        "deliver_test.py" # スクリプト名
    ],
    environment={
        "REDSHIFT_SCHEMA": REDSHIFT_SCHEMA
    }
)

# ワークテーブルの削除処理（バッチ処理正常終了時のみ実施、異常終了時には原因調査のためワークテーブルを削除しない）

delete_w_temp_cm_test_delivery = PostgresOperator(
    task_id='delete_w_temp_cm_test_delivery',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ma/delete_w_temp_cm_test_delivery.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

replace_w_temp_cm_test_delivery >> check_exist_test_delivery_data >> call_batch_test_delivery >> delete_w_temp_cm_test_delivery
