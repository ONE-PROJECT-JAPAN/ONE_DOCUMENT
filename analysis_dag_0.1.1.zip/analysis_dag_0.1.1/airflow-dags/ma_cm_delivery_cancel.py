import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims import batch
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,9,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_cm_delivery_cancel', # DAG名
    default_args=default_args,
    description='ClickM@iler本番配信取消処理',
    schedule_interval='*/10 9-22 * * *', # 毎日 9:00～22:50(JST) 10分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数:DBスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# 取消対象件数取得SQL
SQL_GET_CNT_W_TEMP_CM_PROD_CANCEL = f"""
    SELECT
        count(*)
    FROM
        {DB_SCHEMA}.W_TEMP_PLAN_MNG_CANCEL
    """

#######################################################################################################
# データ構築処理
#######################################################################################################

# 本番配信取消データ取得

replace_w_temp_plan_mng_cancel = PostgresOperator(
    task_id='replace_w_temp_plan_mng_cancel',
    postgres_conn_id='redshift_default',
    sql='sql/ma/replace_w_temp_plan_mng_cancel.sql',
    autocommit=False,
    dag=dag
)

# 配信取消データの有無確認

def get_cancel_count(**context):
    hook = PostgresHook(postgres_conn_id='redshift_default')
    # 配信対象件数有無確認
    for record in hook.get_records(SQL_GET_CNT_W_TEMP_CM_PROD_CANCEL):
        logging.info(f'*** get_cancel_count :{str(record[0])}')
        if record[0] >= 1:
            return True
    logging.warn('*** get_cancel_count : 本番配信取消対象の施策が存在しないため、ClickM@iler本番配信取消処理をスキップします。')
    return False

check_exist_cancel_data = ShortCircuitOperator(
    task_id='check_exist_cancel_data',
    python_callable=get_cancel_count,
    provide_context=True,
    dag=dag
)

# バッチ_本番配信取消処理

call_batch_cancel_delivery = batch.create_operator(
    dag=dag,
    task_id="call_batch_cancel_delivery",
    job_name="delivery-clickmailer",
    queue=batch.QUEUE_DEFAULT,
    command=[
        "cancel_delivery.py" # スクリプト名
    ],
    environment={
        "REDSHIFT_SCHEMA": DB_SCHEMA
    }
)

# ワークテーブルの削除処理（バッチ処理正常終了時のみ実施、異常終了時には原因調査のためワークテーブルを削除しない）

delete_w_temp_plan_mng_cancel = PostgresOperator(
    task_id='delete_w_temp_plan_mng_cancel',
    postgres_conn_id='redshift_default',
    sql='sql/ma/delete_w_temp_plan_mng_cancel.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

replace_w_temp_plan_mng_cancel >> check_exist_cancel_data >> call_batch_cancel_delivery >> delete_w_temp_plan_mng_cancel
