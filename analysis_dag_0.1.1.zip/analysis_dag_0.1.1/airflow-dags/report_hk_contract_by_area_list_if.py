import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
import unicodedata
import boto3
import logging
import pendulum

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST

####################################################################################################
# DAG
####################################################################################################
local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2020,1,1,9,50,0,tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='report_hk_contract_by_area_list_if', # DAG名
    default_args=default_args,
    description='エリア別契約数リストIF',
    schedule_interval='50 9 1 * *', # 毎月1日9時50分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# Python関数
####################################################################################################

REDSHIFT_CONN_ID = 'redshift_default'
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

S3_BUCKET_NAME = Variable.get('transfer_s3_bucket_name')
S3_PREFIX = 'hanbai/Hanbai/StoreAddress/IF'

HEADER = '"YEAR_MONTH","STORE_CD","JGDC","W_CNT_STORE_ADDRESS","D_CNT_STORE_ADDRESS","TUKI_CNT_ADDRESS","MOSAIC_TYPE","MOSAIC_TYPE_NM","NK_CNT","NK_DSR2_CNT","NK_W_CNT","NK_PERSONAL_TUKI_CNT","NK_CORP_TUKI_CNT","NK_OVERSEA_CNT","HK_NK_CNT","HK_NK_DSR2_CNT","HK_HK_CNT","HK_TRIAL_NK_CNT","HK_TRIAL_NK_DSR2_CNT","HK_TRIAL_HK_CNT","HK_SUBSCRIPTION_NK_CNT","HK_SUBSCRIPTION_NK_DSR2_CNT","HK_SUBSCRIPTION_HK_CNT"'

def strnvl(p_val: str) -> str:
    return p_val if p_val != None else ''

def numnvl(p_val: int) -> str:
    return p_val if p_val != None else 0


def get_contract_by_area_if(
    p_conn,
    p_schema: str,
    p_exec_yearmonth: str
) -> list:
    """
    エリア別契約数リスト_IF用データ取得

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名
    p_exec_yearmonth: str
        年月

    Returns
    -------
    list: エリア別契約数リスト_IF用データ
    """
    query = f"""SELECT
                    TO_CHAR(SNAPSHOT_DATE,'yyyymm') AS YEAR_MONTH,
                    STORE_CD,
                    JGDC,
                    W_CNT_STORE_ADDRESS,
                    D_CNT_STORE_ADDRESS,
                    TUKI_CNT_ADDRESS,
                    MOSAIC_TYPE,
                    MOSAIC_TYPE_NM,
                    NK_CNT,
                    NK_DSR2_CNT,
                    NK_W_CNT,
                    NK_PERSONAL_TUKI_CNT,
                    NK_CORP_TUKI_CNT,
                    NK_OVERSEA_CNT,
                    HK_NK_CNT,
                    HK_NK_DSR2_CNT,
                    HK_HK_CNT,
                    HK_TRIAL_NK_CNT,
                    HK_TRIAL_NK_DSR2_CNT,
                    HK_TRIAL_HK_CNT,
                    HK_SUBSCRIPTION_NK_CNT,
                    HK_SUBSCRIPTION_NK_DSR2_CNT,
                    HK_SUBSCRIPTION_HK_CNT
                FROM
                    {p_schema}.T_IMS_HANBAI_NUM_STORE_ADDRESS_SS
                WHERE
                    TO_CHAR(SNAPSHOT_DATE,'yyyymm') = '{p_exec_yearmonth}'"""
    logging.info(query)
    
    value = HEADER
    value += '\r\n'

    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchall()

        for rec in recs:
        
            year_month = rec[0]
            store_cd = rec[1]
            jgdc = rec[2]
            w_cnt_store_address = numnvl(rec[3])
            d_cnt_store_address = numnvl(rec[4])
            tuki_cnt_address = numnvl(rec[5])
            mosaic_type = strnvl(rec[6])
            mosaic_type_nm = strnvl(rec[7])
            nk_cnt = numnvl(rec[8])
            nk_dsr2_cnt = numnvl(rec[9])
            nk_w_cnt = numnvl(rec[10])
            nk_personal_tuki_cnt = numnvl(rec[11])
            nk_corp_tuki_cnt = numnvl(rec[12])
            nk_oversea_cnt = numnvl(rec[13])
            hk_nk_cnt = numnvl(rec[14])
            hk_nk_dsr2_cnt = numnvl(rec[15])
            hk_hk_cnt = numnvl(rec[16])
            hk_trial_nk_cnt = numnvl(rec[17])
            hk_trial_nk_dsr2_cnt = numnvl(rec[18])
            hk_trial_hk_cnt = numnvl(rec[19])
            hk_subscription_nk_cnt = numnvl(rec[20])
            hk_subscription_nk_dsr2_cnt = numnvl(rec[21])
            hk_subscription_hk_cnt = numnvl(rec[22])

            line = ''
            line += f'"{year_month}"'                   # SNAPSHOT_DATE
            line += f',"{store_cd}"'                    # STORE_CD
            line += f',"{jgdc}"'                        # JGDC
            line += f',"{w_cnt_store_address}"'         # W_CNT_STORE_ADDRESS
            line += f',"{d_cnt_store_address}"'         # D_CNT_STORE_ADDRESS
            line += f',"{tuki_cnt_address}"'            # TUKI_CNT_ADDRESS
            line += f',"{mosaic_type}"'                 # MOSAIC_TYPE
            line += f',"{mosaic_type_nm}"'              # MOSAIC_TYPE_NM
            line += f',"{nk_cnt}"'                      # NK_CNT
            line += f',"{nk_dsr2_cnt}"'                 # NK_DSR2_CNT
            line += f',"{nk_w_cnt}"'                    # NK_W_CNT
            line += f',"{nk_personal_tuki_cnt}"'        # NK_PERSONAL_TUKI_CNT
            line += f',"{nk_corp_tuki_cnt}"'            # NK_CORP_TUKI_CNT
            line += f',"{nk_oversea_cnt}"'              # NK_OVERSEA_CNT
            line += f',"{hk_nk_cnt}"'                   # HK_NK_CNT
            line += f',"{hk_nk_dsr2_cnt}"'              # HK_NK_DSR2_CNT
            line += f',"{hk_hk_cnt}"'                   # HK_HK_CNT
            line += f',"{hk_trial_nk_cnt}"'             # HK_TRIAL_NK_CNT
            line += f',"{hk_trial_nk_dsr2_cnt}"'        # HK_TRIAL_NK_DSR2_CNT
            line += f',"{hk_trial_hk_cnt}"'             # HK_TRIAL_HK_CNT
            line += f',"{hk_subscription_nk_cnt}"'      # HK_SUBSCRIPTION_NK_CNT
            line += f',"{hk_subscription_nk_dsr2_cnt}"' # HK_SUBSCRIPTION_NK_DSR2_CNT
            line += f',"{hk_subscription_hk_cnt}"'      # HK_SUBSCRIPTION_HK_CNT
            line += '\r\n'
            
            value += line

    return value

def get_filename(p_exec_yearmonth: str) -> str:
    """
    ファイル名取得

    Parameters
    ----------
    p_area : str
        エリア
    p_exec_yearmonth : str
        年月

    Returns
    -------
    なし
    """
    return f'{S3_PREFIX}/HanbaiList_{p_exec_yearmonth}.csv'

def save_report_to_s3(p_data: str, p_exec_yearmonth: str) -> None:
    """
    エリア別契約数リスト_IF S3出力

    Parameters
    ----------
    p_contents : str
        I/Fデータ
    p_exec_yearmonth : str
        年月

    Returns
    -------
    なし
    """
    object_key = get_filename(p_exec_yearmonth=p_exec_yearmonth)

    s3resource = boto3.resource('s3')
    obj = s3resource.Object(S3_BUCKET_NAME, object_key)
    obj.put(Body=f'{p_data}'.encode('cp932'))

def main(**context) -> None:
    """
    エリア別契約数リスト_IF 主処理

    Parameters
    ----------
    context: dict
        コンテキスト

    Returns
    -------
    なし
    """
    try: 
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        exec_ym = convUTC2JST(context['next_execution_date'], "%Y%m")

        data = get_contract_by_area_if(
            p_conn=conn,
            p_schema=REDSHIFT_SCHEMA,
            p_exec_yearmonth=exec_ym
        )
        save_report_to_s3(
            p_data=data,
            p_exec_yearmonth=exec_ym
        )
    except Exception as e:
        logging.error(f'*** main Exception: {str(e)}')
        conn.rollback()
        raise e

    finally:
        if conn:
            conn.close()

####################################################################################################
# I/Fファイル作成タスク
####################################################################################################

# エリア別契約数リスト（販売店・住所コード別）スナップショット

check_append_t_ims_hanbai_num_store_address_ss = ExternalTaskSensor(
    task_id='check_append_t_ims_hanbai_num_store_address_ss',
    external_dag_id='trns_append_t_ims_hanbai_num_store_address_ss',
    external_task_id='append_t_ims_hanbai_num_store_address_ss',
    execution_delta=timedelta(minutes=40), # 毎日09時10分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

output_contract_by_area_list_if = PythonOperator(
    task_id='output_contract_by_area_list_if',
    python_callable=main,
    provide_context=True,
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

####################################################################################################
# 依存関係
####################################################################################################
check_append_t_ims_hanbai_num_store_address_ss >> output_contract_by_area_list_if >> done_all_task_for_check
