import sys
import os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from airflow import DAG
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_IMS_DSM_DAILY_ETSURANZUMI_HONSU'
local_tz = pendulum.timezone("Asia/Tokyo")

default_args = {
    'start_date': datetime(2021,1,1,8,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id=f'exec_bigquery_{BIGQUERY_TABLE_NAME.lower()}',
    default_args=default_args,
    description=f'{BIGQUERY_TABLE_NAME}構築',
    schedule_interval='0 8 * * *',
    catchup=False
)

#
# 前提テーブル構築チェック
#
check_tables = (
    ('M_AD_NIKKEI_ID',       'trns_replace_m_ad_nikkei_id', 'done_all_task_for_check',  45), # 07:15 JST
    ('send_bigquery_dssv',   'send_bigquery_dssv_1',        'done_all_task_for_check',  40), # 07:20 JST
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=7200,      #120分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

#
# BigQueryテーブル操作
#
with dag:
    update_t_ims_dsm_daily_etsuranzumi_honsu =  bigquery_executor(
        dag=dag,
        group_id='update_t_ims_dsm_daily_etsuranzumi_honsu',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_IMS_DSM_DAILY_ETSURANZUMI_HONSU',
        execute_query='sql/bigquery/execute/UPD__T_IMS_DSM_DAILY_ETSURANZUMI_HONSU.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

check_tasks >> update_t_ims_dsm_daily_etsuranzumi_honsu >> done_all_task_for_check
