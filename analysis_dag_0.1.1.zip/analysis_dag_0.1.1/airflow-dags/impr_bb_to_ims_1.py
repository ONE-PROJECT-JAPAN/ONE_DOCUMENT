import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

import logging
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from boto3 import Session
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.redshift_loader import invoke_redshift_loader

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,3,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_retry_callback': notify_failure,
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_bb_to_ims_1', # DAG名
    default_args=default_args,
    description='法人販売システム(BB)のデータ構築',
    schedule_interval='0 6 * * *', # 毎日06時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# ロード対象ファイルパス
S3_INPUT_PATH = 'inbox/recv/bb/T_BB_AGREEMENT_LIST_'

# ファイル拡張子
S3_FILE_EXT = '.end'
#######################################################################################################
# データ構築処理
#######################################################################################################

# 法人契約者リスト情報データロード (W_BB_AGREEMENT_LIST)

s3_to_redshift_w_bb_agreement_list = PythonOperator(
    task_id='s3_to_redshift_w_bb_agreement_list',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bb',
        'redshift_loader_table_name': 'T_BB_AGREEMENT_LIST',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_target_table_name': 'W_BB_AGREEMENT_LIST',
    },
    dag=dag
)

# 法人契約者リスト情報データ変換処理 (T_BB_AGREEMENT_LIST)

replace_t_bb_agreement_list = PostgresOperator(
    task_id='replace_t_bb_agreement_list',
    postgres_conn_id='redshift_default',
    sql='sql/bb/t_bb_agreement_list.sql',
    autocommit=False,
    dag=dag
)

# ロードするファイルの件数チェック

def check_count_file(**context):
    # 日付取得
    exe_date = context['next_execution_date']

    s3client = Session().client('s3')

    #
    # 対象ファイル確認
    #
    response = None
    keys = None
    
    s3_input_prefix_table = """{}{}""".format(S3_INPUT_PATH, convUTC2JST(exe_date, "%Y%m%d"))
    
    response = s3client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_input_prefix_table)

    # 処理対象ファイル有無チェック
    if not('Contents' in response):
        # ファイルが存在しない場合
        raise Exception('ファイルが存在しない')


    #
    # ファイル存在する場合
    #
    if 'Contents' in response:
        keys = [i['Key'] for i in response['Contents']]
        logging.info(f'*** check_count_file keys: {keys}')
        for key in keys:
            # 拡張子
            path_file_ext = os.path.splitext(key)[1]
            # .endの拡張子のファイルが存在している場合は終了
            if S3_FILE_EXT == path_file_ext:
                # ファイルすべて格納済み
                return
    raise Exception('すべてのファイルが格納されていない。')

check_count_file = PythonOperator(
    task_id="check_count_file",
    python_callable=check_count_file,
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_count_file >> s3_to_redshift_w_bb_agreement_list >> replace_t_bb_agreement_list >> done_all_task_for_check
