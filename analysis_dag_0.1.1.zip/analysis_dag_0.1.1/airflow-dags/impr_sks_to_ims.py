import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_sks_to_ims', # DAG名
    default_args=default_args,
    description='NIKKEI SEEKSシステム(SKS)のデータ構築',
    schedule_interval='0 8 * * *', # 毎日08時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn') 
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# 発注者データロード

s3_to_redshift_t_sks_orderer = PythonOperator(
    task_id='s3_to_redshift_t_sks_orderer',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_ORDERER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# エキスパートデータロード

s3_to_redshift_t_sks_expert = PythonOperator(
    task_id='s3_to_redshift_t_sks_expert',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_EXPERT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# エキスパート経歴データロード

s3_to_redshift_t_sks_expert_career = PythonOperator(
    task_id='s3_to_redshift_t_sks_expert_career',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_EXPERT_CAREER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 経験・実績データロード

s3_to_redshift_t_sks_experience = PythonOperator(
    task_id='s3_to_redshift_t_sks_experience',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_EXPERIENCE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# プロジェクト関係データロード

s3_to_redshift_t_sks_project_relations = PythonOperator(
    task_id='s3_to_redshift_t_sks_project_relations',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_PROJECT_RELATIONS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# プロジェクト

s3_to_redshift_t_sks_project = PythonOperator(
    task_id='s3_to_redshift_t_sks_project',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_PROJECT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# TRUSTDOCK_AMLリスク確認

s3_to_redshift_t_sks_td_aml_check_log = PythonOperator(
    task_id='s3_to_redshift_t_sks_td_aml_check_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_TD_AML_CHECK_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# TRUSTDOCK_身元確認

s3_to_redshift_t_sks_td_verification_check_log = PythonOperator(
    task_id='s3_to_redshift_t_sks_td_verification_check_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'sks',
        'redshift_loader_table_name': 'T_SKS_TD_VERIFICATION_CHECK_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    redshift_to_bigquery_t_sks_orderer = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_orderer',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_orderer.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_ORDERER',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_expert = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_expert',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_expert.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_EXPERT',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_expert_career = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_expert_career',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_expert_career.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_EXPERT_CAREER',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_experience = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_experience',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_experience.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_EXPERIENCE',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_project_relations = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_project_relations',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_project_relations.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_PROJECT_RELATIONS',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_project = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_project',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_project.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_PROJECT',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_td_aml_check_log = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_td_aml_check_log',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_td_aml_check_log.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_TD_AML_CHECK_LOG',
        write_disposition='WRITE_APPEND'
    )

    redshift_to_bigquery_t_sks_td_verification_check_log = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_sks_td_verification_check_log',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_sks_td_verification_check_log.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_SKS_TD_VERIFICATION_CHECK_LOG',
        write_disposition='WRITE_APPEND'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_sks_orderer >> redshift_to_bigquery_t_sks_orderer >> done_all_task_for_check
s3_to_redshift_t_sks_expert >> redshift_to_bigquery_t_sks_expert >> done_all_task_for_check
s3_to_redshift_t_sks_expert_career >> redshift_to_bigquery_t_sks_expert_career >> done_all_task_for_check
s3_to_redshift_t_sks_experience >> redshift_to_bigquery_t_sks_experience >> done_all_task_for_check
s3_to_redshift_t_sks_project_relations >> redshift_to_bigquery_t_sks_project_relations >> done_all_task_for_check
s3_to_redshift_t_sks_project >> redshift_to_bigquery_t_sks_project >> done_all_task_for_check
s3_to_redshift_t_sks_td_aml_check_log >> redshift_to_bigquery_t_sks_td_aml_check_log >> done_all_task_for_check
s3_to_redshift_t_sks_td_verification_check_log >> redshift_to_bigquery_t_sks_td_verification_check_log >> done_all_task_for_check
