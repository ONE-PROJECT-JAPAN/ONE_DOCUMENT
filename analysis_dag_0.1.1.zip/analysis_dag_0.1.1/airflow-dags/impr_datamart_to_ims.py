import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.redshift_loader import invoke_redshift_loader

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,9,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_datamart_to_ims', # DAG名
    default_args=default_args,
    description='データマート連携(DATAMART)のデータ構築',
    schedule_interval='0 9 * * *', # 毎日09時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# ログ情報日別会員データロード

s3_to_redshift_t_log_info_daily_user_id = PythonOperator(
    task_id='s3_to_redshift_t_log_info_daily_user_id',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'datamart',
        'redshift_loader_table_name': 'T_LOG_INFO_DAILY_USER_ID',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ログ情報時間別会員ID別データロード

s3_to_redshift_t_log_info_hourly_user_id = PythonOperator(
    task_id='s3_to_redshift_t_log_info_hourly_user_id',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'datamart',
        'redshift_loader_table_name': 'T_LOG_INFO_HOURLY_USER_ID',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# Primeログ情報日別会員データロード

s3_to_redshift_t_log_info_prime_daily_user_id = PythonOperator(
    task_id='s3_to_redshift_t_log_info_prime_daily_user_id',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'datamart',
        'redshift_loader_table_name': 'T_LOG_INFO_PRIME_DAILY_USER_ID',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# Primeログ情報時間別会員ID別データロード

s3_to_redshift_t_log_info_prime_hourly_user_id = PythonOperator(
    task_id='s3_to_redshift_t_log_info_prime_hourly_user_id',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'datamart',
        'redshift_loader_table_name': 'T_LOG_INFO_PRIME_HOURLY_USER_ID',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)



#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_log_info_daily_user_id
s3_to_redshift_t_log_info_hourly_user_id
s3_to_redshift_t_log_info_prime_daily_user_id
s3_to_redshift_t_log_info_prime_hourly_user_id
