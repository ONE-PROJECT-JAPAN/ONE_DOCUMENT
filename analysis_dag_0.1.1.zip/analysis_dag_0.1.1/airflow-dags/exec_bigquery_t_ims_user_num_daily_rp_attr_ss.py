import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,5,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='exec_bigquery_t_ims_user_num_daily_rp_attr_ss', # DAG名
    default_args=default_args,
    description='会員数日別RPサイト別属性別スナップショット',
    schedule_interval='5 8 * * *', # 毎日 8:05(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_IMS_USER_NUM_DAILY_RP_ATTR_SS'

#######################################################################################################
# データ構築処理
#######################################################################################################

check_finish_t_gp_attr_ac = ExternalTaskSensor(
    task_id='check_finish_t_gp_attr_ac',
    external_dag_id='exec_bigquery_t_gp_attr_ac',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=5),  # 毎日08時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_replace_m_ad_nikkei_id = ExternalTaskSensor(
    task_id='check_replace_m_ad_nikkei_id',
    external_dag_id='trns_replace_m_ad_nikkei_id',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=50),  # 毎日07時15分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_replace_m_is_nx_attribute = ExternalTaskSensor(
    task_id='check_replace_m_is_nx_attribute',
    external_dag_id='exec_bigquery_m_is_nx_attribute',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=55),  # 毎日07時10分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_s3_to_redshift_m_is_nx_rp_registration = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_rp_registration',
    external_dag_id='send_bigquery_is',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=65), # 毎日07時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_s3_to_redshift_t_kk_v_contract_analyze = ExternalTaskSensor(
    task_id='check_s3_to_redshift_t_kk_v_contract_analyze',
    external_dag_id='send_bigquery_kk',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=65), # 毎日07時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

#
# BigQueryテーブル操作
#
with dag:
    append_t_ims_user_num_daily_rp_attr_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_ims_user_num_daily_rp_attr_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_IMS_USER_NUM_DAILY_RP_ATTR_SS',
        execute_query='sql/bigquery/execute/UPD__T_IMS_USER_NUM_DAILY_RP_ATTR_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

[ check_finish_t_gp_attr_ac,
  check_replace_m_ad_nikkei_id, 
  check_replace_m_is_nx_attribute,
  check_s3_to_redshift_m_is_nx_rp_registration,
  check_s3_to_redshift_t_kk_v_contract_analyze
] >> append_t_ims_user_num_daily_rp_attr_ss >> done_all_task_for_check
