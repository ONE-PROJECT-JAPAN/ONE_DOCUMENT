import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,23,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_append_plan_mng_delivery_email', # DAG名
    default_args=default_args,
    description='メール配信データ取込',
    schedule_interval='*/10 8-15 * * *', # 毎日 8:00～15:50(JST) 10分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 施策管理、施策別テスト配信メールアドレスに施策データの取込処理

append_plan_mng_delivery_email = PostgresOperator(
    task_id='append_plan_mng_delivery_email',
    postgres_conn_id='redshift_default',
    sql='sql/ma/append_plan_mng_delivery_email.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

append_plan_mng_delivery_email
