import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_kk', # DAG名
    default_args=default_args,
    description='日経ID課金・決済システム(KK)のBigQuery連携',
    schedule_interval='0 7 * * *', # 毎日07時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# 日経ID課金・決済システム(KK)のデータ構築

check_impr_kk_to_ims = ExternalTaskSensor(
    task_id='check_impr_kk_to_ims',
    external_dag_id='impr_kk_to_ims',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=90), # 05時30分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)

# 日経ID課金・決済システム(KK)のデータ構築

check_impr_kk_to_ims_4 = ExternalTaskSensor(
    task_id='check_impr_kk_to_ims_4',
    external_dag_id='impr_kk_to_ims_4',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=20), # 毎日06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=20), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    """
    契約情報分析VIEW
    """
    redshift_to_bigquery_t_kk_v_contract_analyze = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_contract_analyze',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_contract_analyze.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_CONTRACT_ANALYZE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    外部サービス認可マッピングVIEW
    """
    redshift_to_bigquery_t_kk_v_external_service_permit_mapping = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_external_service_permit_mapping',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_external_service_permit_mapping.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    お試し施策
    """
    redshift_to_bigquery_m_kk_m_trial_campaign = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_kk_m_trial_campaign',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_kk_m_trial_campaign.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_KK_M_TRIAL_CAMPAIGN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    お試し施策適用VIEW
    """
    redshift_to_bigquery_t_kk_v_trial_campaign_apply = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_trial_campaign_apply',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_trial_campaign_apply.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_TRIAL_CAMPAIGN_APPLY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    サービスマスタ
    """
    redshift_to_bigquery_m_kk_m_service = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_kk_m_service',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_kk_m_service.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_KK_M_SERVICE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    プランマスタ
    """
    redshift_to_bigquery_m_kk_m_plan = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_kk_m_plan',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_kk_m_plan.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_KK_M_PLAN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    解約アンケート
    """
    redshift_to_bigquery_t_kk_t_close_enquete = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_close_enquete',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_close_enquete.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_CLOSE_ENQUETE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    契約
    """
    redshift_to_bigquery_t_kk_t_contract = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_contract',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_contract.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_CONTRACT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    割引クーポン施策
    """
    redshift_to_bigquery_m_kk_m_coupon_campaign = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_kk_m_coupon_campaign',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_kk_m_coupon_campaign.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_KK_M_COUPON_CAMPAIGN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    当月カードＮＧ一覧情報VIEW
    """
    redshift_to_bigquery_t_kk_v_present_month_card_ng_list = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_present_month_card_ng_list',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_present_month_card_ng_list.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_PRESENT_MONTH_CARD_NG_LIST',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    契約履歴情報分析VIEW
    """
    redshift_to_bigquery_t_kk_v_contract_history_analyze = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_contract_history_analyze',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_contract_history_analyze.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_CONTRACT_HISTORY_ANALYZE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    割引クーポン施策適用VIEW
    """
    redshift_to_bigquery_t_kk_v_coupon_campaign_apply = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_coupon_campaign_apply',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_coupon_campaign_apply.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_COUPON_CAMPAIGN_APPLY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    割引クーポン価格
    """
    redshift_to_bigquery_m_kk_m_coupon_price = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_kk_m_coupon_price',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_kk_m_coupon_price.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_KK_M_COUPON_PRICE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    無料体験クーポン施策適用VIEW
    """
    redshift_to_bigquery_t_kk_v_free_coupon_campaign_apply = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_v_free_coupon_campaign_apply',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_v_free_coupon_campaign_apply.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_FREE_COUPON_CAMPAIGN_APPLY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    redshift_to_bigquery_t_kk_t_payment_amount_change_results = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_payment_amount_change_results',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_payment_amount_change_results.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_PAYMENT_AMOUNT_CHANGE_RESULTS'
    )

    redshift_to_bigquery_t_kk_t_coupon_apply = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_coupon_apply',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_coupon_apply.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_COUPON_APPLY'
    )

    redshift_to_bigquery_t_kk_t_request_history = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_request_history',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_request_history.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_REQUEST_HISTORY'
    )

    redshift_to_bigquery_t_kk_t_payment = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_payment',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_payment.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_PAYMENT'
    )

    redshift_to_bigquery_t_kk_t_permit = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_permit',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_permit.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_PERMIT'
    )

    redshift_to_bigquery_t_kk_t_plan_price_change_history = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_plan_price_change_history',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_plan_price_change_history.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_PLAN_PRICE_CHANGE_HISTORY'
    )

    redshift_to_bigquery_t_kk_t_contract_detail = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_t_contract_detail',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_t_contract_detail.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_CONTRACT_DETAIL'
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_kk_t_close_enquete_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_t_close_enquete_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_CLOSE_ENQUETE_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_T_CLOSE_ENQUETE_ACCUM.sql'
    )

    bq_update_t_kk_v_contract_history_analyze_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_v_contract_history_analyze_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_CONTRACT_HISTORY_ANALYZE_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_V_CONTRACT_HISTORY_ANALYZE_ACCUM.sql'
    )

    bq_update_t_kk_v_external_service_permit_mapping_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_v_external_service_permit_mapping_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING_ACCUM.sql'
    )

    bq_update_t_kk_v_trial_campaign_apply_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_v_trial_campaign_apply_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM.sql'
    )

    bq_update_t_kk_v_contract_analyze_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_v_contract_analyze_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_CONTRACT_ANALYZE_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_V_CONTRACT_ANALYZE_ACCUM.sql'
    )

    bq_update_t_kk_t_request_history_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_t_request_history_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_T_REQUEST_HISTORY_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_T_REQUEST_HISTORY_ACCUM.sql'
    )

    bq_update_t_kk_v_free_coupon_campaign_apply_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_kk_v_free_coupon_campaign_apply_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_V_FREE_COUPON_CAMPAIGN_APPLY_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_KK_V_FREE_COUPON_CAMPAIGN_APPLY_ACCUM.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_contract_analyze >> bq_update_t_kk_v_contract_analyze_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_external_service_permit_mapping >> bq_update_t_kk_v_external_service_permit_mapping_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_m_kk_m_trial_campaign >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_trial_campaign_apply >> bq_update_t_kk_v_trial_campaign_apply_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_m_kk_m_service >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_m_kk_m_plan >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_t_close_enquete >> bq_update_t_kk_t_close_enquete_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_t_contract >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_m_kk_m_coupon_campaign >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_present_month_card_ng_list >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_contract_history_analyze >> bq_update_t_kk_v_contract_history_analyze_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_coupon_campaign_apply >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_m_kk_m_coupon_price >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims ] >> redshift_to_bigquery_t_kk_v_free_coupon_campaign_apply >> bq_update_t_kk_v_free_coupon_campaign_apply_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_payment_amount_change_results >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_coupon_apply >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_request_history >> bq_update_t_kk_t_request_history_accum >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_payment >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_permit >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_plan_price_change_history >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_kk_to_ims_4 ] >> redshift_to_bigquery_t_kk_t_contract_detail >> done_all_task_for_check
