import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_idrp_to_ims', # DAG名
    default_args=default_args,
    description='IDRPシステム(IDRP)のデータ構築',
    schedule_interval='40 5 * * *', # 毎日05時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 日経ビジネススクール会員属性ワークデータロード

s3_to_redshift_w_ba_user_attr = PythonOperator(
    task_id='s3_to_redshift_w_ba_user_attr',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'idrp',
        'redshift_loader_table_name': 'W_BA_USER_ATTR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
    },
    dag=dag
)

# 日経ウーマノミクス会員属性データ蓄積

s3_to_redshift_t_wfd_user_attr_accum = PythonOperator(
    task_id='s3_to_redshift_t_wfd_user_attr_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'idrp',
        'redshift_loader_table_name': 'T_WFD_USER_ATTR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'RPID', 'NIKKEI_MEMBER_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        }
    },
    dag=dag
)

# 日経BIZGATE会員属性ワークデータロード

s3_to_redshift_w_nbg_user_attr = PythonOperator(
    task_id='s3_to_redshift_w_nbg_user_attr',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'idrp',
        'redshift_loader_table_name': 'W_NBG_USER_ATTR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
    },
    dag=dag
)

# NIKKEISTYLE会員属性ワークデータロード

s3_to_redshift_w_li_user_attr = PythonOperator(
    task_id='s3_to_redshift_w_li_user_attr',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'idrp',
        'redshift_loader_table_name': 'W_LI_USER_ATTR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
    },
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ s3_to_redshift_w_ba_user_attr
, s3_to_redshift_t_wfd_user_attr_accum
, s3_to_redshift_w_nbg_user_attr
, s3_to_redshift_w_li_user_attr ] >> done_all_task_for_check
