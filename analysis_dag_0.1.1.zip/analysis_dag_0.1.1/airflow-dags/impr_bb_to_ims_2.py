import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,2,17,10,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_bb_to_ims_2', # DAG名
    default_args=default_args,
    description='法人販売システム(BB)のデータ構築 月次(2日)',
    schedule_interval='10 17 2 * *', # 月次(2日)17時10分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 法人マスタ情報データロード

s3_to_redshift_m_bb_corporation = PythonOperator(
    task_id='s3_to_redshift_m_bb_corporation',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bb',
        'redshift_loader_table_name': 'M_BB_CORPORATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# 法人マスタ情報データ蓄積

s3_to_redshift_m_bb_corporation_accum = PythonOperator(
    task_id='s3_to_redshift_m_bb_corporation_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bb',
        'redshift_loader_table_name': 'M_BB_CORPORATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'CORPORATE_NUMBER' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_BB_CORPORATION_ACCUM',
    },
    dag=dag
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    法人マスタ情報
    """
    redshift_to_bigquery_m_bb_corporation = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_bb_corporation',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_bb_corporation.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_BB_CORPORATION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_m_bb_corporation >> [s3_to_redshift_m_bb_corporation_accum, redshift_to_bigquery_m_bb_corporation] >> done_all_task_for_check
