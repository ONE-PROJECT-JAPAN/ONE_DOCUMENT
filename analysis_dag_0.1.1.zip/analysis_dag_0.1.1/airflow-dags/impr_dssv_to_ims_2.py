import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from airflow.models import Variable
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,10,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_dssv_to_ims_2', # DAG名
    default_args=default_args,
    description='配信システム(DSSV)のデータ構築',
    schedule_interval='10 8 * * *', # 毎日08時10分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'


#######################################################################################################
# データ構築処理
#######################################################################################################

# ＴＲＮスクラップ分類(無料会員)データロード

s3_to_redshift_t_dsm_t_ds_scrap_kind = PythonOperator(
    task_id='s3_to_redshift_t_dsm_t_ds_scrap_kind',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSM_T_DS_SCRAP_KIND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ＴＲＮスクラップ記事(無料会員)データロード

s3_to_redshift_t_dsm_t_ds_scrap_kiji = PythonOperator(
    task_id='s3_to_redshift_t_dsm_t_ds_scrap_kiji',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSM_T_DS_SCRAP_KIJI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ＴＲＮスクラップ記事データ蓄積(無料会員)

replace_t_dsm_t_ds_scrap_kiji_accum = PostgresOperator(
    task_id='replace_t_dsm_t_ds_scrap_kiji_accum',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/dssv/t_dsm_t_ds_scrap_kiji_accum.sql',
    autocommit=False,
    dag=dag
)

# ＴＲＮスクラップ分類(有料会員)データロード

s3_to_redshift_t_dsy_t_ds_scrap_kind = PythonOperator(
    task_id='s3_to_redshift_t_dsy_t_ds_scrap_kind',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSY_T_DS_SCRAP_KIND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ＴＲＮスクラップ記事(有料会員)データロード

s3_to_redshift_t_dsy_t_ds_scrap_kiji = PythonOperator(
    task_id='s3_to_redshift_t_dsy_t_ds_scrap_kiji',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSY_T_DS_SCRAP_KIJI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ＴＲＮスクラップ記事データ蓄積(有料会員)

replace_t_dsy_t_ds_scrap_kiji_accum = PostgresOperator(
    task_id='replace_t_dsy_t_ds_scrap_kiji_accum',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/dssv/t_dsy_t_ds_scrap_kiji_accum.sql',
    autocommit=False,
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_dsm_t_ds_scrap_kind >> done_all_task_for_check
s3_to_redshift_t_dsm_t_ds_scrap_kiji >> replace_t_dsm_t_ds_scrap_kiji_accum >> done_all_task_for_check
s3_to_redshift_t_dsy_t_ds_scrap_kind >> done_all_task_for_check
s3_to_redshift_t_dsy_t_ds_scrap_kiji >> replace_t_dsy_t_ds_scrap_kiji_accum >> done_all_task_for_check
