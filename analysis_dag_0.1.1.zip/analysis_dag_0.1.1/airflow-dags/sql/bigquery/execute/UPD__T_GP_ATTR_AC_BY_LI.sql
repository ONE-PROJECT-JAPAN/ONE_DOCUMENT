-- NIKKEI STYLE会員属性マートデータ蓄積
DECLARE target_table STRING DEFAULT 'T_GP_ATTR_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;
  
  --差分削除
  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  WHERE TABLE_ID = 5
    AND ATTR_INTERNAL_HASH_ID IN
      (
        SELECT
          HASH_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
      )
  ;


  --差分挿入
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  (
      TABLE_ID
      , ATTR_ID
      , ATTR_INTERNAL_HASH_ID
      , SERIAL_ID
      , ATTR_VALUE_NUMERIC
      , ATTR_VALUE_CHAR
      , ATTR_VALUE_DATE
      , ATTR_VALUE_TIMESTAMP
      , ATTR_VALUE_BOOL
      , ATTR_VALUE_FLOAT
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  --W_LI_USER_ATTR.RPID
  SELECT
      5
      , 1
      , HASH_ID
      , SERIAL_ID
      , CAST(RPID AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.CANCEL_FLAG
  UNION ALL
  SELECT
      5
      , 2
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CANCEL_FLAG AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.REGIST_DATE
  UNION ALL
  SELECT
      5
      , 3
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , REGIST_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.UPDATE_DATE
  UNION ALL
  SELECT
      5
      , 4
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , UPDATE_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03001NSM0
  UNION ALL
  SELECT
      5
      , 5
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03001NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03002NSM0
  UNION ALL
  SELECT
      5
      , 6
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03002NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03003NSM0
  UNION ALL
  SELECT
      5
      , 7
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03003NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03004NSM0
  UNION ALL
  SELECT
      5
      , 8
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03004NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03005NSM0
  UNION ALL
  SELECT
      5
      , 9
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03005NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03006NSM0
  UNION ALL
  SELECT
      5
      , 10
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03006NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03007NSM0
  UNION ALL
  SELECT
      5
      , 11
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03007NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03008NSM0
  UNION ALL
  SELECT
      5
      , 12
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03008NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03009NSM0
  UNION ALL
  SELECT
      5
      , 13
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03009NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03010NSM0
  UNION ALL
  SELECT
      5
      , 14
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03010NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03011NSM0
  UNION ALL
  SELECT
      5
      , 15
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03011NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03012NSM0
  UNION ALL
  SELECT
      5
      , 16
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03012NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03013NSM0
  UNION ALL
  SELECT
      5
      , 17
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03013NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03014NSM0
  UNION ALL
  SELECT
      5
      , 18
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03014NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03015NSM0
  UNION ALL
  SELECT
      5
      , 19
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03015NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03016NSM0
  UNION ALL
  SELECT
      5
      , 20
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03016NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03017NSM0
  UNION ALL
  SELECT
      5
      , 21
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03017NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03018NSM0
  UNION ALL
  SELECT
      5
      , 22
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03018NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03019NSM0
  UNION ALL
  SELECT
      5
      , 23
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03019NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03020NSM0
  UNION ALL
  SELECT
      5
      , 24
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03020NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03021NSM0
  UNION ALL
  SELECT
      5
      , 25
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03021NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03022NSM0
  UNION ALL
  SELECT
      5
      , 26
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03022NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03023NSM0
  UNION ALL
  SELECT
      5
      , 27
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03023NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03024NSM0
  UNION ALL
  SELECT
      5
      , 28
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03024NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03025NSM0
  UNION ALL
  SELECT
      5
      , 29
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03025NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03026NSM0
  UNION ALL
  SELECT
      5
      , 30
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03026NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03027NSM0
  UNION ALL
  SELECT
      5
      , 31
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03027NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03028NSM0
  UNION ALL
  SELECT
      5
      , 32
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03028NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03029NSM0
  UNION ALL
  SELECT
      5
      , 33
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03029NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03030NSM0
  UNION ALL
  SELECT
      5
      , 34
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03030NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03031NSM0
  UNION ALL
  SELECT
      5
      , 35
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03031NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03032NSM0
  UNION ALL
  SELECT
      5
      , 36
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03032NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03033NSM0
  UNION ALL
  SELECT
      5
      , 37
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03033NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03034NSM0
  UNION ALL
  SELECT
      5
      , 38
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03034NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03035NSM0
  UNION ALL
  SELECT
      5
      , 39
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03035NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03036NSM0
  UNION ALL
  SELECT
      5
      , 40
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03036NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03037NSM0
  UNION ALL
  SELECT
      5
      , 41
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03037NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03038NSM0
  UNION ALL
  SELECT
      5
      , 42
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03038NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03039NSM0
  UNION ALL
  SELECT
      5
      , 43
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03039NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03040NSM0
  UNION ALL
  SELECT
      5
      , 44
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03040NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03041NSM0
  UNION ALL
  SELECT
      5
      , 45
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03041NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03042NSM0
  UNION ALL
  SELECT
      5
      , 46
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03042NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03043NSM0
  UNION ALL
  SELECT
      5
      , 47
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03043NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03044NSM0
  UNION ALL
  SELECT
      5
      , 48
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03044NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03045NSM0
  UNION ALL
  SELECT
      5
      , 49
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03045NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03046NSM0
  UNION ALL
  SELECT
      5
      , 50
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03046NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03047NSM0
  UNION ALL
  SELECT
      5
      , 51
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03047NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03048NSM0
  UNION ALL
  SELECT
      5
      , 52
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03048NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03049NSM0
  UNION ALL
  SELECT
      5
      , 53
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03049NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  --W_LI_USER_ATTR.MM_03050NSM0
  UNION ALL
  SELECT
      5
      , 54
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MM_03050NSM0 AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;