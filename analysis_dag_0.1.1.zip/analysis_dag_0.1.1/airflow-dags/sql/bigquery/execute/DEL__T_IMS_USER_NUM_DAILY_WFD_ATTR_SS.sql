DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_WFD_ATTR_SS
  WHERE snapshot_date = exec_date
  ;

END;
