DECLARE target_table STRING DEFAULT 'T_IMS_USER_ID_SIGNUP_CHARGE_START_DATE';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_ID_SIGNUP_CHARGE_START_DATE
  WHERE INS_DATETIME_JST = exec_datetime
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_ID_SIGNUP_CHARGE_START_DATE (
    HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , CONTRACT_NO
    , PLAN_ID
    , PREVIOUS_PLAN_ID
    , CHARGED_PLAN_START_DATE
    , FREE_COUPON_CAMPAIGN_MANAGEMENT_NO
    , COUPON_CAMPAIGN_MANAGEMENT_NO
    , SIGNUP_CHARGE_START_DATE
    , INS_DATETIME_JST
  )
  WITH DATA AS (
    SELECT
      ROW_NUMBER() OVER(
        PARTITION BY
          CO.HASH_ID
          , CO.RP_ID
          , CO.SERVICE_ID
          , CO.CONTRACT_NO
        ORDER BY
          CU.APPLY_DATETIME DESC
      ) AS ROW_NO
      , CO.HASH_ID
      , CO.SERIAL_ID
      , CO.RP_ID
      , CO.SERVICE_ID
      , CO.CONTRACT_NO
      , CO.PLAN_ID
      , CO.CHARGED_PLAN_START_DATE
      -- 無料体験が無く、月末日に有料申込⇒有料解約して無料プラン化している場合は、翌日の月初日に課金開始日が99991231になるため有料プラン開始日を使用する
      , CASE
        WHEN CO.CHARGED_PLAN_START_DATE = CO.CHARGED_PLAN_END_DATE
        AND CO.CHARGE_START_DATE = '9999-12-31'
        THEN CO.CHARGED_PLAN_START_DATE
        ELSE CO.CHARGE_START_DATE
        END AS CHARGE_START_DATE
      , CU.COUPON_CAMPAIGN_MANAGEMENT_NO
      -- 割引額が月額利用料を満たしていれば、割引終了年月の翌月月初を開始日とする
      , CASE
        WHEN COUPON_DISCOUNT_PRICE >= MONTHLY_CHARGE
        THEN DATE_ADD(DATE_TRUNC(CU.COUPON_DISCOUNT_END_YYYYMM_DATE, MONTH), INTERVAL 1 MONTH)
        ELSE NULL
        END AS CHARGE_START_DATE_AFTER_COUPON_CAMPAIGN
      , FC.FREE_COUPON_CAMPAIGN_MANAGEMENT_NO
      , CP.COUPON_DISCOUNT_PRICE
      , PP.MONTHLY_CHARGE
      , RH.PREVIOUS_PLAN_ID
      , exec_datetime AS INS_DATETIME_JST
    FROM
      -- 契約情報分析VIEW
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_ANALYZE CO
      -- 割引クーポン施策適用VIEW
      LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_COUPON_CAMPAIGN_APPLY CU
        ON CO.HASH_ID = CU.HASH_ID
        AND CO.CONTRACT_NO = CU.CONTRACT_NO
        AND CO.RP_ID = CU.RP_ID
        AND CO.SERVICE_ID = CU.SERVICE_ID
        AND CO.PLAN_ID = CU.PLAN_ID
        AND DATE(CU.APPLY_DATETIME) = CO.CHARGED_PLAN_START_DATE
       -- 無料体験クーポン施策適用VIEW
      LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_FREE_COUPON_CAMPAIGN_APPLY FC
        ON CO.HASH_ID = FC.HASH_ID
        AND CO.CONTRACT_NO = FC.CONTRACT_NO
        AND CO.RP_ID = FC.RP_ID
        AND CO.SERVICE_ID = FC.SERVICE_ID
        AND CO.PLAN_ID = FC.PLAN_ID
        AND DATE(FC.APPLY_DATETIME) = CO.CHARGED_PLAN_START_DATE
      -- 割引クーポン価格テーブル
      LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_KK_M_COUPON_PRICE CP
        ON CU.COUPON_CAMPAIGN_MANAGEMENT_NO = CP.COUPON_CAMPAIGN_MANAGEMENT_NO
        AND CU.PLAN_ID = CP.PLAN_ID
      -- プラン価格改定履歴テーブル
      LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_PLAN_PRICE_CHANGE_HISTORY PP
        ON CO.PLAN_ID = PP.PLAN_ID
        AND CO.CHARGED_PLAN_START_DATE >= PP.PLAN_PRICE_START_DATE
        AND CO.CHARGED_PLAN_START_DATE <= PP.PLAN_PRICE_END_DATE
      -- 申請履歴
      LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_REQUEST_HISTORY RH
        ON CO.HASH_ID = RH.HASH_ID
        AND CO.SERVICE_ID = RH.SERVICE_ID
        AND CO.CONTRACT_NO = RH.CONTRACT_NO
        AND CO.REQUEST_NO = RH.REQUEST_NO
    WHERE
      CO.CHARGED_PLAN_START_DATE = DATE_ADD(exec_date, INTERVAL -1 DAY)
  )
  SELECT
    HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , CONTRACT_NO
    , PLAN_ID
    , PREVIOUS_PLAN_ID
    , CHARGED_PLAN_START_DATE
    , FREE_COUPON_CAMPAIGN_MANAGEMENT_NO
    , COUPON_CAMPAIGN_MANAGEMENT_NO
    , CASE
      WHEN CHARGE_START_DATE_AFTER_COUPON_CAMPAIGN > CHARGE_START_DATE
      THEN CHARGE_START_DATE_AFTER_COUPON_CAMPAIGN
      ELSE CHARGE_START_DATE
      END AS SIGNUP_CHARGE_START_DATE
    , INS_DATETIME_JST
  FROM
    DATA
  WHERE
    ROW_NO = 1
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;