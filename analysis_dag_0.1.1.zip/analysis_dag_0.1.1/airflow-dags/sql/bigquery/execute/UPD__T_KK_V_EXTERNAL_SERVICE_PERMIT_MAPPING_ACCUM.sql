DECLARE target_table STRING DEFAULT 'T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING_ACCUM A
  USING (
    SELECT
      HASH_ID
      , SERIAL_ID
      , EXTERNAL_SERVICE_ID
      , PRODUCT_CODE
      , EXTERNAL_SERVICE_PERMIT_KEY
      , LATEST_EXTERNAL_SERVICE_PERMIT_KEY
      , RP_ID
      , SERVICE_ID
      , PLAN_ID
      , FIRST_ENTRY_DATETIME
      , PERMIT_END_DATETIME
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING B
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.EXTERNAL_SERVICE_ID = B.EXTERNAL_SERVICE_ID
    AND A.PRODUCT_CODE = B.PRODUCT_CODE
    AND A.EXTERNAL_SERVICE_PERMIT_KEY = B.EXTERNAL_SERVICE_PERMIT_KEY
    AND A.FIRST_ENTRY_DATETIME = B.FIRST_ENTRY_DATETIME
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      SERIAL_ID = B.SERIAL_ID
      , LATEST_EXTERNAL_SERVICE_PERMIT_KEY = B.LATEST_EXTERNAL_SERVICE_PERMIT_KEY
      , RP_ID = B.RP_ID
      , SERVICE_ID = B.SERVICE_ID
      , PLAN_ID = B.PLAN_ID
      , FIRST_ENTRY_DATETIME = B.FIRST_ENTRY_DATETIME
      , PERMIT_END_DATETIME = B.PERMIT_END_DATETIME
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;