DECLARE target_table STRING DEFAULT 'T_KK_V_CONTRACT_HISTORY_ANALYZE_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_HISTORY_ANALYZE_ACCUM A
  USING (
    SELECT
      HASH_ID
      , SERIAL_ID
      , RP_ID
      , SERVICE_ID
      , PLAN_ID
      , CONTRACT_NO
      , SERVICE_START_DATE
      , SERVICE_END_DATE
      , REQUEST_NO
      , REQUEST_STATUS
      , REQUEST_TYPE
      , DS_REQUEST_TYPE
      , PLAN_START_DATE
      , PLAN_END_DATE
      , LAST_UPDATE_DATETIME
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_HISTORY_ANALYZE B
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.RP_ID = B.RP_ID
    AND A.SERVICE_ID = B.SERVICE_ID
    AND A.PLAN_ID = B.PLAN_ID
    AND A.CONTRACT_NO = B.CONTRACT_NO
    AND A.REQUEST_NO = B.REQUEST_NO
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      HASH_ID = B.HASH_ID
      , SERIAL_ID = B.SERIAL_ID
      , RP_ID = B.RP_ID
      , SERVICE_ID = B.SERVICE_ID
      , PLAN_ID = B.PLAN_ID
      , CONTRACT_NO = B.CONTRACT_NO
      , SERVICE_START_DATE = B.SERVICE_START_DATE
      , SERVICE_END_DATE = B.SERVICE_END_DATE
      , REQUEST_NO = B.REQUEST_NO
      , REQUEST_STATUS = B.REQUEST_STATUS
      , REQUEST_TYPE = B.REQUEST_TYPE
      , DS_REQUEST_TYPE = B.DS_REQUEST_TYPE
      , PLAN_START_DATE = B.PLAN_START_DATE
      , PLAN_END_DATE = B.PLAN_END_DATE
      , LAST_UPDATE_DATETIME = B.LAST_UPDATE_DATETIME
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;