--
-- 会員数日別RPサイト別利用状態別スナップショット
--
DECLARE target_table STRING DEFAULT 'T_IMS_USER_NUM_DAILY_RP_STATUS_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_STATUS_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_STATUS_SS(
    SNAPSHOT_DATE
    , RP_ID
    , USED_USER_COUNT
    , CANCEL_USER_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
  )
  SELECT
    exec_date AS SNAPSHOT_DATE
    , RP_ID
    --利用会員数
    , SUM(CASE WHEN A.REG_STATUS = '1' THEN 1 ELSE 0 END) AS USED_USER_COUNT
    --解約会員数
    , SUM(CASE WHEN A.REG_STATUS = '0' THEN 1 ELSE 0 END) AS CANCEL_USER_COUNT
    , 'IMS' AS INS_BATCH_ID
    , exec_datetime AS INS_DT_TM
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_RP_REGISTRATION A
  WHERE
    -- プラス1倶楽部
    RP_ID = 1063
  GROUP BY
    RP_ID
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;