DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_RP_SERVICE_PLN_LASTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE last_month_last_day DATE DEFAULT DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL -1 DAY); --先月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_RP_SERVICE_PLN_LASTDAY_SS
  WHERE SNAPSHOT_DATE = last_month_last_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_RP_SERVICE_PLN_LASTDAY_SS (
    SNAPSHOT_DATE
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , USER_COUNT
    , CANCEL_COUNT
    , CHANGE_COUNT
    , CURRENT_MONTH_CANCEL_COUNT
    , CURRENT_MONTH_CHANGE_COUNT
    , LOST_W_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
    SNAPSHOT_DATE
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    --会員数
    , COUNT(DISTINCT HASH_ID) AS USER_COUNT
    --解約予約、変更予約
    , COUNT(
      DISTINCT CASE
        WHEN CANCEL_FLG = 1
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CANCEL_COUNT
    , COUNT(
      DISTINCT CASE
        WHEN CHANGE_FLG = 1
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CHANGE_COUNT
    --当月締め解約申込予約数
    , COUNT(
      DISTINCT CASE
        WHEN CANCEL_FLG = 1
        AND CURRENT_MONTH_CANCEL_FLG = 1
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CURRENT_MONTH_CANCEL_COUNT
    , COUNT(
      DISTINCT CASE
        WHEN CHANGE_FLG = 1
        AND CURRENT_MONTH_CHANGE_FLG = 1
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CURRENT_MONTH_CHANGE_COUNT
    --解約・変更申込予約（W落ち）数
    , COUNT(
      DISTINCT CASE
        WHEN LOST_W_FLG = 1
        THEN HASH_ID
        ELSE NULL
        END
    ) AS LOST_W_COUNT
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_RP_SERVICE_PLN_LASTDAY_SS
  WHERE
    SNAPSHOT_DATE = last_month_last_day
  GROUP BY
    SNAPSHOT_DATE
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;