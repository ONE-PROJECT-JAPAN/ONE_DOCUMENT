DECLARE target_table STRING DEFAULT 'T_BA_USER_ATTR';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BA_USER_ATTR A
  USING (
    SELECT
      RPID
      , HASH_ID
      , SERIAL_ID
      , OPEN_USER_NO
      , MAIL_NOTIFICATION
      , CANCEL_FLAG
      , REGIST_DATE
      , UPDATE_DATE
      , 'IMS' AS INS_PGM_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_PGM_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_BA_USER_ATTR
    UNION ALL
    --IFに存在しないデータを結合
    SELECT
      RPID
      , HASH_ID
      , SERIAL_ID
      , OPEN_USER_NO
      , MAIL_NOTIFICATION
      , CANCEL_FLAG
      , REGIST_DATE
      , UPDATE_DATE
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BA_USER_ATTR A
    WHERE
      NOT EXISTS (
        SELECT
          1
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.W_BA_USER_ATTR B
        WHERE
          B.HASH_ID = A.HASH_ID
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;