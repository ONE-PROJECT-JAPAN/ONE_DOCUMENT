DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS (
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , PRICEPLN_SYSTEM_ID
    , PRICEPLN_CD
    , CANCEL_FLG
    , CHANGE_FLG
    , PREFEC
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , CHARGE_KBN
  )
  SELECT
    exec_date
    , V.HASH_ID
    , V.SERIAL_ID
    , V.PRICEPLN_SYSTEM_ID
    , V.PRICEPLN_CD
    , V.CANCEL_FLG
    , V.CHANGE_FLG
    , ADD.PREFEC
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
    , CHARGE_KBN
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_DS_PRIORITY_PLN V
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE ATTR
      ON V.HASH_ID = ATTR.HASH_ID
      --会員
      AND ATTR.WITHDRAWAL_FLAG = '0'
      --一般ユーザー
      AND ATTR.USER_TYPE = '0'
    LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_MM_ADDRESS ADD
      ON ATTR.ADDRESS_CODE = ADD.ADRS_CD
  WHERE
    V.PRICEPLN_SYSTEM_ID IS NOT NULL
    AND V.PRICEPLN_CD IS NOT NULL
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;