DECLARE target_table STRING DEFAULT 'T_DSU_T_DS_JWALERT_INFO_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_JWALERT_INFO_ACCUM A
  USING (
    SELECT
      INSDATE
      , UPDATEDATE
      , HASH_ID
      , SERIAL_ID
      , TONYU_NUM
      , NIK_CODE
      , PERSONAL_NAME
      , PERSONAL_NAME_SEARCH
      , ALERT_MAIL_PATTERN_ID
      , ALERT_MAIL_P_RECEIVE_FLG
      , ALERT_MAIL_M_RECEIVE_FLG
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_JWALERT_INFO B
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.TONYU_NUM = B.TONYU_NUM
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      INSDATE = B.INSDATE
      , UPDATEDATE = B.UPDATEDATE
      , HASH_ID = B.HASH_ID
      , SERIAL_ID = B.SERIAL_ID
      , TONYU_NUM = B.TONYU_NUM
      , NIK_CODE = B.NIK_CODE
      , PERSONAL_NAME = B.PERSONAL_NAME
      , PERSONAL_NAME_SEARCH = B.PERSONAL_NAME_SEARCH
      , ALERT_MAIL_PATTERN_ID = B.ALERT_MAIL_PATTERN_ID
      , ALERT_MAIL_P_RECEIVE_FLG = B.ALERT_MAIL_P_RECEIVE_FLG
      , ALERT_MAIL_M_RECEIVE_FLG = B.ALERT_MAIL_M_RECEIVE_FLG
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;