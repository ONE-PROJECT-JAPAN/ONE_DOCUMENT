/*

   参照テーブル:
      D_IMS_NIKKEI_MEMBER_NO_LIST
      M_AD_NIKKEI_ID
      M_IS_NX_MIGRATION
      T_BPP_V_USER_SERVICE_ALL

*/
DECLARE target_table STRING DEFAULT 'T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS
  (
      SNAPSHOT_DATE
      , SERVICE_ID
      , DSP_USERNUM_KBN1
      , DSP_USERNUM_KBN2
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  SELECT
      exec_date AS SNAPSHOT_DATE
      , SS.SERVICE_ID
      , SS.DSP_USERNUM_KBN1
      , SS.DSP_USERNUM_KBN2
      , SS.PRICEPLN_SYSTEM_ID
      , SS.USER_COUNT
      , '{{ dag.dag_id }}' AS INS_PGM_ID                            
      , exec_datetime AS INS_DT_TM    
      , '{{ dag.dag_id }}' AS UPD_PGM_ID                            
      , exec_datetime AS UPD_DT_TM    
  FROM
  (
  WITH USER_SERVICE
  AS
  (
      
      SELECT
          '01' AS DSP_USERNUM_KBN2
          , S.SERIALID
          , S.HASH_ID
          , S.SERVICE_ID
          , S.LINK_STATUS
          , S.LINKENTRY_ON
          , S.DMIN_STATUS
          , S.DMEXT_STATUS
      FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BPP_V_USER_SERVICE_ALL S
      WHERE
          SERVICE_ID <> 'gateway'
      AND SERVICE_ID IS NOT NULL
      AND LINK_STATUS = 0
      UNION ALL
      
      SELECT
          '02' AS DSP_USERNUM_KBN2
          , S.SERIALID
          , S.HASH_ID
          , '01' AS SERVICE_ID        
          , S.LINK_STATUS
          , S.LINKENTRY_ON
          , S.DMIN_STATUS
          , S.DMEXT_STATUS
      FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BPP_V_USER_SERVICE_ALL S
      WHERE
          SERVICE_ID <> 'gateway'
      AND SERVICE_ID IS NOT NULL
      AND LINK_STATUS = 0
  )
  SELECT
      S.SERVICE_ID
      , '01' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND S.HASH_ID = N.HASH_ID
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '02' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION M
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID A
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND S.HASH_ID = N.HASH_ID
  AND S.HASH_ID = M.HASH_ID
  AND S.HASH_ID = A.HASH_ID
  AND (M.ORIGINAL_SITE = 'BPPM' OR M.MRG_ORG_SITE = 'BPPM')
  AND A.ORIGINAL_STATUS = '9'
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '03' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND S.HASH_ID = N.HASH_ID
  AND S.LINKENTRY_ON >= (exec_date - 1)
  AND S.LINKENTRY_ON < exec_date
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '04' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID A
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND N.NIKKEI_MAIL_FLAG = '1'
  AND S.HASH_ID = N.HASH_ID
  AND S.HASH_ID = A.HASH_ID
  AND A.ORIGINAL_STATUS = '9'
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '05' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID A
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND N.THIRDPARTY_MAIL_FLAG = '1'
  AND S.HASH_ID = N.HASH_ID
  AND S.HASH_ID = A.HASH_ID
  AND A.ORIGINAL_STATUS = '9'
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '06' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND S.HASH_ID = N.HASH_ID
  AND S.DMIN_STATUS = 0
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '07' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND S.HASH_ID = N.HASH_ID
  AND S.DMEXT_STATUS = 0
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '08' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID A
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND N.PRICEPLN_KBN IN ('01', '02')
  AND S.HASH_ID = N.HASH_ID
  AND S.HASH_ID = A.HASH_ID
  AND A.ORIGINAL_STATUS = '9'
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      S.SERVICE_ID
      , '09' AS DSP_USERNUM_KBN1
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT S.SERIALID) AS USER_COUNT
  FROM
      USER_SERVICE S
      , domo.D_IMS_NIKKEI_MEMBER_NO_LIST N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID A
  WHERE
      N.USER_TYPE = '0'
  AND N.WITHDRAWAL_FLAG = '0'
  AND N.PRICEPLN_KBN IN ('03', '04')
  AND S.HASH_ID = N.HASH_ID
  AND S.HASH_ID = A.HASH_ID
  AND A.ORIGINAL_STATUS = '9'
  GROUP BY
      S.SERVICE_ID
      , S.DSP_USERNUM_KBN2
      , N.PRICEPLN_SYSTEM_ID
  ) SS
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;