DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_RP_SERVICE_PLN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE next_month_first_day DATE DEFAULT DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL 1 MONTH); --翌月1日
DECLARE last_day DATE DEFAULT DATE_ADD(next_month_first_day, INTERVAL -1 DAY); --当月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_RP_SERVICE_PLN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_RP_SERVICE_PLN_SS (
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , PLAN_FLG
    , REQUEST_TYPE
    , DS_REQUEST_TYPE
    , CANCEL_FLG
    , CHANGE_FLG
    , CURRENT_MONTH_CANCEL_FLG
    , CURRENT_MONTH_CHANGE_FLG
    , LOST_W_FLG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , CHARGE_KBN
  )
  SELECT
    exec_date
    , A.HASH_ID
    , A.SERIAL_ID
    , B.RP_ID
    , B.SERVICE_ID
    , B.PLAN_ID
    , B.PLAN_FLG
    , B.REQUEST_TYPE
    , B.DS_REQUEST_TYPE
    , IFNULL(B.CANCELLATION_RESERVED_FLG, 0)
    --プラン変更予約フラグ
    , CASE
      WHEN B.RESERVED_REQUEST_NO > 0
      AND B.PLAN_CHANGE_REQUEST_DATE IS NOT NULL
      THEN 1
      ELSE 0
      END AS CHANGE_FLG
    --当月締め解約予約フラグ
    , CASE
      WHEN B.FARST_FREE_FLG = 0
      AND B.RESERVED_REQUEST_NO > 0
      AND B.CHARGED_PLAN_END_REQUEST_DATE IS NOT NULL
      --当月末日
      AND B.FIXED_RESERVED_DATE = last_day
      THEN 1
      ELSE 0
      END AS CURRENT_MONTH_CANCEL_FLG
    --当月締め変更予約フラグ
    , CASE
      WHEN B.FARST_FREE_FLG = 0
      AND B.RESERVED_REQUEST_NO > 0
      AND B.PLAN_CHANGE_REQUEST_DATE IS NOT NULL
      --翌月1日
      AND B.FIXED_RESERVED_DATE = next_month_first_day
      THEN 1
      ELSE 0
      END AS CURRENT_MONTH_CHANGE_FLG
    , IFNULL(B.LOST_W_FLG, 0)
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
    , CASE
      WHEN B.PLAN_FLG = 0
      OR B.CHARGE_START_DATE > exec_date
      THEN 1
      ELSE 2
      END AS CHARGE_KBN
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE A
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_ANALYZE B
      ON A.HASH_ID = B.HASH_ID
  WHERE
    --一般ユーザー、退会していない
    A.USER_TYPE = '0'
    AND A.WITHDRAWAL_FLAG = '0'
    --サービスが終了していない
    AND B.SERVICE_END_DATE >= exec_date
    AND B.LATEST_CONTRACT_NO = B.CONTRACT_NO
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;