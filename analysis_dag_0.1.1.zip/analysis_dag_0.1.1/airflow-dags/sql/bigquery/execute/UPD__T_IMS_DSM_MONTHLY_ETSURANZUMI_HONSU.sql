DECLARE target_table STRING DEFAULT 'T_IMS_DSM_MONTHLY_ETSURANZUMI_HONSU';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE first_day DATE DEFAULT DATE_TRUNC(exec_date, MONTH); --当月1日
DECLARE last_month STRING DEFAULT FORMAT_DATE('%Y%m', DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL -1 DAY)); --先月

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_DSM_MONTHLY_ETSURANZUMI_HONSU
  WHERE YEAR_MONTH = last_month
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_DSM_MONTHLY_ETSURANZUMI_HONSU (
    YEAR_MONTH
    , HASH_ID
    , SERIAL_ID
    , ETSURANZUMI_HONSU
    , INS_DT_TM
  )
  SELECT
    last_month AS YEAR_MONTH
    , AC.HASH_ID
    , AC.SERIAL_ID
    , SUM(AC.ETSURANZUMI_HONSU) AS ETSURANZUMI_HONSU
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_ETSURANZUMI_HONSU_LOG_ACCUM AC
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID NK
      ON NK.HASH_ID = AC.HASH_ID
      AND NK.PRICEPLN_KBN = '04'
  WHERE
    AC.ETSURANZUMI_HONSU > 0
    AND DATE(AC.INSDATE) = first_day
  GROUP BY
    YEAR_MONTH
    , HASH_ID
    , SERIAL_ID
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;