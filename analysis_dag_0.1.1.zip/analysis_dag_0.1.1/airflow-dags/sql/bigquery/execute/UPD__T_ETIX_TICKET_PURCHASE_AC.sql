DECLARE target_table STRING DEFAULT 'T_ETIX_TICKET_PURCHASE_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_ETIX_TICKET_PURCHASE_AC
  WHERE DATE(INS_DT_TM) = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_ETIX_TICKET_PURCHASE_AC (
    EVENT_NAME
    , EVENT_GENRE
    , EVENT_START_DATE
    , EVENT_END_DATE
    , OPEN_USER_ID
    , TICKET_PRICE_NAME
    , TICKET_PRICE
    , PURCHASE_DT_TM
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
    EVENT_NAME
    , EVENT_GENRE
    , EVENT_START_DATE
    , EVENT_END_DATE
    , OPEN_USER_ID
    , TICKET_PRICE_NAME
    , TICKET_PRICE
    , PURCHASE_DT_TM
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_ETIX_TICKET_PURCHASE
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;