DECLARE target_table STRING DEFAULT 'T_CM_DELIVERY_RESULT_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_DELIVERY_RESULT_SS A
  USING (
    SELECT
      S.PLAN_ID
      , MAX(T.EDATE) AS EDATE
      , SUM(T.TOTAL) AS TOTAL
      , SUM(T.SUCCESS) AS SUCCESS
      , SUM(T.ERROR) AS ERROR
      , SUM(T.HBBSBB) AS HBBSBB
      , SUM(T.UNIQOPEN) AS UNIQOPEN
      , SUM(T.OPEN) AS OPEN
      , SUM(T.UNIQCLICK) AS UNIQCLICK
      , SUM(T.CLICK) AS CLICK
      , 'IMS' AS INS_PGM_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_PGM_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_SUMMARY_AC T
      INNER JOIN (
        SELECT
          SU.MAILIDX
          , SU.PLAN_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_SUCCESS_AC SU
        UNION DISTINCT
        SELECT
          ER.MAILIDX
          , ER.PLAN_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_ERROR_AC ER
      ) S
        ON T.MAILIDX = S.MAILIDX
    WHERE
      {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(S.PLAN_ID) = false
    GROUP BY
      PLAN_ID
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;