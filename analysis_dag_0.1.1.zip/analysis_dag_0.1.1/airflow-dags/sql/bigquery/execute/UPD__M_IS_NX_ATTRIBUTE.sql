DECLARE target_table STRING DEFAULT 'M_IS_NX_ATTRIBUTE';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE
  USING (
    SELECT
      HASH_ID
      , SERIAL_ID
      , EMAIL
      , REMINDER_QUESTION
      , REMINDER_ANSWER
      , SECOND_EMAIL
      , LAST_NAME
      , FIRST_NAME
      , LAST_NAME_KANA
      , FIRST_NAME_KANA
      , RESIDENT_ABROAD
      , COUNTRY_CODE
      , ZIP_CODE
      , ADDRESS_CODE
      , ADDRESS1
      , ADDRESS2
      , TEL1
      , TEL2
      , TEL3
      , TEL_JOINT
      , OVERSEAS_ZIP_CODE
      , OVERSEAS_ADDRESS1
      , OVERSEAS_ADDRESS2
      , OVERSEAS_ADDRESS3
      , OVERSEAS_TEL
      , SEX
      , BIRTH
      , OCCUPATION_NO
      , BUSINESS_NO
      , JOB_NO
      , POSITION_NO
      , EMPLOYEES_NO
      , INCOME_NO
      , NEWS_SUBSCRIPTION1
      , NEWS_SUBSCRIPTION2
      , NEWS_SUBSCRIPTION3
      , NEWS_SUBSCRIPTION4
      , NEWS_SUBSCRIPTION5
      , NEWS_SUBSCRIPTION6
      , NEWS_SUBSCRIPTION7
      , NEWS_SUBSCRIPTION8
      , NEWS_SUBSCRIPTION9
      , NEWS_SUBSCRIPTION10
      , NEWS_SUBSCRIPTION11
      , NEWS_SUBSCRIPTION12
      , NEWS_SUBSCRIPTION13
      , NEWS_SUBSCRIPTION14
      , NEWS_SUBSCRIPTION15
      , NEWS_SUBSCRIPTION16
      , NEWS_SUBSCRIPTION17
      , NEWS_SUBSCRIPTION18
      , NEWS_SUBSCRIPTION19
      , NEWS_SUBSCRIPTION20
      , NEWS_SUBSCRIPTION_SUMMARY_FLAG
      , INTEREST1
      , INTEREST2
      , INTEREST3
      , INTEREST4
      , INTEREST5
      , INTEREST6
      , INTEREST7
      , INTEREST8
      , INTEREST9
      , INTEREST10
      , INTEREST11
      , INTEREST12
      , INTEREST13
      , INTEREST14
      , INTEREST15
      , INTEREST16
      , INTEREST17
      , INTEREST18
      , INTEREST19
      , INTEREST20
      , NIKKEI_MAIL_FLAG
      , THIRDPARTY_MAIL_FLAG
      , NIKKEI_MONITOR_FLAG
      , COMPANY_NAME
      , COMPANY_TYPE_CODE
      , COMPANY_TYPE_LOCATION
      , COMPANY_ZIP_CODE
      , COMPANY_ADDRESS
      , COMPANY_BUSINESS_UNIT
      , COMPANY_TEL1
      , COMPANY_TEL2
      , COMPANY_TEL3
      , COMPANY_OVERSEAS_NAME
      , COMPANY_OVERSEAS_ADDRESS
      , COMPANY_OVERSEAS_TEL
      , USER_TYPE
      , ENTRY_DATE
      , WITHDRAWAL_DATE
      , WITHDRAWAL_FLAG
      , CREATE_DATE
      , CREATE_USER
      , UPDATE_DATE
      , UPDATE_USER
      , DELETE_DATE
      , DELETE_USER
      , DELETE_FLG
      , 'IMS'
      , exec_datetime
      , 'IMS'
      , exec_datetime
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE_IF
    WHERE
      HASH_ID NOT IN (
        SELECT
          ATTR.HASH_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE_IF ATTR
        LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION BP
          ON ATTR.HASH_ID = BP.HASH_ID
        LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION NID
          ON BP.EST_IDENTICAL_HASH_ID = NID.HASH_ID
        WHERE
          {{ var.value.atlas_bigquery_ims_dataset_name }}.IF_EMPTY(ATTR.WITHDRAWAL_FLAG, '0') = '1'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IF_EMPTY(BP.ORIGINAL_SITE, 'NID')   = 'BPPM'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IF_EMPTY(NID.MRG_ORG_SITE, 'NID')   = 'BPPM'
      )
  )
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;