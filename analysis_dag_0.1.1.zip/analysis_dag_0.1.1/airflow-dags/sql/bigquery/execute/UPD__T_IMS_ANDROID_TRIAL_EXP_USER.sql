DECLARE target_table STRING DEFAULT 'T_IMS_ANDROID_TRIAL_EXP_USER';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_ANDROID_TRIAL_EXP_USER A
  USING (
    SELECT
      RHA.REQUEST_APPLY_DATE
      , NI.HASH_ID
      , NI.SERIAL_ID
      , CASE
        WHEN RHA.PLAN_END_DATE < exec_date
        THEN 0
        ELSE 1
        END AS CONTRACT_FLG
      , RHA.PLAN_END_DATE
      , exec_datetime AS INS_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_REQUEST_HISTORY_ACCUM RHA
      INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID NI
        ON NI.HASH_ID = RHA.HASH_ID
    WHERE
      RHA.SERVICE_ID = 'DS00000000001'
      AND RHA.PLAN_ID = 'DS00000000000002'
      AND RHA.REQUEST_TYPE in (1,9)
      AND RHA.REQUEST_APPLY_DATE >= '2018-06-06'
      AND RHA.CAMPAIGN_CODE IN ('androidap1monthtrial' , '0android2019haruwari', '00000000201911andapp', '02020hatsuwariandapp')
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;