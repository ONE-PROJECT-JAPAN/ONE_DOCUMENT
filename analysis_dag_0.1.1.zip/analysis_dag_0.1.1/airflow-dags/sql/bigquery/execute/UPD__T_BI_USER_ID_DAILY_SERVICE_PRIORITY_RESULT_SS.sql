DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE(exec_datetime);

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS (
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , PLAN_START_DATE
    , CANCEL_FLG
    , CHANGE_FLG
    , CORP_FLG
    , VALID_CONTRACT_FLG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , CHARGE_KBN
  )
  SELECT
    exec_date
    , SVC.HASH_ID
    , SVC.SERIAL_ID
    , SVC.RP_ID
    , SVC.SERVICE_ID
    , SVC.PLAN_ID
    , SVC.PLAN_START_DATE
    , SVC.CANCEL_FLG
    , SVC.CHANGE_FLG
    , SVC.CORP_FLG
    , CASE
      WHEN (
        --電子版優先判定結果
        DS_PRI.PLAN_ID IS NOT NULL
        --サービス優先判定結果
        OR SVC_PRI.PLAN_ID IS NOT NULL
        --グループ契約優先判定結果
        OR GRP_PRI.PLAN_ID IS NOT NULL
      )
      THEN 1 --有効な契約
      ELSE 0 --無効な契約
      END AS VALID_CONTRACT_FLG
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
    , SVC.CHARGE_KBN
  FROM
    --サービス全量（電子版、電子版オプション、サービス）
    (
      --法人契約サービス
      SELECT
        TBB.HASH_ID
        , TBB.SERIAL_ID
        , TBB.RP_ID
        , TBB.SERVICE_ID
        , MBB.PLAN_ID
        , TBB.USESTART_DATE AS PLAN_START_DATE
        , 2 AS CORP_FLG --法人契約
        , 0 AS CANCEL_FLG
        , 0 AS CHANGE_FLG
        , 9 AS CHARGE_KBN
      FROM
        (
          SELECT
            HASH_ID
            , SERIAL_ID
            , RP_ID
            , SERVICE_ID
            , USESTART_DATE
            , REPORT_CATEGORY
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST
        ) TBB
        INNER JOIN (
          SELECT
            RP_ID
            , SERVICE_ID
            , REPORT_CATEGORY
            , PLAN_ID
            , YUKO_FLG
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.M_BB_CORPORATE_PLN
        ) MBB
          ON TBB.RP_ID = MBB.RP_ID
          AND TBB.SERVICE_ID = MBB.SERVICE_ID
          AND TBB.REPORT_CATEGORY = MBB.REPORT_CATEGORY
          AND MBB.YUKO_FLG = '1'
      UNION ALL
      --個人契約サービス
      SELECT
        HASH_ID
        , SERIAL_ID
        , RP_ID
        , SERVICE_ID
        , PLAN_ID
        , PLAN_START_DATE
        , 1 AS CORP_FLG --個人契約
        , IFNULL(CANCELLATION_RESERVED_FLG, 0) AS CANCEL_FLG
        , IFNULL(LOST_W_FLG, 0) AS CHANGE_FLG
        , CASE
          WHEN PLAN_FLG = 0
          OR CHARGE_START_DATE > exec_date
          THEN 1
          ELSE 2
          END AS CHARGE_KBN
      FROM
        (
          SELECT
            HASH_ID
            , SERIAL_ID
            , RP_ID
            , SERVICE_ID
            , PLAN_ID
            , PLAN_START_DATE
            , CANCELLATION_RESERVED_FLG
            , LOST_W_FLG
            , PLAN_FLG
            , CHARGE_START_DATE
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_ANALYZE
          WHERE
            LATEST_CONTRACT_NO = CONTRACT_NO
            AND SERVICE_END_DATE >= exec_date
        )
      UNION ALL
      --GooglePlay契約サービス
      SELECT
        HASH_ID
        , SERIAL_ID
        , RP_ID
        , SERVICE_ID
        , PLAN_ID
        , DATE(FIRST_ENTRY_DATETIME) AS PLAN_START_DATE
        , 1 AS CORP_FLG --個人契約
        , CASE
          WHEN PERMIT_END_DATETIME = '9999-12-31 23:59:59'
          THEN 0
          ELSE 1
          END AS CANCEL_FLG
        , 0 AS CHANGE_FLG
        , 9 AS CHARGE_KBN
      FROM
        (
          SELECT
            HASH_ID
            , SERIAL_ID
            , RP_ID
            , SERVICE_ID
            , PLAN_ID
            , FIRST_ENTRY_DATETIME
            , PERMIT_END_DATETIME
            , ROW_NUMBER() OVER(
              PARTITION BY
                HASH_ID
              -- 重複する場合は「初回登録日時」が直近のものを採用
              ORDER BY
                FIRST_ENTRY_DATETIME DESC
            ) AS RANK
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING
          WHERE
            LATEST_EXTERNAL_SERVICE_PERMIT_KEY = EXTERNAL_SERVICE_PERMIT_KEY
            AND DATE(PERMIT_END_DATETIME) >= exec_date
        )
      WHERE
        RANK = 1
    ) SVC
    --退会していない一般ユーザーのみを抽出
    INNER JOIN (
      SELECT
        HASH_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE
      WHERE
        WITHDRAWAL_FLAG = '0' --会員
        AND USER_TYPE = '0' --一般ユーザー
    ) ATR
      ON SVC.HASH_ID = ATR.HASH_ID
    --電子版優先判定
    LEFT OUTER JOIN (
      SELECT
        HASH_ID
        , PRICEPLN_CD AS PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_DS_PRIORITY_PLN
    ) DS_PRI
      ON SVC.HASH_ID = DS_PRI.HASH_ID
      AND SVC.PLAN_ID = DS_PRI.PLAN_ID
    --サービス優先判定
    LEFT OUTER JOIN (
      SELECT
        HASH_ID
        , PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_SERVICE_PRIORITY_PLN
    ) SVC_PRI
      ON SVC.HASH_ID = SVC_PRI.HASH_ID
      AND SVC.PLAN_ID = SVC_PRI.PLAN_ID
    --グループ契約優先判定
    LEFT OUTER JOIN (
      SELECT
        HASH_ID
        , PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_GRP_PRIORITY_PLN
    ) GRP_PRI
      ON SVC.HASH_ID = GRP_PRI.HASH_ID
      AND SVC.PLAN_ID = GRP_PRI.PLAN_ID
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;