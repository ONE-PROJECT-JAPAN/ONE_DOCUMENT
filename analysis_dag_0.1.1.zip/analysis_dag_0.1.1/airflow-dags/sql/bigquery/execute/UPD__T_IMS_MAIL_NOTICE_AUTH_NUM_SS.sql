DECLARE target_table STRING DEFAULT 'T_IMS_MAIL_NOTICE_AUTH_NUM_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_MAIL_NOTICE_AUTH_NUM_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_MAIL_NOTICE_AUTH_NUM_SS (
    SNAPSHOT_DATE
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , PLAN_TYPE
    , SERVICE_REGIST_STATUS
    , MIGRATION_STATUS
    , MAIL_KIND
    , MAIL_NM
    , MAIL_TYPE
    , MAIL_AUTH_NUM
    , INS_DT_TM
  )
  (
    --電子版のRPID/サービスID/プランIDのマスタを作成する
    WITH DS_PLAN_MST AS (
      --個人契約（NKDK）
      SELECT DISTINCT
        KK_SERV.RP_ID
        , KK_SERV.SERVICE_ID
        , KK_PLAN.PLAN_ID
      FROM
        (
          SELECT DISTINCT
            RP_ID
            , SERVICE_ID
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.M_KK_M_SERVICE
          WHERE
            RP_ID = 'DS'
        ) KK_SERV
        INNER JOIN (
          SELECT DISTINCT
            SERVICE_ID
            , PLAN_ID
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.M_KK_M_PLAN
        ) KK_PLAN
          ON KK_SERV.SERVICE_ID = KK_PLAN.SERVICE_ID
      UNION DISTINCT
      --法人契約（NKBB）
      SELECT DISTINCT
        RP_ID
        , SERVICE_ID
        , PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_BB_CORPORATE_PLN
      WHERE
        RP_ID = 'DSB2B'
      UNION DISTINCT
      --アプリ契約（コードマスタで定義）
      SELECT DISTINCT
        VALUE1 AS RP_ID
        , VALUE2 AS SERVICE_ID
        , VALUE3 AS PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
      WHERE
        MASTER_TYPE = 'MST610'
        AND MASTER_GRP_TYPE = 'GCRM610'
        AND YUKO_FLG = '1'
    )
    --日経メール許諾を集計する
    SELECT
      exec_date AS SNAPSHOT_DATE
      , MST.RP_ID
      , MST.SERVICE_ID
      , MAD.PLAN_ID
      , MAD.PLAN_TYPE
      , MAD.SERVICE_REGIST_STATUS
      , MAD.MIGRATION_STATUS
      , CD.MAIL_KIND
      , CD.MAIL_NM
      , NULL AS MAIL_TYPE
      , MAD.MAIL_AUTH_NUM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          PRICEPLN_CD AS PLAN_ID
          , CASE
            WHEN PRICEPLN_KBN IN ('01', '02')
            THEN 'Y'
            WHEN PRICEPLN_KBN IN ('04')
            THEN 'M'
            ELSE NULL
            END AS PLAN_TYPE
          , CASE
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 0
            THEN 'NK'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 1
            THEN 'BP'
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 1
            THEN 'ALL'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 0
            THEN 'N/A'
            ELSE ''
            END AS SERVICE_REGIST_STATUS
          , CASE
            WHEN ORIGINAL_SITE = '9'
            THEN 'ICM'
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(ORIGINAL_SITE) = true
            THEN ''
            ELSE 'CMP'
            END AS MIGRATION_STATUS
          , COUNT(DISTINCT MAD.SERIAL_ID) AS MAIL_AUTH_NUM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
          INNER JOIN (
            SELECT
              HASH_ID
              , SERIAL_ID
              , NIKKEI_RP
              , BP_RP
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_USER_RP_REGISTRATION
          ) RP
            ON RP.SERIAL_ID = MAD.SERIAL_ID
        WHERE
          USER_TYPE = '一般ユーザー'
          AND WITHDRAWAL_FLAG = '会員'
          AND NIKKEI_MAIL_FLAG = '日経メール許諾'
        GROUP BY
          PLAN_ID
          , PLAN_TYPE
          , SERVICE_REGIST_STATUS
          , MIGRATION_STATUS
      ) MAD
      LEFT JOIN DS_PLAN_MST MST
        ON MAD.PLAN_ID = MST.PLAN_ID
      CROSS JOIN (
        SELECT DISTINCT
          VALUE1 AS MAIL_KIND
          , CODE_NAME1 AS MAIL_NM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
        WHERE
          MASTER_TYPE = 'MST610'
          AND MASTER_GRP_TYPE = 'GCRM611'
          AND YUKO_FLG = '1'
      ) CD
    UNION ALL
    --第三者メール許諾を集計する
    SELECT
      exec_date AS SNAPSHOT_DATE
      , MST.RP_ID
      , MST.SERVICE_ID
      , MAD.PLAN_ID
      , MAD.PLAN_TYPE
      , MAD.SERVICE_REGIST_STATUS
      , MAD.MIGRATION_STATUS
      , CD.MAIL_KIND
      , CD.MAIL_NM
      , NULL AS MAIL_TYPE
      , MAD.MAIL_AUTH_NUM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          PRICEPLN_CD AS PLAN_ID
          , CASE
            WHEN PRICEPLN_KBN IN ('01', '02')
            THEN 'Y'
            WHEN PRICEPLN_KBN IN ('04')
            THEN 'M'
            ELSE NULL
            END AS PLAN_TYPE
          , CASE
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 0
            THEN 'NK'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 1
            THEN 'BP'
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 1
            THEN 'ALL'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 0
            THEN 'N/A'
            ELSE ''
            END AS SERVICE_REGIST_STATUS
          , CASE
            WHEN ORIGINAL_SITE = '9'
            THEN 'ICM'
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(ORIGINAL_SITE) = true
            THEN ''
            ELSE 'CMP'
            END AS MIGRATION_STATUS
          , COUNT(DISTINCT MAD.SERIAL_ID) AS MAIL_AUTH_NUM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
          INNER JOIN (
            SELECT
              HASH_ID
              , SERIAL_ID
              , NIKKEI_RP
              , BP_RP
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_USER_RP_REGISTRATION
          ) RP
            ON RP.SERIAL_ID = MAD.SERIAL_ID
        WHERE
          USER_TYPE = '一般ユーザー'
          AND WITHDRAWAL_FLAG = '会員'
          AND THIRDPARTY_MAIL_FLAG = '第三者メール許諾'
        GROUP BY
          PLAN_ID
          , PLAN_TYPE
          , SERVICE_REGIST_STATUS
          , MIGRATION_STATUS
      ) MAD
      LEFT JOIN DS_PLAN_MST MST
        ON MAD.PLAN_ID = MST.PLAN_ID
      CROSS JOIN (
        SELECT DISTINCT
          VALUE1 AS MAIL_KIND
          , CODE_NAME1 AS MAIL_NM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
        WHERE
          MASTER_TYPE = 'MST610'
          AND MASTER_GRP_TYPE = 'GCRM612'
          AND YUKO_FLG = '1'
      ) CD
    UNION ALL
    --日経IDリサーチモニターを集計する
    SELECT
      exec_date AS SNAPSHOT_DATE
      , MST.RP_ID
      , MST.SERVICE_ID
      , MAD.PLAN_ID
      , MAD.PLAN_TYPE
      , MAD.SERVICE_REGIST_STATUS
      , MAD.MIGRATION_STATUS
      , CD.MAIL_KIND
      , CD.MAIL_NM
      , NULL AS MAIL_TYPE
      , MAD.MAIL_AUTH_NUM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          PRICEPLN_CD AS PLAN_ID
          , CASE
            WHEN PRICEPLN_KBN IN ('01', '02')
            THEN 'Y'
            WHEN PRICEPLN_KBN IN ('04')
            THEN 'M'
            ELSE NULL
            END AS PLAN_TYPE
          , CASE
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 0
            THEN 'NK'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 1
            THEN 'BP'
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 1
            THEN 'ALL'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 0
            THEN 'N/A'
            ELSE ''
            END AS SERVICE_REGIST_STATUS
          , CASE
            WHEN ORIGINAL_SITE = '9'
            THEN 'ICM'
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(ORIGINAL_SITE) = true
            THEN ''
            ELSE 'CMP'
            END AS MIGRATION_STATUS
          , COUNT(DISTINCT MAD.SERIAL_ID) AS MAIL_AUTH_NUM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
          INNER JOIN (
            SELECT
              HASH_ID
              , SERIAL_ID
              , NIKKEI_RP
              , BP_RP
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_USER_RP_REGISTRATION
          ) RP
            ON RP.SERIAL_ID = MAD.SERIAL_ID
        WHERE
          USER_TYPE = '一般ユーザー'
          AND WITHDRAWAL_FLAG = '会員'
          AND NIKKEI_MONITOR_FLAG = 'モニターを希望する'
        GROUP BY
          PLAN_ID
          , PLAN_TYPE
          , SERVICE_REGIST_STATUS
          , MIGRATION_STATUS
      ) MAD
      LEFT JOIN DS_PLAN_MST MST
        ON MAD.PLAN_ID = MST.PLAN_ID
      CROSS JOIN (
        SELECT DISTINCT
          VALUE1 AS MAIL_KIND
          , CODE_NAME1 AS MAIL_NM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
        WHERE
          MASTER_TYPE = 'MST610'
          AND MASTER_GRP_TYPE = 'GCRM613'
          AND YUKO_FLG = '1'
      ) CD
    UNION ALL
    --Myグループ更新通知メールを集計する
    SELECT
      exec_date AS SNAPSHOT_DATE
      , MST.RP_ID
      , MST.SERVICE_ID
      , MAD.PLAN_ID
      , MAD.PLAN_TYPE
      , MAD.SERVICE_REGIST_STATUS
      , MAD.MIGRATION_STATUS
      , CD.MAIL_KIND
      , CD.MAIL_NM
      , NULL AS MAIL_TYPE
      , MAD.MAIL_AUTH_NUM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          PRICEPLN_CD AS PLAN_ID
          , CASE
            WHEN PRICEPLN_KBN IN ('01', '02')
            THEN 'Y'
            WHEN PRICEPLN_KBN IN ('04')
            THEN 'M'
            ELSE NULL
            END AS PLAN_TYPE
          , CASE
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 0
            THEN 'NK'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 1
            THEN 'BP'
            WHEN RP.NIKKEI_RP = 1
            AND RP.BP_RP = 1
            THEN 'ALL'
            WHEN RP.NIKKEI_RP = 0
            AND RP.BP_RP = 0
            THEN 'N/A'
            ELSE ''
            END AS SERVICE_REGIST_STATUS
          , CASE
            WHEN ORIGINAL_SITE = '9'
            THEN 'ICM'
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(ORIGINAL_SITE) = true
            THEN ''
            ELSE 'CMP'
            END AS MIGRATION_STATUS
          , COUNT(DISTINCT MAD.SERIAL_ID) AS MAIL_AUTH_NUM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
          INNER JOIN (
            SELECT
              HASH_ID
              , SERIAL_ID
              , NIKKEI_RP
              , BP_RP
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_USER_RP_REGISTRATION
          ) RP
            ON RP.SERIAL_ID = MAD.SERIAL_ID
        WHERE
          USER_TYPE = '一般ユーザー'
          AND WITHDRAWAL_FLAG = '会員'
          AND UPDATE_NOTICE_MAIL_PC = 1
        GROUP BY
          PLAN_ID
          , PLAN_TYPE
          , SERVICE_REGIST_STATUS
          , MIGRATION_STATUS
      ) MAD
      LEFT JOIN DS_PLAN_MST MST
        ON MAD.PLAN_ID = MST.PLAN_ID
      CROSS JOIN (
        SELECT DISTINCT
          VALUE1 AS MAIL_KIND
          , CODE_NAME1 AS MAIL_NM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
        WHERE
          MASTER_TYPE = 'MST610'
          AND MASTER_GRP_TYPE = 'GCRM614'
          AND YUKO_FLG = '1'
      ) CD
    UNION ALL
    --電子版メルマガを集計する
    SELECT
      exec_date AS SNAPSHOT_DATE
      , MST.RP_ID
      , MST.SERVICE_ID
      , TRN.PLAN_ID
      , TRN.PLAN_TYPE
      , TRN.SERVICE_REGIST_STATUS
      , TRN.MIGRATION_STATUS
      , TRN.MAIL_KIND
      , TRN.MAIL_NM
      , TRN.MAIL_TYPE
      , TRN.MAIL_AUTH_NUM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          MAD.PLAN_ID
          , MAD.PLAN_TYPE
          , MAD.SERVICE_REGIST_STATUS
          , MAD.MIGRATION_STATUS
          , MST.MAIL_KIND
          , MST.MAIL_NM
          , TRN.MAIL_TYPE
          , SUM(
              CASE
              --有料メルマガかつ電子版有料契約
              WHEN (
                MST.MAIL_AUTH_KIND IN ('00', '01')
                AND MAD.PLAN_TYPE = 'Y'
              )
              THEN 1
              --無料メルマガかつ電子版無料契約
              WHEN MST.MAIL_AUTH_KIND IN ('00', '02')
              AND MAD.PLAN_TYPE = 'M'
              THEN 1
              --それ以外
              ELSE 0
              END
          ) AS MAIL_AUTH_NUM
        FROM
          --メール種別/メールタイプ（パソコン/携帯電話/プッシュ通知）のマスタを作成する
          (
            --メール種別
            SELECT DISTINCT
              SEND_MAIL_KIND AS MAIL_KIND
              , SEND_MAIL_NM AS MAIL_NM
              , MAIL_AUTH_KIND
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_MAIL_SEND_KIND
            WHERE
              DEL_FLG = '0'
              AND SEND_MAIL_KIND NOT IN (
                SELECT
                  VALUE1
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST620'
                  AND MASTER_GRP_TYPE IN ('GCRM62001', 'GCRM62002')
                  AND YUKO_FLG = '1'
              )
            UNION ALL
            -- Apportion経由でしか入ってこないメール種別 (NIKKEI Briefing, Nikkei Financial)
            SELECT
                VALUE1     AS MAIL_KIND
               ,CODE_NAME1 AS MAIL_NM
               ,VALUE2     AS MAIL_AUTH_KIND
            FROM
                {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
                MASTER_TYPE = 'MST620'
                AND MASTER_GRP_TYPE IN ('GCRM62001', 'GCRM62003')
                AND YUKO_FLG = '1'
          ) MST
          INNER JOIN (
            --パソコン
            SELECT
              HASH_ID
              , SERIAL_ID
              , SEND_MAIL_KIND AS MAIL_KIND
              , 'PC' AS MAIL_TYPE
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_MAIL_SET_INFO
            WHERE
              DEL_FLG = '0'
              AND MAIN_SEND_FLG = '1'
              --プッシュ通知は除く
              AND SEND_MAIL_KIND NOT IN (
                SELECT
                  VALUE1
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST610'
                  AND MASTER_GRP_TYPE = 'GCRM615'
                  AND YUKO_FLG = '1'
              )
              -- NIKKEI BriefingはT_DSU_T_DS_MAIL_SET_INFOから除く
              AND SEND_MAIL_KIND NOT IN (
                SELECT DISTINCT
                  VALUE1
                FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST620'
                  AND MASTER_GRP_TYPE = 'GCRM62001'
                  AND YUKO_FLG = '1'
              )
            UNION ALL
            --携帯電話
            SELECT
              HASH_ID
              , SERIAL_ID
              , SEND_MAIL_KIND AS MAIL_KIND
              , 'CP' AS MAIL_TYPE
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_MAIL_SET_INFO
            WHERE
              DEL_FLG = '0'
              AND SUB_SEND_FLG = '1'
              --プッシュ通知は除く
              AND SEND_MAIL_KIND NOT IN (
                SELECT DISTINCT
                  VALUE1
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST610'
                  AND MASTER_GRP_TYPE = 'GCRM615'
                  AND YUKO_FLG = '1'
              )
              -- NIKKEI BriefingはT_DSU_T_DS_MAIL_SET_INFOから除く
              AND SEND_MAIL_KIND NOT IN (
                SELECT DISTINCT
                  VALUE1
                FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST620'
                  AND MASTER_GRP_TYPE = 'GCRM62001'
                  AND YUKO_FLG = '1'
              )
            UNION ALL
            --プッシュ通知
            SELECT
              HASH_ID
              , SERIAL_ID
              , SEND_MAIL_KIND AS MAIL_KIND
              , 'PN' AS MAIL_TYPE
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_MAIL_SET_INFO
            WHERE
              DEL_FLG = '0'
              --パソコン/携帯電話の両方のフラグを一応確認する
              AND MAIN_SEND_FLG = '1'
              AND SUB_SEND_FLG = '1'
              --プッシュ通知を対象とする
              AND SEND_MAIL_KIND IN (
                SELECT DISTINCT
                  VALUE1
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST610'
                  AND MASTER_GRP_TYPE = 'GCRM615'
                  AND YUKO_FLG = '1'
              )
              -- NIKKEI BriefingはT_DSU_T_DS_MAIL_SET_INFOから除く
              AND SEND_MAIL_KIND NOT IN (
                SELECT DISTINCT
                  VALUE1
                FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
                WHERE
                  MASTER_TYPE = 'MST620'
                  AND MASTER_GRP_TYPE = 'GCRM62001'
                  AND YUKO_FLG = '1'
              )
              
            UNION ALL
            -----
            SELECT
                 HASH_ID
                ,SERIAL_ID
                ,SUB_CATEGORY AS MAIL_KIND
                ,'PC' AS MAIL_TYPE
            FROM
                {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_USER_MAIL_AUTH
            WHERE
                IS_ENABLED = 1
            AND
                --プッシュ通知は除く
                CATEGORY = 'mail'
            UNION ALL

            --プッシュ通知
            SELECT
                 HASH_ID
                ,SERIAL_ID
                ,SUB_CATEGORY AS MAIL_KIND
                ,'PN' AS MAIL_TYPE
            FROM
                {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_USER_MAIL_AUTH
            WHERE
                IS_ENABLED = 1
            AND
                CATEGORY = 'push'
          ) TRN
            ON MST.MAIL_KIND = TRN.MAIL_KIND
          INNER JOIN (
            SELECT
              PRICEPLN_CD AS PLAN_ID
              , CASE
                WHEN PRICEPLN_KBN IN ('01', '02')
                THEN 'Y'
                WHEN PRICEPLN_KBN IN ('04')
                THEN 'M'
                ELSE NULL
                END AS PLAN_TYPE
              , CASE
                WHEN RP.NIKKEI_RP = 1
                AND RP.BP_RP = 0
                THEN 'NK'
                WHEN RP.NIKKEI_RP = 0
                AND RP.BP_RP = 1
                THEN 'BP'
                WHEN RP.NIKKEI_RP = 1
                AND RP.BP_RP = 1
                THEN 'ALL'
                WHEN RP.NIKKEI_RP = 0
                AND RP.BP_RP = 0
                THEN 'N/A'
                ELSE ''
                END AS SERVICE_REGIST_STATUS
              , CASE
                WHEN ORIGINAL_SITE = '9'
                THEN 'ICM'
                WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(ORIGINAL_SITE) = true
                THEN ''
                ELSE 'CMP'
                END AS MIGRATION_STATUS
              , MAD.HASH_ID
              , MAD.SERIAL_ID
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
              INNER JOIN (
                SELECT
                  HASH_ID
                  , SERIAL_ID
                  , NIKKEI_RP
                  , BP_RP
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_USER_RP_REGISTRATION
              ) RP
                ON RP.SERIAL_ID = MAD.SERIAL_ID
            WHERE
              USER_TYPE = '一般ユーザー'
              AND WITHDRAWAL_FLAG = '会員'
          ) MAD
            ON TRN.SERIAL_ID = MAD.SERIAL_ID
        WHERE
          {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(SERVICE_REGIST_STATUS) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(MIGRATION_STATUS) = false
        GROUP BY
          MAD.PLAN_ID
          , MAD.PLAN_TYPE
          , MAD.SERVICE_REGIST_STATUS
          , MAD.MIGRATION_STATUS
          , MST.MAIL_KIND
          , MST.MAIL_NM
          , TRN.MAIL_TYPE
      ) TRN
      LEFT JOIN DS_PLAN_MST MST
        ON TRN.PLAN_ID = MST.PLAN_ID
  )
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;