DECLARE target_table STRING DEFAULT 'T_MM_PORT_CUSTOM_INFO_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_MM_PORT_CUSTOM_INFO_AC A
  USING (
    SELECT
      INSDATE
    , UPDATEDATE
    , HASH_ID
    , SERIAL_ID
    , SHOW_ID_1
    , SHOW_ID_2
    , SHOW_ID_3
    , SHOW_ID_4
    , SHOW_ID_5
    , SHOW_ID_6
    , SHOW_ID_7
    , SHOW_ID_8
    , SHOW_ID_9
    , SHOW_ID_10
    , SHOW_ID_11
    , SHOW_ID_12
    , SHOW_ID_13
    , SHOW_ID_14
    , SHOW_ID_15
    , SHOW_ID_16
    , SHOW_ID_17
    , SHOW_ID_18
    , SHOW_ID_19
    , SHOW_ID_20
    , SHOW_ID_21
    , SHOW_ID_22
    , SHOW_ID_23
    , SHOW_ID_24
    , SHOW_ID_25
    , SHOW_ID_26
    , SHOW_ID_27
    , SHOW_ID_28
    , SHOW_ID_29
    , SHOW_ID_30
    , 'IMS' as INS_BATCH_ID
    , exec_datetime as INS_DT_TM
    , 'IMS' as UPD_BATCH_ID
    , exec_datetime as UPD_DT_TM
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_MM_PORT_CUSTOM_INFO
  ) B
    ON A.HASH_ID = B.HASH_ID
  WHEN MATCHED THEN
    UPDATE
    SET
        INSDATE = B.INSDATE
      , UPDATEDATE = B.UPDATEDATE
      , SERIAL_ID = B.SERIAL_ID
      , SHOW_ID_1 = B.SHOW_ID_1
      , SHOW_ID_2 = B.SHOW_ID_2
      , SHOW_ID_3 = B.SHOW_ID_3
      , SHOW_ID_4 = B.SHOW_ID_4
      , SHOW_ID_5 = B.SHOW_ID_5
      , SHOW_ID_6 = B.SHOW_ID_6
      , SHOW_ID_7 = B.SHOW_ID_7
      , SHOW_ID_8 = B.SHOW_ID_8
      , SHOW_ID_9 = B.SHOW_ID_9
      , SHOW_ID_10 = B.SHOW_ID_10
      , SHOW_ID_11 = B.SHOW_ID_11
      , SHOW_ID_12 = B.SHOW_ID_12
      , SHOW_ID_13 = B.SHOW_ID_13
      , SHOW_ID_14 = B.SHOW_ID_14
      , SHOW_ID_15 = B.SHOW_ID_15
      , SHOW_ID_16 = B.SHOW_ID_16
      , SHOW_ID_17 = B.SHOW_ID_17
      , SHOW_ID_18 = B.SHOW_ID_18
      , SHOW_ID_19 = B.SHOW_ID_19
      , SHOW_ID_20 = B.SHOW_ID_20
      , SHOW_ID_21 = B.SHOW_ID_21
      , SHOW_ID_22 = B.SHOW_ID_22
      , SHOW_ID_23 = B.SHOW_ID_23
      , SHOW_ID_24 = B.SHOW_ID_24
      , SHOW_ID_25 = B.SHOW_ID_25
      , SHOW_ID_26 = B.SHOW_ID_26
      , SHOW_ID_27 = B.SHOW_ID_27
      , SHOW_ID_28 = B.SHOW_ID_28
      , SHOW_ID_29 = B.SHOW_ID_29
      , SHOW_ID_30 = B.SHOW_ID_30
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;