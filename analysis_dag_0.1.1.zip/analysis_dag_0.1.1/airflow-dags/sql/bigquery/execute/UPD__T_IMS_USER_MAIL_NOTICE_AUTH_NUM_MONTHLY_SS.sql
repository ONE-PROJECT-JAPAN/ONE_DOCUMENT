DECLARE target_table STRING DEFAULT 'T_IMS_USER_MAIL_NOTICE_AUTH_NUM_MONTHLY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_MAIL_NOTICE_AUTH_NUM_MONTHLY_SS
  WHERE snapshot_date = exec_date
  ;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_MAIL_NOTICE_AUTH_NUM_MONTHLY_SS
  WITH
  ds AS (
    SELECT
        HASH_ID
      , 1 AS TOTAL
      , CASE WHEN PRICEPLN_KBN <> '04' THEN 1 ELSE 0 END AS PAID_MEMBER
      , CASE WHEN PRICEPLN_KBN = '04' THEN 1 ELSE 0 END AS FREE_MEMBER
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
    WHERE
      1 = 1
      AND WITHDRAWAL_FLAG   = '会員'
      AND USER_TYPE = '一般ユーザー'
      AND NOT (NIKKEI_RP = 0 AND BP_RP = 1)
      AND PRICEPLN_KBN IN ('01', '02', '04')                                              -- 電子版会員を抽出
      AND PRICEPLN_CD NOT IN ('CRMDSB2B00000003', 'CRMDSB2BCP000003', 'CRMDSB2BCP100003') -- 業務ライセンス、業務ライセンスPro、法人Pro(グループ機能抑制版)を除外
  )
  , nk AS (
    SELECT
        HASH_ID
      , 1 AS TOTAL
      , CASE WHEN NIKKEI_RP = 0 AND BP_RP = 1 THEN 0 ELSE 1 END AS NIKKEI_ID_MEMBER
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
    WHERE
      1 = 1
      AND WITHDRAWAL_FLAG   = '会員'
      AND USER_TYPE = '一般ユーザー'
      AND ORIGINAL_SITE <> '9' -- 統合移行中会員を除く
  )
  , dsnk AS (
    SELECT
        sum(ifnull(ds.PAID_MEMBER, 0)) AS DS_PAID_MEMBER_COUNT
      , sum(ifnull(ds.FREE_MEMBER, 0)) AS DS_FREE_MEMBER_COUNT
      , sum(ifnull(ds.TOTAL, 0)) AS DS_MEMBER_TOTAL_COUNT
      , sum(ifnull(nk.NIKKEI_ID_MEMBER, 0)) AS NIKKEI_ID_MEMBER_COUNT_EXCEPT_RP
      , sum(ifnull(nk.TOTAL, 0)) AS NIKKEI_ID_TOTAL_COUNT
    FROM
      nk LEFT JOIN ds ON nk.HASH_ID = ds.HASH_ID
  )
  , IMS_MAIL_KIND AS (
    SELECT DISTINCT
        mail_kind
      , mail_nm
      , mail_type
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_MAIL_NOTICE_AUTH_NUM_SS
  )
  , DS_MEMBER_MAIL_PERMISSION AS (
    SELECT
        plan_type
      , mail_kind
      , mail_type
      , mail_auth_num
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_MAIL_NOTICE_AUTH_NUM_SS
    WHERE
      1 = 1
      AND date_trunc(snapshot_date, MONTH) = date_trunc(CURRENT_DATE, MONTH)
      AND ifnull(service_regist_status, '') <> 'BP'
      AND plan_type IN ('Y', 'M')
      AND plan_id NOT IN ('CRMDSB2B00000003', 'CRMDSB2BCP000003', 'CRMDSB2BCP100003')
  )
  , NIKKEI_ID_MAIL_PERMISSION AS (
  SELECT
      service_regist_status
    , mail_kind
    , mail_type
    , mail_auth_num
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_MAIL_NOTICE_AUTH_NUM_SS
  WHERE
    1 = 1
    AND date_trunc(snapshot_date, MONTH) = date_trunc(CURRENT_DATE, MONTH)
    AND ifnull(migration_status, '') <> 'ICM'

  )
  , tmp AS (
    SELECT
        '001' AS users_kind
      , 'DS_PAID_MEMBER_COUNT' AS users_kind_nm
      , DS_PAID_MEMBER_COUNT AS users_total_num
      , IMS_MAIL_KIND.mail_kind
      , mail_nm AS mail_kind_nm
      , IMS_MAIL_KIND.mail_type
      , ifnull(sum(mail_auth_num), 0) AS mail_notice_auth_num
    FROM
        dsnk
      , IMS_MAIL_KIND
        LEFT JOIN DS_MEMBER_MAIL_PERMISSION
          ON  IMS_MAIL_KIND.mail_kind = DS_MEMBER_MAIL_PERMISSION.mail_kind
          AND ifnull(IMS_MAIL_KIND.mail_type, '') = ifnull(DS_MEMBER_MAIL_PERMISSION.mail_type, '')
          AND plan_type = 'Y'
    GROUP BY
      DS_PAID_MEMBER_COUNT, IMS_MAIL_KIND.mail_kind, mail_nm, IMS_MAIL_KIND.mail_type

    UNION ALL
    SELECT
        '002'
      , 'DS_FREE_MEMBER_COUNT'
      , DS_FREE_MEMBER_COUNT
      , IMS_MAIL_KIND.mail_kind
      , mail_nm
      , IMS_MAIL_KIND.mail_type
      , ifnull(sum(mail_auth_num), 0)
    FROM
        dsnk
      , IMS_MAIL_KIND
        LEFT JOIN DS_MEMBER_MAIL_PERMISSION
          ON  IMS_MAIL_KIND.mail_kind = DS_MEMBER_MAIL_PERMISSION.mail_kind
          AND ifnull(IMS_MAIL_KIND.mail_type, '') = ifnull(DS_MEMBER_MAIL_PERMISSION.mail_type, '')
          AND plan_type = 'M'
    GROUP BY
      DS_FREE_MEMBER_COUNT, IMS_MAIL_KIND.mail_kind, mail_nm, IMS_MAIL_KIND.mail_type

    UNION ALL
    SELECT
        '003'
      , 'DS_MEMBER_TOTAL_COUNT'
      , DS_MEMBER_TOTAL_COUNT
      , IMS_MAIL_KIND.mail_kind
      , mail_nm
      , IMS_MAIL_KIND.mail_type
      , ifnull(sum(mail_auth_num), 0)
    FROM
        dsnk
      , IMS_MAIL_KIND
        LEFT JOIN DS_MEMBER_MAIL_PERMISSION
          ON  IMS_MAIL_KIND.mail_kind = DS_MEMBER_MAIL_PERMISSION.mail_kind
          AND ifnull(IMS_MAIL_KIND.mail_type, '') = ifnull(DS_MEMBER_MAIL_PERMISSION.mail_type, '')
    GROUP BY
      DS_MEMBER_TOTAL_COUNT, IMS_MAIL_KIND.mail_kind, mail_nm, IMS_MAIL_KIND.mail_type

    UNION ALL
    SELECT
        '004'
      , 'NIKKEI_ID_MEMBER_COUNT_EXCEPT_RP'
      , NIKKEI_ID_MEMBER_COUNT_EXCEPT_RP
      , IMS_MAIL_KIND.mail_kind
      , mail_nm
      , IMS_MAIL_KIND.mail_type
      , ifnull(sum(mail_auth_num), 0)
    FROM
        dsnk
      , IMS_MAIL_KIND
        LEFT JOIN NIKKEI_ID_MAIL_PERMISSION
          ON  IMS_MAIL_KIND.mail_kind = NIKKEI_ID_MAIL_PERMISSION.mail_kind
          AND ifnull(IMS_MAIL_KIND.mail_type, '') = ifnull(NIKKEI_ID_MAIL_PERMISSION.mail_type, '')
          AND ifnull(service_regist_status, '') <> 'BP'
    GROUP BY
      NIKKEI_ID_MEMBER_COUNT_EXCEPT_RP, IMS_MAIL_KIND.mail_kind, mail_nm, IMS_MAIL_KIND.mail_type

    UNION ALL
    SELECT
        '005'
      , 'NIKKEI_ID_TOTAL_COUNT'
      , NIKKEI_ID_TOTAL_COUNT
      , IMS_MAIL_KIND.mail_kind
      , mail_nm
      , IMS_MAIL_KIND.mail_type
      , ifnull(sum(mail_auth_num), 0)
    FROM
        dsnk
      , IMS_MAIL_KIND
        LEFT JOIN NIKKEI_ID_MAIL_PERMISSION
          ON  IMS_MAIL_KIND.mail_kind = NIKKEI_ID_MAIL_PERMISSION.mail_kind
          AND ifnull(IMS_MAIL_KIND.mail_type, '') = ifnull(NIKKEI_ID_MAIL_PERMISSION.mail_type, '')
    GROUP BY
      NIKKEI_ID_TOTAL_COUNT, IMS_MAIL_KIND.mail_kind, mail_nm, IMS_MAIL_KIND.mail_type
  )
  SELECT
      exec_date AS snapshot_date
    , users_kind
    , users_kind_nm
    , users_total_num
    , mail_kind
    , mail_kind_nm
    , mail_type
    , mail_notice_auth_num
  FROM
    tmp
  ORDER BY
    users_kind, mail_kind, mail_type desc
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
