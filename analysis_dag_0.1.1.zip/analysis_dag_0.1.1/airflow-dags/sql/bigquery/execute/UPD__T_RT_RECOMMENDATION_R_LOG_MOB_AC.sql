DECLARE target_table STRING DEFAULT 'T_RT_RECOMMENDATION_R_LOG_MOB_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_RT_RECOMMENDATION_R_LOG_MOB_AC A
  USING (
    SELECT
      MEMBER
      , SESSION_ID
      , IMPRESSION_DATE
      , CLICK_DATE
      , CONVERSION_DATE
      , RECOMMEND_POSITION
      , RECOMMEND_RULE
      , RECOMMEND
      , CONTENT
      , VISIT
      , PAGE_VIEW
      , IP_ADDR
      , SITE
      , PAGE
      , AREA
      , WEATHER
      , TEMPERATURE
      , 'IMS' AS INS_PGM_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_PGM_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_RT_RECOMMENDATION_R_LOG_MOB
  ) B
    ON A.MEMBER = B.MEMBER
    AND A.SESSION_ID = B.SESSION_ID
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      MEMBER = B.MEMBER
      , SESSION_ID = B.SESSION_ID
      , IMPRESSION_DATE = B.IMPRESSION_DATE
      , CLICK_DATE = B.CLICK_DATE
      , CONVERSION_DATE = B.CONVERSION_DATE
      , RECOMMEND_POSITION = B.RECOMMEND_POSITION
      , RECOMMEND_RULE = B.RECOMMEND_RULE
      , RECOMMEND = B.RECOMMEND
      , CONTENT = B.CONTENT
      , VISIT = B.VISIT
      , PAGE_VIEW = B.PAGE_VIEW
      , IP_ADDR = B.IP_ADDR
      , SITE = B.SITE
      , PAGE = B.PAGE
      , AREA = B.AREA
      , WEATHER = B.WEATHER
      , TEMPERATURE = B.TEMPERATURE
      , UPD_PGM_ID = B.UPD_PGM_ID
      , UPD_DT_TM = B.UPD_DT_TM
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;