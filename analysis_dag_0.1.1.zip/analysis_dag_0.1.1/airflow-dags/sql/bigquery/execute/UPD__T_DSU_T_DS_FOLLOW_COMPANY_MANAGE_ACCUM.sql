DECLARE target_table STRING DEFAULT 'T_DSU_T_DS_FOLLOW_COMPANY_MANAGE_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_FOLLOW_COMPANY_MANAGE_ACCUM A
  USING (
    SELECT
      INSDATE
      , UPDATEDATE
      , FOLLOW_TYPE
      , FOLLOW_ID
      , FOLLOW_NAME
      , NEWS_UPDATEDATE
      , DELETE_FLAG
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_FOLLOW_COMPANY_MANAGE B
  ) B
    ON A.FOLLOW_TYPE = B.FOLLOW_TYPE
    AND A.FOLLOW_ID = B.FOLLOW_ID
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      INSDATE = B.INSDATE
      , UPDATEDATE = B.UPDATEDATE
      , FOLLOW_TYPE = B.FOLLOW_TYPE
      , FOLLOW_ID = B.FOLLOW_ID
      , FOLLOW_NAME = B.FOLLOW_NAME
      , NEWS_UPDATEDATE = B.NEWS_UPDATEDATE
      , DELETE_FLAG = B.DELETE_FLAG
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;