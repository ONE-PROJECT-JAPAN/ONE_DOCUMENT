/*
  登録テーブル(Target):
    T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS
  参照テーブル(Source):
    V_IMS_SERVICE_USER_ID_WITH_FOROFFICE
    M_CRM_CODE
    T_KK_V_CONTRACT_ANALYZE
    T_BB_AGREEMENT_LIST
    M_BB_CORPORATE_PLN
  シリアルIDアップデート時参照テーブル:
    M_IS_OX_USER
*/
DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --追加・更新・削除処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS T
  USING (
    SELECT
        exec_date AS SNAPSHOT_DATE
      , view.HASH_ID
      , view.SERIAL_ID
      , view.RP_ID
      , view.SERVICE_ID
      , view.PLAN_ID
      , view.FOROFFICE_RP_ID
      , view.FOROFFICE_SERVICE_ID
      , view.FOROFFICE_PLAN_ID
      , view.FOROFFICE_PRODUCT_NAME
      , kk.PLAN_START_DATE
      , CASE WHEN bb.USESTART_DATE IS NULL THEN bb_forOffice.USESTART_DATE ELSE bb.USESTART_DATE END AS USESTART_DATE
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      -- 会員ID日別サービス契約ビュー
      {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_SERVICE_USER_ID_WITH_FOROFFICE view
      INNER JOIN
        -- プロメディア用マート抽出対象サービス
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE code
        ON  view.SERVICE_ID = code.VALUE1
        AND view.PLAN_ID = code.VALUE2
        AND code.MASTER_TYPE = 'MST650'
        AND code.YUKO_FLG = '1'
      LEFT OUTER JOIN
        -- 契約情報分析VIEW:PLAN_START_DATE取得用
        {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_ANALYZE kk
        ON  view.HASH_ID = kk.HASH_ID
        AND view.RP_ID = kk.RP_ID
        AND view.SERVICE_ID = kk.SERVICE_ID
        AND view.PLAN_ID = kk.PLAN_ID
      LEFT OUTER JOIN
        -- 法人契約者リスト、法人プランマスタ:USESTART_DATE取得用
        (
          SELECT
              tbb.HASH_ID
            , tbb.RP_ID
            , tbb.SERVICE_ID
            , tbb.USESTART_DATE
            , mbb.PLAN_ID
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST tbb
            INNER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_BB_CORPORATE_PLN mbb
              ON  tbb.RP_ID = mbb.RP_ID
              AND tbb.SERVICE_ID = mbb.SERVICE_ID
              AND tbb.REPORT_CATEGORY = mbb.REPORT_CATEGORY) bb
        ON  view.HASH_ID = bb.HASH_ID
        AND view.RP_ID = bb.RP_ID
        AND view.SERVICE_ID = bb.SERVICE_ID
        AND view.PLAN_ID = bb.PLAN_ID
      LEFT OUTER JOIN
        -- 法人契約者リスト、法人プランマスタ forOffice:USESTART_DATE取得用
        (
          SELECT
              tbb.HASH_ID
            , tbb.RP_ID
            , tbb.SERVICE_ID
            , tbb.USESTART_DATE
            , mbb.PLAN_ID
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST tbb
            INNER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_BB_CORPORATE_PLN mbb
              ON  tbb.RP_ID = mbb.RP_ID
              AND tbb.SERVICE_ID = mbb.SERVICE_ID
              AND tbb.REPORT_CATEGORY = mbb.REPORT_CATEGORY) bb_forOffice
        ON  view.HASH_ID = bb_forOffice.HASH_ID
        AND view.FOROFFICE_RP_ID = bb_forOffice.RP_ID
        AND view.FOROFFICE_SERVICE_ID = bb_forOffice.SERVICE_ID
        AND view.FOROFFICE_PLAN_ID = bb_forOffice.PLAN_ID
  ) S
    -- スナップショット日付が当日かつ、会員ID日別サービス契約ビューの下記が一致している場合はUPDATE、一致しない場合はINSERT、一致しない場合かつ当日データの場合は削除
    -- [RP_ID, SERVICE_ID, PLAN_ID]:個人・法人・forOffice用に展開した内包サービス
    -- [FOROFFICE_RP_ID, FOROFFICE_SERVICE_ID, FOROFFICE_PLAN_ID]:forOfficeサービス(forOfficeサービス以外はNULL)
    ON (
      T.SNAPSHOT_DATE = S.SNAPSHOT_DATE
      AND T.HASH_ID = S.HASH_ID
      AND T.RP_ID = S.RP_ID
      AND T.SERVICE_ID = S.SERVICE_ID
      AND T.PLAN_ID = S.PLAN_ID
      AND COALESCE(T.FOROFFICE_RP_ID, '') = COALESCE(S.FOROFFICE_RP_ID, '')
      AND COALESCE(T.FOROFFICE_SERVICE_ID, '') = COALESCE(S.FOROFFICE_SERVICE_ID, '')
      AND COALESCE(T.FOROFFICE_PLAN_ID, '') = COALESCE(S.FOROFFICE_PLAN_ID, ''))
  WHEN MATCHED THEN
    UPDATE SET
      -- 「契約情報分析VIEW:PLAN_START_DATE」「法人契約者リスト、法人プランマスタ:USESTART_DATE」が後から更新された場合を考慮
        SERIAL_ID = S.SERIAL_ID
      , PLAN_START_DATE = S.PLAN_START_DATE
      , USESTART_DATE = S.USESTART_DATE
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY SOURCE AND SNAPSHOT_DATE = DATE(CURRENT_DATETIME('Asia/Tokyo')) THEN
    DELETE
  WHEN NOT MATCHED THEN
    INSERT ROW
  ;

  -- SERIAL_ID がNULLのデータ（7日以前）について、オープン化ユーザID管理テーブルから最新のSERIAL_IDを取得してUPDATE
  UPDATE
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS SS
  SET
      SS.SERIAL_ID = OX.SERIAL_ID
    , SS.UPD_BATCH_ID = 'IMS'
    , SS.UPD_DT_TM = exec_datetime
  FROM
    (
      SELECT
          DISTINCT(SERIAL_ID)
        , HASH_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_OX_USER
      WHERE
        SERIAL_ID IS NOT NULL) OX
  WHERE
        SS.HASH_ID = OX.HASH_ID
    AND SS.SNAPSHOT_DATE >= DATE_SUB(exec_date, INTERVAL 7 DAY)
    AND SS.SERIAL_ID IS NULL
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
