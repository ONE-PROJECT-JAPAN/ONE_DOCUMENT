/*

   参照テーブル:
      M_CRM_CODE
      M_IS_NX_ATTRIBUTE_IF_ACCUM
      M_IS_NX_MIGRATION
      V_BI_DSP_USER_DAILY_SS
        M_BI_TIME
        M_CRM_CODE
        T_BI_USER_NUM_DAILY_KBN_PAST_SS
        T_BI_USER_NUM_DAILY_KBN_SS
        T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_SS
        T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_LASTDAY_SS
        V_BI_USER_NUM_DAILY_PLN_SS
          T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_SS
          T_BI_USER_NUM_DAILY_KBN_SS
          T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_LASTDAY_SS
      V_BI_USER_ID_DS_PRIORITY_PLN
        M_BB_CORPORATE_PLN
        M_CRM_CODE
        M_IS_NX_ATTRIBUTE
        T_BB_AGREEMENT_LIST
        T_KK_V_CONTRACT_ANALYZE
        T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING

*/
DECLARE target_table STRING DEFAULT 'T_IMS_USER_NUM_DAILY_KBN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_KBN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_KBN_SS
  (
        SNAPSHOT_DATE
      , DSP_USERNUM_KBN
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  WITH
          
      USER_COUNT_08 AS
      (SELECT 
         exec_date AS SNAPSHOT_DATE
         , '08' AS DSP_USERNUM_KBN
         , CASE WHEN A.PRICEPLN_SYSTEM_ID = '99' THEN
             NULL
           ELSE
             A.PRICEPLN_SYSTEM_ID 
           END AS PRICEPLN_SYSTEM_ID
         , A.USER_COUNT
         , '{{ dag.dag_id }}' AS INS_PGM_ID                          
         , exec_datetime AS INS_DT_TM    
         , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
         , exec_datetime AS UPD_DT_TM    
      FROM (
        SELECT
            C.PRICEPLN_SYSTEM_ID        AS PRICEPLN_SYSTEM_ID
         ,  COUNT(M.PRICEPLN_SYSTEM_ID) AS USER_COUNT
        FROM
          (
            SELECT
              CODE AS PRICEPLN_SYSTEM_ID 
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST450'
            AND
              MASTER_GRP_TYPE = 'GCRM450'
            AND
              YUKO_FLG = '1'
            UNION ALL
            SELECT
              '99' AS PRICEPLN_SYSTEM_ID
          ) C
        LEFT OUTER JOIN
          (
            SELECT
              CASE WHEN T.PRICEPLN_SYSTEM_ID IS NOT NULL THEN
                T.PRICEPLN_SYSTEM_ID
              ELSE
                '99'
              END AS PRICEPLN_SYSTEM_ID
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE_IF_ACCUM attr       
              LEFT OUTER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION mig_bp ON           
              attr.HASH_ID = mig_bp.HASH_ID
              LEFT OUTER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION mig_id ON           
              mig_bp.EST_IDENTICAL_HASH_ID = mig_id.HASH_ID
              LEFT OUTER JOIN
              (
                SELECT
                   HASH_ID
                  ,PRICEPLN_SYSTEM_ID
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_DS_PRIORITY_PLN     
                GROUP BY
                  HASH_ID
                 ,PRICEPLN_SYSTEM_ID
              ) T ON
              attr.HASH_ID = T.HASH_ID
            WHERE
              
              (IFNULL(attr.WITHDRAWAL_FLAG,'0') <> '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '0'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.EMAIL_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.MRG_ORG_SITE,'NID') = 'NID')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '0'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '0'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '1'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') <> '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.EMAIL_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.MRG_ORG_SITE,'NID') = 'NID')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
                  AND IFNULL(mig_id.MRG_ORG_SITE,'NID') <> 'BPPM')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') <> '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '1'
                  AND IFNULL(mig_bp.EMAIL_STATUS,'0') = '1'
                  AND IFNULL(mig_bp.MRG_ORG_SITE,'NID') = 'NID')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
                  AND IFNULL(mig_bp.MERGE_STATUS,'0') = '9'
                  AND IFNULL(mig_bp.EMAIL_STATUS,'0') = '1'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM')
              
              OR (IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
                  AND IFNULL(mig_bp.ATTR_STATUS,'0') = '1'
                  AND IFNULL(mig_bp.EMAIL_STATUS,'0') <> '1'
                  AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
                  AND mig_id.MRG_ORG_SITE IS NULL)
            ) M
            ON C.PRICEPLN_SYSTEM_ID = M.PRICEPLN_SYSTEM_ID
        GROUP BY
          C.PRICEPLN_SYSTEM_ID
        ) A
      )
      ,
      
      USER_COUNT_09 AS
      (SELECT 
          exec_date AS SNAPSHOT_DATE
          , '09' AS DSP_USERNUM_KBN
          , CASE WHEN A.PRICEPLN_SYSTEM_ID = '99' THEN
              NULL
            ELSE
              A.PRICEPLN_SYSTEM_ID 
            END AS PRICEPLN_SYSTEM_ID
          , A.USER_COUNT
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM (
        SELECT
            C.PRICEPLN_SYSTEM_ID        AS PRICEPLN_SYSTEM_ID
          , COUNT(M.PRICEPLN_SYSTEM_ID) AS USER_COUNT
        FROM
          (
            SELECT
              CODE AS PRICEPLN_SYSTEM_ID 
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST450'
            AND
              MASTER_GRP_TYPE = 'GCRM450'
            AND
              YUKO_FLG = '1'
            UNION ALL
            SELECT
              '99' AS PRICEPLN_SYSTEM_ID
          ) C
        LEFT OUTER JOIN
          (
            SELECT
              CASE WHEN T.PRICEPLN_SYSTEM_ID IS NOT NULL THEN
                T.PRICEPLN_SYSTEM_ID
              ELSE
                '99'
              END AS PRICEPLN_SYSTEM_ID
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE_IF_ACCUM attr       
              LEFT OUTER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION mig_bp ON           
              attr.HASH_ID = mig_bp.HASH_ID
              LEFT OUTER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_MIGRATION mig_id ON           
              mig_bp.EST_IDENTICAL_HASH_ID = mig_id.HASH_ID
              LEFT OUTER JOIN
              (  
                SELECT
                  HASH_ID
                 ,PRICEPLN_SYSTEM_ID
                FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_DS_PRIORITY_PLN     
                GROUP BY
                  HASH_ID
                 ,PRICEPLN_SYSTEM_ID
              ) T ON
              attr.HASH_ID = T.HASH_ID
            WHERE  
              
              IFNULL(attr.WITHDRAWAL_FLAG,'0') = '1'
              AND IFNULL(mig_bp.ORIGINAL_SITE,'NID') = 'BPPM'
              AND IFNULL(mig_id.MRG_ORG_SITE,'NID') = 'BPPM'
          ) M
          ON C.PRICEPLN_SYSTEM_ID = M.PRICEPLN_SYSTEM_ID
        GROUP BY
          C.PRICEPLN_SYSTEM_ID
        )A
      )
      
      SELECT SNAPSHOT_DATE
          , '01' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_ID
          , USER_COUNT
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_DSP_USER_DAILY_SS                                       
      WHERE SNAPSHOT_DATE = exec_date
          AND DSP_USERNUM_CODE = 'CRM06001'                            
          AND RECORD_KBN = 1
  UNION ALL
      
      SELECT USER_COUNT_08.SNAPSHOT_DATE
          , '07' AS DSP_USERNUM_KBN
          , '03' AS PRICEPLN_SYSTEM_ID
          , IFNULL(USER_COUNT_08.USER_COUNT, 0) + IFNULL(USER_COUNT_09.USER_COUNT, 0)
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM USER_COUNT_08, USER_COUNT_09
      WHERE
              USER_COUNT_08.PRICEPLN_SYSTEM_ID = '03'
          AND USER_COUNT_09.PRICEPLN_SYSTEM_ID = '03'
  UNION ALL
      
      SELECT USER_COUNT_08.SNAPSHOT_DATE
          , '07' AS DSP_USERNUM_KBN
          , '02' AS PRICEPLN_SYSTEM_ID
          , IFNULL(USER_COUNT_08.USER_COUNT, 0) + IFNULL(USER_COUNT_09.USER_COUNT, 0)
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM USER_COUNT_08, USER_COUNT_09
      WHERE
              USER_COUNT_08.PRICEPLN_SYSTEM_ID = '02'
          AND USER_COUNT_09.PRICEPLN_SYSTEM_ID = '02'
  UNION ALL
      
      SELECT USER_COUNT_08.SNAPSHOT_DATE
          , '07' AS DSP_USERNUM_KBN
          , '04' AS PRICEPLN_SYSTEM_ID
          , IFNULL(USER_COUNT_08.USER_COUNT, 0) + IFNULL(USER_COUNT_09.USER_COUNT, 0)
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM USER_COUNT_08, USER_COUNT_09
      WHERE
              USER_COUNT_08.PRICEPLN_SYSTEM_ID = '04'
          AND USER_COUNT_09.PRICEPLN_SYSTEM_ID = '04'
  UNION ALL
      
      SELECT USER_COUNT_08.SNAPSHOT_DATE
          , '07' AS DSP_USERNUM_KBN
          , NULL AS PRICEPLN_SYSTEM_ID
          , IFNULL(USER_COUNT_08.USER_COUNT, 0) + IFNULL(USER_COUNT_09.USER_COUNT, 0)
          , '{{ dag.dag_id }}' AS INS_PGM_ID                          
          , exec_datetime AS INS_DT_TM    
          , '{{ dag.dag_id }}' AS UPD_PGM_ID                          
          , exec_datetime AS UPD_DT_TM    
      FROM USER_COUNT_08, USER_COUNT_09
      WHERE
              USER_COUNT_08.PRICEPLN_SYSTEM_ID IS NULL
          AND USER_COUNT_09.PRICEPLN_SYSTEM_ID IS NULL
  UNION ALL
      
      SELECT SNAPSHOT_DATE
           , DSP_USERNUM_KBN
           , PRICEPLN_SYSTEM_ID
           , USER_COUNT
           , INS_PGM_ID
           , INS_DT_TM
           , UPD_PGM_ID
           , UPD_DT_TM
       FROM USER_COUNT_08
          
  UNION ALL
      
      SELECT SNAPSHOT_DATE
           , DSP_USERNUM_KBN
           , PRICEPLN_SYSTEM_ID
           , USER_COUNT
           , INS_PGM_ID
           , INS_DT_TM
           , UPD_PGM_ID
           , UPD_DT_TM
      FROM USER_COUNT_09
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
