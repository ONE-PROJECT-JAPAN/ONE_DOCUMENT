DECLARE target_table STRING DEFAULT 'M_IS_NX_RP_REGISTRATION_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_RP_REGISTRATION_ACCUM A
  USING (
    SELECT
        HASH_ID
      , SERIAL_ID
      , RP_ID
      , REG_STATUS
      , CREATE_DATE
      , CREATE_USER
      , UPDATE_DATE
      , UPDATE_USER
      , DELETE_DATE
      , DELETE_USER
      , DELETE_FLG
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_RP_REGISTRATION
  ) B
    ON A.HASH_ID      = B.HASH_ID
    AND A.RP_ID       = B.RP_ID
    AND A.CREATE_DATE = B.CREATE_DATE
    AND A.UPDATE_DATE = B.UPDATE_DATE
  WHEN MATCHED THEN
    -- IF/ACCUMの両方に存在
    UPDATE
    SET
        SERIAL_ID   = B.SERIAL_ID
      , RP_ID       = B.RP_ID
      , REG_STATUS  = B.REG_STATUS
      , CREATE_DATE = B.CREATE_DATE
      , CREATE_USER = B.CREATE_USER
      , UPDATE_DATE = B.UPDATE_DATE
      , UPDATE_USER = B.UPDATE_USER
      , DELETE_DATE = B.DELETE_DATE
      , DELETE_USER = B.DELETE_USER
      , DELETE_FLG  = B.DELETE_FLG
      , UPD_BATCH_ID= 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    -- IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
