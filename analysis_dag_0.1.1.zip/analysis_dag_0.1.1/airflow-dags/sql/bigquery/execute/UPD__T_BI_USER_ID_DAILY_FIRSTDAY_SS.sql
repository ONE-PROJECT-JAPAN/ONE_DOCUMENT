DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_FIRSTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE first_day DATE DEFAULT DATE_TRUNC(exec_date, MONTH); --当月1日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_FIRSTDAY_SS
  WHERE SNAPSHOT_DATE = first_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_FIRSTDAY_SS (
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , PRICEPLN_CD_SYSTEM_ID
    , PRICEPLN_CD
    , TRIAL_FLG
    , ZIP_CODE
    , ADDRESS_CODE
    , OCCUPATION_NO
    , BUSINESS_NO
    , JOB_NO
    , POSITION_NO
    , EMPLOYEES_NO
    , INCOME_NO
    , NIKKEI_MAIL_FLAG
    , THIRDPARTY_MAIL_FLAG
    , NIKKEI_MONITOR_FLAG
    , ENTRY_DATE
    , WITHDRAWAL_DATE
    , CREATE_DATE
    , UPDATE_DATE
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , SEX
    , BIRTHDAY
    , AGE
    , STATE_POSTAL
    , CHARGE_KBN
    , COUNTRY_CODE
    , RESIDENT_ABROAD
  )
  SELECT
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , PRICEPLN_CD_SYSTEM_ID
    , PRICEPLN_CD
    , TRIAL_FLG
    , ZIP_CODE
    , ADDRESS_CODE
    , OCCUPATION_NO
    , BUSINESS_NO
    , JOB_NO
    , POSITION_NO
    , EMPLOYEES_NO
    , INCOME_NO
    , NIKKEI_MAIL_FLAG
    , THIRDPARTY_MAIL_FLAG
    , NIKKEI_MONITOR_FLAG
    , ENTRY_DATE
    , WITHDRAWAL_DATE
    , CREATE_DATE
    , UPDATE_DATE
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , SEX
    , BIRTHDAY
    , AGE
    , STATE_POSTAL
    , CHARGE_KBN
    , COUNTRY_CODE
    , RESIDENT_ABROAD
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SS
  WHERE
    SNAPSHOT_DATE = first_day
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;