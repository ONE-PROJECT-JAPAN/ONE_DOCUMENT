DECLARE target_table STRING DEFAULT 'T_BB_USER_NUM_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_USER_NUM_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS
  WHERE DATE(INS_DT_TM) = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_USER_NUM_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS
  (
      SNAPSHOT_DATE
    , RP_ID
    , SERVICE_ID
    , REPORT_CATEGORY
    , USER_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
      BB.SNAPSHOT_DATE           AS SNAPSHOT_DATE
    , BB.RP_ID                   AS RP_ID
    , BB.SERVICE_ID              AS SERVICE_ID
    , BB.REPORT_CATEGORY         AS REPORT_CATEGORYAS
    , COUNT(BB.SERIAL_ID)        AS USER_COUNT
    , '{{ dag.dag_id }}'
    , exec_datetime
    , '{{ dag.dag_id }}'
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS  BB
  WHERE
    BB.SNAPSHOT_DATE = exec_date
  GROUP BY
      BB.SNAPSHOT_DATE
    , BB.RP_ID
    , BB.SERVICE_ID
    , BB.REPORT_CATEGORY
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;