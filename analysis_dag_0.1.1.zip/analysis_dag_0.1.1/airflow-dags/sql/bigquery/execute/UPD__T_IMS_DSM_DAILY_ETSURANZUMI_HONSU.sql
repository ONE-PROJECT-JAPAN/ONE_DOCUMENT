DECLARE target_table STRING DEFAULT 'T_IMS_DSM_DAILY_ETSURANZUMI_HONSU';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE yesterday DEFAULT DATE_ADD(exec_date, INTERVAL -1 DAY);

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_DSM_DAILY_ETSURANZUMI_HONSU
  WHERE ETSURANZUMI_DATE = yesterday
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_DSM_DAILY_ETSURANZUMI_HONSU (
    ETSURANZUMI_DATE
    , HASH_ID
    , SERIAL_ID
    , ETSURANZUMI_HONSU
    , INS_DT_TM
  )
  SELECT
    DATE(AC.INSDATE) AS ETSURANZUMI_DATE
    , AC.HASH_ID
    , AC.SERIAL_ID
    , COUNT(AC.HASH_ID) AS ETSURANZUMI_HONSU
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM AC
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID NK
      ON NK.HASH_ID = AC.HASH_ID
      AND NK.PRICEPLN_KBN = '04'
  WHERE
    DATE(AC.INSDATE) = yesterday
  GROUP BY
    ETSURANZUMI_DATE
    , HASH_ID
    , SERIAL_ID
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;