DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE first_day DATE DEFAULT DATE_TRUNC(exec_date, MONTH); --当月1日
DECLARE last_month_last_day DATE DEFAULT DATE_ADD(first_day, INTERVAL -1 DAY); --先月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS
  WHERE SNAPSHOT_DATE = last_month_last_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS (
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , CORP_FLG
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , CANCEL_FLG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , CHARGE_KBN
  )
  SELECT
    last_month_last_day
    , HASH_ID
    , SERIAL_ID
    , CORP_FLG
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , CANCEL_FLG
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
    , CHARGE_KBN
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_SERVICE_PRIORITY_PLN_LASTDAY
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;