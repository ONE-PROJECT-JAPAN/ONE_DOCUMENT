DECLARE target_table STRING DEFAULT 'T_IMS_USER_BRIEFING_MAIL_AUTH';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_BRIEFING_MAIL_AUTH A
  USING (
    SELECT
      USER_INFO.HASH_ID
      , USER_INFO.SERIAL_ID
      , MAIL_INFO.SEND_MAIL_KIND
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          IFNULL(HASH_ID, '') HASH_ID
          , SERIAL_ID
          , MAD.PRICEPLN_KBN
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID MAD
        WHERE
          WITHDRAWAL_FLAG = '会員'
          AND USER_TYPE = '一般ユーザー'
          AND ORIGINAL_SITE <> '9'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(PRICEPLN_CD) = false
          AND PRICEPLN_CD NOT IN ('DS00000000000001')
      ) AS USER_INFO
      INNER JOIN (
        SELECT
            IFNULL(MAIL_INFO.HASH_ID, '') HASH_ID
          , MAIL_INFO.SERIAL_ID
          , MAIL_KIND.MAIL_AUTH_KIND
          , MAIL_KIND.SEND_MAIL_KIND
        FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_USER_MAIL_AUTH AS MAIL_INFO
          , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_MAIL_SEND_KIND AS MAIL_KIND
        WHERE
          MAIL_INFO.SUB_CATEGORY = MAIL_KIND.SEND_MAIL_KIND
          --削除フラグ
          AND MAIL_KIND.DEL_FLG = '0'
          --PCメールフラグ
          AND MAIL_INFO.IS_ENABLED = 1
          --SEND_MAIL_KINDのブラックリストに含まれていないこと
          AND MAIL_KIND.SEND_MAIL_KIND NOT IN (
            SELECT
              VALUE1
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST620'
              AND MASTER_GRP_TYPE = 'GCRM62002'
              AND YUKO_FLG = '1'
          )
          --NIKKEI Briefingであること
          AND MAIL_KIND.SEND_MAIL_KIND IN (
              SELECT
                  VALUE1
              FROM
                  {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE 
              WHERE
                  MASTER_TYPE = 'MST620' 
                  AND MASTER_GRP_TYPE = 'GCRM62001'
                  AND YUKO_FLG = '1'
          )
      ) AS MAIL_INFO
        ON USER_INFO.SERIAL_ID = MAIL_INFO.SERIAL_ID
    WHERE
      MAIL_INFO.MAIL_AUTH_KIND = '00'
      OR (
        MAIL_INFO.MAIL_AUTH_KIND = '01'
        AND USER_INFO.PRICEPLN_KBN IN ('01', '02')
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;