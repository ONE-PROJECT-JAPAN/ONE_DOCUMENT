DECLARE target_table STRING DEFAULT 'T_IMS_USER_DS_LAST_ACCESS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_DS_LAST_ACCESS A
  USING (
    WITH MAD AS (
      SELECT
        HASH_ID
        , SERIAL_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
      WHERE
        {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(SERIAL_ID) = false
    ),
    --直近電子版訪問状況
    ATL AS (
      SELECT
        ig_usr_user_id AS SERIAL_ID
        , DATETIME(MAX(er_dat_jp_timestamp)) AS LAST_ACCESS_DT_TM
      FROM
        atlas.v_atlas_yesterday
      WHERE
        ig_sys_source <> 'adobe_analytics'
        AND ig_ctx_product_family = 'DS'
        AND ig_category = 'page'
        AND ig_action = 'view'
        AND ig_usr_user_id IS NOT NULL
        AND er_bot_is_bot = false
      GROUP BY
        ig_usr_user_id
    )
    --過去データと新データを結合して日時が新しいほうを採用
    SELECT
      HASH_ID
      , SERIAL_ID
      , MAX(LAST_ACCESS_DT_TM) AS LAST_ACCESS_DT_TM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          HASH_ID
          , SERIAL_ID
          , LAST_ACCESS_DT_TM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_DS_LAST_ACCESS
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , ATL.LAST_ACCESS_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN ATL
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
      )
    GROUP BY
      HASH_ID
      , SERIAL_ID
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;