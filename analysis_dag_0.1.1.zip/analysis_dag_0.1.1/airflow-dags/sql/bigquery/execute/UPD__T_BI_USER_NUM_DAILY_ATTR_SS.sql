DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_ATTR_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_ATTR_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_ATTR_SS(
    SNAPSHOT_DATE
    , RP_KBN
    , ATTRIBUTE_KBN1
    , ATTRIBUTE_KBN2
    , PRICEPLN_SYSTEM_ID
    , USER_COUNT
    , USER_COUNT_DSR3
    , USER_COUNT_DSR2
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
    exec_date
    , RP_KBN
    , ATTRIBUTE_KBN1
    , ATTRIBUTE_KBN2
    , PRICEPLN_SYSTEM_ID
    , USER_NUM
    , USER_COUNT_DSR3
    , USER_COUNT_DSR2
    , 'IMS' AS INS_BATCH_ID
    , exec_datetime AS INS_DT_TM
    , 'IMS' AS UPD_BATCH_ID
    , exec_datetime AS UPD_DT_TM
  FROM
    (
      (
        --区分：職業(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.OCCUPATION_NO = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM010'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：所属(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.JOB_NO = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM011'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：役職(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.POSITION_NO = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM012'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：年収(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.INCOME_NO = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM013'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：地域(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.PREFEC = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM014'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：年代(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.V_M_IS_AGE
            ON M_AD_NIKKEI_ID.BIRTH >= V_M_IS_AGE.AGE_FROM2
            AND M_AD_NIKKEI_ID.BIRTH <= V_M_IS_AGE.AGE_TO2
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON V_M_IS_AGE.AGE2 = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM015'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND M_AD_NIKKEI_ID.BIRTH <> '18680101'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：性別(日経ID会員)
        SELECT
          'CRM160001' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06003' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR3
          , SUM(
            CASE M_CRM_RKN_PLN.PLNSUM_CD
              WHEN 'CRM06004' THEN 1
              ELSE 0
              END
          ) AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.SEX = M_CRM_CODE.VALUE1
          LEFT JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_RKN_PLN
            ON M_AD_NIKKEI_ID.PRICEPLN_CD = M_CRM_RKN_PLN.PRICEPLN_CD
            AND M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID = M_CRM_RKN_PLN.PRICEPLN_SYSTEM_ID
            AND M_CRM_RKN_PLN.PLNSUM_CD IN ('CRM06003', 'CRM06004')
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM016'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：職業(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.OCCUPATION_NO = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM010'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：所属(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.JOB_NO = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM011'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：役職(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.POSITION_NO = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM012'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：年収(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.INCOME_NO = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM013'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：地域(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.PREFEC = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM014'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：年代(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.V_M_IS_AGE
            ON M_AD_NIKKEI_ID.BIRTH >= V_M_IS_AGE.AGE_FROM2
            AND M_AD_NIKKEI_ID.BIRTH <= V_M_IS_AGE.AGE_TO2
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON V_M_IS_AGE.AGE2 = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM015'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND M_AD_NIKKEI_ID.BIRTH <> '18680101'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：性別(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON M_AD_NIKKEI_ID.SEX = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM016'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：メルマガ購読(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.MAIL_MAGAZINE_FLAG AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM017'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：最終学歴(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.FINAL_GAKUREKI AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM018'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：関心テーマ(MA)(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_SKILLUP
            ON T_EDU_T_USER_INFO.HASH_ID = T_EDU_T_USER_SKILLUP.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_SKILLUP.SKILL_UP_ID AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM019'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：海外経験有無(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.OVERSEAS_EXP AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM020'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：海外経験内容(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_OVERSEAS_EXP
            ON T_EDU_T_USER_INFO.HASH_ID = T_EDU_T_USER_OVERSEAS_EXP.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_OVERSEAS_EXP.OVERSEAS_EXP_ID AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM021'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：TOEIC(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.ENGLISH_LEVEL1 AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM022'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        --区分：日経TEST(Bizアカデミー会員)
        SELECT
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.ENGLISH_LEVEL2 AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM023'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
      UNION ALL
      (
        SELECT
          --区分:お知らせメール配信(Bizアカデミー会員)
          'CRM160002' AS RP_KBN
          , M_CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
          , M_CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
          , M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , COUNT(M_AD_NIKKEI_ID.HASH_ID) AS USER_NUM
          , 0 AS USER_COUNT_DSR3
          , 0 AS USER_COUNT_DSR2
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_EDU_T_USER_INFO
            ON M_AD_NIKKEI_ID.HASH_ID = T_EDU_T_USER_INFO.HASH_ID
          INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            ON CAST(T_EDU_T_USER_INFO.MAIL_NOTIFICATION_FLAG AS STRING) = M_CRM_CODE.VALUE1
        WHERE
          M_CRM_CODE.MASTER_TYPE = 'MST100'
          AND M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM025'
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE2) = false
          AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(M_CRM_CODE.VALUE3) = false
          AND M_CRM_CODE.YUKO_FLG = '1'
          AND M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員'
          AND M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー'
          AND T_EDU_T_USER_INFO.RESERVE10 = 0
        GROUP BY
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID
          , M_CRM_CODE.VALUE2
          , M_CRM_CODE.VALUE3
      )
    )
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;