-- 日経ウーマノミクス会員属性マートデータ蓄積
DECLARE target_table STRING DEFAULT 'T_GP_ATTR_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  --差分削除
  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  WHERE TABLE_ID = 1
    AND ATTR_INTERNAL_HASH_ID IN
      (
        SELECT
          HASH_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
      )
  ;

  --差分挿入
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  (
      TABLE_ID
      , ATTR_ID
      , ATTR_INTERNAL_HASH_ID
      , SERIAL_ID
      , ATTR_VALUE_NUMERIC
      , ATTR_VALUE_CHAR
      , ATTR_VALUE_DATE
      , ATTR_VALUE_TIMESTAMP
      , ATTR_VALUE_BOOL
      , ATTR_VALUE_FLOAT
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  --T_WFD_USER_ATTR.RPID
  SELECT
      1
      , 1
      , HASH_ID
      , SERIAL_ID
      , CAST(RPID AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.PERSONAL_INCOME
  UNION ALL
  SELECT
      1
      , 2
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , PERSONAL_INCOME AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.MARITAL_STATUS
  UNION ALL
  SELECT
      1
      , 3
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , MARITAL_STATUS AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.CHILDREN_FLAG
  UNION ALL
  SELECT
      1
      , 6
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CHILDREN_FLAG AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.WFMM_FLAG
  UNION ALL
  SELECT
      1
      , 12
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , WFMM_FLAG AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.CANCEL_FLAG
  UNION ALL
  SELECT
      1
      , 29
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CANCEL_FLAG AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  --T_WFD_USER_ATTR.REGIST_DATE
  UNION ALL
  SELECT
      1
      , 30
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , REGIST_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
      --T_WFD_USER_ATTR.UPDATE_DATE
  UNION ALL
  SELECT
      1
      , 31
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , UPDATE_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_WFD_USER_ATTR
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;