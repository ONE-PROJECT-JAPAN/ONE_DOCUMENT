DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_KBN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_KBN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_KBN_SS (
    SNAPSHOT_DATE
    , DSP_USERNUM_KBN
    , PRICEPLN_SYSTEM_ID
    , USER_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  WITH
  BASE_DT AS (
    SELECT
      NID_DT_FROM
      , NID_DT_TO
      , ADJUST_DT
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_BI_TIME
    WHERE
      DAY_DT = exec_date
  ),
  PRICEPLN_SYSTEM_MST AS (
    SELECT
      '02' AS ID
    UNION ALL
    SELECT
      '03' AS ID
    UNION ALL
    SELECT
      '04' AS ID
  )
  SELECT
    exec_date
    , DSP_USERNUM_KBN
    , PRICEPLN_SYSTEM_ID
    , USER_COUNT
    , 'IMS'
    , exec_date
    , 'IMS'
    , exec_date
  FROM
    (
      --日経ID会員(新日経IDシステム基準)
      (
        SELECT
          '01' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_ID
          , COUNT(HASH_ID) AS USER_COUNT
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
        WHERE
          WITHDRAWAL_FLAG = '会員'
          AND USER_TYPE = '一般ユーザー'
        GROUP BY
          PRICEPLN_SYSTEM_ID
      )
      UNION ALL
      --日経ID入会者(新日経IDシステム基準)
      (
        SELECT
          '14' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_ID
          , COUNT(HASH_ID) AS USER_COUNT
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          , BASE_DT
        WHERE
          USER_TYPE = '一般ユーザー'
          AND ENTRY_DATE >= BASE_DT.NID_DT_FROM
          AND ENTRY_DATE < BASE_DT.NID_DT_TO
        GROUP BY
          PRICEPLN_SYSTEM_ID
      )
      UNION ALL
      --日経ID退会者(新日経IDシステム基準)
      (
        SELECT
          '15' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_ID
          , COUNT(HASH_ID) AS USER_COUNT
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
          , BASE_DT
        WHERE
          USER_TYPE = '一般ユーザー'
          AND WITHDRAWAL_DATE >= BASE_DT.NID_DT_FROM
          AND WITHDRAWAL_DATE < BASE_DT.NID_DT_TO
        GROUP BY
          PRICEPLN_SYSTEM_ID
      )
      UNION ALL
      --日経ID会員(日付基準)
      (
        SELECT
          '16' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_MST.ID AS PRICEPLN_SYSTEM_ID
          , (IFNULL(V1.CNT,0) - IFNULL(V2.CNT, 0) + IFNULL(V3.CNT,0)) AS USER_COUNT
        FROM
          PRICEPLN_SYSTEM_MST
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , COUNT(HASH_ID) AS CNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              WITHDRAWAL_FLAG = '会員'
              AND USER_TYPE = '一般ユーザー'
            GROUP BY
              PRICEPLN_SYSTEM_ID
          ) V1
            ON V1.PRICEPLN_SYSTEM_ID = PRICEPLN_SYSTEM_MST.ID
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , COUNT(HASH_ID) AS CNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
              , BASE_DT
            WHERE
              USER_TYPE = '一般ユーザー'
              AND ENTRY_DATE >= BASE_DT.ADJUST_DT
            GROUP BY
              PRICEPLN_SYSTEM_ID
          ) V2
            ON V2.PRICEPLN_SYSTEM_ID = PRICEPLN_SYSTEM_MST.ID
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , COUNT(HASH_ID) AS CNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
              , BASE_DT
            WHERE
              USER_TYPE = '一般ユーザー'
              AND WITHDRAWAL_DATE >= BASE_DT.ADJUST_DT
            GROUP BY
              PRICEPLN_SYSTEM_ID
          ) V3
            ON V3.PRICEPLN_SYSTEM_ID = PRICEPLN_SYSTEM_MST.ID
      )
      UNION ALL
      --日経ID入会者(日付基準)
      (
        SELECT
          '17' AS DSP_USERNUM_KBN
          , PRICEPLN_SYSTEM_MST.ID
          , IFNULL(USER_COUNT, 0) AS USER_COUNT
        FROM
          PRICEPLN_SYSTEM_MST
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , COUNT(HASH_ID) AS USER_COUNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              USER_TYPE = '一般ユーザー'
              AND DATE(ENTRY_DATE) = DATE_ADD(exec_date, INTERVAL -1 DAY)
            GROUP BY
              PRICEPLN_SYSTEM_ID
          ) MAD
            ON MAD.PRICEPLN_SYSTEM_ID = PRICEPLN_SYSTEM_MST.ID
      )
      UNION ALL
      --日経ID退会者(日付基準)
      (
        SELECT
          '18' AS DSP_USERNUM_KBN
          , C.CODE AS PRICEPLN_SYSTEM_ID
          , COUNT(M.PRICEPLN_SYSTEM_ID) AS USER_COUNT
        FROM
          (
            SELECT
              CODE
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST450'
              AND MASTER_GRP_TYPE = 'GCRM450'
              AND YUKO_FLG = '1'
          ) C
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              USER_TYPE = '一般ユーザー'
              AND DATE(WITHDRAWAL_DATE) = DATE_ADD(exec_date, INTERVAL 1 DAY)
          ) M
            ON C.CODE = M.PRICEPLN_SYSTEM_ID
        GROUP BY
          C.CODE
      )
      UNION ALL
      --お試し会員
      (
        SELECT
          '30' AS DSP_USERNUM_KBN
          , C.CODE AS PRICEPLN_SYSTEM_ID
          , COUNT(M.PRICEPLN_SYSTEM_ID) AS USER_COUNT
        FROM
          (
            SELECT
              CODE
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST450'
              AND MASTER_GRP_TYPE = 'GCRM450'
              AND YUKO_FLG = '1'
          ) C
          LEFT OUTER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              WITHDRAWAL_FLAG = '会員'
              AND USER_TYPE = '一般ユーザー'
              AND TRIAL_FLG = 1
          ) M
            ON C.CODE = M.PRICEPLN_SYSTEM_ID
        GROUP BY
          C.CODE
      )
      UNION ALL
      --移行元サイト、移行ステータス別会員
      (
        SELECT
          C.VALUE1 AS DSP_USERNUM_KBN
          , M.PRICEPLN_SYSTEM_ID
          , M.USER_COUNT
        FROM
          (
            SELECT
              VALUE1
              , VALUE2
              , VALUE3
              , YUKO_FLG
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST180'
              AND MASTER_GRP_TYPE = 'GCRM180'
              AND YUKO_FLG = '1'
          ) C
          INNER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , ORIGINAL_SITE
              , ORIGINAL_STATUS
              , COUNT(HASH_ID) AS USER_COUNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              WITHDRAWAL_FLAG = '会員'
              AND USER_TYPE = '一般ユーザー'
            GROUP BY
              PRICEPLN_SYSTEM_ID
              , ORIGINAL_SITE
              , ORIGINAL_STATUS
          ) M
            ON C.VALUE2 = M.ORIGINAL_SITE
            AND C.VALUE3 = M.ORIGINAL_STATUS
      )
      UNION ALL
      --移行元サイト別お試し利用中会員
      (
        SELECT
          C.VALUE1 AS DSP_USERNUM_KBN
          , M.PRICEPLN_SYSTEM_ID
          , M.USER_COUNT
        FROM
          (
            SELECT
              VALUE1
              , VALUE2
              , VALUE3
              , YUKO_FLG
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
            WHERE
              MASTER_TYPE = 'MST180'
              AND MASTER_GRP_TYPE = 'GCRM181'
              AND YUKO_FLG = '1'
          ) C
          INNER JOIN (
            SELECT
              PRICEPLN_SYSTEM_ID
              , ORIGINAL_SITE
              , TRIAL_FLG
              , COUNT(HASH_ID) AS USER_COUNT
            FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
            WHERE
              WITHDRAWAL_FLAG = '会員'
              AND USER_TYPE = '一般ユーザー'
            GROUP BY
              PRICEPLN_SYSTEM_ID
              , ORIGINAL_SITE
              , TRIAL_FLG
          ) M
            ON C.VALUE2 = M.ORIGINAL_SITE
            AND C.VALUE3 = CAST(M.TRIAL_FLG AS STRING)
      )
    )
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;