DECLARE target_table STRING DEFAULT 'T_IMS_KIJI_SEGMENT_FIXED_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_KIJI_SEGMENT_FIXED_SS
  WHERE DATE(SEND_DATETIME) = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_KIJI_SEGMENT_FIXED_SS (
    SEND_DATETIME
    , USR_SEGMENT
    , PUSH_SEGMENT
    , KIJI_ID
    , INS_DT_TM
  )
  SELECT
    SEND_DATETIME
    , USR_SEGMENT
    , PUSH_SEGMENT
    , KIJI_ID
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_KIJI_SEGMENT_FIXED
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;