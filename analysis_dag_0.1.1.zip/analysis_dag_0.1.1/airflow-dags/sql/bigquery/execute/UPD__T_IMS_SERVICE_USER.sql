DECLARE target_table STRING DEFAULT 'T_IMS_SERVICE_USER';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_SERVICE_USER
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_SERVICE_USER (
    SNAPSHOT_DATE
    , SERVICE_ID
    , HASH_ID
    , SERIAL_ID
  )
  SELECT
    exec_date
    , SERVICE_ID
    , HASH_ID
    , SERIAL_ID
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_ANALYZE
  WHERE
    SERVICE_ID = 'WAP0000000001'
    --当日、または、それ以降にサービス利用開始したユーザは連携対象外
    AND SERVICE_START_DATE < exec_date
    --最新の契約の条件は契約番号 = 直近契約番号となるはずである。だが、そもそも契約情報分析VIEWにはこの条件のデータしか存在しないため自明のはず。
    AND CONTRACT_NO = LATEST_CONTRACT_NO
  UNION DISTINCT
  SELECT
    exec_date
    , SERVICE_ID
    , HASH_ID
    , SERIAL_ID
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_V_CONTRACT_HISTORY_ANALYZE
  WHERE
    SERVICE_ID = 'WAP0000000001'
    --前日にサービス利用終了したユーザは連携対象
    AND SERVICE_END_DATE = DATE_ADD(exec_date, INTERVAL -1 DAY)
  UNION DISTINCT
  SELECT
    exec_date
    , SERVICE_ID
    , HASH_ID
    , SERIAL_ID
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;