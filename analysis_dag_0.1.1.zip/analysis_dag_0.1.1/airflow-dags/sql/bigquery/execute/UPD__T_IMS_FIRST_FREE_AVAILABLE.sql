DECLARE target_table STRING DEFAULT 'T_IMS_FIRST_FREE_AVAILABLE';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_FIRST_FREE_AVAILABLE A
  USING (
    WITH
    TARGET_SERVICE AS (
      SELECT
        SERVICE_ID
        , FREE_PLAN_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_KK_M_SERVICE
      WHERE
        SERVICE_ID IN (
          'DS00000000001'
        )
    )
    , TARGET_USER AS (
      SELECT
        HASH_ID
        , SERIAL_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE_IF
      WHERE
        --退会者は除外
        WITHDRAWAL_FLAG = '0'
    )
    --有料契約会員
    , PAID_USER AS (
      SELECT
        A.HASH_ID
        , A.SERVICE_ID
      FROM
        (
          SELECT
            HASH_ID
            , 'DS00000000001' AS SERVICE_ID
            , PRICEPLN_CD AS PLAN_ID
          FROM
            {{ var.value.atlas_bigquery_ims_dataset_name }}.V_BI_USER_ID_DS_PRIORITY_PLN
        ) A
        INNER JOIN TARGET_SERVICE B
          ON A.SERVICE_ID = B.SERVICE_ID
      WHERE
        {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(B.FREE_PLAN_ID) = true
        OR A.PLAN_ID <> B.FREE_PLAN_ID
    )
    --ユーザ×サービス
    , BASE AS (
      SELECT
        A.*
        , B.SERVICE_ID
      FROM
        TARGET_USER A
        CROSS JOIN TARGET_SERVICE B
        LEFT OUTER JOIN PAID_USER C
          ON A.HASH_ID = C.HASH_ID
          AND B.SERVICE_ID = C.SERVICE_ID
      WHERE
        --有料契約は除外
        {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(C.SERVICE_ID) = true
    )
    --契約状況
    , CONTRACT AS (
      SELECT
        A.HASH_ID
        , A.SERVICE_ID
        , MAX(A.CHARGED_PLAN_START_DATE) AS CHARGED_PLAN_START_DATE
        , MAX(
          CASE
            --無料プランありのサービス
            --8:解約(無料プランに変更) 10:強制解約(無料プランに変更) 13:契約重複解約(無料プランに変更)
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(B.FREE_PLAN_ID) = false
            AND A.REQUEST_TYPE IN (8, 10, 13)
            THEN A.REQUEST_APPLY_DATE
            --無料プランなしのサービス
            --4:解約 6:強制解約 14:契約重複みちづれ解約
            WHEN {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(B.FREE_PLAN_ID) = true
            AND A.REQUEST_TYPE IN (4, 6, 14)
            THEN A.REQUEST_APPLY_DATE
            ELSE NULL
            END
        ) AS CHARGED_PLAN_END_DATE
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_REQUEST_HISTORY A
        LEFT OUTER JOIN TARGET_SERVICE B
          ON A.SERVICE_ID = B.SERVICE_ID
      WHERE
        A.EXCLUDE_FLG = 0
      GROUP BY
        A.HASH_ID
        , A.SERVICE_ID
    )
    SELECT
      A.HASH_ID
      , A.SERIAL_ID
      , A.SERVICE_ID
      , exec_datetime AS AVAILABLE_DATETIME
    FROM
      BASE A
      LEFT OUTER JOIN CONTRACT B
        ON A.HASH_ID = B.HASH_ID
        AND A.SERVICE_ID = B.SERVICE_ID
    WHERE
      --有料契約未経験
      B.CHARGED_PLAN_START_DATE IS NULL
      OR (
        --有料未契約
        B.CHARGED_PLAN_START_DATE <= B.CHARGED_PLAN_END_DATE
        AND (
          --1ヶ月無料施策未体験
          B.CHARGED_PLAN_START_DATE < '2019-07-01'
          --有料解約後1年経過
          OR DATE_ADD(B.CHARGED_PLAN_END_DATE, INTERVAL 12 MONTH) < exec_date
        )
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;