DECLARE target_table STRING DEFAULT 'T_APP_USER_MAIL_AUTH_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_APP_USER_MAIL_AUTH_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_APP_USER_MAIL_AUTH_SS (
    SNAPSHOT_DATE
    , ID
    , USER_SERIAL_ID
    , CATEGORY
    , SUB_CATEGORY
    , IS_ENABLED
    , CREATED_AT
    , UPDATED_AT
    , INS_DT_TM
  )
  SELECT
    exec_date
    , ID
    , USER_SERIAL_ID
    , CATEGORY
    , SUB_CATEGORY
    , IS_ENABLED
    , CREATED_AT
    , UPDATED_AT
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.W_APP_USER_MAIL_AUTH
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;