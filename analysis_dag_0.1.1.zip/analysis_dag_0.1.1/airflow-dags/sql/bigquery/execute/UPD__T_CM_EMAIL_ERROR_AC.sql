DECLARE target_table STRING DEFAULT 'T_CM_EMAIL_ERROR_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_ERROR_AC A
  USING (
    WITH IF_DATA AS (
      SELECT
        PARSE_DATETIME('%Y%m%d%H%M%S', SDATE) AS SDATE
        , IFNULL(EMAIL, '') AS EMAIL
        , CAST(MAILIDX AS INT64) AS MAILIDX
        , CAST(SEQIDX AS INT64) AS SEQIDX
        , CAST(NULLIF(CODE, '') AS INT64) AS CODE
        , CAST(NULLIF(DELIVERY_ORDER, '') AS INT64) AS DELIVERY_ORDER
        , IFNULL(HASH_ID, '') AS HASH_ID
        , IFNULL(SERIAL_ID, '') AS SERIAL_ID
        , IFNULL(PLAN_ID, '') AS PLAN_ID
        , CAST(NULL AS STRING) AS HOST_NO
        , 'IMS' AS INS_PGM_ID
        , exec_datetime AS INS_DT_TM
        , 'IMS' AS UPD_PGM_ID
        , exec_datetime AS UPD_DT_TM
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.W_CM_EMAIL_ERROR
      WHERE
        IFNULL(SDATE, '') <> '0'
    )
    SELECT
      *
    FROM
      IF_DATA
    UNION ALL
    --IFに存在しないデータを結合
    SELECT
      SDATE
      , EMAIL
      , MAILIDX
      , SEQIDX
      , CODE
      , DELIVERY_ORDER
      , HASH_ID
      , SERIAL_ID
      , PLAN_ID
      , HOST_NO
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_ERROR_AC A
    WHERE
      NOT EXISTS (
        SELECT
          1
        FROM
          IF_DATA B
        WHERE
          A.MAILIDX = B.MAILIDX
          AND A.SEQIDX = B.SEQIDX
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;