DECLARE target_table STRING DEFAULT 'T_KK_T_CLOSE_ENQUETE_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_CLOSE_ENQUETE_ACCUM A
  USING (
    SELECT
      ENQUETE_ID
      , ENQUETE_NO
      , HASH_ID
      , SERIAL_ID
      , SERVICE_ID
      , PLAN_ID
      , ANSWER_DATETIME
      , CONTRACT_NO
      , REQUEST_NO
      , CONTENTS_ID
      , CONTENTS_TYPE
      , CLOSE_REASON_FLG
      , CLOSE_REASON
      , FREE_INPUT_TEXT
      , CREATE_ID
      , CREATE_DATETIME
      , UPDATE_ID
      , UPDATE_DATETIME
      , DELETE_ID
      , DELETE_DATETIME
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_T_CLOSE_ENQUETE B
  ) B
    ON A.ENQUETE_ID = B.ENQUETE_ID
    AND A.ENQUETE_NO = B.ENQUETE_NO
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      ENQUETE_ID = B.ENQUETE_ID
      , ENQUETE_NO = B.ENQUETE_NO
      , HASH_ID = B.HASH_ID
      , SERIAL_ID = B.SERIAL_ID
      , SERVICE_ID = B.SERVICE_ID
      , PLAN_ID = B.PLAN_ID
      , ANSWER_DATETIME = B.ANSWER_DATETIME
      , CONTRACT_NO = B.CONTRACT_NO
      , REQUEST_NO = B.REQUEST_NO
      , CONTENTS_ID = B.CONTENTS_ID
      , CONTENTS_TYPE = B.CONTENTS_TYPE
      , CLOSE_REASON_FLG = B.CLOSE_REASON_FLG
      , CLOSE_REASON = B.CLOSE_REASON
      , FREE_INPUT_TEXT = B.FREE_INPUT_TEXT
      , CREATE_ID = B.CREATE_ID
      , CREATE_DATETIME = B.CREATE_DATETIME
      , UPDATE_ID = B.UPDATE_ID
      , UPDATE_DATETIME = B.UPDATE_DATETIME
      , DELETE_ID = B.DELETE_ID
      , DELETE_DATETIME = B.DELETE_DATETIME
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;