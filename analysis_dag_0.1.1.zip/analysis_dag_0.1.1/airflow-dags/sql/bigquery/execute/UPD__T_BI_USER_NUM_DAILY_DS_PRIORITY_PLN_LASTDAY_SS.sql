DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_LASTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE last_month_last_day DATE DEFAULT DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL -1 DAY); --先月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_LASTDAY_SS
  WHERE SNAPSHOT_DATE = last_month_last_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_LASTDAY_SS (
    SNAPSHOT_DATE
    , PRICEPLN_SYSTEM_ID
    , PRICEPLN_CD
    , USER_COUNT
    , CANCEL_COUNT
    , CHANGE_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
    SNAPSHOT_DATE
    , PRICEPLN_SYSTEM_ID
    , PRICEPLN_CD
    , COUNT(HASH_ID) AS USER_COUNT
    , SUM(CASE WHEN CANCEL_FLG = 1 THEN 1 ELSE 0 END)
    , SUM(CASE WHEN CHANGE_FLG = 1 THEN 1 ELSE 0 END)
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_LASTDAY_SS
  WHERE
    SNAPSHOT_DATE = last_month_last_day
    AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(PRICEPLN_SYSTEM_ID) = false
    AND {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(PRICEPLN_CD) = false
  GROUP BY
    SNAPSHOT_DATE
    , PRICEPLN_SYSTEM_ID
    , PRICEPLN_CD
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;