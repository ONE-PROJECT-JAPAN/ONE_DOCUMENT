DECLARE target_table STRING DEFAULT 'T_BB_AGREEMENT_LIST_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST_ACCUM A
  USING (
    SELECT
      HASH_ID
      , SERIAL_ID
      , RP_ID
      , SERVICE_ID
      , TRIAL_FLAG
      , USESTART_DATE
      , REPORT_CATEGORY
      , BBC_FLAG
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST B
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.RP_ID = B.RP_ID
    AND A.SERVICE_ID = B.SERVICE_ID
    AND A.USESTART_DATE = B.USESTART_DATE
    AND A.REPORT_CATEGORY = B.REPORT_CATEGORY
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      HASH_ID = B.HASH_ID
      , SERIAL_ID = B.SERIAL_ID
      , RP_ID = B.RP_ID
      , SERVICE_ID = B.SERVICE_ID
      , TRIAL_FLAG = B.TRIAL_FLAG
      , USESTART_DATE = B.USESTART_DATE
      , REPORT_CATEGORY = B.REPORT_CATEGORY
      , BBC_FLAG = B.BBC_FLAG
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;