DECLARE target_table STRING DEFAULT 'M_IMS_OPEN_USER_ID';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IMS_OPEN_USER_ID A
  USING (
    SELECT
      OU.C_OPEN_USER_ID
      , OU.HASH_ID
      , OU.SERIAL_ID
      , exec_datetime AS INS_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_OX_USER OU
      INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IMS_RP RP
        ON CAST(OU.C_CLIENT_ID AS STRING) = RP.RP_ID
    WHERE
      RP.AWS_RS_FLG  = 1
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;