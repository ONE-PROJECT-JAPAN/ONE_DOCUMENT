/*

   参照テーブル:
      D_IMS_NIKKEI_MEMBER_NO_LIST
      M_AD_NIKKEI_ID
      M_IS_NX_MIGRATION
      T_BPP_V_USER_SERVICE_ALL

*/
DECLARE target_table STRING DEFAULT 'T_CRM_CMK_NUM_MONTHLY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CRM_CMK_NUM_MONTHLY_SS
  WHERE DATE(INS_DT_TM) = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CRM_CMK_NUM_MONTHLY_SS
  SELECT
      YEAR_MONTH
      ,USER_COUNT_1
      ,USER_COUNT_3 - USER_COUNT_1 AS USER_COUNT_2
      ,USER_COUNT_3
      ,'{{ dag.dag_id }}'
      ,exec_datetime
      ,'{{ dag.dag_id }}'
      ,exec_datetime
  FROM
      (
          SELECT
              FORMAT_TIMESTAMP('%Y%m', M_RP.CREATE_DATE) AS YEAR_MONTH
              ,COUNT(
                      CASE
                          WHEN date_diff(CAST(M_RP.CREATE_DATE AS DATE), CAST(M_AD.ENTRY_DATE AS DATE), DAY) <= 7
                              THEN 1
                          ELSE NULL
                      END
                    ) AS USER_COUNT_1
              ,COUNT(*) AS USER_COUNT_3
          FROM
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AS M_AD
          INNER JOIN
              {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_RP_REGISTRATION AS M_RP
          ON
              M_AD.HASH_ID = M_RP.HASH_ID
          WHERE
              M_RP.CREATE_DATE >= CAST((FORMAT_DATE('%Y-%m', DATE_ADD(CURRENT_DATE, INTERVAL -1 MONTH)) || '-01') AS DATE)
          AND
              M_RP.CREATE_DATE < CAST((FORMAT_DATE('%Y-%m', CURRENT_DATE) || '-01') AS DATE)
          AND
              M_RP.RP_ID = 1018
          AND
              M_AD.USER_TYPE = '一般ユーザー'
          AND
              M_AD.ORIGINAL_SITE <> '9'
          AND
              M_AD.EMAIL NOT like '%@nex.nikkei.co.jp'
          GROUP BY
              YEAR_MONTH
      ) AS A
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;