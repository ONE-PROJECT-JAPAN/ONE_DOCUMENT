DECLARE target_table STRING DEFAULT 'BRIEFING_20190411_T_DSU_T_DS_MAIL_SET_INFO_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.BRIEFING_20190411_T_DSU_T_DS_MAIL_SET_INFO_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.BRIEFING_20190411_T_DSU_T_DS_MAIL_SET_INFO_SS(
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , SEND_MAIL_KIND
    , SEND_MAIL_NM
  )
  SELECT
    exec_date
    , IFNULL(A.HASH_ID, '')
    , A.SERIAL_ID
    , A.SUB_CATEGORY
    , B.SEND_MAIL_NM
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_USER_MAIL_AUTH A
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.V_APP_MAIL_SEND_KIND B
      ON (
        SUBSTR(B.SEND_MAIL_KIND, 6, 3) = 'BRH'
        OR B.SEND_MAIL_KIND IN ('00301SCH0', '00302SCH0', '00303SCH0', '00304SCH0')
      )
      AND B.DEL_FLG <> '1'
      AND B.SEND_MAIL_KIND = A.SUB_CATEGORY
  WHERE
    A.IS_ENABLED = 1
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;