DECLARE target_table STRING DEFAULT 'T_IMS_EVENT_APPLY';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EVENT_APPLY A
  USING (
    SELECT DISTINCT
      A.HASH_ID
      , A.SERIAL_ID
      , A.EVENT_SYSTEM_ID
      , A.EVENT_ID
      , A.EVENT_NAME
      , A.CATEGORY_NAME
      , A.SUB_CATEGORY_NAME
      , A.EVENT_START_DATE
      , A.EVENT_START_DOW
      , A.EVENT_START_TIME
      , A.EVENT_END_DATE
      , A.EVENT_END_DOW
      , A.EVENT_END_TIME
      , A.FREE_EVENT_FLG
      , A.USER_PLACE_NAME
      , A.USER_PLACE_COUNTRY
      , A.USER_PLACE_PREFECTURE
      , A.USER_PLACE_CITY
      , A.CAPACITY
      , CAST(A.PRICE AS INT64)
      , A.APPLY_DATE
      , A.SECONDARY_USE_SIGN
      , A.CHECKIN_FLG
      , A.LAST_CHECKIN_DATE
      , exec_datetime
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_EVENT_APPLY A
    WHERE
      {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(A.HASH_ID) = false
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;