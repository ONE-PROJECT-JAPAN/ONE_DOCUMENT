DECLARE target_table STRING DEFAULT 'M_EE_V_CRM_MASTER_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.M_EE_V_CRM_MASTER_ACCUM A
  USING (
    WITH IF_DATA AS (
      SELECT
        FORM_ID
        , FORM_TYPE
        , FORM_NAME
        , FORM_ITEM_ID
        , ITEM_NAME
        , TITLE
        , INPUT_TYPE_ID
        , SELECT_ID
        , SELECT_ITEM_NAME
        , 'IMS' AS INS_BATCH_ID
        , exec_datetime AS INS_DT_TM
        , 'IMS' AS UPD_BATCH_ID
        , exec_datetime AS UPD_DT_TM
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_EE_V_CRM_MASTER
    )
    SELECT
      *
    FROM
      IF_DATA
    UNION ALL
    --IFに存在しないデータを結合
    SELECT
      FORM_ID
      , FORM_TYPE
      , FORM_NAME
      , FORM_ITEM_ID
      , ITEM_NAME
      , TITLE
      , INPUT_TYPE_ID
      , SELECT_ID
      , SELECT_ITEM_NAME
      , INS_BATCH_ID
      , INS_DT_TM
      , UPD_BATCH_ID
      , UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_EE_V_CRM_MASTER_ACCUM A
    WHERE
      NOT EXISTS (
        SELECT
          1
        FROM
          IF_DATA B
        WHERE
          A.FORM_ID = B.FORM_ID
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;