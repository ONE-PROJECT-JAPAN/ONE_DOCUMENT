DECLARE target_table STRING DEFAULT 'T_IMS_EVENT';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EVENT A
  USING (
    SELECT
      A.EVENT_SYSTEM_ID
      , A.EVENT_ID
      , A.EVENT_NAME
      , A.CATEGORY_NAME
      , A.SUB_CATEGORY_NAME
      , A.EVENT_START_DATE
      , A.EVENT_START_DOW
      , A.EVENT_START_TIME
      , A.EVENT_END_DATE
      , A.EVENT_END_DOW
      , A.EVENT_END_TIME
      , A.FREE_EVENT_FLG
      , A.USER_PLACE_NAME
      , A.USER_PLACE_COUNTRY
      , A.USER_PLACE_PREFECTURE
      , A.USER_PLACE_CITY
      , A.CAPACITY
      , CAST(A.PRICE AS INT64) AS PRICE
      , COUNT(A.EVENT_SYSTEM_ID) AS APPLY_COUNT
      , COUNT(B.HASH_ID) AS NIKKEI_ID_USE_APPLY_COUNT
      , SUM(
          CASE
          WHEN B.CHECKIN_FLG = 1
          THEN 1
          ELSE 0
          END
        ) AS CHECKIN_COUNT
      , SUM(
          CASE
          WHEN B.HASH_ID IS NOT NULL
          AND B.CHECKIN_FLG = 1
          THEN 1
          ELSE 0
          END
        ) AS NIKKEI_ID_USE_CHECKIN_COUNT
      , exec_datetime
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_EVENT A
      LEFT OUTER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_EVENT_APPLY B
        ON A.EVENT_ID = B.EVENT_ID
        AND A.EVENT_NAME = B.EVENT_NAME
    GROUP BY
      A.EVENT_SYSTEM_ID
      , A.EVENT_ID
      , A.EVENT_NAME
      , A.CATEGORY_NAME
      , A.SUB_CATEGORY_NAME
      , A.EVENT_START_DATE
      , A.EVENT_START_DOW
      , A.EVENT_START_TIME
      , A.EVENT_END_DATE
      , A.EVENT_END_DOW
      , A.EVENT_END_TIME
      , A.FREE_EVENT_FLG
      , A.USER_PLACE_NAME
      , A.USER_PLACE_COUNTRY
      , A.USER_PLACE_PREFECTURE
      , A.USER_PLACE_CITY
      , A.CAPACITY
      , A.PRICE
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;