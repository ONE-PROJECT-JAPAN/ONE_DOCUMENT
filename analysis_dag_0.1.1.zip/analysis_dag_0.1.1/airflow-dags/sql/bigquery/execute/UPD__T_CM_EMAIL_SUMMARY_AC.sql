DECLARE target_table STRING DEFAULT 'T_CM_EMAIL_SUMMARY_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_CM_EMAIL_SUMMARY_AC A
  USING (
    SELECT
      PARSE_DATETIME('%Y%m%d%H%M%S', SDATE) AS SDATE
      , PARSE_DATETIME('%Y%m%d%H%M%S', EDATE) AS EDATE
      , IFNULL(TITLE, '') AS TITLE
      , IFNULL(SUBJECT, '') AS SUBJECT
      , IFNULL(HTMLTEXT, '') AS HTMLTEXT
      , CAST(MAILIDX AS INT64) AS MAILIDX
      , CAST(NULLIF(TOTAL, '') AS INT64) AS TOTAL
      , CAST(NULLIF(SUCCESS, '') AS INT64) AS SUCCESS
      , CAST(NULLIF(ERROR, '') AS INT64) AS ERROR
      , CAST(NULLIF(HBBSBB, '') AS INT64) AS HBBSBB
      , CAST(NULLIF(UNIQOPEN, '') AS INT64) AS UNIQOPEN
      , CAST(NULLIF(OPEN, '') AS INT64) AS OPEN
      , CAST(NULLIF(UNIQCLICK, '') AS INT64) AS UNIQCLICK
      , CAST(NULLIF(CLICK, '') AS INT64) AS CLICK
      , CAST(NULLIF(CCOUNT, '') AS INT64) AS CCOUNT
      , CAST(NULLIF(CAMOUNT, '') AS INT64) AS CAMOUNT
      , CAST(NULL AS STRING) AS HOST_NO
      , 'IMS' AS INS_PGM_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_PGM_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_CM_EMAIL_SUMMARY
  ) B
    ON A.MAILIDX = B.MAILIDX
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      SDATE = B.SDATE
      , EDATE = B.EDATE
      , TITLE = B.TITLE
      , SUBJECT = B.SUBJECT
      , HTMLTEXT = B.HTMLTEXT
      , MAILIDX = B.MAILIDX
      , TOTAL = B.TOTAL
      , SUCCESS = B.SUCCESS
      , ERROR = B.ERROR
      , HBBSBB = B.HBBSBB
      , UNIQOPEN = B.UNIQOPEN
      , OPEN = B.OPEN
      , UNIQCLICK = B.UNIQCLICK
      , CLICK = B.CLICK
      , CCOUNT = B.CCOUNT
      , CAMOUNT = B.CAMOUNT
      , HOST_NO = B.HOST_NO
      , UPD_PGM_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;