DECLARE target_table STRING DEFAULT 'T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS
  WHERE DATE(INS_DT_TM) = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS
  (
      SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , TRIAL_FLAG
    , USESTART_DATE
    , REPORT_CATEGORY
    , BBC_FLAG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
      exec_date
    , BB.HASH_ID
    , BB.SERIAL_ID
    , BB.RP_ID
    , BB.SERVICE_ID
    , BB.TRIAL_FLAG
    , BB.USESTART_DATE
    , BB.REPORT_CATEGORY
    , BB.BBC_FLAG
    , '{{ dag.dag_id }}'
    , exec_datetime
    , '{{ dag.dag_id }}'
    , exec_datetime
  FROM
     {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BB_AGREEMENT_LIST  BB
  ;


  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;