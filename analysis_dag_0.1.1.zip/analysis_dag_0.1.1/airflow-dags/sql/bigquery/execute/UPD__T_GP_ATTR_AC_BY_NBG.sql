-- 日経BizGate会員属性マートデータ蓄積
DECLARE target_table STRING DEFAULT 'T_GP_ATTR_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  --差分削除
  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  WHERE TABLE_ID = 2
    AND ATTR_INTERNAL_HASH_ID IN
      (
        SELECT
          HASH_ID
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
      )
  ;


  --差分挿入
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC
  (
      TABLE_ID
      , ATTR_ID
      , ATTR_INTERNAL_HASH_ID
      , SERIAL_ID
      , ATTR_VALUE_NUMERIC
      , ATTR_VALUE_CHAR
      , ATTR_VALUE_DATE
      , ATTR_VALUE_TIMESTAMP
      , ATTR_VALUE_BOOL
      , ATTR_VALUE_FLOAT
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  --W_NBG_USER_ATTR.RPID
  SELECT
      2
      , 1
      , HASH_ID
      , SERIAL_ID
      , CAST(RPID AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.COMPANY_SALES
  UNION ALL
  SELECT
      2
      , 2
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , COMPANY_SALES AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_MANAGEMENT
  UNION ALL
  SELECT
      2
      , 3
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_MANAGEMENT AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_GLOBALIZATION
  UNION ALL
  SELECT
      2
      , 4
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_GLOBALIZATION AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_MARKETING
  UNION ALL
  SELECT
      2
      , 5
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_MARKETING AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_IT
  UNION ALL
  SELECT
      2
      , 6
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_IT AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_ORGANIZATION_PERSON
  UNION ALL
  SELECT
      2
      , 7
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_ORGANIZATION_PERSON AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_INNOVATION
  UNION ALL
  SELECT
      2
      , 8
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_INNOVATION AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_MONOZUKURI
  UNION ALL
  SELECT
      2
      , 9
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_MONOZUKURI AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_FINANCE
  UNION ALL
  SELECT
      2
      , 10
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_FINANCE AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_CORPORATE_ACQUISITION
  UNION ALL
  SELECT
      2
      , 11
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_CORPORATE_ACQUISITION AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_SOCIAL_BUSINESS
  UNION ALL
  SELECT
      2
      , 12
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_SOCIAL_BUSINESS AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_CSR
  UNION ALL
  SELECT
      2
      , 13
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_CSR AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_ENVIRONMENT
  UNION ALL
  SELECT
      2
      , 14
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_ENVIRONMENT AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INTEREST_THEME_POLITICAL_ECONOMIC
  UNION ALL
  SELECT
      2
      , 15
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INTEREST_THEME_POLITICAL_ECONOMIC AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INFO_COLLECT_METHOD_MAGAZINE
  UNION ALL
  SELECT
      2
      , 16
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INFO_COLLECT_METHOD_MAGAZINE AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INFO_COLLECT_METHOD_BOOK
  UNION ALL
  SELECT
      2
      , 17
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INFO_COLLECT_METHOD_BOOK AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INFO_COLLECT_METHOD_WEBSITE
  UNION ALL
  SELECT
      2
      , 18
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INFO_COLLECT_METHOD_WEBSITE AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INFO_COLLECT_METHOD_SOCIAL
  UNION ALL
  SELECT
      2
      , 19
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INFO_COLLECT_METHOD_SOCIAL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.INFO_COLLECT_METHOD_SEMINAR
  UNION ALL
  SELECT
      2
      , 20
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , INFO_COLLECT_METHOD_SEMINAR AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.BIZGATEMM
  UNION ALL
  SELECT
      2
      , 21
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , BIZGATEMM AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_ENGLISH
  UNION ALL
  SELECT
      2
      , 22
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_ENGLISH AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_CHINESE
  UNION ALL
  SELECT
      2
      , 23
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_CHINESE AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_MBA
  UNION ALL
  SELECT
      2
      , 24
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_MBA AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_QUALIFICATION
  UNION ALL
  SELECT
      2
      , 25
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_QUALIFICATION AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_MANAGEMENT
  UNION ALL
  SELECT
      2
      , 26
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_MANAGEMENT AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_THINKING
  UNION ALL
  SELECT
      2
      , 27
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_THINKING AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_COMMUNICATION
  UNION ALL
  SELECT
      2
      , 28
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_COMMUNICATION AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_CHANGEJOBS
  UNION ALL
  SELECT
      2
      , 29
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_CHANGEJOBS AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_ENTREPRENEURSHIP
  UNION ALL
  SELECT
      2
      , 30
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_ENTREPRENEURSHIP AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_WORK_ABROAD
  UNION ALL
  SELECT
      2
      , 31
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_WORK_ABROAD AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_STUDY_ABROAD
  UNION ALL
  SELECT
      2
      , 32
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_STUDY_ABROAD AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_OTHER
  UNION ALL
  SELECT
      2
      , 33
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_OTHER AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CAREER_UP_WANTS_OTHER_TEXT
  UNION ALL
  SELECT
      2
      , 34
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CAREER_UP_WANTS_OTHER_TEXT AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.CANCEL_FLAG
  UNION ALL
  SELECT
      2
      , 35
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , CANCEL_FLAG AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , CAST(NULL AS DATETIME) AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.REGIST_DATE
  UNION ALL
  SELECT
      2
      , 36
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , REGIST_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  --W_NBG_USER_ATTR.UPDATE_DATE
  UNION ALL
  SELECT
      2
      , 37
      , HASH_ID
      , SERIAL_ID
      , CAST(NULL AS INT) AS ATTR_VALUE_NUMERIC
      , NULL AS ATTR_VALUE_CHAR
      , CAST(NULL AS DATE) AS ATTR_VALUE_DATE
      , UPDATE_DATE AS ATTR_VALUE_TIMESTAMP
      , CAST(NULL AS BOOLEAN) AS ATTR_VALUE_BOOL
      , CAST(NULL AS NUMERIC) AS ATTR_VALUE_FLOAT
      , '{{ dag.dag_id }}'
      , exec_datetime
      , '{{ dag.dag_id }}'
      , exec_datetime
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_NBG_USER_ATTR
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;