--
-- 会員ID日別スナップショット
--
DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_SS(
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , PRICEPLN_CD_SYSTEM_ID
    , PRICEPLN_CD
    , TRIAL_FLG
    , ZIP_CODE
    , ADDRESS_CODE
    , OCCUPATION_NO
    , BUSINESS_NO
    , JOB_NO
    , POSITION_NO
    , EMPLOYEES_NO
    , INCOME_NO
    , NIKKEI_MAIL_FLAG
    , THIRDPARTY_MAIL_FLAG
    , NIKKEI_MONITOR_FLAG
    , ENTRY_DATE
    , WITHDRAWAL_DATE
    , CREATE_DATE
    , UPDATE_DATE
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , SEX
    , BIRTHDAY
    , AGE
    , STATE_POSTAL
    , CHARGE_KBN
    , COUNTRY_CODE
    , RESIDENT_ABROAD
  )
  SELECT
    exec_date AS SNAPSHOT_DATE
    , T1.HASH_ID
    , T1.SERIAL_ID
    , T1.PRICEPLN_SYSTEM_ID
    , T1.PRICEPLN_CD
    , T1.TRIAL_FLG
    , T2.ZIP_CODE
    , T2.ADDRESS_CODE
    , T2.OCCUPATION_NO
    , T2.BUSINESS_NO
    , T2.JOB_NO
    , T2.POSITION_NO
    , T2.EMPLOYEES_NO
    , T2.INCOME_NO
    , T2.NIKKEI_MAIL_FLAG
    , T2.THIRDPARTY_MAIL_FLAG
    , T2.NIKKEI_MONITOR_FLAG
    , T2.ENTRY_DATE
    , T2.WITHDRAWAL_DATE
    , T2.CREATE_DATE
    , T2.UPDATE_DATE
    , 'IMS' AS INS_BATCH_ID
    , exec_datetime AS INS_DT_TM
    , 'IMS' AS UPD_BATCH_ID
    , exec_datetime AS UPD_DT_TM
    , T1.SEX
    , T1.BIRTH
    , T1.AGE2
    , T1.PREFEC
    , T1.CHARGE_KBN
    , T2.COUNTRY_CODE
    , T2.RESIDENT_ABROAD
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID T1
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE T2
      ON T1.HASH_ID = T2.HASH_ID
  WHERE
    T2.WITHDRAWAL_FLAG = '0'
    AND T2.USER_TYPE = '0'
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;