/*

   参照テーブル:
      M_AD_NIKKEI_ID
      M_CRM_CODE
      T_GP_ATTR_AC
      V_IMS_BA_USER_ID
        M_IS_NX_ATTRIBUTE
        M_IS_NX_RP_REGISTRATION
        T_GP_ATTR_AC
      V_IMS_GDY_USER_ID
        M_IS_NX_ATTRIBUTE
        M_IS_NX_RP_REGISTRATION
        T_GP_ATTR_AC
        T_KK_V_CONTRACT_ANALYZE
      V_IMS_LI_USER_ID
        M_IS_NX_ATTRIBUTE
        M_IS_NX_RP_REGISTRATION
        T_GP_ATTR_AC

*/
DECLARE target_table STRING DEFAULT 'T_IMS_USER_NUM_DAILY_RP_ATTR_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_ATTR_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_ATTR_SS
  (
      SNAPSHOT_DATE
      , RP_ID
      , ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT1
      , USER_COUNT2
      , USER_COUNT3
      , USER_COUNT4
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  SELECT
      exec_date AS SNAPSHOT_DATE
      , CASE
        WHEN S.JW_KBN = 1
        THEN 'JW' 
        WHEN S.JW_KBN = 2
        THEN 'JWB2B'
        END AS RP_ID
      , S.ATTRIBUTE_KBN1
      , S.ATTRIBUTE_KBN2
      , S.ATTRIBUTE_KBN3
      , S.PRICEPLN_SYSTEM_ID
      , S.USER_COUNT1
      , S.USER_COUNT2
      , S.USER_COUNT3
      , S.USER_COUNT4
      , '{{ dag.dag_id }}' AS INS_PGM_ID                            
      , exec_datetime AS INS_DT_TM    
      , '{{ dag.dag_id }}' AS UPD_PGM_ID                            
      , exec_datetime AS UPD_DT_TM    
  FROM
  (
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26001'
  AND CRM_CODE.CODE = 'CRM2600101'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.OCCUPATION_NO = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26002'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.JOB_NO = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26003'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.POSITION_NO = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26004'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.INCOME_NO = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26005'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.PREFEC = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26006'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.AGE2 = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26007'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.BIRTH <> '18680101'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  UNION ALL
  SELECT
      CRM_CODE.VALUE2 AS ATTRIBUTE_KBN1
      , CRM_CODE.VALUE3 AS ATTRIBUTE_KBN2
      , CRM_CODE.VALUE4 AS ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , AD_NK.JW_FLG AS JW_KBN
      , COUNT(DISTINCT AD_NK.HASH_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID AD_NK
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CRM_CODE
  WHERE AD_NK.SEX = CRM_CODE.VALUE1
  AND CRM_CODE.MASTER_TYPE = 'MST260'
  AND CRM_CODE.MASTER_GRP_TYPE = 'GCRM26008'
  AND CRM_CODE.YUKO_FLG = '1'
  AND AD_NK.USER_TYPE = '一般ユーザー'
  AND AD_NK.WITHDRAWAL_FLAG = '会員'
  AND AD_NK.JW_FLG != 0
  GROUP BY
      ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , AD_NK.PRICEPLN_SYSTEM_ID
      , JW_KBN
  ) S
  ;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_ATTR_SS
  (
      SNAPSHOT_DATE
      , RP_ID
      , ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT1
      , USER_COUNT2
      , USER_COUNT3
      , USER_COUNT4
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  SELECT
      exec_date AS SNAPSHOT_DATE
      , 'GDY' AS RP_ID
      , S.ATTRIBUTE_KBN1
      , S.ATTRIBUTE_KBN2
      , S.ATTRIBUTE_KBN3
      , S.PRICEPLN_SYSTEM_ID
      , S.USER_COUNT1
      , S.USER_COUNT2
      , S.USER_COUNT3
      , S.USER_COUNT4
      , '{{ dag.dag_id }}' AS INS_PGM_ID                            
      , exec_datetime AS INS_DT_TM    
      , '{{ dag.dag_id }}' AS UPD_PGM_ID                            
      , exec_datetime AS UPD_DT_TM    
  FROM
  (
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28001'
  AND C.CODE = 'CRM2800101'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID 
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.SEX = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28002'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28003'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CN
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CS
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = CN.VALUE1                    
  AND CN.MASTER_TYPE = 'MST280'
  AND CN.MASTER_GRP_TYPE = 'GCRM28003'            
  AND CN.YUKO_FLG = '1'
  AND N.SEX = CS.VALUE1
  AND CS.MASTER_TYPE = 'MST280'
  AND CS.MASTER_GRP_TYPE = 'GCRM28002'            
  AND CS.YUKO_FLG = '1'
  AND CN.VALUE3 = C.VALUE1
  AND CS.VALUE3 = C.VALUE4
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28004'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.OCCUPATION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28005'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.BUSINESS_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28006'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.JOB_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28007'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.POSITION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28008'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.EMPLOYEES_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28009'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.INCOME_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28010'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PREFEC = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28011'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.NEWS_SUBSCRIPTION1 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28012'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28013'            
  AND C.YUKO_FLG = '1'
  AND C.VALUE1 IS NOT NULL
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD IS NULL
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28013'
  AND C.CODE = 'CRM2801305'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , COUNT(DISTINCT V.FREE_SERIAL_ID) AS USER_COUNT2
      , COUNT(DISTINCT V.PAY_SERIAL_ID) AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_GDY_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28014'
  AND C.YUKO_FLG = '1'
  AND ((N.INTEREST1 = C.VALUE1 AND C.CODE = 'CRM2801401')        
    OR (N.INTEREST2 = C.VALUE1 AND C.CODE = 'CRM2801402')        
    OR (N.INTEREST3 = C.VALUE1 AND C.CODE = 'CRM2801403')        
    OR (N.INTEREST4 = C.VALUE1 AND C.CODE = 'CRM2801404')        
    OR (N.INTEREST5 = C.VALUE1 AND C.CODE = 'CRM2801405')        
    OR (N.INTEREST6 = C.VALUE1 AND C.CODE = 'CRM2801406')        
    OR (N.INTEREST7 = C.VALUE1 AND C.CODE = 'CRM2801407')        
    OR (N.INTEREST8 = C.VALUE1 AND C.CODE = 'CRM2801408')        
    OR (N.INTEREST9 = C.VALUE1 AND C.CODE = 'CRM2801409')        
    OR (N.INTEREST10 = C.VALUE1 AND C.CODE = 'CRM2801410')        
    OR (N.INTEREST11 = C.VALUE1 AND C.CODE = 'CRM2801411')        
    OR (N.INTEREST12 = C.VALUE1 AND C.CODE = 'CRM2801412')        
    OR (N.INTEREST13 = C.VALUE1 AND C.CODE = 'CRM2801413')        
  )
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  ) S
  ;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_ATTR_SS
  (
      SNAPSHOT_DATE
      , RP_ID
      , ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT1
      , USER_COUNT2
      , USER_COUNT3
      , USER_COUNT4
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  SELECT
      exec_date AS SNAPSHOT_DATE
      , 'LI' AS RP_ID
      , S.ATTRIBUTE_KBN1
      , S.ATTRIBUTE_KBN2
      , S.ATTRIBUTE_KBN3
      , S.PRICEPLN_SYSTEM_ID
      , S.USER_COUNT1
      , S.USER_COUNT2
      , S.USER_COUNT3
      , S.USER_COUNT4
      , '{{ dag.dag_id }}' AS INS_PGM_ID                            
      , exec_datetime AS INS_DT_TM    
      , '{{ dag.dag_id }}' AS UPD_PGM_ID                            
      , exec_datetime AS UPD_DT_TM    
  FROM
  (
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34001'
  AND C.CODE = 'CRM3400101'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.SEX = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34002'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34003'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CN
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CS
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = CN.VALUE1                    
  AND CN.MASTER_TYPE = 'MST340'
  AND CN.MASTER_GRP_TYPE = 'GCRM34003'            
  AND CN.YUKO_FLG = '1'
  AND N.SEX = CS.VALUE1
  AND CS.MASTER_TYPE = 'MST340'
  AND CS.MASTER_GRP_TYPE = 'GCRM34002'            
  AND CS.YUKO_FLG = '1'
  AND CN.VALUE3 = C.VALUE1
  AND CS.VALUE3 = C.VALUE4
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34004'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.OCCUPATION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34005'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.BUSINESS_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34006'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.JOB_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34007'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.POSITION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34008'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.EMPLOYEES_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34009'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.INCOME_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34010'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PREFEC = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34011'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.NEWS_SUBSCRIPTION1 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34012'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34013'            
  AND C.YUKO_FLG = '1'
  AND C.VALUE1 IS NOT NULL
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD IS NULL
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34013'
  AND C.CODE = 'CRM3401305'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST340'
  AND C.MASTER_GRP_TYPE = 'GCRM34014'
  AND C.YUKO_FLG = '1'
  AND ((N.INTEREST1 = C.VALUE1 AND C.CODE = 'CRM3401401')        
    OR (N.INTEREST2 = C.VALUE1 AND C.CODE = 'CRM3401402')        
    OR (N.INTEREST3 = C.VALUE1 AND C.CODE = 'CRM3401403')        
    OR (N.INTEREST4 = C.VALUE1 AND C.CODE = 'CRM3401404')        
    OR (N.INTEREST5 = C.VALUE1 AND C.CODE = 'CRM3401405')        
    OR (N.INTEREST6 = C.VALUE1 AND C.CODE = 'CRM3401406')        
    OR (N.INTEREST7 = C.VALUE1 AND C.CODE = 'CRM3401407')        
    OR (N.INTEREST8 = C.VALUE1 AND C.CODE = 'CRM3401408')        
    OR (N.INTEREST9 = C.VALUE1 AND C.CODE = 'CRM3401409')        
    OR (N.INTEREST10 = C.VALUE1 AND C.CODE = 'CRM3401410')        
    OR (N.INTEREST11 = C.VALUE1 AND C.CODE = 'CRM3401411')        
    OR (N.INTEREST12 = C.VALUE1 AND C.CODE = 'CRM3401412')        
    OR (N.INTEREST13 = C.VALUE1 AND C.CODE = 'CRM3401413')        
  )
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC G
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_LI_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND G.SERIAL_ID = V.SERIAL_ID
  AND G.ATTR_VALUE_CHAR = C.VALUE1
  AND G.TABLE_ID = 5
  AND CAST(G.ATTR_ID AS STRING) = C.VALUE5
  AND C.MASTER_TYPE = 'MST340'
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  ) S
  ;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_NUM_DAILY_RP_ATTR_SS
  (
      SNAPSHOT_DATE
      , RP_ID
      , ATTRIBUTE_KBN1
      , ATTRIBUTE_KBN2
      , ATTRIBUTE_KBN3
      , PRICEPLN_SYSTEM_ID
      , USER_COUNT1
      , USER_COUNT2
      , USER_COUNT3
      , USER_COUNT4
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
  )
  SELECT
      exec_date AS SNAPSHOT_DATE
      , 'BA' AS RP_ID
      , S.ATTRIBUTE_KBN1
      , S.ATTRIBUTE_KBN2
      , S.ATTRIBUTE_KBN3
      , S.PRICEPLN_SYSTEM_ID
      , S.USER_COUNT1
      , S.USER_COUNT2
      , S.USER_COUNT3
      , S.USER_COUNT4
      , '{{ dag.dag_id }}' AS INS_PGM_ID                            
      , exec_datetime AS INS_DT_TM    
      , '{{ dag.dag_id }}' AS UPD_PGM_ID                            
      , exec_datetime AS UPD_DT_TM    
  FROM
  (
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST350'
  AND C.MASTER_GRP_TYPE = 'GCRM35001'
  AND C.CODE = 'CRM3500101'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.SEX = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28002'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28003'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CN
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE CS
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.AGE2 = CN.VALUE1                    
  AND CN.MASTER_TYPE = 'MST280'
  AND CN.MASTER_GRP_TYPE = 'GCRM28003'            
  AND CN.YUKO_FLG = '1'
  AND N.SEX = CS.VALUE1
  AND CS.MASTER_TYPE = 'MST280'
  AND CS.MASTER_GRP_TYPE = 'GCRM28002'            
  AND CS.YUKO_FLG = '1'
  AND CN.VALUE3 = C.VALUE1
  AND CS.VALUE3 = C.VALUE4
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28004'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  AND N.BIRTH <> '18680101'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.OCCUPATION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28005'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.BUSINESS_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28006'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.JOB_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28007'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.POSITION_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28008'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.EMPLOYEES_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28009'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.INCOME_NO = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28010'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PREFEC = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28011'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.NEWS_SUBSCRIPTION1 = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28012'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD = C.VALUE1                    
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28013'            
  AND C.YUKO_FLG = '1'
  AND C.VALUE1 IS NOT NULL
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND N.PRICEPLN_CD IS NULL
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28013'
  AND C.CODE = 'CRM2801305'            
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND C.MASTER_TYPE = 'MST280'
  AND C.MASTER_GRP_TYPE = 'GCRM28014'
  AND C.YUKO_FLG = '1'
  AND ((N.INTEREST1 = C.VALUE1 AND C.CODE = 'CRM2801401')        
    OR (N.INTEREST2 = C.VALUE1 AND C.CODE = 'CRM2801402')        
    OR (N.INTEREST3 = C.VALUE1 AND C.CODE = 'CRM2801403')        
    OR (N.INTEREST4 = C.VALUE1 AND C.CODE = 'CRM2801404')        
    OR (N.INTEREST5 = C.VALUE1 AND C.CODE = 'CRM2801405')        
    OR (N.INTEREST6 = C.VALUE1 AND C.CODE = 'CRM2801406')        
    OR (N.INTEREST7 = C.VALUE1 AND C.CODE = 'CRM2801407')        
    OR (N.INTEREST8 = C.VALUE1 AND C.CODE = 'CRM2801408')        
    OR (N.INTEREST9 = C.VALUE1 AND C.CODE = 'CRM2801409')        
    OR (N.INTEREST10 = C.VALUE1 AND C.CODE = 'CRM2801410')    
    OR (N.INTEREST11 = C.VALUE1 AND C.CODE = 'CRM2801411')    
    OR (N.INTEREST12 = C.VALUE1 AND C.CODE = 'CRM2801412')    
    OR (N.INTEREST13 = C.VALUE1 AND C.CODE = 'CRM2801413')    
  )
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  UNION ALL
  SELECT
      C.VALUE2 AS ATTRIBUTE_KBN1
      , C.VALUE3 AS ATTRIBUTE_KBN2
      , C.VALUE4 AS ATTRIBUTE_KBN3
      , N.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
      , COUNT(DISTINCT V.SERIAL_ID) AS USER_COUNT1
      , NULL AS USER_COUNT2
      , NULL AS USER_COUNT3
      , NULL AS USER_COUNT4
  FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID N
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.T_GP_ATTR_AC G
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.V_IMS_BA_USER_ID V
      , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE C
  WHERE N.SERIAL_ID = V.SERIAL_ID
  AND G.SERIAL_ID = V.SERIAL_ID
  AND G.ATTR_VALUE_CHAR = C.VALUE1
  AND G.TABLE_ID = 6
  AND CAST(G.ATTR_ID AS STRING) = C.VALUE5
  AND C.MASTER_TYPE = 'MST350'
  AND C.YUKO_FLG = '1'
  AND N.USER_TYPE = '一般ユーザー'
  AND N.WITHDRAWAL_FLAG = '会員'
  AND V.REG_STATUS = '1'
  AND IFNULL(V.CANCEL_FLAG, '') <> '1'
  GROUP BY
      C.VALUE2
      , C.VALUE3
      , C.VALUE4
      , N.PRICEPLN_SYSTEM_ID
  ) S
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;