--
-- 会員ID日別RPサイト別サービス別プラン別スナップショット(月末日用)
--
DECLARE target_table STRING DEFAULT 'T_BI_USER_ID_DAILY_RP_SERVICE_PLN_LASTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE first_day DATE DEFAULT DATE_TRUNC(exec_date, MONTH); --当月1日
DECLARE last_month_last_day DATE DEFAULT DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL -1 DAY); --先月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_RP_SERVICE_PLN_LASTDAY_SS
  WHERE SNAPSHOT_DATE = last_month_last_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_RP_SERVICE_PLN_LASTDAY_SS(
    SNAPSHOT_DATE
    , HASH_ID
    , SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , PLAN_FLG
    , REQUEST_TYPE
    , DS_REQUEST_TYPE
    , CANCEL_FLG
    , CHANGE_FLG
    , CURRENT_MONTH_CANCEL_FLG
    , CURRENT_MONTH_CHANGE_FLG
    , LOST_W_FLG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
    , CHARGE_KBN
  )
  SELECT
    last_month_last_day
    , A.HASH_ID
    , A.SERIAL_ID
    , RP_ID
    , SERVICE_ID
    , PLAN_ID
    , PLAN_FLG
    , REQUEST_TYPE
    , DS_REQUEST_TYPE
    , IFNULL(CANCELLATION_RESERVED_FLG, 0)
    --有料プラン変更予約フラグ
    , CASE
      WHEN RESERVED_REQUEST_NO > 0
      AND PLAN_CHANGE_REQUEST_DATE IS NOT NULL
      THEN 1
      ELSE 0
      END AS CHANGE_FLG
    --当月締め有料プラン解約予約フラグ
    , CASE
      WHEN FARST_FREE_FLG = 0
      AND RESERVED_REQUEST_NO > 0
      AND CHARGED_PLAN_END_REQUEST_DATE IS NOT NULL
      AND FIXED_RESERVED_DATE = last_month_last_day
      --先月末日
      THEN 1
      ELSE 0
      END AS CURRENT_MONTH_CANCEL_FLG
    --当月締め有料プラン変更予約フラグ
    , CASE
      WHEN FARST_FREE_FLG = 0
      AND RESERVED_REQUEST_NO > 0
      AND PLAN_CHANGE_REQUEST_DATE IS NOT NULL
      AND FIXED_RESERVED_DATE = first_day
      --当月1日
      THEN 1
      ELSE 0
      END AS CURRENT_MONTH_CHANGE_FLG
    , IFNULL(LOST_W_FLG, 0)
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
    , CASE
      WHEN PLAN_FLG = 0
      OR CHARGE_START_DATE > last_month_last_day
      THEN 1
      ELSE 2
      END AS CHARGE_KBN
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.M_IS_NX_ATTRIBUTE A
    INNER JOIN {{ var.value.atlas_bigquery_ims_dataset_name }}.T_KK_CONTRACT_ANALYZE_LASTDAY C
      ON A.HASH_ID = C.HASH_ID
  WHERE
    --一般ユーザー、退会していない
    A.USER_TYPE = '0'
    AND A.WITHDRAWAL_FLAG = '0'
    --サービスが終了していない
    AND C.SERVICE_END_DATE >= last_month_last_day
    AND C.LATEST_CONTRACT_NO = C.CONTRACT_NO
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;