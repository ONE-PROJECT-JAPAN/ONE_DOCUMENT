DECLARE target_table STRING DEFAULT 'T_DSU_T_DS_CLIPPING_KEYWORDS_ACCUM';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_CLIPPING_KEYWORDS_ACCUM A
  USING (
    SELECT
      INSDATE
      , UPDATEDATE
      , HASH_ID
      , SERIAL_ID
      , TONYU_NUM
      , DSP_ORD
      , CUST_NO
      , CLIPPING_KEYWORDS
      , CLIPPING_ALIAS_NM
      , KEITAI_RENDO_FLG
      , ALERT_MAIL_P_RECEIVE_FLG
      , ALERT_MAIL_M_RECEIVE_FLG
      , ZERO_FLG
      , '0' AS DELETE_FLG
      , 'IMS' AS INS_BATCH_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_BATCH_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_DSU_T_DS_CLIPPING_KEYWORDS B
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.CLIPPING_KEYWORDS = B.CLIPPING_KEYWORDS
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
      UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
      , DELETE_FLG = '0'
  WHEN NOT MATCHED BY SOURCE THEN
    --IFに存在しない
    UPDATE
    SET
      UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
      , DELETE_FLG = '1'
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;