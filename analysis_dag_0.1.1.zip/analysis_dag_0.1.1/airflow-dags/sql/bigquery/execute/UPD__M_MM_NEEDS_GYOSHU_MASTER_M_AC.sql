DECLARE target_table STRING DEFAULT 'M_MM_NEEDS_GYOSHU_MASTER_M_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.M_MM_NEEDS_GYOSHU_MASTER_M_AC A
  USING (
    SELECT
        RECID
        , M_BUNRUI_CODE
        , SORT_NUMBER
        , DATADATE
        , MIJOJO_HUBAN_FLAG
        , NAME_S
        , NAME_R
        , INSDATE
        , UPDATEDATE
        , NAME_R_NKD
        , 'IMS' AS INS_BATCH_ID
        , exec_datetime AS INS_DT_TM
        , 'IMS' AS UPD_BATCH_ID
        , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.M_MM_NEEDS_GYOSHU_MASTER_M B
  ) B
    ON A.M_BUNRUI_CODE = B.M_BUNRUI_CODE
  WHEN MATCHED THEN
    --IFに存在
    UPDATE
    SET
       RECID = B.RECID
      , SORT_NUMBER = B.SORT_NUMBER
      , DATADATE = B.DATADATE
      , MIJOJO_HUBAN_FLAG = B.MIJOJO_HUBAN_FLAG
      , NAME_S = B.NAME_S
      , NAME_R = B.NAME_R
      , INSDATE = B.INSDATE
      , UPDATEDATE = B.UPDATEDATE
      , NAME_R_NKD = B.NAME_R_NKD
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
