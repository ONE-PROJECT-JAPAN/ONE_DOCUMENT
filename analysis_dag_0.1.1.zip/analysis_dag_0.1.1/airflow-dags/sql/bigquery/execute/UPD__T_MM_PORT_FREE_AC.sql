DECLARE target_table STRING DEFAULT 'T_MM_PORT_FREE_AC';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_MM_PORT_FREE_AC A
  USING (
    SELECT
      HASH_ID
    , SERIAL_ID
    , PORTFOLIO_NO
    , GROUP_NO
    , FREE_NAME
    , KUCHISU
    , PRICE
    , SEQ_NO
    , MONEY_USER_FLAG
    , INSDATE
    , UPDATEDATE
    , 'IMS' as INS_BATCH_ID
    , exec_datetime as INS_DT_TM
    , 'IMS' as UPD_BATCH_ID
    , exec_datetime as UPD_DT_TM
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_MM_PORT_FREE
  ) B
    ON A.HASH_ID = B.HASH_ID
    AND A.PORTFOLIO_NO = B.PORTFOLIO_NO
  WHEN MATCHED THEN
    UPDATE
    SET
        SERIAL_ID = B.SERIAL_ID
      , GROUP_NO = B.GROUP_NO
      , FREE_NAME = B.FREE_NAME
      , KUCHISU = B.KUCHISU
      , PRICE = B.PRICE
      , SEQ_NO = B.SEQ_NO
      , MONEY_USER_FLAG = B.MONEY_USER_FLAG
      , INSDATE = B.INSDATE
      , UPDATEDATE = B.UPDATEDATE
      , UPD_BATCH_ID = 'IMS'
      , UPD_DT_TM = exec_datetime
  WHEN NOT MATCHED BY TARGET THEN
    --IFのみに存在
    INSERT ROW
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;
