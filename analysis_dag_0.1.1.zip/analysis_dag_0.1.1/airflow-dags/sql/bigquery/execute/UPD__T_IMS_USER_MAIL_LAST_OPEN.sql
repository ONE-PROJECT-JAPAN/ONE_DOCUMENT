DECLARE target_table STRING DEFAULT 'T_IMS_USER_MAIL_LAST_OPEN';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_MAIL_LAST_OPEN A
  USING (
    WITH
    MAD AS (
      SELECT
        HASH_ID
        , SERIAL_ID
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
      WHERE
        {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(SERIAL_ID) = false
    ),
    --直近メール開封状況
    ATL AS (
      SELECT
        ig_usr_user_id AS SERIAL_ID
        , ig_ctx_content_name AS CONTENT_NAME
        , DATETIME(er_dat_jp_timestamp) AS OPEN_DT_TM
      FROM
        atlas.v_atlas_yesterday
      WHERE
        ig_sys_source <> 'adobe_analytics'
        AND ig_action = 'open'
        AND ig_category = 'mail'
        AND ig_sys_source = 'mail'
        AND ig_usr_user_id IS NOT NULL
        AND er_bot_is_bot = false
    )
    --過去データと新データを結合して日時が新しいほうを採用
    SELECT
      HASH_ID
      , SERIAL_ID
      , SEND_MAIL_KIND
      , MAX(LAST_OPEN_DT_TM) AS LAST_OPEN_DT_TM
      , exec_datetime AS INS_DT_TM
    FROM
      (
        SELECT
          HASH_ID
          , SERIAL_ID
          , SEND_MAIL_KIND
          , LAST_OPEN_DT_TM
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_USER_MAIL_LAST_OPEN
        --電子版メールマガジン（テキスト・ALL）
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , '00005MMT0' AS SEND_MAIL_KIND
          , ATL.OPEN_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN (
            SELECT
              *
            FROM
              ATL
            WHERE
              SUBSTRING(CONTENT_NAME, 14, 4) = 'DSMM'
          ) AS ATL
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
        --日経ニュースメール（テキスト・ALL）
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , '00020NST0' AS SEND_MAIL_KIND
          , ATL.OPEN_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN (
            SELECT
              *
            FROM
              ATL
            WHERE
              SUBSTRING(CONTENT_NAME, 14, 4) = 'NEWS'
          ) AS ATL
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
        --速報メール（テキスト・ALL)
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , '00001SKT0' AS SEND_MAIL_KIND
          , ATL.OPEN_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN (
            SELECT
              *
            FROM
              ATL
            WHERE
              LENGTH(CONTENT_NAME) = 20
              AND CONTENT_NAME LIKE 'NKSM%'
          ) AS atl
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
        --Myニュースメール（テキスト・有料）
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , '00026MYT0' AS SEND_MAIL_KIND
          , ATL.OPEN_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN (
            SELECT
              *
            FROM
              ATL
            WHERE
              SUBSTRING(CONTENT_NAME, 14, 4) = 'MYNM'
          ) AS ATL
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
        --NIKKEI BRIEFING
        UNION ALL
        SELECT
          MAD.HASH_ID
          , MAD.SERIAL_ID
          , 'BRIEFING' AS SEND_MAIL_KIND
          , ATL.OPEN_DT_TM
        FROM
          MAD
          LEFT OUTER JOIN (
            SELECT
              *
            FROM
              ATL
            WHERE
              LENGTH(CONTENT_NAME) = 19
              AND (
                CONTENT_NAME LIKE 'NKBR%'
                OR CONTENT_NAME LIKE 'SCMGR3001%'
                OR CONTENT_NAME LIKE 'SCMGR3002%'
                OR CONTENT_NAME LIKE 'SCMGR3003%'
                OR CONTENT_NAME LIKE 'SCMGR3004%'
              )
          ) AS ATL
            ON MAD.SERIAL_ID = ATL.SERIAL_ID
      )
    GROUP BY
      HASH_ID
      , SERIAL_ID
      , SEND_MAIL_KIND
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;