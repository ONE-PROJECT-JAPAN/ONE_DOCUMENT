DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_PK_CONTRACT_LASTDAY_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');
DECLARE last_month_last_day DATE DEFAULT DATE_ADD(DATE_TRUNC(exec_date, MONTH), INTERVAL -1 DAY); --先月末日

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_PK_CONTRACT_LASTDAY_SS
  WHERE SNAPSHOT_DATE = last_month_last_day
  ;

  --更新処理
  INSERT
  INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_PK_CONTRACT_LASTDAY_SS (
    SNAPSHOT_DATE
    , PRODUCT_CD
    , USER_COUNT
    , CANCEL_COUNT
    , CHANGE_COUNT
    , CONTRACT_USER_COUNT
    , CONTRACT_CANCEL_COUNT
    , CONTRACT_CHANGE_COUNT
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
  )
  SELECT
    SNAPSHOT_DATE
    , PRODUCT_CD
    --会員数
    , COUNT(DISTINCT HASH_ID) AS USER_COUNT
    --解約予約
    , COUNT(
      DISTINCT CASE
        WHEN CANCEL_FLG = '1'
        AND CRM_CANCEL_EXCLUDE_FLG <> '1'
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CANCEL_COUNT
    --変更予約
    , COUNT(
      DISTINCT CASE
        WHEN CHANGE_FLG = '1'
        AND CRM_CANCEL_EXCLUDE_FLG <> '1'
        THEN HASH_ID
        ELSE NULL
        END
    ) AS CHANGE_COUNT
    --契約数
    , COUNT(DISTINCT CONTRACT_SPECIFIC_NO) AS CONTRACT_USER_COUNT
    --解約予約契約数
    , COUNT(
      DISTINCT CASE
        WHEN CANCEL_FLG = '1'
        AND CRM_CANCEL_EXCLUDE_FLG <> '1'
        THEN CONTRACT_SPECIFIC_NO
        ELSE NULL
        END
    ) AS CONTRACT_CANCEL_COUNT
    --変更予約契約数
    , COUNT(
      DISTINCT CASE
        WHEN CHANGE_FLG = '1'
        AND CRM_CANCEL_EXCLUDE_FLG <> '1'
        THEN CONTRACT_SPECIFIC_NO
        ELSE NULL
        END
    ) AS CONTRACT_CHANGE_COUNT
    , 'IMS'
    , exec_datetime
    , 'IMS'
    , exec_datetime
  FROM
    {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_ID_DAILY_PK_CONTRACT_LASTDAY_SS
  WHERE
    SNAPSHOT_DATE = last_month_last_day
  GROUP BY
    SNAPSHOT_DATE
    , PRODUCT_CD
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;