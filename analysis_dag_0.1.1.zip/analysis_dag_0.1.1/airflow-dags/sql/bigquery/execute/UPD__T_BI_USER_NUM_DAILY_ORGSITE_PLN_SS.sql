/*

   参照テーブル:
      M_AD_NIKKEI_ID
      M_CRM_CODE

*/
DECLARE target_table STRING DEFAULT 'T_BI_USER_NUM_DAILY_ORGSITE_PLN_SS';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  BEGIN TRANSACTION;

  DELETE FROM {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_ORGSITE_PLN_SS
  WHERE SNAPSHOT_DATE = exec_date
  ;

  --更新処理
  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_BI_USER_NUM_DAILY_ORGSITE_PLN_SS
  (
          SNAPSHOT_DATE
          ,ORGSITE_KBN
          ,PRICEPLN_SYSTEM_ID
          ,PRICEPLN_CD
          ,USER_COUNT
          ,INS_BATCH_ID
          ,INS_DT_TM
          ,UPD_BATCH_ID
          ,UPD_DT_TM
  )
  (
  SELECT
          exec_date AS SNAPSHOT_DATE
          ,M_CRM_CODE.CODE AS ORGSITE_KBN
          ,M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID AS PRICEPLN_SYSTEM_ID
          ,M_AD_NIKKEI_ID.PRICEPLN_CD AS PRICEPLN_CD
          ,COUNT(*) AS USER_COUNT
          ,'{{ dag.dag_id }}'
          ,exec_datetime
          ,'{{ dag.dag_id }}'
          ,exec_datetime
  FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
        , {{ var.value.atlas_bigquery_ims_dataset_name }}.M_CRM_CODE
  WHERE
          M_AD_NIKKEI_ID.WITHDRAWAL_FLAG = '会員' AND
          M_AD_NIKKEI_ID.USER_TYPE = '一般ユーザー' AND
          M_AD_NIKKEI_ID.PRICEPLN_SYSTEM_ID IS NOT NULL AND
          M_AD_NIKKEI_ID.PRICEPLN_CD IS NOT NULL AND
          M_CRM_CODE.MASTER_TYPE = 'MST170' AND
          M_CRM_CODE.MASTER_GRP_TYPE = 'GCRM170' AND
          M_CRM_CODE.YUKO_FLG = '1' AND
          M_CRM_CODE.VALUE1 = M_AD_NIKKEI_ID.ORIGINAL_SITE
  GROUP BY
          SNAPSHOT_DATE
          ,ORGSITE_KBN
          ,PRICEPLN_SYSTEM_ID
          ,PRICEPLN_CD
  )
  ;

  COMMIT TRANSACTION;

EXCEPTION WHEN ERROR THEN

  ROLLBACK TRANSACTION;

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;