DECLARE target_table STRING DEFAULT 'T_LI_USER_ATTR';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_LI_USER_ATTR A
  USING (
    SELECT
      RPID
      , HASH_ID
      , SERIAL_ID
      , CANCEL_FLAG
      , REGIST_DATE
      , UPDATE_DATE
      , MM_03001NSM0
      , MM_03002NSM0
      , MM_03003NSM0
      , MM_03004NSM0
      , MM_03005NSM0
      , MM_03006NSM0
      , MM_03007NSM0
      , MM_03008NSM0
      , MM_03009NSM0
      , MM_03010NSM0
      , MM_03011NSM0
      , MM_03012NSM0
      , MM_03013NSM0
      , MM_03014NSM0
      , MM_03015NSM0
      , MM_03016NSM0
      , MM_03017NSM0
      , MM_03018NSM0
      , MM_03019NSM0
      , MM_03020NSM0
      , MM_03021NSM0
      , MM_03022NSM0
      , MM_03023NSM0
      , MM_03024NSM0
      , MM_03025NSM0
      , MM_03026NSM0
      , MM_03027NSM0
      , MM_03028NSM0
      , MM_03029NSM0
      , MM_03030NSM0
      , MM_03031NSM0
      , MM_03032NSM0
      , MM_03033NSM0
      , MM_03034NSM0
      , MM_03035NSM0
      , MM_03036NSM0
      , MM_03037NSM0
      , MM_03038NSM0
      , MM_03039NSM0
      , MM_03040NSM0
      , MM_03041NSM0
      , MM_03042NSM0
      , MM_03043NSM0
      , MM_03044NSM0
      , MM_03045NSM0
      , MM_03046NSM0
      , MM_03047NSM0
      , MM_03048NSM0
      , MM_03049NSM0
      , MM_03050NSM0
      , 'IMS' AS INS_PGM_ID
      , exec_datetime AS INS_DT_TM
      , 'IMS' AS UPD_PGM_ID
      , exec_datetime AS UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR
    UNION ALL
    --IFに存在しないデータを結合
    SELECT
      RPID
      , HASH_ID
      , SERIAL_ID
      , CANCEL_FLAG
      , REGIST_DATE
      , UPDATE_DATE
      , MM_03001NSM0
      , MM_03002NSM0
      , MM_03003NSM0
      , MM_03004NSM0
      , MM_03005NSM0
      , MM_03006NSM0
      , MM_03007NSM0
      , MM_03008NSM0
      , MM_03009NSM0
      , MM_03010NSM0
      , MM_03011NSM0
      , MM_03012NSM0
      , MM_03013NSM0
      , MM_03014NSM0
      , MM_03015NSM0
      , MM_03016NSM0
      , MM_03017NSM0
      , MM_03018NSM0
      , MM_03019NSM0
      , MM_03020NSM0
      , MM_03021NSM0
      , MM_03022NSM0
      , MM_03023NSM0
      , MM_03024NSM0
      , MM_03025NSM0
      , MM_03026NSM0
      , MM_03027NSM0
      , MM_03028NSM0
      , MM_03029NSM0
      , MM_03030NSM0
      , MM_03031NSM0
      , MM_03032NSM0
      , MM_03033NSM0
      , MM_03034NSM0
      , MM_03035NSM0
      , MM_03036NSM0
      , MM_03037NSM0
      , MM_03038NSM0
      , MM_03039NSM0
      , MM_03040NSM0
      , MM_03041NSM0
      , MM_03042NSM0
      , MM_03043NSM0
      , MM_03044NSM0
      , MM_03045NSM0
      , MM_03046NSM0
      , MM_03047NSM0
      , MM_03048NSM0
      , MM_03049NSM0
      , MM_03050NSM0
      , INS_PGM_ID
      , INS_DT_TM
      , UPD_PGM_ID
      , UPD_DT_TM
    FROM
      {{ var.value.atlas_bigquery_ims_dataset_name }}.T_LI_USER_ATTR A
    WHERE
      NOT EXISTS (
        SELECT
          1
        FROM
          {{ var.value.atlas_bigquery_ims_dataset_name }}.W_LI_USER_ATTR B
        WHERE
          B.HASH_ID = A.HASH_ID
      )
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;