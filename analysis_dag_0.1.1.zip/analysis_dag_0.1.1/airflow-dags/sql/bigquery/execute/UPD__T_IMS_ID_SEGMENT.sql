DECLARE target_table STRING DEFAULT 'T_IMS_ID_SEGMENT';
DECLARE exec_datetime DATETIME DEFAULT CURRENT_DATETIME('Asia/Tokyo');
DECLARE exec_date DATE DEFAULT DATE('{{ next_execution_date }}', 'Asia/Tokyo');

BEGIN

  --更新処理
  MERGE {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_ID_SEGMENT A
  USING (
    WITH
    --属性
    ATTRIBUTE AS (
      SELECT
        HASH_ID
        , SERIAL_ID
        , CASE
          --A. 業種軸
          WHEN BUSINESS_NAME = '金融・証券・保険'
          THEN 'A1'
          WHEN BUSINESS_NAME IN ('電気、電子機器', '自動車、輸送機器', 'エネルギー', '機械、重電業')
          THEN 'A2'
          WHEN BUSINESS_NAME IN ('通信サービス', '情報処理、ＳＩ、ソフトウェア')
          THEN 'A3'
          WHEN BUSINESS_NAME = '卸売・小売業・商業（商社含む）'
          THEN 'A4'
          -- B. 職業・職種軸
          WHEN JOB_NAME = '営業・販売'
          OR (
            AGE IN ('20代', '20歳未満')
            AND OCCUPATION_NAME = 'お勤め（会社員、公務員など）'
          )
          OR (
            AGE IN ('20代', '20歳未満')
            AND OCCUPATION_NAME = '学生'
          )
          THEN 'B1'
          WHEN (
            JOB_NAME = '経営者・役員'
            AND EMPLOYEES_SCALE NOT IN ('1～9人', '10～49人')
          )
          OR BUSINESS_NAME = 'コンサル・会計・法律関連'
          THEN 'B2'
          WHEN AGE IN ('40代', '50代')
          AND (POSITION_NAME IN ('本部長クラス', '部長クラス', '課長クラス'))
          THEN 'B3'
          WHEN (
            JOB_NAME = '経営者・役員'
            AND EMPLOYEES_SCALE IN ('1～9人', '10～49人')
          )
          OR OCCUPATION_NAME = '自営・自由業'
          OR OCCUPATION_NAME = '主婦（パート含む）'
          OR OCCUPATION_NAME = '無職'
          OR AGE IN ('70代以上')
          THEN 'B4'
          -- C. 年代軸
          WHEN AGE IN ('30代', '40代')
          AND OCCUPATION_NAME IN ('お勤め（会社員、公務員など）', '学生')
          THEN 'C1'
          WHEN AGE IN ('50代', '60代')
          AND OCCUPATION_NAME IN ('お勤め（会社員、公務員など）', '学生')
          THEN 'C2'
          ELSE 'Z9'
          END AS INDUSTRY_SEGMENT_NO
      FROM
        {{ var.value.atlas_bigquery_ims_dataset_name }}.M_AD_NIKKEI_ID
      WHERE
        {{ var.value.atlas_bigquery_ims_dataset_name }}.IS_EMPTY(SERIAL_ID) = false
    )
    SELECT
      HASH_ID
      , SERIAL_ID
      , CASE INDUSTRY_SEGMENT_NO
        WHEN 'A1' THEN 'A1.金融業'
        WHEN 'A2' THEN 'A2.電気電子・自動車・インフラ業'
        WHEN 'A3' THEN 'A3.情報処理・通信サービス業'
        WHEN 'A4' THEN 'A4.卸売・小売業・商業'
        WHEN 'B1' THEN 'B1.営業販売・20代お勤め・学生'
        WHEN 'B2' THEN 'B2.中規模以上経営者・コンサル'
        WHEN 'B3' THEN 'B3.40-50代役職者（部課長クラス以上）'
        WHEN 'B4' THEN 'B4.個人投資家全般（自営、小規模経営者、無職）'
        WHEN 'C1' THEN 'C1.30-40代お勤め一般'
        WHEN 'C2' THEN 'C2.50-60代お勤め一般'
        WHEN 'Z9' THEN 'Z9.その他'
        END AS INDUSTRY_SEGMENT
      , exec_datetime
    FROM
      ATTRIBUTE
  ) B
    ON FALSE
  WHEN NOT MATCHED THEN
    INSERT ROW
  WHEN NOT MATCHED BY SOURCE THEN
    DELETE
  ;

EXCEPTION WHEN ERROR THEN

  INSERT INTO {{ var.value.atlas_bigquery_ims_dataset_name }}.T_IMS_EXECUTE_ERROR_MNG
  VALUES (
    exec_datetime
    , target_table
    , @@error.message
    , @@error.formatted_stack_trace
  )
  ;

  RAISE USING MESSAGE = @@error.message;

END;