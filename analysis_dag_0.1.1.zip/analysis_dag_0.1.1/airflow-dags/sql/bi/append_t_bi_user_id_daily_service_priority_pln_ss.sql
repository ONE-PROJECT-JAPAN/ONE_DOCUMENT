/*

   参照テーブル:
      M_IS_NX_ATTRIBUTE
      V_BI_USER_ID_SERVICE_PRIORITY_PLN
        M_BB_CORPORATE_PLN
        M_CRM_CODE
        T_BB_AGREEMENT_LIST
        T_KK_V_CONTRACT_ANALYZE

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS
(
     SNAPSHOT_DATE
    ,USER_NO
    ,CORP_FLG
    ,RP_ID
    ,SERVICE_ID
    ,PLAN_ID
    ,CANCEL_FLG
    ,INS_BATCH_ID
    ,INS_DT_TM
    ,UPD_BATCH_ID
    ,UPD_DT_TM
    ,CHARGE_KBN
)    
(
SELECT
     {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
    ,V.USER_NO
    ,V.CORP_FLG
    ,V.RP_ID
    ,V.SERVICE_ID
    ,V.PLAN_ID
    ,V.CANCEL_FLG
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,CHARGE_KBN
FROM    
    {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_SERVICE_PRIORITY_PLN V
INNER JOIN
    {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE ATTR
ON
    V.USER_NO = ATTR.USER_NO
AND
    ATTR.WITHDRAWAL_FLAG = '0'
AND
    ATTR.USER_TYPE = '0'
)
;