/*

   参照テーブル:
      M_IS_NX_ATTRIBUTE
      T_PK_V_CONTRACT_INFO

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BI_USER_ID_DAILY_PK_CONTRACT_SS
(
    SNAPSHOT_DATE
    , CONTRACT_SPECIFIC_NO
    , NIKKEI_MEMBER_NO
    , PRODUCT_CD
    , CANCEL_FLG
    , CHANGE_FLG
    , CURRENT_MONTH_CANCEL_FLG
    , BAITAI_KBN_CD
    , KAMI_BAITAI_KBN_CD
    , SET_ALLDAY_KBN
    , W_DROP_FLG
    , DELIVERY_NOT_ST_FLG
    , CRM_CANCEL_EXCLUDE_FLG
    , GENDOKU_KBN
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
)
SELECT
    {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() AS SNAPSHOT_DATE
    , C.CONTRACT_SPECIFIC_NO
    , C.NIKKEI_MEMBER_NO
    , C.PRODUCT_CD
    , C.CANCEL_FLG
    , C.CHANGE_FLG
    , C.CURRENT_MONTH_CANCEL_FLG
    , C.BAITAI_KBN_CD
    , C.KAMI_BAITAI_KBN_CD
    , C.SET_ALLDAY_KBN
    , C.W_DROP_FLG
    , C.DELIVERY_NOT_ST_FLG
    , C.CRM_CANCEL_EXCLUDE_FLG
    , C.GENDOKU_KBN
    , '{{ dag.dag_id }}' AS INS_BATCH_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_BATCH_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE A
INNER JOIN
    {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO C
ON
    A.USER_NO = C.NIKKEI_MEMBER_NO
WHERE
    A.USER_TYPE = '0'
AND
    A.WITHDRAWAL_FLAG = '0'
AND
    C.CONTRACT_FLG = '1'
;