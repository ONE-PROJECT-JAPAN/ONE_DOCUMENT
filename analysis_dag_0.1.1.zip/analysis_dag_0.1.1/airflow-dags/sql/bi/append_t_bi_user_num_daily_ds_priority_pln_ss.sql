/*

   参照テーブル:
      T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BI_USER_NUM_DAILY_DS_PRIORITY_PLN_SS
(
      SNAPSHOT_DATE
     ,PRICEPLN_SYSTEM_ID
     ,PRICEPLN_CD
     ,USER_COUNT
     ,CANCEL_COUNT
     ,CHANGE_COUNT
     ,INS_BATCH_ID
     ,INS_DT_TM
     ,UPD_BATCH_ID
     ,UPD_DT_TM
)
(
SELECT
     SS.SNAPSHOT_DATE                  AS SNAPSHOT_DATE
    ,SS.PRICEPLN_SYSTEM_ID             AS PRICEPLN_SYSTEM_ID
    ,SS.PRICEPLN_CD                    AS PRICEPLN_CD
    ,COUNT(*)                          AS USER_COUNT
    ,SUM(
        CASE 
            WHEN SS.CANCEL_FLG = 1 THEN 1
             ELSE 0
         END) AS CANCEL_COUNT
    ,SUM(
        CASE WHEN SS.CHANGE_FLG = 1
            THEN 1
            ELSE 0
        END ) AS CHANGE_COUNT
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
     {{ var.value.redshift_ims_schema_name }}.T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS SS
WHERE
    SS.SNAPSHOT_DATE = {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
AND
    SS.PRICEPLN_SYSTEM_ID IS NOT NULL
AND
    SS.PRICEPLN_CD IS NOT NULL
GROUP BY
     SS.SNAPSHOT_DATE
    ,SS.PRICEPLN_SYSTEM_ID
    ,SS.PRICEPLN_CD
)
;