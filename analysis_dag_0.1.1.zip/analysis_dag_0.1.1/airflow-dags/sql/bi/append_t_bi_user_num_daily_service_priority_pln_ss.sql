/*

   参照テーブル:
      T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BI_USER_NUM_DAILY_SERVICE_PRIORITY_PLN_SS
(
      SNAPSHOT_DATE
     ,CORP_FLG
     ,RP_ID
     ,SERVICE_ID
     ,PLAN_ID
     ,USER_COUNT
     ,CANCEL_COUNT
     ,INS_BATCH_ID
     ,INS_DT_TM
     ,UPD_BATCH_ID
     ,UPD_DT_TM
)
(
SELECT
     SS.SNAPSHOT_DATE                  AS SNAPSHOT_DATE
    ,SS.CORP_FLG                       AS CORP_FLG
    ,SS.RP_ID                          AS RP_ID
    ,SS.SERVICE_ID                     AS SERVICE_ID
    ,SS.PLAN_ID                        AS PLAN_ID
    ,COUNT(*)                          AS USER_COUNT
    ,SUM(
        CASE 
            WHEN SS.CANCEL_FLG = 1 THEN 1
             ELSE 0
         END ) AS CANCEL_COUNT
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
     {{ var.value.redshift_ims_schema_name }}.T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS SS
WHERE
    SS.SNAPSHOT_DATE = {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
AND
    SS.RP_ID IS NOT NULL
AND
    SS.SERVICE_ID IS NOT NULL
AND
    SS.PLAN_ID IS NOT NULL
GROUP BY
     SS.SNAPSHOT_DATE
    ,SS.CORP_FLG
    ,SS.RP_ID
    ,SS.SERVICE_ID
    ,SS.PLAN_ID
)
;