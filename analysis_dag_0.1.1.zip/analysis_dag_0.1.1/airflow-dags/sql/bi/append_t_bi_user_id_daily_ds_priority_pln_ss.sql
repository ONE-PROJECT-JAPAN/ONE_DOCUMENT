/*

   参照テーブル:
      M_IS_MM_ADDRESS
      M_IS_NX_ATTRIBUTE
      V_BI_USER_ID_DS_PRIORITY_PLN
        M_BB_CORPORATE_PLN
        M_CRM_CODE
        M_IS_NX_ATTRIBUTE
        T_BB_AGREEMENT_LIST
        T_KK_V_CONTRACT_ANALYZE
        T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS
(
     SNAPSHOT_DATE
    ,USER_NO
    ,PRICEPLN_SYSTEM_ID
    ,PRICEPLN_CD
    ,CANCEL_FLG
    ,CHANGE_FLG
    ,PREFEC
    ,INS_BATCH_ID
    ,INS_DT_TM
    ,UPD_BATCH_ID
    ,UPD_DT_TM
    ,CHARGE_KBN
)
(
SELECT
     {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
    ,V.USER_NO
    ,V.PRICEPLN_SYSTEM_ID
    ,V.PRICEPLN_CD
    ,V.CANCEL_FLG
    ,V.CHANGE_FLG
    ,ADD.PREFEC
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    ,CHARGE_KBN
FROM
    {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_DS_PRIORITY_PLN V
INNER JOIN
    {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE ATTR
ON
    V.USER_NO = ATTR.USER_NO
AND
    ATTR.WITHDRAWAL_FLAG = '0'
AND
    ATTR.USER_TYPE = '0'
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS ADD
ON
    ATTR.ADDRESS_CODE = ADD.ADRS_CD
WHERE    
    V.PRICEPLN_SYSTEM_ID IS NOT NULL
AND
    V.PRICEPLN_CD IS NOT NULL
)
;