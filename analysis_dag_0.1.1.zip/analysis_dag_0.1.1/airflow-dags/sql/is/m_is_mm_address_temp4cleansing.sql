
/*******************************************************************************
  SQL名:
       住所マスタ データクレンジング（前処理）

  処理概要:
       住所マスタテーブルにロードしたIFデータを元に
       クレンジング処理用の一時テーブルを生成して、
       クレンジング処理前ファイルを生成する
*******************************************************************************/

-- 一時テーブルの削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS_TEMP_CLEANSING
;

-- ROWIDを付加した作業用テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS_TEMP_CLEANSING AS
SELECT
    ROW_NUMBER () over(order by ADRS_CD) AS ROWID
   ,ADRS_CD
   ,PREFEC_CD
   ,CITY_CD
   ,TSUSHO_CD
   ,CHOME_CD
   ,NEW_ADRS_CD
   ,ADRS_TYPE
   ,ZIPCODE
   ,BCD_INFO
   ,BCD_MOJINUM
   ,ZIPCODE_INFO1
   ,ZIPCODE_INFO2
   ,OYAKO_SIKIBETSU_FLG
   ,OYAKO_CD
   ,PREFEC_FUYOU_CD
   ,PREFEC_KANA
   ,CITY_KANA
   ,TSUSHO_KANA
   ,CHOME_KANA
   ,PREFEC_KANA_MOJINUM
   ,CITY_KANA_MOJINUM
   ,TSUSHO_KANA_MOJINUM
   ,CHOME_KANA_MOJINUM
   ,TOTAL_KANA_MOJINUM
   ,PREFEC
   ,CITY
   ,TSUSHO
   ,CHOME
   ,PREFEC_MOJINUM
   ,CITY_MOJINUM
   ,TSUSHO_MOJINUM
   ,CHOME_MOJINUM
   ,TOTAL_MOJINUM
   ,PREFEC_JISHU
   ,CITY_JISHU1
   ,CITY_JISHU2
   ,TOWN_JISHU1
   ,TOWN_JISHU2
   ,CHOME_JISHU1
   ,CHOME_JISHU2
   ,OAZA_FLG1
   ,OAZA_FLG2
   ,TSUSHO_SIKIBETSU
   ,TSUSHO_FLG
   ,DATA_YMD
   ,OLD_YMD
   ,NEW_YMD
   ,KOSHO_YMD
   ,ZIPCODE_YMD
   ,BCD_YMD
   ,OYAKO_YMD
   ,TSUSHO_YMD
   ,CHOME_YMD
   ,OLD_ZIPCODE
   ,SHOW_FLG
   ,SORT_ORDER
   ,CREATE_DATE
   ,CREATE_USER
   ,UPDATE_DATE
   ,UPDATE_USER
   ,DELETE_DATE
   ,DELETE_USER
   ,DELETE_FLG
FROM {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS
;

-- クレンジング対象項目を抜き出し、クレンジング処理前のファイルを作成する
UNLOAD ($$
SELECT
   M.ROWID                     AS ROWID_IF
  ,M.ADRS_CD                   AS ADRS_CD
  ,RTRIM(NVL(M.ZIPCODE,''))    AS ZIPCODE
  ,NVL(M.PREFEC,'')      ||
      NVL(M.CITY,'')     ||
      NVL(M.TSUSHO,'')   ||
      NVL(M.CHOME,'')          AS ADDRESS
FROM {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS_TEMP_CLEANSING M
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS_CL_AC AC
    WHERE
      M.ADRS_CD = AC.ADRS_CD
    AND
      NVL(M.ZIPCODE,'') = NVL(AC.ZIPCODE,'')
    AND
      NVL(M.PREFEC,'') = NVL(AC.PREFEC,'')
    AND
      NVL(M.CITY,'') = NVL(AC.CITY,'')
    AND
      NVL(M.TSUSHO,'') = NVL(AC.TSUSHO,'')
    AND
      NVL(M.CHOME,'') = NVL(AC.CHOME,'')
    AND
      AC.CL_END_DT = '9999-12-31'
  )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/M_IS_MM_ADDRESS/M_IS_MM_ADDRESS_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
