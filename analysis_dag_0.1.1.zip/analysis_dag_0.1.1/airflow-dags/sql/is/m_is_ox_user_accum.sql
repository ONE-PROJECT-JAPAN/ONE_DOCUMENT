
/*******************************************************************************
  SQL名:
    ユ オープン化ユーザーID管理テーブルデータ蓄積

  処理概要:
        オープン化ユーザーID管理テーブルデータの蓄積を行う

       蓄積キー:
         C_OPEN_USER_ID

*******************************************************************************/
-- IFテーブルのデータと同じキーのテータを蓄積テーブルから削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_OX_USER_ACCUM 
    WHERE 
    (C_OPEN_USER_ID) IN (
        SELECT 
            C_OPEN_USER_ID
        FROM {{ var.value.redshift_ims_schema_name }}.M_IS_OX_USER
    )
;

-- IFテーブルのデータを蓄積テーブルに追加
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IS_OX_USER_ACCUM
(    C_OPEN_USER_ID
,    C_CLIENT_ID
,    C_LOCAL_USER_ID
,    CREATE_DATE
,    CREATE_USER
,    UPDATE_DATE
,    UPDATE_USER
,    DELETE_DATE
,    DELETE_USER
,    DELETE_FLG
,    INS_BATCH_ID
,    INS_DT_TM
,    UPD_BATCH_ID
,    UPD_DT_TM
)
SELECT
     C_OPEN_USER_ID
,    C_CLIENT_ID
,    C_LOCAL_USER_ID
,    CREATE_DATE
,    CREATE_USER
,    UPDATE_DATE
,    UPDATE_USER
,    DELETE_DATE
,    DELETE_USER
,    DELETE_FLG
,    '{{ dag.dag_id }}' AS INS_BATCH_ID
,    CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
,    '{{ dag.dag_id }}' AS UPD_BATCH_ID
,    CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.M_IS_OX_USER
;
