
/*******************************************************************************
  SQL名:
    共通属性テーブルデータ差分ファイル作成

  処理概要:
       共通属性テーブル蓄積を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
*******************************************************************************/
UNLOAD ('
SELECT
   M.ROWID                       AS ROWID_IF
  ,CAST(M.USER_NO AS VARCHAR)    AS USER_NO
  ,NVL(M.LAST_NAME, \'\')        AS LAST_NAME
  ,NVL(M.FIRST_NAME, \'\')       AS FIRST_NAME
  ,NVL(M.ZIP_CODE, \'\')         AS ZIP_CODE
  ,NVL(M.ADDRESS_CODE, \'\')     AS ADDRESS_CODE
  ,NVL(A.PREFEC, \'\')        ||
    NVL(A.CITY, \'\')         ||
    NVL(A.TSUSHO, \'\')       ||
    NVL(A.CHOME, \'\')        ||
    NVL(M.ADDRESS1, \'\')     ||
    NVL(M.ADDRESS2, \'\')        AS ADDRESS
  ,NVL(M.TEL1, \'\')             AS TEL1
  ,NVL(M.TEL2, \'\')             AS TEL2
  ,NVL(M.TEL3, \'\')             AS TEL3
  ,NVL(M.TEL_JOINT, \'\')        AS TEL_JOINT
  ,NVL(M.COMPANY_NAME, \'\')     AS COMPANY_NAME
  ,NVL(M.COMPANY_ZIP_CODE, \'\') AS COMPANY_ZIP_CODE
  ,NVL(M.COMPANY_ADDRESS, \'\')  AS COMPANY_ADDRESS
  ,NVL(M.COMPANY_TEL1, \'\')   ||
    NVL(M.COMPANY_TEL2, \'\')  ||
    NVL(M.COMPANY_TEL3, \'\')    AS COMPANY_TEL
FROM {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE_ACCUM M
-- 住所コードをキーに住所マスタテーブルから都道府県名,市区町村名,大字通称名,字丁目名を取得
LEFT JOIN
  (SELECT DISTINCT
          PREFEC
         ,CITY
         ,TSUSHO
         ,CHOME
         ,ADRS_CD
   FROM {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS
  ) A
ON
  M.ADDRESS_CODE = A.ADRS_CD
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE_ACCUM_CL_AC AC
    WHERE
      M.USER_NO = AC.USER_NO
    AND
      NVL(M.EMAIL, \'\') = NVL(AC.EMAIL, \'\')
    AND
      NVL(M.SECOND_EMAIL, \'\') = NVL(AC.SECOND_EMAIL, \'\')
    AND
      NVL(M.LAST_NAME, \'\') = NVL(AC.LAST_NAME, \'\')
    AND
      NVL(M.FIRST_NAME, \'\') = NVL(AC.FIRST_NAME, \'\')
    AND
      NVL(M.ZIP_CODE, \'\') = NVL(AC.ZIP_CODE, \'\')
    AND
      NVL(M.ADDRESS_CODE, \'\') = NVL(AC.ADDRESS_CODE, \'\')
    AND
      NVL(M.ADDRESS1, \'\') = NVL(AC.ADDRESS1, \'\')
    AND
      NVL(M.ADDRESS2, \'\') = NVL(AC.ADDRESS2, \'\')
    AND
      NVL(M.TEL1, \'\') = NVL(AC.TEL1, \'\')
    AND
      NVL(M.TEL2, \'\') = NVL(AC.TEL2, \'\')
    AND
      NVL(M.TEL3, \'\') = NVL(AC.TEL3, \'\')
    AND
      NVL(M.TEL_JOINT, \'\') = NVL(AC.TEL_JOINT, \'\')
    AND
      NVL(M.COMPANY_NAME, \'\') = NVL(AC.COMPANY_NAME, \'\')
    AND
      NVL(M.COMPANY_ZIP_CODE, \'\') = NVL(AC.COMPANY_ZIP_CODE, \'\')
    AND
      NVL(M.COMPANY_ADDRESS, \'\') = NVL(AC.COMPANY_ADDRESS, \'\')
    AND
      NVL(M.COMPANY_TEL1, \'\') = NVL(AC.COMPANY_TEL1, \'\')
    AND
      NVL(M.COMPANY_TEL2, \'\') = NVL(AC.COMPANY_TEL2, \'\')
    AND
      NVL(M.COMPANY_TEL3, \'\') = NVL(AC.COMPANY_TEL3, \'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
ORDER BY M.ADDRESS_CODE
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/M_IS_NX_ATTRIBUTE_ACCUM/M_IS_NX_ATTRIBUTE_ACCUM_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
