/*

   参照テーブル:
      T_CM_EMAIL_SUMMARY_AC
      T_CM_EMAIL_SUCCESS_AC
      T_CM_EMAIL_ERROR_AC
      T_IMS_PLAN_MNG
      T_CM_DELIVERY_RESULT_SS

*/
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_CM_DELIVERY_RESULT_SS
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_CM_DELIVERY_RESULT_SS
(
     PLAN_ID
    ,EDATE
    ,TOTAL
    ,SUCCESS
    ,ERROR
    ,HBBSBB
    ,UNIQOPEN
    ,"OPEN"
    ,UNIQCLICK
    ,CLICK
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     S.PLAN_ID
    ,MAX(T.EDATE)
    ,SUM(T.TOTAL)
    ,SUM(T.SUCCESS)
    ,SUM(T.ERROR)
    ,SUM(T.HBBSBB)
    ,SUM(T.UNIQOPEN)
    ,SUM(T."OPEN")
    ,SUM(T.UNIQCLICK)
    ,SUM(T.CLICK)
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_SUMMARY_AC T
INNER JOIN
    (SELECT
        SU.MAILIDX
        ,SU.PLAN_ID
     FROM
        {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_SUCCESS_AC SU
    UNION
    SELECT
        ER.MAILIDX
        ,ER.PLAN_ID
    FROM
        {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_ERROR_AC ER
    ) S
ON
    T.MAILIDX = S.MAILIDX
WHERE
    S.PLAN_ID IS NOT NULL
GROUP BY
    PLAN_ID
;

UPDATE
    {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG S
SET
     PROD_DELIVERY_STATUS_CD = '040'
    ,PROD_DELIVERY_TM = T.EDATE
    ,UPD_PGM_ID = '{{ dag.dag_id }}'
    ,UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM 
    {{ var.value.redshift_ims_schema_name }}.T_CM_DELIVERY_RESULT_SS T
WHERE
    S.PLAN_ID = T.PLAN_ID
AND
    S.PROD_DELIVERY_STATUS_CD = '030'
;
