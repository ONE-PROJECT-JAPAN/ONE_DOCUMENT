
/*******************************************************************************
  SQL名:
    メールサマリ情報テーブル蓄積

  処理概要:
       メールサマリ情報テーブル蓄積を行う

       蓄積キー:
         MAILIDX
*******************************************************************************/
-- IFテーブルのデータと同じキーのテータを蓄積テーブルから削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_SUMMARY_AC
    WHERE
    (MAILIDX) IN (
        SELECT 
            MAILIDX
        FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_SUMMARY
    )
;
-- IFテーブルのデータを蓄積テーブルに追加
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_SUMMARY_AC (
      SDATE
    , EDATE
    , TITLE
    , SUBJECT
    , HTMLTEXT
    , MAILIDX
    , TOTAL
    , SUCCESS
    , ERROR
    , HBBSBB
    , UNIQOPEN
    , "OPEN"
    , UNIQCLICK
    , CLICK
    , CCOUNT
    , CAMOUNT
    , INS_PGM_ID
    , INS_DT_TM
    , UPD_PGM_ID
    , UPD_DT_TM
)
SELECT  
      NULLIF((SUBSTRING(IF.SDATE, 1, 8) || ' ' || SUBSTRING(IF.SDATE, 9, 14)), ' ')::TIMESTAMP
    , NULLIF((SUBSTRING(IF.EDATE, 1, 8) || ' ' || SUBSTRING(IF.EDATE, 9, 14)), ' ')::TIMESTAMP
    , NULLIF(IF.TITLE, '')
    , NULLIF(IF.SUBJECT, '')
    , NULLIF(IF.HTMLTEXT, '')
    , CAST(NULLIF(IF.MAILIDX, '') AS BIGINT)
    , CAST(NULLIF(IF.TOTAL, '') AS BIGINT)
    , CAST(NULLIF(IF.SUCCESS, '') AS BIGINT)
    , CAST(NULLIF(IF.ERROR, '') AS BIGINT)
    , CAST(NULLIF(IF.HBBSBB, '') AS BIGINT)
    , CAST(NULLIF(IF.UNIQOPEN, '') AS BIGINT)
    , CAST(NULLIF(IF."OPEN", '') AS BIGINT)
    , CAST(NULLIF(IF.UNIQCLICK, '') AS BIGINT)
    , CAST(NULLIF(IF.CLICK, '') AS BIGINT)
    , CAST(NULLIF(IF.CCOUNT, '') AS BIGINT)
    , CAST(NULLIF(IF.CAMOUNT, '') AS BIGINT)
    , '{{ dag.dag_id }}' AS INS_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_SUMMARY IF
;
