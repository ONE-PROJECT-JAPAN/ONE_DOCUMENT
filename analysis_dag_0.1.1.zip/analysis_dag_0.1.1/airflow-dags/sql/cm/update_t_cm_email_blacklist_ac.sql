
/*******************************************************************************
  SQL名:
    エラーアドレス情報テーブル蓄積

  処理概要:
       エラーアドレス情報テーブル蓄積を行う

       蓄積キー:
         EMAIL
*******************************************************************************/
-- IFテーブルのデータと同じキーのテータを蓄積テーブルから削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_BLACKLIST_AC
    WHERE 
    (EMAIL) IN (
        SELECT 
            EMAIL
        FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_BLACKLIST
    )
;
-- IFテーブルのデータを蓄積テーブルに追加
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_BLACKLIST_AC (
      EMAIL
    , ERRORCODE 
    , INS_PGM_ID
    , INS_DT_TM
    , UPD_PGM_ID
    , UPD_DT_TM
)
SELECT  
      NULLIF(IF.EMAIL, '')
    , NULLIF(IF.ERRORCODE, '')
    , '{{ dag.dag_id }}' AS INS_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_BLACKLIST IF
;
