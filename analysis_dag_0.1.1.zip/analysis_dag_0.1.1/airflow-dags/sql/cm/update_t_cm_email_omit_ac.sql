
/*******************************************************************************
  SQL名:
    再送設定による除外情報テーブル蓄積

  処理概要:
       再送設定による除外情報テーブル蓄積を行う

       蓄積キー:
         EMAIL
         MAILIDX
*******************************************************************************/
-- IFテーブルのデータと同じキーのテータを蓄積テーブルから削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_OMIT_AC
    WHERE
    (EMAIL, MAILIDX) IN (
        SELECT 
            EMAIL
            , MAILIDX
        FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_OMIT
    )
;
-- IFテーブルのデータを蓄積テーブルに追加
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_OMIT_AC (
      SDATE
    , EMAIL
    , MAILIDX
    , NIKKEI_ID
    , PLAN_ID
    , INS_PGM_ID
    , INS_DT_TM
    , UPD_PGM_ID
    , UPD_DT_TM
)
SELECT  
      NULLIF((SUBSTRING(IF.SDATE, 1, 8) || ' ' || SUBSTRING(IF.SDATE, 9, 14)), ' ')::TIMESTAMP
    , NULLIF(IF.EMAIL, '')
    , CAST(NULLIF(IF.MAILIDX, '') AS BIGINT)
    , NULLIF(IF.NIKKEI_ID, '')
    , NULLIF(IF.PLAN_ID, '')
    , '{{ dag.dag_id }}' AS INS_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_OMIT IF
;
