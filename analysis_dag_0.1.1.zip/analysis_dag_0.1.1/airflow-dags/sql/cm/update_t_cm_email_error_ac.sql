
/*******************************************************************************
  SQL名:
    配信結果（エラー）テーブル蓄積

  処理概要:
       配信結果（エラー）テーブル蓄積を行う

       蓄積キー:
         MAILIDX
         SEQIDX
*******************************************************************************/
-- IFテーブルのデータと同じキーのテータを蓄積テーブルから削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_ERROR_AC 
    WHERE 
    (MAILIDX,SEQIDX) IN (
        SELECT 
             MAILIDX::BIGINT AS MAILIDX
            ,SEQIDX::BIGINT AS SEQIDX
        FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_ERROR
        WHERE
             NVL(SDATE,'') <> '0'
    )
;
-- IFテーブルのデータを蓄積テーブルに追加
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_CM_EMAIL_ERROR_AC (
      SDATE
    , EMAIL
    , MAILIDX
    , SEQIDX
    , CODE
    , DELIVERY_ORDER
    , NIKKEI_ID
    , PLAN_ID
    , INS_PGM_ID
    , INS_DT_TM
    , UPD_PGM_ID
    , UPD_DT_TM
)
SELECT  
      NULLIF((SUBSTRING(IF.SDATE, 1, 8) || ' ' || SUBSTRING(IF.SDATE, 9, 14)), ' ')::TIMESTAMP
    , NULLIF(IF.EMAIL, '')
    , CAST(NULLIF(IF.MAILIDX, '') AS BIGINT)
    , CAST(NULLIF(IF.SEQIDX, '') AS BIGINT)
    , CAST(NULLIF(IF.CODE, '') AS BIGINT)
    , CAST(NULLIF(IF.DELIVERY_ORDER, '') AS BIGINT)
    , NULLIF(IF.NIKKEI_ID, '')
    , NULLIF(IF.PLAN_ID, '')
    , '{{ dag.dag_id }}' AS INS_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_PGM_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.W_CM_EMAIL_ERROR IF
WHERE
     NVL(IF.SDATE,'') <> '0'
;
