/*******************************************************************************
  SQL名:
    蓄積用_固定項目データ差分ファイル作成

  処理概要:
       蓄積用_固定項目を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

UNLOAD ('
SELECT
   M.ROWID            AS ROWID_IF
  ,M.フォームID       AS フォームID
  ,M.応募者ID         AS 応募者ID
  ,M.氏名             AS 氏名
  ,M.お勤め先名       AS お勤め先名
  ,M.お勤め先郵便番号 AS お勤め先郵便番号
  ,M.お勤め先住所     AS お勤め先住所
  ,M.お勤め先電話番号 AS お勤め先電話番号
  ,M.郵便番号         AS 郵便番号
  ,M.ご住所           AS ご住所
  ,M.電話番号         AS 電話番号
FROM
  {{ var.value.redshift_ims_schema_name }}.T_EE_V_蓄積用_固定項目 M
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.T_EE_V_AC_FIXED_ITEM_CL_AC AC
    WHERE
      M.フォームID = AC.FORM_ID
    AND
      M.応募者ID = AC.APPLICANT_ID
    AND
      NVL(M.メールアドレス,\'\') = NVL(AC.EMAIL,\'\')
    AND
      NVL(M.第２メールアドレス,\'\') = NVL(AC.SECOND_EMAIL,\'\')
    AND
      NVL(M.氏名,\'\') = NVL(AC.NAME,\'\')
    AND
      NVL(M.お勤め先名,\'\') = NVL(AC.WORKPLACE_NM,\'\')
    AND
      NVL(M.お勤め先郵便番号,\'\') = NVL(AC.WORKPLACE_ZIPCODE,\'\')
    AND
      NVL(M.お勤め先住所,\'\') = NVL(AC.WORKPLACE_ADDRESS,\'\')
    AND
      NVL(M.お勤め先電話番号,\'\') = NVL(AC.WORKPLACE_TELNO,\'\')
    AND
      NVL(M.郵便番号,\'\') = NVL(AC.ZIPCODE,\'\')
    AND
      NVL(M.ご住所,\'\') = NVL(AC.ADDRESS,\'\')
    AND
      NVL(M.電話番号,\'\') = NVL(AC.TELNO,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_EE_V_AC_FIXED_ITEM/T_EE_V_AC_FIXED_ITEM_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
