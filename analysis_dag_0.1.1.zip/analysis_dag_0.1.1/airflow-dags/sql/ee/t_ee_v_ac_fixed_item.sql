/*******************************************************************************
  SQL名:
        イベントアンケートデータ固定項目蓄積・個人情報削除
  処理概要:
        T_EE_V_蓄積用_固定項目
       蓄積キー:
         "フォームID", "応募者ID"
       参照テーブル:
         "T_EE_V_応募内容_テキスト2"
         "T_EE_V_応募内容_メールアドレス2"
         "T_EE_V_応募内容_選択2"
         M_IS_mm_address
         M_IS_mm_business
         M_IS_mm_code
         M_IS_mm_country
         M_IS_mm_job
         M_IS_mm_occupation
         M_IS_mm_position
*******************************************************************************/
CREATE TEMP TABLE TEMP1_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,ISNULL("メールアドレス_1"."メールアドレス","メールアドレス_2"."メールアドレス") AS "メールアドレス"
,"第２メールアドレス_1"."メールアドレス" AS "第２メールアドレス"
,SUBSTRING(
 CASE
   WHEN ISNULL("氏名（フリガナ）_1"."応募内容",'') || ISNULL("氏名（フリガナ）_2"."応募内容",'') <> '' THEN
     ISNULL("氏名（フリガナ）_1"."応募内容",'') || ISNULL("氏名（フリガナ）_2"."応募内容",'')
   ELSE
     ISNULL("氏名（フリガナ）_3"."応募内容",'') || ISNULL("氏名（フリガナ）_4"."応募内容",'')
 END    
 , 1, 121) AS "氏名（フリガナ）"
,SUBSTRING(
 CASE
   WHEN ISNULL("氏名_1"."応募内容",'') || ISNULL("氏名_2"."応募内容",'') <> '' THEN
     ISNULL("氏名_1"."応募内容",'') || ISNULL("氏名_2"."応募内容",'')
   ELSE
     ISNULL("氏名_3"."応募内容",'') || ISNULL("氏名_4"."応募内容",'')
 END    
 , 1, 121) AS "氏名"
,"生年月日_1"."応募内容" AS "生年月日"
,"性別_2".SEX_DESC AS "性別"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
    WHERE "入力形態ID" = '0901'
     AND NOT "メールアドレス" IS NULL
    GROUP BY "フォームID","応募者ID","メールアドレス"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS B
    ON
    A."入力形態ID" = '0901' AND NOT A."メールアドレス" IS NULL AND
    B."入力形態ID" = '0901' AND NOT SUBSTRING(B."メールアドレス",1,256) IS NULL AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."メールアドレス" < SUBSTRING(B."メールアドレス",1,256)
    ) AS "メールアドレス_1"
    ON "メールアドレス_1"."フォームID" = C."フォームID" AND "メールアドレス_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
    WHERE "入力形態ID" = '0005'
     AND NOT "メールアドレス" IS NULL
    GROUP BY "フォームID","応募者ID","メールアドレス"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS B
    ON
    A."入力形態ID" = '0005' AND NOT A."メールアドレス" IS NULL AND
    B."入力形態ID" = '0005' AND NOT SUBSTRING(B."メールアドレス",1,256) IS NULL AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."メールアドレス" < SUBSTRING(B."メールアドレス",1,256)
    ) AS "メールアドレス_2"
    ON "メールアドレス_2"."フォームID" = C."フォームID" AND "メールアドレス_2"."応募者ID" = C."応募者ID"
    
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
    WHERE "入力形態ID" = '0902'
     AND NOT "メールアドレス" IS NULL
    GROUP BY "フォームID","応募者ID","メールアドレス"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."メールアドレス",1,256) AS "メールアドレス" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2" AS B
    ON
    A."入力形態ID" = '0902' AND NOT A."メールアドレス" IS NULL AND
    B."入力形態ID" = '0902' AND NOT SUBSTRING(B."メールアドレス",1,256) IS NULL AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."メールアドレス" < SUBSTRING(B."メールアドレス",1,256)
    ) AS "第２メールアドレス_1"
    ON "第２メールアドレス_1"."フォームID" = C."フォームID" AND "第２メールアドレス_1"."応募者ID" = C."応募者ID"
    
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0903' AND "枝番" = 1
    ) AS "氏名（フリガナ）_1"
    ON "氏名（フリガナ）_1"."フォームID" = C."フォームID" AND "氏名（フリガナ）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0903' AND "枝番" = 2
    ) AS "氏名（フリガナ）_2"
    ON "氏名（フリガナ）_2"."フォームID" = C."フォームID" AND "氏名（フリガナ）_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0011' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,121) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0011' AND A."枝番" = 1 AND
    B."入力形態ID" = '0011' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "氏名（フリガナ）_3"
    ON "氏名（フリガナ）_3"."フォームID" = C."フォームID" AND "氏名（フリガナ）_3"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0011' AND "枝番" = 2
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,121) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0011' AND A."枝番" = 2 AND
    B."入力形態ID" = '0011' AND B."枝番" = 2 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "氏名（フリガナ）_4"
    ON "氏名（フリガナ）_4"."フォームID" = C."フォームID" AND "氏名（フリガナ）_4"."応募者ID" = C."応募者ID"
    
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0904' AND "枝番" = 1
    ) AS "氏名_1"
    ON "氏名_1"."フォームID" = C."フォームID" AND "氏名_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0904' AND "枝番" = 2
    ) AS "氏名_2"
    ON "氏名_2"."フォームID" = C."フォームID" AND "氏名_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0003' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,121) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0003' AND A."枝番" = 1 AND
    B."入力形態ID" = '0003' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "氏名_3"
    ON "氏名_3"."フォームID" = C."フォームID" AND "氏名_3"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,121) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0003' AND "枝番" = 2
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,121) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0003' AND A."枝番" = 2 AND
    B."入力形態ID" = '0003' AND B."枝番" = 2 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "氏名_4"
    ON "氏名_4"."フォームID" = C."フォームID" AND "氏名_4"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,8) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0905' AND "枝番" = 1
    ) AS "生年月日_1"
    ON "生年月日_1"."フォームID" = C."フォームID" AND "生年月日_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0906' AND "枝番" = 1
    ) AS "性別_1"
    ON "性別_1"."フォームID" = C."フォームID" AND "性別_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT LABEL AS SEX_DESC, VALUE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_code
       WHERE MASTER_TYPE = 'SEX'
       ) AS "性別_2"
       ON "性別_2".VALUE = "性別_1"."選択肢ID"
;

CREATE TEMP TABLE TEMP2_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,"職業_2".OCCUPATION_NAME AS "職業"
,"業種_2".BUSINESS_NAME AS "業種"
,"職種_2".JOB_NAME AS "職種"
,"役職_2".POSITION_NAME AS "役職"
,"従業員規模_2".LABEL AS "従業員規模"
,CASE ("海外居住チェック_1"."選択肢ID")
   WHEN '0' THEN '日本国内'
   WHEN '1' THEN '海外居住'
 END
 AS "海外居住チェック"
,SUBSTRING(
 CASE
   WHEN ISNULL("お勤め先名_1"."応募内容",'') <> '' THEN
     "お勤め先名_1"."応募内容"
   ELSE
     "お勤め先名_2"."応募内容"
 END    
 ,1,120) AS "お勤め先名"
,"所属される部署名_1"."応募内容" AS "所属される部署名"
,ISNULL("お勤め先郵便番号_1"."応募内容","お勤め先郵便番号_2"."応募内容") AS "お勤め先郵便番号"
,ISNULL("お勤め先住所_1"."応募内容","お勤め先住所_2"."応募内容") AS "お勤め先住所"
,"お勤め先電話番号_1"."応募内容" AS "お勤め先電話番号"
,ISNULL("郵便番号_1"."応募内容","郵便番号_2"."応募内容") AS "郵便番号"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0907' AND "枝番" = 1
    ) AS "職業_1"
    ON "職業_1"."フォームID" = C."フォームID" AND "職業_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT OCCUPATION_NAME, OCCUPATION_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_occupation
       ) AS "職業_2"
       ON "職業_2".OCCUPATION_NO = SUBSTRING("職業_1"."選択肢ID",2,3)
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0907' AND "枝番" = 2
    ) AS "業種_1"
    ON "業種_1"."フォームID" = C."フォームID" AND "業種_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT BUSINESS_NAME, BUSINESS_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_business
       ) AS "業種_2"
       ON "業種_2".BUSINESS_NO = SUBSTRING("業種_1"."選択肢ID",2,3)
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0907' AND "枝番" = 3
    ) AS "職種_1"
    ON "職種_1"."フォームID" = C."フォームID" AND "職種_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT JOB_NAME, JOB_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_job
       ) AS "職種_2"
       ON "職種_2".JOB_NO = SUBSTRING("職種_1"."選択肢ID",2,3)
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0907' AND "枝番" = 4
    ) AS "役職_1"
    ON "役職_1"."フォームID" = C."フォームID" AND "役職_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT POSITION_NAME, POSITION_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_position
       ) AS "役職_2"
       ON "役職_2".POSITION_NO = SUBSTRING("役職_1"."選択肢ID",2,3)
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0907' AND "枝番" = 5
    ) AS "従業員規模_1"
    ON "従業員規模_1"."フォームID" = C."フォームID" AND "従業員規模_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT LABEL, VALUE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_code
       WHERE MASTER_TYPE = 'EMPLOYEES_NO'
       ) AS "従業員規模_2"
       ON "従業員規模_2".VALUE = SUBSTRING("従業員規模_1"."選択肢ID",2,3)
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0908' AND "枝番" = 1
    ) AS "海外居住チェック_1"
    ON "海外居住チェック_1"."フォームID" = C."フォームID" AND "海外居住チェック_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,120) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0909' AND "枝番" = 1
    ) AS "お勤め先名_1"
    ON "お勤め先名_1"."フォームID" = C."フォームID" AND "お勤め先名_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,120) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0012' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,120) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0012' AND A."枝番" = 1 AND
    B."入力形態ID" = '0012' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "お勤め先名_2"
    ON "お勤め先名_2"."フォームID" = C."フォームID" AND "お勤め先名_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,100) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0910' AND "枝番" = 1
    ) AS "所属される部署名_1"
    ON "所属される部署名_1"."フォームID" = C."フォームID" AND "所属される部署名_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(TRANSLATE("応募内容",'-',''),1,7) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0911' AND "枝番" = 1
    ) AS "お勤め先郵便番号_1"
    ON "お勤め先郵便番号_1"."フォームID" = C."フォームID" AND "お勤め先郵便番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(TRANSLATE("応募内容",'-',''),1,7) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0013' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(TRANSLATE(A."応募内容",'-',''),1,7) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0013' AND A."枝番" = 1 AND
    B."入力形態ID" = '0013' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "お勤め先郵便番号_2"
    ON "お勤め先郵便番号_2"."フォームID" = C."フォームID" AND "お勤め先郵便番号_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,100) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0911' AND "枝番" = 2
    ) AS "お勤め先住所_1"
    ON "お勤め先住所_1"."フォームID" = C."フォームID" AND "お勤め先住所_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,100) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0013' AND "枝番" = 2
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,100) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0013' AND A."枝番" = 2 AND
    B."入力形態ID" = '0013' AND B."枝番" = 2 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "お勤め先住所_2"
    ON "お勤め先住所_2"."フォームID" = C."フォームID" AND "お勤め先住所_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,26) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0912' AND "枝番" = 1
    ) AS "お勤め先電話番号_1"
    ON "お勤め先電話番号_1"."フォームID" = C."フォームID" AND "お勤め先電話番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(TRANSLATE("応募内容",'-',''),1,7) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0913' AND "枝番" = 1
    ) AS "郵便番号_1"
    ON "郵便番号_1"."フォームID" = C."フォームID" AND "郵便番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(TRANSLATE("応募内容",'-',''),1,7) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0004' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(TRANSLATE(A."応募内容",'-',''),1,7) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0004' AND A."枝番" = 1 AND
    B."入力形態ID" = '0004' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "郵便番号_2"
    ON "郵便番号_2"."フォームID" = C."フォームID" AND "郵便番号_2"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP3_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,SUBSTRING(
  CASE
    WHEN ISNULL("ご住所_1"."応募内容",'') || ISNULL("ご住所_2"."応募内容",'') || ISNULL("ご住所_3"."応募内容",'') = '' THEN
      CASE
        WHEN "ご住所_4"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_4"."応募内容"
      END
       ||
      CASE
        WHEN "ご住所_5"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_5"."応募内容"
      END
       ||
      CASE
        WHEN "ご住所_6"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_6"."応募内容"
      END
    ELSE
      CASE
        WHEN "ご住所_1"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_1"."応募内容"
      END
       ||
      CASE
        WHEN "ご住所_2"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_2"."応募内容"
      END
       ||
      CASE
        WHEN "ご住所_3"."応募内容" IS NULL THEN
          ''
        ELSE
          "ご住所_3"."応募内容"
      END
  END
  , 1, 396) AS "ご住所"
,ISNULL("電話番号_1"."応募内容","電話番号_2"."応募内容") AS "電話番号"
,"海外お勤め先名_1"."応募内容" AS "海外お勤め先名"
,"海外お勤め先の住所_1"."応募内容" AS "海外お勤め先の住所"
,"海外お勤め先電話番号_1"."応募内容" AS "海外お勤め先電話番号"
,"居住国名_2".COUNTRY_NAME AS "居住国名"
,SUBSTRING(
  CASE
    WHEN ISNULL("海外ご住所_1"."応募内容",'') || ISNULL("海外ご住所_2"."応募内容",'') || ISNULL("海外ご住所_3"."応募内容",'') = '' THEN
      CASE
        WHEN "海外ご住所_4"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_4"."応募内容" || ' '
      END
       ||
      CASE
        WHEN "海外ご住所_5"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_5"."応募内容" || ' '
      END
       ||
      CASE
        WHEN "海外ご住所_6"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_6"."応募内容"
      END
    ELSE
      CASE
        WHEN "海外ご住所_1"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_1"."応募内容" || ' '
      END
       ||
      CASE
        WHEN "海外ご住所_2"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_2"."応募内容" || ' '
      END
       ||
      CASE
        WHEN "海外ご住所_3"."応募内容" IS NULL THEN
          ''
        ELSE
          "海外ご住所_3"."応募内容"
      END
  END
  , 1, 302) AS "海外ご住所"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),12,100) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0913' AND "枝番" = 2
    ) AS "ご住所_1"
    ON "ご住所_1"."フォームID" = C."フォームID" AND "ご住所_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,396) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0913' AND "枝番" = 3
    ) AS "ご住所_2"
    ON "ご住所_2"."フォームID" = C."フォームID" AND "ご住所_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,396) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0913' AND "枝番" = 4
    ) AS "ご住所_3"
    ON "ご住所_3"."フォームID" = C."フォームID" AND "ご住所_3"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),12,100) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0004' AND "枝番" = 2
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),12,100) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0004' AND A."枝番" = 2 AND
    B."入力形態ID" = '0004' AND B."枝番" = 2 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "ご住所_4"
    ON "ご住所_4"."フォームID" = C."フォームID" AND "ご住所_4"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,396) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0004' AND "枝番" = 3
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),1,396) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0004' AND A."枝番" = 3 AND
    B."入力形態ID" = '0004' AND B."枝番" = 3 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "ご住所_5"
    ON "ご住所_5"."フォームID" = C."フォームID" AND "ご住所_5"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,396) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0004' AND "枝番" = 4
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),1,396) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0004' AND A."枝番" = 4 AND
    B."入力形態ID" = '0004' AND B."枝番" = 4 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "ご住所_6"
    ON "ご住所_6"."フォームID" = C."フォームID" AND "ご住所_6"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,26) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0914' AND "枝番" = 1
    ) AS "電話番号_1"
    ON "電話番号_1"."フォームID" = C."フォームID" AND "電話番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,26) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0006' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,26) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0006' AND A."枝番" = 1 AND
    B."入力形態ID" = '0006' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "電話番号_2"
    ON "電話番号_2"."フォームID" = C."フォームID" AND "電話番号_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,100) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0915' AND "枝番" = 1
    ) AS "海外お勤め先名_1"
    ON "海外お勤め先名_1"."フォームID" = C."フォームID" AND "海外お勤め先名_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,300) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0916' AND "枝番" = 1
    ) AS "海外お勤め先の住所_1"
    ON "海外お勤め先の住所_1"."フォームID" = C."フォームID" AND "海外お勤め先の住所_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,30) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0917' AND "枝番" = 1
    ) AS "海外お勤め先電話番号_1"
    ON "海外お勤め先電話番号_1"."フォームID" = C."フォームID" AND "海外お勤め先電話番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0918' AND "枝番" = 1
    ) AS "居住国名_1"
    ON "居住国名_1"."フォームID" = C."フォームID" AND "居住国名_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT COUNTRY_NAME, CODE_NUMERIC FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_country
       ) AS "居住国名_2"
       ON "居住国名_2".CODE_NUMERIC = "居住国名_1"."選択肢ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0919' AND "枝番" = 1
    ) AS "海外ご住所_1"
    ON "海外ご住所_1"."フォームID" = C."フォームID" AND "海外ご住所_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0919' AND "枝番" = 2
    ) AS "海外ご住所_2"
    ON "海外ご住所_2"."フォームID" = C."フォームID" AND "海外ご住所_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0919' AND "枝番" = 3
    ) AS "海外ご住所_3"
    ON "海外ご住所_3"."フォームID" = C."フォームID" AND "海外ご住所_3"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0015' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),1,302) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0015' AND A."枝番" = 1 AND
    B."入力形態ID" = '0015' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "海外ご住所_4"
    ON "海外ご住所_4"."フォームID" = C."フォームID" AND "海外ご住所_4"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0015' AND "枝番" = 2
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),1,302) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0015' AND A."枝番" = 2 AND
    B."入力形態ID" = '0015' AND B."枝番" = 2 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "海外ご住所_5"
    ON "海外ご住所_5"."フォームID" = C."フォームID" AND "海外ご住所_5"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING(ISNULL("応募内容",''),1,302) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0015' AND "枝番" = 3
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(ISNULL(A."応募内容",''),1,302) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0015' AND A."枝番" = 3 AND
    B."入力形態ID" = '0015' AND B."枝番" = 3 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "海外ご住所_6"
    ON "海外ご住所_6"."フォームID" = C."フォームID" AND "海外ご住所_6"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP4_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,ISNULL("海外郵便番号_1"."応募内容","海外郵便番号_2"."応募内容") AS "海外郵便番号"
,"海外電話番号_1"."応募内容" AS "海外電話番号"
,"世帯年収_2".LABEL AS "世帯年収"
,CASE
   WHEN NOT "新聞購読状況（日本経済新聞）_1"."選択肢ID" IS NULL THEN
     '購読中'
   WHEN "新聞購読状況（日本経済新聞）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '未購読'
 END
 AS "新聞購読状況（日本経済新聞）"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,20) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0919' AND "枝番" = 4
    ) AS "海外郵便番号_1"
    ON "海外郵便番号_1"."フォームID" = C."フォームID" AND "海外郵便番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",SUBSTRING("応募内容",1,20) AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0015' AND "枝番" = 4
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",SUBSTRING(A."応募内容",1,20) AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0015' AND A."枝番" = 4 AND
    B."入力形態ID" = '0015' AND B."枝番" = 4 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "海外郵便番号_2"
    ON "海外郵便番号_2"."フォームID" = C."フォームID" AND "海外郵便番号_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",SUBSTRING("応募内容",1,30) AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0920' AND "枝番" = 1
    ) AS "海外電話番号_1"
    ON "海外電話番号_1"."フォームID" = C."フォームID" AND "海外電話番号_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0921' AND "枝番" = 1
    ) AS "世帯年収_1"
    ON "世帯年収_1"."フォームID" = C."フォームID" AND "世帯年収_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT LABEL, VALUE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_code
       WHERE MASTER_TYPE = 'INCOME_NO'
       ) AS "世帯年収_2"
       ON "世帯年収_2".VALUE = "世帯年収_1"."選択肢ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "選択肢ID" = '001'
    ) AS "新聞購読状況（日本経済新聞）_1"
    ON "新聞購読状況（日本経済新聞）_1"."フォームID" = C."フォームID" AND "新聞購読状況（日本経済新聞）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（日本経済新聞）_2"
    ON "新聞購読状況（日本経済新聞）_2"."フォームID" = C."フォームID" AND "新聞購読状況（日本経済新聞）_2"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP5_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,CASE
   WHEN NOT "新聞購読状況（日経産業新聞）_1"."選択肢ID" IS NULL THEN
     '購読中'
   WHEN "新聞購読状況（日経産業新聞）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '未購読'
 END
 AS "新聞購読状況（日経産業新聞）"
,CASE
   WHEN NOT "新聞購読状況（日経MJ）_1"."選択肢ID" IS NULL THEN
     '購読中'
   WHEN "新聞購読状況（日経MJ）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '未購読'
 END
 AS "新聞購読状況（日経MJ）"
,CASE
   WHEN NOT "新聞購読状況（日経ヴェリタス）_1"."選択肢ID" IS NULL THEN
     '購読中'
   WHEN "新聞購読状況（日経ヴェリタス）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '未購読'
 END
 AS "新聞購読状況（日経ヴェリタス）"
,CASE
   WHEN NOT "新聞購読状況（THE NIKKEI Weekly）_1"."選択肢ID" IS NULL THEN
     '購読中'
   WHEN "新聞購読状況（THE NIKKEI Weekly）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '未購読'
 END
 AS "新聞購読状況（THE NIKKEI Weekly）"
 
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "選択肢ID" = '002'
    ) AS "新聞購読状況（日経産業新聞）_1"
    ON "新聞購読状況（日経産業新聞）_1"."フォームID" = C."フォームID" AND "新聞購読状況（日経産業新聞）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（日経産業新聞）_2"
    ON "新聞購読状況（日経産業新聞）_2"."フォームID" = C."フォームID" AND "新聞購読状況（日経産業新聞）_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "選択肢ID" = '003'
    ) AS "新聞購読状況（日経MJ）_1"
    ON "新聞購読状況（日経MJ）_1"."フォームID" = C."フォームID" AND "新聞購読状況（日経MJ）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（日経MJ）_2"
    ON "新聞購読状況（日経MJ）_2"."フォームID" = C."フォームID" AND "新聞購読状況（日経MJ）_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "選択肢ID" = '004'
    ) AS "新聞購読状況（日経ヴェリタス）_1"
    ON "新聞購読状況（日経ヴェリタス）_1"."フォームID" = C."フォームID" AND "新聞購読状況（日経ヴェリタス）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（日経ヴェリタス）_2"
    ON "新聞購読状況（日経ヴェリタス）_2"."フォームID" = C."フォームID" AND "新聞購読状況（日経ヴェリタス）_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "選択肢ID" = '005'
    ) AS "新聞購読状況（THE NIKKEI Weekly）_1"
    ON "新聞購読状況（THE NIKKEI Weekly）_1"."フォームID" = C."フォームID" AND "新聞購読状況（THE NIKKEI Weekly）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（THE NIKKEI Weekly）_2"
    ON "新聞購読状況（THE NIKKEI Weekly）_2"."フォームID" = C."フォームID" AND "新聞購読状況（THE NIKKEI Weekly）_2"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP6_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,CASE
   WHEN NOT "日経メール許諾_1"."選択肢ID" IS NULL THEN
     '日経メール許諾'
   ELSE
     '拒否'
 END
 AS "日経メール許諾"
,CASE "日経IDリサーチモニタフラグ_1"."選択肢ID"
   WHEN '1' THEN
     'モニターを希望する'
   WHEN '0' THEN
     '希望しない'
   ELSE
     NULL
 END
 AS "日経IDリサーチモニタフラグ"
,CASE
   WHEN NOT "興味・関心のある情報（エンターテインメント）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（エンターテインメント）"
,CASE
   WHEN NOT "興味・関心のある情報（食と健康）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（食と健康）"
,CASE
   WHEN NOT "興味・関心のある情報（自己啓発・学習）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（自己啓発・学習）"
,CASE
   WHEN NOT "興味・関心のある情報（ショッピング）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（ショッピング）"
,CASE
   WHEN NOT "興味・関心のある情報（住宅・インテリア）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（住宅・インテリア）"
,CASE
   WHEN NOT "興味・関心のある情報（マネー情報）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（マネー情報）"
 FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0923' AND "選択肢ID" = '1' AND "枝番" = '1'
    ) AS "日経メール許諾_1"
    ON "日経メール許諾_1"."フォームID" = C."フォームID" AND "日経メール許諾_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0924' AND "枝番" = '1'
    ) AS "日経IDリサーチモニタフラグ_1"
    ON "日経IDリサーチモニタフラグ_1"."フォームID" = C."フォームID" AND "日経IDリサーチモニタフラグ_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '01'
    ) AS "興味・関心のある情報（エンターテインメント）_1"
    ON "興味・関心のある情報（エンターテインメント）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（エンターテインメント）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '02'
    ) AS "興味・関心のある情報（食と健康）_1"
    ON "興味・関心のある情報（食と健康）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（食と健康）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '03'
    ) AS "興味・関心のある情報（自己啓発・学習）_1"
    ON "興味・関心のある情報（自己啓発・学習）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（自己啓発・学習）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '04'
    ) AS "興味・関心のある情報（ショッピング）_1"
    ON "興味・関心のある情報（ショッピング）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（ショッピング）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '05'
    ) AS "興味・関心のある情報（住宅・インテリア）_1"
    ON "興味・関心のある情報（住宅・インテリア）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（住宅・インテリア）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '06'
    ) AS "興味・関心のある情報（マネー情報）_1"
    ON "興味・関心のある情報（マネー情報）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（マネー情報）_1"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP7_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,CASE
   WHEN NOT "興味・関心のある情報（住まいと家族）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（住まいと家族）"
,CASE
   WHEN NOT "興味・関心のある情報（文化教養）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（文化教養）"
,CASE
   WHEN NOT "興味・関心のある情報（旅行・スポーツ・アウトドア）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（旅行・スポーツ・アウトドア）"
,CASE
   WHEN NOT "興味・関心のある情報（ビジネス）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（ビジネス）"
,CASE
   WHEN NOT "興味・関心のある情報（カーライフ）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（カーライフ）"
,CASE
   WHEN NOT "興味・関心のある情報（ファッション）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（ファッション）"
,CASE
   WHEN NOT "興味・関心のある情報（コンピュータ＆テクノロジー）_1"."選択肢ID" IS NULL THEN
     '関心がある'
   ELSE
     '関心がない'
 END
 AS "興味・関心のある情報（コンピュータ＆テクノロジー）"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '07'
    ) AS "興味・関心のある情報（住まいと家族）_1"
    ON "興味・関心のある情報（住まいと家族）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（住まいと家族）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '08'
    ) AS "興味・関心のある情報（文化教養）_1"
    ON "興味・関心のある情報（文化教養）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（文化教養）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '09'
    ) AS "興味・関心のある情報（旅行・スポーツ・アウトドア）_1"
    ON "興味・関心のある情報（旅行・スポーツ・アウトドア）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（旅行・スポーツ・アウトドア）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '10'
    ) AS "興味・関心のある情報（ビジネス）_1"
    ON "興味・関心のある情報（ビジネス）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（ビジネス）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '11'
    ) AS "興味・関心のある情報（カーライフ）_1"
    ON "興味・関心のある情報（カーライフ）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（カーライフ）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '12'
    ) AS "興味・関心のある情報（ファッション）_1"
    ON "興味・関心のある情報（ファッション）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（ファッション）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0925' AND "選択肢ID" = '13'
    ) AS "興味・関心のある情報（コンピュータ＆テクノロジー）_1"
    ON "興味・関心のある情報（コンピュータ＆テクノロジー）_1"."フォームID" = C."フォームID" AND "興味・関心のある情報（コンピュータ＆テクノロジー）_1"."応募者ID" = C."応募者ID"
;

CREATE TEMP TABLE TEMP8_CRM03EE01 AS
SELECT 
 C."フォームID"
,C."応募者ID"
,"居住国名（日経ID非連動）_2".COUNTRY_NAME AS "居住国名（日経ID非連動）"
,CASE
   WHEN NOT "新聞購読状況（未読）_1"."選択肢ID" IS NULL THEN
     'すべて未購読'
   WHEN "新聞購読状況（未読）_2"."選択肢ID" IS NULL THEN
     NULL
   ELSE
     '購読あり'
 END
 AS "新聞購読状況（未読）"
,CASE
   WHEN NOT "第三者メール許諾フラグ_1"."選択肢ID" IS NULL THEN
     '第三者メール許諾'
   ELSE
     '拒否'
 END
 AS "第三者メール許諾フラグ"
,ISNULL("都道府県名_2".ADDR_1,"都道府県名_4".ADDR_1) AS "都道府県名"
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0014' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","選択肢ID","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0014' AND A."枝番" = 1 AND
    B."入力形態ID" = '0014' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "居住国名（日経ID非連動）_1"
    ON "居住国名（日経ID非連動）_1"."フォームID" = C."フォームID" AND "居住国名（日経ID非連動）_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
      SELECT COUNTRY_NAME, CODE_NUMERIC FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_country
       ) AS "居住国名（日経ID非連動）_2"
       ON "居住国名（日経ID非連動）_2".CODE_NUMERIC = "居住国名（日経ID非連動）_1"."選択肢ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND "枝番" = 1 AND "選択肢ID" = '-'
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND A."枝番" = 1 AND A."選択肢ID" = '-' AND
    B."入力形態ID" = '0922' AND B."枝番" = 1 AND B."選択肢ID" = '-' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（未読）_1"
    ON "新聞購読状況（未読）_1"."フォームID" = C."フォームID" AND "新聞購読状況（未読）_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0922' AND NOT "選択肢ID" IS NULL
    GROUP BY "フォームID","応募者ID","選択肢ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",A."選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2" AS B
    ON
    A."入力形態ID" = '0922' AND
    B."入力形態ID" = '0922' AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."選択肢ID" > B."選択肢ID"
    ) AS "新聞購読状況（未読）_2"
    ON "新聞購読状況（未読）_2"."フォームID" = C."フォームID" AND "新聞購読状況（未読）_2"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID","選択肢ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    WHERE "入力形態ID" = '0923' AND "選択肢ID" = '2'
    ) AS "第三者メール許諾フラグ_1"
    ON "第三者メール許諾フラグ_1"."フォームID" = C."フォームID" AND "第三者メール許諾フラグ_1"."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT "フォームID","応募者ID",TRANSLATE("応募内容",'-','') AS "応募内容" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0913' AND "枝番" = 1
    ) AS "都道府県名_1"
    ON "都道府県名_1"."フォームID" = C."フォームID" AND "都道府県名_1"."応募者ID" = C."応募者ID"
    LEFT JOIN(
     SELECT DISTINCT PREFEC AS ADDR_1, ZIPCODE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address
      EXCEPT
      SELECT A.PREFEC, A.ZIPCODE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address AS A
      JOIN
      {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address AS B
      ON
      A.ZIPCODE = B.ZIPCODE AND
      A.PREFEC > B.PREFEC
      ) AS "都道府県名_2"
      ON "都道府県名_2".ZIPCODE = "都道府県名_1"."応募内容"
 LEFT JOIN(
   SELECT DISTINCT "フォームID","応募者ID",TRANSLATE("応募内容",'-','') AS "応募内容","フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
    WHERE "入力形態ID" = '0004' AND "枝番" = 1
    GROUP BY "フォームID","応募者ID","応募内容","フォーム項目ID"
    EXCEPT
    SELECT A."フォームID",A."応募者ID",TRANSLATE(A."応募内容",'-','') AS "応募内容",A."フォーム項目ID" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS A
    JOIN
    {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" AS B
    ON
    A."入力形態ID" = '0004' AND A."枝番" = 1 AND
    B."入力形態ID" = '0004' AND B."枝番" = 1 AND
    A."フォームID" = B."フォームID" AND A."応募者ID" = B."応募者ID" AND
    A."フォーム項目ID" > B."フォーム項目ID"
    ) AS "都道府県名_3"
    ON "都道府県名_3"."フォームID" = C."フォームID" AND "都道府県名_3"."応募者ID" = C."応募者ID"
    LEFT JOIN(
     SELECT DISTINCT PREFEC AS ADDR_1, ZIPCODE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address
      EXCEPT
      SELECT A.PREFEC, A.ZIPCODE FROM {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address AS A
      JOIN
      {{ var.value.redshift_ims_schema_name }}.M_IS_mm_address AS B
      ON
      A.ZIPCODE = B.ZIPCODE AND
      A.PREFEC > B.PREFEC
      ) AS "都道府県名_4"
      ON "都道府県名_4".ZIPCODE = "都道府県名_3"."応募内容"
;

DELETE FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_蓄積用_固定項目"
WHERE
(    "フォームID"
,    "応募者ID"
)
IN
(
SELECT
     "フォームID"
,    "応募者ID"
FROM
     {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
UNION
SELECT
     "フォームID"
,    "応募者ID"
FROM
     {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
UNION
SELECT
     "フォームID"
,    "応募者ID"
FROM
     {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
)
;

UPDATE {{ var.value.redshift_ims_schema_name }}."T_EE_V_蓄積用_固定項目"
SET  "日経ID会員番号_表示用"  = NULL
,    "メールアドレス"         = NULL
,    "第２メールアドレス"     = NULL
,    "氏名（フリガナ）"       = NULL
,    "氏名"                   = NULL
,    "生年月日"               = NULL
,    "お勤め先名"             = NULL
,    "所属される部署名"       = NULL
,    "お勤め先郵便番号"       = NULL
,    "お勤め先住所"           = NULL
,    "お勤め先電話番号"       = NULL
,    "郵便番号"               = NULL
,    "ご住所"                 = NULL
,    "電話番号"               = NULL
,    "海外お勤め先名"         = NULL
,    "海外お勤め先の住所"     = NULL
,    "海外お勤め先電話番号"   = NULL
,    "海外ご住所"             = NULL
,    "海外郵便番号"           = NULL
,    "海外電話番号"           = NULL
,    "個人情報削除済みフラグ" = 1
,    UPD_BATCH_ID             = '{{ dag.dag_id }}'
,    UPD_DT_TM                = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE "個人情報削除済みフラグ" = 0
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}."T_EE_V_蓄積用_固定項目"
(
フォームID
,応募者ID
,日経ID会員番号_表示用
,日経ID会員番号
,メールアドレス
,第２メールアドレス
,氏名（フリガナ）
,氏名
,生年月日
,性別
,職業
,業種
,職種
,役職
,従業員規模
,海外居住チェック
,お勤め先名
,所属される部署名
,お勤め先郵便番号
,お勤め先住所
,お勤め先電話番号
,郵便番号
,ご住所
,電話番号
,海外お勤め先名
,海外お勤め先の住所
,海外お勤め先電話番号
,居住国名
,海外ご住所
,海外郵便番号
,海外電話番号
,世帯年収
,新聞購読状況（日本経済新聞）
,新聞購読状況（日経産業新聞）
,新聞購読状況（日経MJ）
,新聞購読状況（日経ヴェリタス）
,"新聞購読状況（THE NIKKEI WEEKLY）"
,日経メール許諾
,日経IDリサーチモニタフラグ
,興味・関心のある情報（エンターテインメント）
,興味・関心のある情報（食と健康）
,興味・関心のある情報（自己啓発・学習）
,興味・関心のある情報（ショッピング）
,興味・関心のある情報（住宅・インテリア）
,興味・関心のある情報（マネー情報）
,興味・関心のある情報（住まいと家族）
,興味・関心のある情報（文化教養）
,興味・関心のある情報（旅行・スポーツ・アウトドア）
,興味・関心のある情報（ビジネス）
,興味・関心のある情報（カーライフ）
,興味・関心のある情報（ファッション）
,興味・関心のある情報（コンピュータ＆テクノロジー）
,居住国名（日経ID非連動）
,応募者登録日時
,応募者更新日時
,フォーム名
,新聞購読状況（未読）
,第三者メール許諾フラグ
,都道府県名
,個人情報削除済みフラグ
,INS_BATCH_ID
,INS_DT_TM
,UPD_BATCH_ID
,UPD_DT_TM
)
SELECT 
 C."フォームID"
,C."応募者ID"
,LPAD(CAST(C."日経ID会員番号" AS VARCHAR),10,'0') AS "日経ID会員番号_表示用"
,C."日経ID会員番号"
,T1."メールアドレス"
,T1."第２メールアドレス"
,T1."氏名（フリガナ）"
,T1."氏名"
,T1."生年月日"
,T1."性別"
,T2."職業"
,T2."業種"
,T2."職種"
,T2."役職"
,T2."従業員規模"
,T2."海外居住チェック"
,T2."お勤め先名"
,T2."所属される部署名"
,T2."お勤め先郵便番号"
,T2."お勤め先住所"
,T2."お勤め先電話番号"
,T2."郵便番号"
,T3."ご住所"
,T3."電話番号"
,T3."海外お勤め先名"
,T3."海外お勤め先の住所"
,T3."海外お勤め先電話番号"
,T3."居住国名"
,T3."海外ご住所"
,T4."海外郵便番号"
,T4."海外電話番号"
,T4."世帯年収"
,T4."新聞購読状況（日本経済新聞）"
,T5."新聞購読状況（日経産業新聞）"
,T5."新聞購読状況（日経MJ）"
,T5."新聞購読状況（日経ヴェリタス）"
,T5."新聞購読状況（THE NIKKEI Weekly）"
,T6."日経メール許諾"
,T6."日経IDリサーチモニタフラグ"
,T6."興味・関心のある情報（エンターテインメント）"
,T6."興味・関心のある情報（食と健康）"
,T6."興味・関心のある情報（自己啓発・学習）"
,T6."興味・関心のある情報（ショッピング）"
,T6."興味・関心のある情報（住宅・インテリア）"
,T6."興味・関心のある情報（マネー情報）"
,T7."興味・関心のある情報（住まいと家族）"
,T7."興味・関心のある情報（文化教養）"
,T7."興味・関心のある情報（旅行・スポーツ・アウトドア）"
,T7."興味・関心のある情報（ビジネス）"
,T7."興味・関心のある情報（カーライフ）"
,T7."興味・関心のある情報（ファッション）"
,T7."興味・関心のある情報（コンピュータ＆テクノロジー）"
,T8."居住国名（日経ID非連動）"
,C.応募者登録日時
,C.応募者更新日時
,C.フォーム名
,T8."新聞購読状況（未読）"
,T8."第三者メール許諾フラグ"
,T8."都道府県名"
,0 AS "個人情報削除済みフラグ"
,'{{ dag.dag_id }}' AS INS_BATCH_ID
,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
,'{{ dag.dag_id }}' AS UPD_BATCH_ID
,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM (
    SELECT "フォームID" , "応募者ID",MAX("日経ID会員番号") AS "日経ID会員番号",MAX("応募者登録日時") AS "応募者登録日時",MAX("応募者更新日時") AS "応募者更新日時",MAX("フォーム名") AS "フォーム名"
    FROM(
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2" 
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_メールアドレス2"
        UNION
        SELECT "フォームID" , "応募者ID","日経ID会員番号","応募者登録日時","応募者更新日時","フォーム名" FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
    ) A GROUP BY "フォームID" , "応募者ID"
) C
 LEFT JOIN(
   SELECT * FROM TEMP1_CRM03EE01
    ) AS T1
    ON T1."フォームID" = C."フォームID" AND T1."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP2_CRM03EE01
    ) AS T2
    ON T2."フォームID" = C."フォームID" AND T2."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP3_CRM03EE01
    ) AS T3
    ON T3."フォームID" = C."フォームID" AND T3."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP4_CRM03EE01
    ) AS T4
    ON T4."フォームID" = C."フォームID" AND T4."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP5_CRM03EE01
    ) AS T5
    ON T5."フォームID" = C."フォームID" AND T5."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP6_CRM03EE01
    ) AS T6
    ON T6."フォームID" = C."フォームID" AND T6."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP7_CRM03EE01
    ) AS T7
    ON T7."フォームID" = C."フォームID" AND T7."応募者ID" = C."応募者ID"
 LEFT JOIN(
   SELECT * FROM TEMP8_CRM03EE01
    ) AS T8
    ON T8."フォームID" = C."フォームID" AND T8."応募者ID" = C."応募者ID"
;
