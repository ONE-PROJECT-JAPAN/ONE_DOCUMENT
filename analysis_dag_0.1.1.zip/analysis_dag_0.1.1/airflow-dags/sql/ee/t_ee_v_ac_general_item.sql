/*******************************************************************************
  SQL名:
        イベントアンケートデータ汎用項目蓄積
  処理概要:
        T_EE_V_蓄積用_汎用項目の蓄積を行う
       蓄積キー:
         "フォームID", "応募者ID"
       参照テーブル:
         T_EE_V_応募内容_テキスト2
         T_EE_V_応募内容_選択2
*******************************************************************************/
DELETE FROM {{ var.value.redshift_ims_schema_name }}."T_EE_V_蓄積用_汎用項目"
WHERE
(    "フォームID"
,    "応募者ID"
)
IN
(
SELECT
     "フォームID"
,    "応募者ID"
FROM
     {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
UNION
SELECT
     "フォームID"
,    "応募者ID"
FROM
     {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}."T_EE_V_蓄積用_汎用項目"
(    "フォームID"
,    "応募者ID"
,    "フォーム項目ID"
,    "項目名"
,    "枝番"
,    "選択肢ID"
,    "応募内容"
,    "その他テキスト"
,    INS_BATCH_ID
,    INS_DT_TM
,    UPD_BATCH_ID
,    UPD_DT_TM
)
SELECT
     "フォームID"
,    "応募者ID"
,    "フォーム項目ID"
,    "項目名"
,    "枝番"
,    null as "選択肢ID"
,    SUBSTRING("応募内容",1,2000) AS "応募内容"
,    null as "その他テキスト"
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM  {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_テキスト2"
WHERE "入力形態ID" NOT IN
('0003','0004','0005','0006','0011','0012','0013','0014','0015','0901','0902','0903','0904','0905','0906','0907','0908','0909','0910','0911','0912','0913','0914','0915','0916','0917','0918','0919','0920','0921','0922','0923','0924','0925')
UNION
SELECT
     "フォームID"
,    "応募者ID"
,    "フォーム項目ID"
,    SUBSTRING("項目名",1,50) AS "項目名"
,    "枝番"
,    "選択肢ID"
,    SUBSTRING("応募内容",1,2000) AS "応募内容"
,    SUBSTRING("その他テキスト",1,2000) AS "その他テキスト"
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM  {{ var.value.redshift_ims_schema_name }}."T_EE_V_応募内容_選択2"
WHERE "入力形態ID" NOT IN
('0003','0004','0005','0006','0011','0012','0013','0014','0015','0901','0902','0903','0904','0905','0906','0907','0908','0909','0910','0911','0912','0913','0914','0915','0916','0917','0918','0919','0920','0921','0922','0923','0924','0925')
;
