
/*******************************************************************************
  SQL名:
    ユーザー情報ビュー蓄積データの更新

  処理概要:
       T_BPP_T_USERに存在しない日経ID（退会済）の場合T_BPP_V_USER_ALL_ACのBP_STATUSを0に更新する
       
       参照テーブル
       T_BPP_T_USER
*******************************************************************************/
UPDATE {{ var.value.redshift_ims_schema_name }}.T_BPP_V_USER_ALL_AC
    SET BP_STATUS = 0
WHERE
    BP_STATUS = 1 AND SERIALID NOT IN (
        SELECT SERIALID from {{ var.value.redshift_ims_schema_name }}.T_BPP_T_USER
    )
;
