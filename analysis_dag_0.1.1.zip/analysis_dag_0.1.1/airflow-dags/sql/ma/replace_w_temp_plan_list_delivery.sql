
/*******************************************************************************
  SQL名:
    本番配信連携処理に必要なデータ取得処理
  処理概要:
       #1 本番配信ワークテーブルから施策一覧作成
       #2 本番配信リスト作成
       #3 基本情報作成
*******************************************************************************/

/*******************************************************************************
       #1 本番配信ワークテーブルから施策一覧作成
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_LIST_DELIVERY
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_LIST_DELIVERY AS
SELECT
 PLAN_ID                                -- 施策ID
 , '7' as SERVICE_NO                    -- サービス番号
 , '0' as CM_DELIVERY_STATUS            -- ClickMailer配信状態（0:配信未済、1：配信済）
FROM
(
    SELECT
        row_number() over () as rownum  -- 行番号
        , PLAN_ID                       -- 施策ID
    FROM
        {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY
    GROUP BY PLAN_ID
) DEL
WHERE
    DEL.rownum IN (
        SELECT
            DEL2.rownum
        FROM 
        (
            SELECT
                row_number() over () as rownum -- 行番号
            FROM
                {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY GROUP BY PLAN_ID) DEL2
        )
;

/*******************************************************************************
       #2 配信リスト作成
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_DELIVERY_LIST
;

-- テーブル作成及びデータ追加(本番データ)
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_DELIVERY_LIST AS
SELECT 
  'PROD' as FLAG_PROD_TEST                 -- 本番/テスト区分
  , '7' as SERVICE_NO                      -- サービス番号
  , MAIN.PLAN_ID as PLAN_ID                -- 施策ID
  , MAIN.EMAIL as EMAIL                    -- メールアドレス
  , MAIN.NAME as NAME                      -- 氏名
  , MAIN.CUSTOMER_ID as CUSTOMER_ID        -- 会員番号
  , MAIN.URL1 as URL1                      -- URL1
  , MAIN.URL2 as URL2                      -- URL2
  , '0' as DELETE_FLG                      -- 削除フラグ
FROM {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY MAIN
INNER JOIN 
  (SELECT 
    PLAN_ID                                -- 施策ID
    , LOWER(EMAIL) as EMAIL                -- メールアドレス
    , MIN(CUSTOMER_ID) as CUSTOMER_ID      -- 会員番号
   FROM
     {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY
   GROUP BY
     PLAN_ID
     , LOWER(EMAIL)
  ) LOWER_EMAIL_DATA
  ON MAIN.PLAN_ID= LOWER_EMAIL_DATA.PLAN_ID AND MAIN.CUSTOMER_ID = LOWER_EMAIL_DATA.CUSTOMER_ID
ORDER BY
 PLAN_ID
 , EMAIL
;

/*******************************************************************************
       #3 基本情報作成
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_BASIC_SET_MNG
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_BASIC_SET_MNG AS
SELECT DISTINCT
 w.PLAN_ID                              -- 施策ID
 , b.REJECT_SLIST_IDX                   -- 配信除外グループ
 , b.BLOCK_GROUP_IDX                    -- ブロックグループ
 , b.MAILFROM                           -- FROMアドレス
 , b.MAILTO                             -- 受信者
 , b.REPLYTO                            -- 返信アドレス
 , b.ERRORSTO                           -- ERRORS-TOアドレス
 , b.ENCODING                           -- エンコーディング
 , b.CHARSET                            -- 文字セット
 , b.TTERM                              -- トラッキング期間
 , b.CLICK_SET                          -- URLトラッキング
 , b.SITE_SET                           -- サイトトラッキング
 , b.ATC_SET                            -- 添付ファイル個数
 , b.GUBUN                              -- メール区分コード
 , b.RNAME                              -- 顧客固有情報
 , b.MTYPE                              -- MTYPE
 , b.U_IDX                              -- ユーザID
 , b.G_IDX                              -- グループID
 , b.PRIORITY                           -- 優先順位
 , b.SIGN                               -- S/MIME署名
 , b.SPEED                              -- 配信通数値
 , w.MCOMMENT                           -- 案件名
 , w.SUBJECT                            -- 件名
 , w.BODY                               -- 本文
 , w.BODY_FORMAT                        -- 本文形式
 , w.DELIVERY_TM                        -- 配信日時
 , TO_CHAR(w.DELIVERY_TM, 'YYYYMMDDHH24MISS') as CM_DELIVERY_TM --配信日時（YYYYMMDDhhmmssに変換）
 , TO_CHAR(DATEADD(day, b.TTERM, w.DELIVERY_TM), 'YYYYMMDDHH24MISS') as CM_TTERM --トラッキング期間  配信日時 + トラッキング期間（YYYYMMDDhhmmssに変換）
FROM
 {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY w
INNER JOIN
 {{ var.value.redshift_ims_schema_name }}.M_IMS_CM_BASIC_SET_MNG b
ON
 b.BASIC_SET_ID = w.BASIC_SET_ID
WHERE
 b.DELETE_FLG = '0'
;
