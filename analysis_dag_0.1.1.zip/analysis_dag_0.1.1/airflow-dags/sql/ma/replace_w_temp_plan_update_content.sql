
/*******************************************************************************
  SQL名:
    コンテンツ差替が必要なデータ取得
  処理概要:
       本番配信状態コードが「080:コンテンツ差替中」を取得する
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_UPDATE_CONTENT
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_UPDATE_CONTENT AS
SELECT
 PLAN_ID                     -- 施策ID
 , PROD_DELIVERY_STATUS_CD   -- 本番配信状態コード
 , SUBJECT                   -- 件名
 , BODY_FORMAT               -- 本文形式
 , BODY                      -- 本文
 , '0' as CM_UPDATE_STATUS   -- ClickMailer処理状態（0:処理未済、1：処理済）
FROM
 {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG
WHERE
 DELETE_FLG = '0'
AND
 PROD_DELIVERY_STATUS_CD = '080'
;
