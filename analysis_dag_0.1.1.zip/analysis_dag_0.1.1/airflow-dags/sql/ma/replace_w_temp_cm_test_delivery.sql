
/*******************************************************************************
  SQL名:
    テスト配信ワークデータ取得処理
  処理概要:
       CLICKM@ILERテスト配信ワークテーブルに配信対象のデータを追加する
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_TEST_DELIVERY
;

-- テスト配信状態が「テスト配信登録済」かつ、施策種別が1 or 3の場合、ワークテーブルに挿入する。
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_TEST_DELIVERY AS
    SELECT
      '7' as SERVICE_NO
      , m.PLAN_ID
      , m.TEST_DELIVERY_TM as DELIVERY_TM
      , m.SUBJECT
      , m.BODY_FORMAT
      , m.BODY
      , m.BASIC_SET_ID
      , m.MAILFROM
      , m.REPLYTO
      , t.EMAIL
      , CRM.VALUE1 as NAME
      , CRM.VALUE4 as URL1
      , NULL as URL2
      , CASE
         WHEN m.PLAN_CLASS_CD = '1' THEN LEFT(m.PLAN_NM, 63)
         ELSE ' '
         END as MCOMMENT
     , '0' as CM_DELIVERY_STATUS -- ClickMailer配信状態（0:配信未済、1：配信済）
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_TEST_DELIVERY_EMAIL t
    CROSS JOIN  
      {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE CRM
    INNER JOIN
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG m
    ON
      m.PLAN_ID = t.PLAN_ID
    WHERE
      CRM.MASTER_TYPE='MST520'
    AND
      CRM.MASTER_GRP_TYPE='GCRM520'
    AND
      CRM.YUKO_FLG='1'
    AND
      m.PLAN_CLASS_CD IN ('1','3')
    AND
      m.DELETE_FLG = '0'
    AND
      m.TEST_DELIVERY_STATUS_CD = '020'
;
