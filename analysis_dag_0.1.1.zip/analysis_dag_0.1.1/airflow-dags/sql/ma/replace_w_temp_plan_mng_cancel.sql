
/*******************************************************************************
  SQL名:
    本番配信取消処理に必要なデータ取得処理
  処理概要:
       本番配信状態コードが「本番配信取消中」を取得する
       「050:本番配信取消中」
       「060:本番配信取消中（コンテンツ差替のため）」
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_MNG_CANCEL
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_MNG_CANCEL AS
SELECT DISTINCT
 PLAN_ID                        -- 施策ID
 , PROD_DELIVERY_STATUS_CD      -- 本番配信状態コード
 , '0' as CM_UPDATE_STATUS      -- ClickMailer処理状態（0:処理未済、1：処理済）
FROM
 {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG
WHERE
 DELETE_FLG = '0'
AND
(
 PROD_DELIVERY_STATUS_CD = '050'
OR
 PROD_DELIVERY_STATUS_CD = '060'
)
;
