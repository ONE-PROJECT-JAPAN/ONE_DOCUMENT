
/*******************************************************************************
  SQL名:
    本番配信ワークデータ取得処理
  処理概要:
       CLICKM@ILER本番配信ワークテーブルに配信対象のデータを追加する
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY
;

-- 本番配信状態が「本番配信登録済」かつ施策種別が1 or 3の施策データを取得し、ワークテーブルに挿入する。
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY AS
SELECT
  *
FROM (
    /* MA */
    SELECT
      DISTINCT m.PLAN_ID as PLAN_ID                             -- 施策ID
      ,'7' as SERVICE_NO                                        -- 配信日時
      , m.PROD_DELIVERY_SCHEDULED_TM as DELIVERY_TM             -- 配信日時
      , m.SUBJECT as SUBJECT                                    -- 件名
      , m.BODY_FORMAT as BODY_FORMAT                            -- 本文形式
      , m.BODY as BODY                                          -- 本文
      , m.BASIC_SET_ID as BASIC_SET_ID                          -- 基本設定
      , m.MAILFROM as MAILFROM                                  -- FROMアドレス
      , m.REPLYTO as REPLYTO                                    -- 返信アドレス
      , m.TTERM as TTERM                                        -- トラッキング期間
      , a.EMAIL as EMAIL                                        -- メールアドレス
      , a.LAST_NAME || a.FIRST_NAME as NAME                     -- 氏名
      , s.USER_NO as CUSTOMER_ID                                -- 会員番号
      , e.VALUE1 as URL1                                        -- URL1
      , e.VALUE2 as URL2                                        -- URL2
      , ' ' as MCOMMENT                                         -- 案件名
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG m
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_MA_EXPORT_INFO e
        ON m.PLAN_ID = e.EXPORT_ID
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_USER_SERIAL_ID s
        ON e.SERIAL_ID = s.SERIAL_ID
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE a
        ON s.USER_NO = a.USER_NO
    WHERE
      m.PLAN_CLASS_CD = '3'
      AND m.DELETE_FLG = '0'
      AND m.PROD_DELIVERY_STATUS_CD = '020'
      AND m.PROD_DELIVERY_SCHEDULED_TM::DATE = CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())::DATE
      AND a.EMAIL IS NOT NULL
    UNION ALL
    /* TGML */
    SELECT
      DISTINCT m.PLAN_ID as PLAN_ID                             -- 施策ID
      , '7' as SERVICE_NO                                       -- 配信日時
      , m.PROD_DELIVERY_SCHEDULED_TM as DELIVERY_TM             -- 配信日時
      , m.SUBJECT as SUBJECT                                    -- 件名
      , m.BODY_FORMAT as BODY_FORMAT                            -- 本文形式
      , m.BODY as BODY                                          -- 本文
      , m.BASIC_SET_ID as BASIC_SET_ID                          -- 基本設定
      , m.MAILFROM as MAILFROM                                  -- 受信者
      , m.REPLYTO as REPLYTO                                    -- 返信アドレス
      , m.TTERM as TTERM                                        -- トラッキング期間
      , a.EMAIL as EMAIL                                        -- メールアドレス
      , a.LAST_NAME || a.FIRST_NAME as NAME                     -- 氏名
      , a.USER_NO as CUSTOMER_ID                                -- 会員番号
      , null as URL1                                            -- URL1
      , null as URL2                                            -- URL2
      , LEFT(m.PLAN_NM, 63) as MCOMMENT                         -- 案件名
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG m
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_IMS_PROPOSAL p
        ON m.PLAN_ID = p.PLAN_ID
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_IMS_CAMP_HISTORY h
        ON p.ID = h.PROPOSAL_ID
      INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE a
        ON h.CUSTOMER_ID = a.USER_NO
    WHERE
      m.PLAN_CLASS_CD = '1'
      AND m.DELETE_FLG = '0'
      AND m.PROD_DELIVERY_STATUS_CD = '020'
      AND m.PROD_DELIVERY_SCHEDULED_TM::DATE = (CONVERT_TIMEZONE('Asia/Tokyo', GETDATE()) + 1)::DATE
      AND p.DELFLG = '0'
      AND a.EMAIL IS NOT NULL
) T1
;
