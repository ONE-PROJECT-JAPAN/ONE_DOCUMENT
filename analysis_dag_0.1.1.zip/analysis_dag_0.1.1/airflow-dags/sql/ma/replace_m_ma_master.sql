
/*******************************************************************************
  SQL名:
    MAマスタデータロード
  処理概要:
       データ削除
       ロード処理
*******************************************************************************/

-- データ削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.{{ params.table_name }}
;

-- データロード
COPY {{ var.value.redshift_ims_schema_name }}.{{ params.table_name }}
FROM '{{ params.s3_path }}_{{ convUTC2JST(next_execution_date, "%Y%m%d") }}/' 
iam_role '{{ var.value.redshift_default_role_arn }}'
EMPTYASNULL
TRUNCATECOLUMNS
TIMEFORMAT 'auto'
ACCEPTINVCHARS
DELIMITER '\t'
IGNOREHEADER 0
CSV QUOTE AS '"'
gzip
;
