
/*******************************************************************************
  SQL名:
    MA連携データ取込
  処理概要:
       MA抽出情報を元に、
       施策管理、施策別テスト配信メールアドレスに施策データの取込処理を行う。
*******************************************************************************/
--施策管理差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG
(
  PLAN_ID
  , PLAN_CLASS_CD
  , PLAN_NM
  , PROD_DELIVERY_STATUS_CD
  , PROD_DELIVERY_SCHEDULED_TM
  , BASIC_SET_ID
  , MAILFROM
  , REPLYTO
  , TTERM
  , TEST_DELIVERY_ADD_EMAIL
  , CONTENT_TEMPLATE_ID
  , SUBJECT
  , BODY_FORMAT
  , BODY
  , DELETE_FLG
  , INS_PGM_ID
  , INS_DT_TM
  , UPD_PGM_ID
  , UPD_DT_TM
)
SELECT
  T1.EXPORT_ID
  , '3'
  , T2.CAMPAIGN_NAME || TO_CHAR(T1.EXPORT_DATE, '_YYYYMMDD')
  , '020'
  , TO_TIMESTAMP(T1.EXPORT_DATE || T2.DELIVERY_TIME_HHMI, 'YYYY-MM-DDHHMI')
  , T2.BASIC_SET_ID
  , T3.MAILFROM
  , T3.REPLYTO
  , T3.TTERM
  , T2.TEST_DELIVERY_ADD_EMAIL
  , T2.CONTENT_TEMPLATE_ID
  , T4.SUBJECT
  , T4.BODY_FORMAT
  , T4.BODY
  , '0'
  , '{{ dag.dag_id }}' AS INS_PGM_ID
  , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  , '{{ dag.dag_id }}' AS UPD_PGM_ID
  , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  (
    SELECT
      EXPORT_ID
      , CAMPAIGN_ID
      , EXPORT_DATE
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_MA_EXPORT_INFO
    GROUP BY
      EXPORT_ID
      , CAMPAIGN_ID
      , EXPORT_DATE
  ) T1
  INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_MA_MAIL_SEND_INFO T2
    ON T1.CAMPAIGN_ID = T2.CAMPAIGN_ID
  INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_IMS_CM_BASIC_SET_MNG T3
    ON T2.BASIC_SET_ID = T3.BASIC_SET_ID
  INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_IMS_CONTENT_TEMPLATE_MNG T4
    ON T2.CONTENT_TEMPLATE_ID = T4.CONTENT_TEMPLATE_ID
WHERE
  NOT EXISTS(
    SELECT
      1
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG SUB
    WHERE
      T1.EXPORT_ID = SUB.PLAN_ID
  )
;

--施策別テスト配信メールアドレス差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_TEST_DELIVERY_EMAIL
(
  PLAN_ID
  , PLAN_CLASS_CD
  , EMAIL
  , INS_PGM_ID
  , INS_DT_TM
  , UPD_PGM_ID
  , UPD_DT_TM
)
WITH SPLIT_TEST_DELIVERY_ADD_EMAIL AS (
SELECT
  PLAN_ID AS PLAN_ID
  , CAST('3' as VARCHAR) AS PLAN_CLASS_CD
  , EMAIL AS EMAIL
  , CAST('{{ dag.dag_id }}' as VARCHAR) AS INS_PGM_ID
  , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  , CAST('{{ dag.dag_id }}' as VARCHAR) AS UPD_PGM_ID
  , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  (
    SELECT
      PLAN_ID
      , SPLIT_PART(TEST_DELIVERY_ADD_EMAIL, ',', (ROW_NUMBER() OVER (PARTITION BY PLAN_ID))::INTEGER) AS EMAIL
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_MNG
      CROSS JOIN SVV_TABLE_INFO
    WHERE
      PLAN_CLASS_CD = '3'
      AND TEST_DELIVERY_ADD_EMAIL IS NOT NULL
  )
WHERE
  EMAIL != ''
)
SELECT
  PLAN_ID
  , PLAN_CLASS_CD
  , EMAIL
  , INS_PGM_ID
  , INS_DT_TM
  , UPD_PGM_ID
  , UPD_DT_TM
FROM
  SPLIT_TEST_DELIVERY_ADD_EMAIL
WHERE
  NOT EXISTS (
        SELECT
          1
        FROM
          {{ var.value.redshift_ims_schema_name }}.T_IMS_PLAN_TEST_DELIVERY_EMAIL SUB
        WHERE
          SPLIT_TEST_DELIVERY_ADD_EMAIL.PLAN_ID = SUB.PLAN_ID
      )
;
