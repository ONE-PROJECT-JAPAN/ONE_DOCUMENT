
/*******************************************************************************
  SQL名:
    本番配信連携処理で使用したワークテーブルの削除
  処理概要:
       本番配信連携処理で使用したワークテーブルを削除する
*******************************************************************************/

DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_PLAN_LIST_DELIVERY
;
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_DELIVERY_LIST
;
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_BASIC_SET_MNG
;
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_TEMP_CM_PROD_DELIVERY
;
