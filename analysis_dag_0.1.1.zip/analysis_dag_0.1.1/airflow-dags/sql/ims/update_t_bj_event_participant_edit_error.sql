/*******************************************************************************
  SQL名:
    異常終了処理：イベント参加者ファイルのチェック処理

  処理概要:
       イベント参加者取込管理のステータスを更新する

*******************************************************************************/

UPDATE {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_LOAD_MNG
SET
     LOAD_STATUS_CD = {{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='load_status_cd') }}
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
     EVENT_ID = '{{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='event_id') }}'
;
