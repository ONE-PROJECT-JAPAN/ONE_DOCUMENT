/*******************************************************************************
  SQL名:
    名寄せ結果作成

  処理概要:
    名寄せ結果ワークから名寄せ結果を作成する。
*******************************************************************************/

--名寄せ結果削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_IMS_NAYOSE_RESULT
;


--名寄せ結果挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_NAYOSE_RESULT
(
  LIST_ID
 ,LIST_INTERNAL_ID
 ,NAYOSE_RULE_ID
 ,RULE_INTERNAL_NO
 ,INS_PGM_ID
 ,INS_DT_TM
 ,UPD_PGM_ID
 ,UPD_DT_TM
)
SELECT
  LIST_ID
 ,LIST_INTERNAL_ID
 ,NAYOSE_RULE_ID
 ,RULE_INTERNAL_NO
 ,'{{ dag.dag_id }}' AS INS_PGM_ID
 ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
 ,'{{ dag.dag_id }}' AS UPD_PGM_ID
 ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.W_IMS_NAYOSE_RESULT
;
