
/*******************************************************************************
  SQL名:
    販売局リスト作成

  処理概要:
       下記の順で処理を実施する
       #01 リスト背番号発番済名寄せ(日経ID)処理
       #02 リスト背番号発番済名寄せ(メールアドレス)処理(更新分)
       #03 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分)「処理#03」
       #04 リスト背番号発番済名寄せ(メールアドレス)処理(除外対象挿入分)
       #05 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理「処理#05」
       #06 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理(除外対象挿入分)
       #07 リスト背番号新規発番(日経ID)処理
       #08 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分)「処理#03」
       #09 リスト背番号新規発番(メールアドレス)処理
       #10 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理「処理#05」
       #11 リスト背番号新規発番(住所・電話番号・氏名／会社名)処理
       #12 リスト背番号新規発番(その他背番号未済)処理
       #13 販売局リスト作成
*******************************************************************************/

/*******************************************************************************
  #01 リスト背番号発番済名寄せ(日経ID)処理
*******************************************************************************/
--リスト背番号発番一時テーブル作成(日経ID)
CREATE TEMP TABLE INDEXING_NIKKEI_ID_TMP(
   USER_NO                    VARCHAR(52)
  ,LIST_NO                    VARCHAR(120)
  ,NIKKEI_MEMBER_NO           VARCHAR(40)
  ,EMAIL_CL                   VARCHAR(1024)
  ,ADDR_CL_ADDR               VARCHAR(5296)
  ,TELNO_CL                   VARCHAR(1020)
  ,NAME_COMPANY_NM_CL_NM      VARCHAR(1440)
);

--リスト背番号発番一時テーブル作成(メールアドレス)
CREATE TEMP TABLE INDEXING_MAIL_TMP(
   USER_NO                    VARCHAR(52)
  ,LIST_NO                    VARCHAR(120)
  ,NIKKEI_MEMBER_NO           VARCHAR(40)
  ,EMAIL_CL                   VARCHAR(1024)
  ,ADDR_CL_ADDR               VARCHAR(5296)
  ,TELNO_CL                   VARCHAR(1020)
  ,NAME_COMPANY_NM_CL_NM      VARCHAR(1440)
);

--リスト背番号発番一時テーブル作成(住所・電話番号・氏名／会社名)
CREATE TEMP TABLE INDEXING_ADDR_TMP(
   USER_NO                    VARCHAR(52)
  ,LIST_NO                    VARCHAR(120)
  ,NIKKEI_MEMBER_NO           VARCHAR(40)
  ,EMAIL_CL                   VARCHAR(1024)
  ,ADDR_CL_ADDR               VARCHAR(5296)
  ,TELNO_CL                   VARCHAR(1020)
  ,NAME_COMPANY_NM_CL_NM      VARCHAR(1440)
);

--リスト背番号発番一時テーブル作成(その他背番号未済)
CREATE TEMP TABLE INDEXING_OTHER_TMP(
   USER_NO                    VARCHAR(52)
  ,LIST_NO                    VARCHAR(120)
  ,NIKKEI_MEMBER_NO           VARCHAR(40)
  ,EMAIL_CL                   VARCHAR(1024)
  ,ADDR_CL_ADDR               VARCHAR(5296)
  ,TELNO_CL                   VARCHAR(1020)
  ,NAME_COMPANY_NM_CL_NM      VARCHAR(1440)
)
;

--読者基本情報、読者追加情報一時テーブル作成
CREATE TEMP TABLE TEMP_T_HK_BASIC_INFO_USER_CL_AC
AS
SELECT
    USER_NO
   ,NIKKEI_MEMBER_NO
   ,NIKKEI_ENTRY_DATE
   ,NIKKEI_NEW_CREATE_FLG
   ,CHARGE_CUST_NO
   ,ADDRESS_CD
   ,HON_SHISHA_CD
   ,ZIPCODE
   ,ZIPCODE_CL
   ,CLKEY_PREFECTURE_NM AS PREFECTURE_NM
   ,CLKEY_SHIKUTYOUSON_NM AS SHIKUTYOUSON_NM
   ,CLKEY_TSUSHO_NM AS TSUSHO_NM
   ,CLKEY_CHOME_NM AS CHOME_NM
   ,BANTI
   ,BUILDING
   ,ADDR_CL_ADDR
   ,ADDR_CL_PREFEC
   ,ADDR_CL_CITY
   ,ADDR_CL_TSUSHO
   ,ADDR_CL_CHOME
   ,ADDR_CL_ADDR1
   ,ADDR_CL_ADDR2
   ,ADDR_CL_ADDR3
   ,ADDR_CL_ADDR_CD
   ,NAME_COMPANY_NM
   ,NAME_COMPANY_NM_YOMI
   ,DEPARTMENT_NM
   ,NAME_COMPANY_NM_CL_LAST_NM
   ,NAME_COMPANY_NM_CL_FIRST_NM
   ,NAME_COMPANY_NM_CL_NM
   ,NAME_COMPANY_NM_CL_CORP_NM
   ,NAME_COMPANY_NM_CL_DEPT_NM
   ,SUBSCRIBER
   ,TELNO
   ,TELNO_CL
   ,FAXNO
   ,DAYTIME_CONTACT
   ,DAYTIME_CONTACT_CL
   ,EMAIL
   ,EMAIL_CL
   ,EMAIL_2
   ,EMAIL_2_CL
   ,SUBSCRIPTION_TYPE_CD
   ,SECONDARY_USE_SIGN
   ,NAYOSE_KEY
   ,UPDATE_KBN
   ,UPDATE_DATE
   ,CL_END_DT
   ,1 AS SYSTEM_FROM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER_CL_AC
UNION ALL
SELECT
    USER_NO
   ,NIKKEI_MEMBER_NO
   ,CAST(NULL AS TIMESTAMP) AS NIKKEI_ENTRY_DATE
   ,CAST(NULL AS INT) AS NIKKEI_NEW_CREATE_FLG
   ,CHARGE_CUST_NO
   ,ADDRESS_CD
   ,HON_SHISHA_CD
   ,ZIPCODE
   ,ZIPCODE_CL
   ,CLKEY_PREFECTURE_NM AS PREFECTURE_NM
   ,CLKEY_SHIKUTYOUSON_NM AS SHIKUTYOUSON_NM
   ,CLKEY_TSUSHO_NM AS TSUSHO_NM
   ,CLKEY_CHOME_NM AS CHOME_NM
   ,BANTI
   ,BUILDING
   ,ADDR_CL_ADDR
   ,ADDR_CL_PREFEC
   ,ADDR_CL_CITY
   ,ADDR_CL_TSUSHO
   ,ADDR_CL_CHOME
   ,ADDR_CL_ADDR1
   ,ADDR_CL_ADDR2
   ,ADDR_CL_ADDR3
   ,ADDR_CL_ADDR_CD
   ,NAME_COMPANY_NM
   ,NAME_COMPANY_NM_YOMI
   ,DEPARTMENT_NM
   ,NAME_COMPANY_NM_CL_LAST_NM
   ,NAME_COMPANY_NM_CL_FIRST_NM
   ,NAME_COMPANY_NM_CL_NM
   ,NAME_COMPANY_NM_CL_CORP_NM
   ,NAME_COMPANY_NM_CL_DEPT_NM
   ,SUBSCRIBER
   ,TELNO
   ,TELNO_CL
   ,FAXNO
   ,DAYTIME_CONTACT
   ,DAYTIME_CONTACT_CL
   ,EMAIL
   ,EMAIL_CL
   ,EMAIL_2
   ,EMAIL_2_CL
   ,SUBSCRIPTION_TYPE_CD
   ,SECONDARY_USE_SIGN
   ,NAYOSE_KEY
   ,UPDATE_KBN
   ,UPDATE_DATE
   ,CL_END_DT
   ,1 AS SYSTEM_FROM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_E_TRIAL_USER_CL_AC
UNION ALL
SELECT
    USER_NO
   ,NIKKEI_MEMBER_NO
   ,NIKKEI_ENTRY_DATE
   ,NIKKEI_NEW_CREATE_FLG
   ,CHARGE_CUST_NO
   ,ADDRESS_CD
   ,HON_SHISHA_CD
   ,ZIPCODE
   ,ZIPCODE_CL
   ,CLKEY_PREFECTURE_NM AS PREFECTURE_NM
   ,CLKEY_SHIKUTYOUSON_NM AS SHIKUTYOUSON_NM
   ,CLKEY_TSUSHO_NM AS TSUSHO_NM
   ,CLKEY_CHOME_NM AS CHOME_NM
   ,BANTI
   ,BUILDING
   ,ADDR_CL_ADDR
   ,ADDR_CL_PREFEC
   ,ADDR_CL_CITY
   ,ADDR_CL_TSUSHO
   ,ADDR_CL_CHOME
   ,ADDR_CL_ADDR1
   ,ADDR_CL_ADDR2
   ,ADDR_CL_ADDR3
   ,ADDR_CL_ADDR_CD
   ,NAME_COMPANY_NM
   ,NAME_COMPANY_NM_YOMI
   ,DEPARTMENT_NM
   ,NAME_COMPANY_NM_CL_LAST_NM
   ,NAME_COMPANY_NM_CL_FIRST_NM
   ,NAME_COMPANY_NM_CL_NM
   ,NAME_COMPANY_NM_CL_CORP_NM
   ,NAME_COMPANY_NM_CL_DEPT_NM
   ,SUBSCRIBER
   ,TELNO
   ,TELNO_CL
   ,FAXNO
   ,DAYTIME_CONTACT
   ,DAYTIME_CONTACT_CL
   ,EMAIL
   ,EMAIL_CL
   ,EMAIL_2
   ,EMAIL_2_CL
   ,SUBSCRIPTION_TYPE_CD
   ,SECONDARY_USE_SIGN
   ,NAYOSE_KEY
   ,UPDATE_KBN
   ,UPDATE_DATE
   ,CL_END_DT
   ,1 AS SYSTEM_FROM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_USER_CL_AC
UNION ALL
SELECT
    T.APPLICANT_MNG_NO AS USER_NO
   ,T.NIKKEI_MEMBER_NO
   ,CAST(NULL AS TIMESTAMP) AS NIKKEI_ENTRY_DATE
   ,CAST(NULL AS INT) AS NIKKEI_NEW_CREATE_FLG
   ,NULL AS CHARGE_CUST_NO
   ,ADDRESS_CD
   ,CASE WHEN T.ADDRESS_CD IS NOT NULL THEN M1.HON_SHISHA_CD
         ELSE M3.HON_SHISHA_CD
    END AS HON_SHISHA_CD
   ,T.ZIPCODE
   ,T.ZIPCODE_CL
   ,T.PREFECTURE_NM
   ,T.SHIKUTYOUSON_NM
   ,T.TSUSHO_NM
   ,T.CHOME_NM
   ,T.BANTI
   ,T.BUILDING
   ,T.ADDR_CL_ADDR
   ,T.ADDR_CL_PREFEC
   ,T.ADDR_CL_CITY
   ,T.ADDR_CL_TSUSHO
   ,T.ADDR_CL_CHOME
   ,T.ADDR_CL_ADDR1
   ,T.ADDR_CL_ADDR2
   ,T.ADDR_CL_ADDR3
   ,T.ADDR_CL_ADDR_CD
   ,T.NAME
   ,T.NAME_YOMI
   ,NULL AS DEPARTMENT_NM
   ,T.NAME_CL_LAST_NM
   ,T.NAME_CL_FIRST_NM
   ,T.NAME_CL_NM
   ,T.NAME_CL_CORP_NM
   ,T.NAME_CL_DEPT_NM
   ,NULL AS SUBSCRIBER
   ,T.TELNO
   ,T.TELNO_CL
   ,NULL AS FAXNO
   ,NULL AS DAYTIME_CONTACT
   ,NULL AS DAYTIME_CONTACT_CL
   ,T.EMAIL
   ,T.EMAIL_CL
   ,NULL AS EMAIL_2
   ,NULL AS EMAIL_2_CL
   ,CAST(NULL AS INT) AS SUBSCRIPTION_TYPE_CD
   ,CASE WHEN T.SECONDARY_USE_SIGN = TRUE  THEN 1
         WHEN T.SECONDARY_USE_SIGN = FALSE THEN 0
         ELSE NULL
    END AS SECONDARY_USE_SIGN
   ,NULL AS NAYOSE_KEY
   ,CAST(NULL AS INT) AS UPDATE_KBN
   ,T.CREATE_UPDATE_DT_TM AS UPDATE_DATE
   ,T.CL_END_DT
   ,2 AS SYSTEM_FROM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_CL_AC T
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL M1
ON
    SUBSTRING(T.ADDRESS_CD, 1, 2) = M1.PREFECTURE_CD
AND
    SUBSTRING(T.ADDRESS_CD, 3, 3) = M1.SHIKUTYOUSON_CD
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_STORE M2
ON
    T.STORE_CD = M2.STORE_CD
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_AREA M3
ON
    M2.AREA_CD = M3.AREA_CD
UNION ALL
SELECT
    'W' || T.APPLICANT_MNG_NO AS USER_NO
   ,T.NIKKEI_MEMBER_NO
   ,CAST(NULL AS TIMESTAMP) AS NIKKEI_ENTRY_DATE
   ,CAST(NULL AS INT) AS NIKKEI_NEW_CREATE_FLG
   ,NULL AS CHARGE_CUST_NO
   ,ADDRESS_CD
   ,CASE WHEN T.ADDRESS_CD IS NOT NULL THEN M1.HON_SHISHA_CD
         ELSE M3.HON_SHISHA_CD
    END AS HON_SHISHA_CD
   ,T.ZIPCODE
   ,T.ZIPCODE_CL
   ,T.PREFECTURE_NM
   ,T.SHIKUTYOUSON_NM
   ,T.TSUSHO_NM
   ,T.CHOME_NM
   ,T.BANTI
   ,T.BUILDING
   ,T.ADDR_CL_ADDR
   ,T.ADDR_CL_PREFEC
   ,T.ADDR_CL_CITY
   ,T.ADDR_CL_TSUSHO
   ,T.ADDR_CL_CHOME
   ,T.ADDR_CL_ADDR1
   ,T.ADDR_CL_ADDR2
   ,T.ADDR_CL_ADDR3
   ,T.ADDR_CL_ADDR_CD
   ,T.NAME
   ,T.NAME_YOMI
   ,NULL AS DEPARTMENT_NM
   ,T.NAME_CL_LAST_NM
   ,T.NAME_CL_FIRST_NM
   ,T.NAME_CL_NM
   ,T.NAME_CL_CORP_NM
   ,T.NAME_CL_DEPT_NM
   ,NULL AS SUBSCRIBER
   ,T.TELNO
   ,T.TELNO_CL
   ,NULL AS FAXNO
   ,NULL AS DAYTIME_CONTACT
   ,NULL AS DAYTIME_CONTACT_CL
   ,T.EMAIL
   ,T.EMAIL_CL
   ,NULL AS EMAIL_2
   ,NULL AS EMAIL_2_CL
   ,CAST(NULL AS INT) AS SUBSCRIPTION_TYPE_CD
   ,CAST(NULL AS INT) AS SECONDARY_USE_SIGN
   ,NULL AS NAYOSE_KEY
   ,CAST(NULL AS INT) AS UPDATE_KBN
   ,T.CREATE_UPDATE_DT_TM AS UPDATE_DATE
   ,T.CL_END_DT
   ,3 AS SYSTEM_FROM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_MNG_INFO_CL_AC T
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL M1
ON
    SUBSTRING(T.ADDRESS_CD, 1, 2) = M1.PREFECTURE_CD
AND
    SUBSTRING(T.ADDRESS_CD, 3, 3) = M1.SHIKUTYOUSON_CD
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_STORE M2
ON
    T.STORE_CD = M2.STORE_CD
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_HK_AREA M3
ON
    M2.AREA_CD = M3.AREA_CD
;

CREATE TEMP TABLE TEMP_T_HK_ADDITIONAL_INFO_USER_CL_AC
AS
SELECT
    USER_NO
   ,SEX
   ,BIRTHDAY
   ,COMPANY_NM
   ,DEPARTMENT_NM
   ,COMPANY_NM_CL_CORP_NM
   ,DEPARTMENT_NM_CL_DEPT_NM
   ,POST_NM
   ,COLLEGE_NM
   ,COURSE_NM
   ,COURSE_DETAIL_NM
   ,OCCUPATION_NM
   ,OCCUPATION_NM_CL
   ,SECONDARY_READING
   ,SECONDARY_READING_CL
   ,UPDATE_KBN
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
   ,UPDATE_CNT
   ,CL_START_DT
   ,CL_END_DT
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC
UNION ALL
SELECT
    USER_NO
   ,SEX
   ,BIRTHDAY
   ,COMPANY_NM
   ,DEPARTMENT_NM
   ,COMPANY_NM_CL_CORP_NM
   ,DEPARTMENT_NM_CL_DEPT_NM
   ,POST_NM
   ,COLLEGE_NM
   ,COURSE_NM
   ,COURSE_DETAIL_NM
   ,OCCUPATION_NM
   ,OCCUPATION_NM_CL
   ,SECONDARY_READING
   ,SECONDARY_READING_CL
   ,UPDATE_KBN
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
   ,UPDATE_CNT
   ,CL_START_DT
   ,CL_END_DT
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_E_TRIAL_USER_CL_AC
UNION ALL
SELECT
    USER_NO
   ,SEX
   ,BIRTHDAY
   ,COMPANY_NM
   ,DEPARTMENT_NM
   ,COMPANY_NM_CL_CORP_NM
   ,DEPARTMENT_NM_CL_DEPT_NM
   ,POST_NM
   ,COLLEGE_NM
   ,COURSE_NM
   ,COURSE_DETAIL_NM
   ,OCCUPATION_NM
   ,OCCUPATION_NM_CL
   ,SECONDARY_READING
   ,SECONDARY_READING_CL
   ,UPDATE_KBN
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
   ,UPDATE_CNT
   ,CL_START_DT
   ,CL_END_DT
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_PK_USER_CL_AC
;

--販売局リスト背番号管理の利用中フラグ更新(UPDATE)
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
SET
    USE_FLG = TRUE
   ,UPD_PGM_ID = '{{ dag.dag_id }}'
   ,UPD_DT_TM  = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
   (LIST_NO,USER_NO) IN (SELECT LIST_NO,USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
;

UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
SET
    USE_FLG = FALSE
   ,UPD_PGM_ID = '{{ dag.dag_id }}'
   ,UPD_DT_TM  = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
   (LIST_NO,USER_NO) NOT IN (SELECT LIST_NO,USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
;

--販売局リスト全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.D_IMS_HANBAIKYOKU_LIST
;

--販売局リスト背番号マスタ全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
;

--最新の情報で販売局リスト背番号管理の更新(日経ID)
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG HLNM
SET
   EMAIL_CL              = WKAN.EMAIL_CL
  ,ADDR_CL_ADDR          = WKAN.ADDR_CL_ADDR
  ,TELNO_CL              = WKAN.TELNO_CL
  ,NAME_COMPANY_NM_CL_NM = WKAN.NAME_COMPANY_NM_CL_NM
  ,UPD_PGM_ID            = '{{ dag.dag_id }}'
  ,UPD_DT_TM             = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC
    WHERE
      (NIKKEI_MEMBER_NO, USER_NO) IN (SELECT NIKKEI_MEMBER_NO, USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND
      CL_END_DT = '9999-12-31'
  ) WKAN
WHERE
  HLNM.USER_NO          = WKAN.USER_NO
AND
  HLNM.NIKKEI_MEMBER_NO = WKAN.NIKKEI_MEMBER_NO
;

--販売局リスト背番号マスタへ挿入(日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       NIKKEI_MEMBER_NO
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
      NIKKEI_MEMBER_NO
  ) LATEST
ON
  BUSR.NIKKEI_MEMBER_NO  = LATEST.NIKKEI_MEMBER_NO
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  NOT EXISTS (SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '1' AND BUSR.NIKKEI_MEMBER_NO = VALUE2)
;

--日経IDで名寄せされたレコードのうち、販売局リスト背番号管理に存在しない読者番号のレコードを
--販売局リスト背番号管理へ挿入(日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   HLN.LIST_NO
  ,WKBN.USER_NO
  ,WKBN.NIKKEI_MEMBER_NO
  ,WKBN.EMAIL_CL
  ,WKBN.ADDR_CL_ADDR
  ,WKBN.TELNO_CL
  ,WKBN.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC TMP
    WHERE
      (NIKKEI_MEMBER_NO) IN (SELECT NIKKEI_MEMBER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND
      NOT EXISTS (
          SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG MNG
          WHERE TMP.NIKKEI_MEMBER_NO = MNG.NIKKEI_MEMBER_NO AND TMP.USER_NO = MNG.USER_NO
      )
    AND
      CL_END_DT = '9999-12-31'
  ) WKBN
ON
  HLN.USER_NO = WKBN.USER_NO
;

--前回のリスト背番号発番が除外済の場合、前回のリスト背番号設定(日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,CAST(LIST_NO AS BIGINT) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    WHERE
      USE_FLG = TRUE
  ) LATEST
ON
  BUSR.USER_NO  = LATEST.USER_NO
AND
  BUSR.NIKKEI_MEMBER_NO  = LATEST.NIKKEI_MEMBER_NO
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.NIKKEI_MEMBER_NO IN (SELECT VALUE2 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '1' AND VALUE1 = '0')
;

/*******************************************************************************
  #02 リスト背番号発番済名寄せ(メールアドレス)処理(更新分)
*******************************************************************************/
--最新の情報で販売局リスト背番号管理の更新(メールアドレス)
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG  HLNM
SET
   ADDR_CL_ADDR          = WKAM.ADDR_CL_ADDR
  ,TELNO_CL              = WKAM.TELNO_CL
  ,NAME_COMPANY_NM_CL_NM = WKAM.NAME_COMPANY_NM_CL_NM
  ,UPD_PGM_ID            = '{{ dag.dag_id }}'
  ,UPD_DT_TM             = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC
    WHERE
      (EMAIL_CL, USER_NO) IN (SELECT EMAIL_CL, USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND
      (USER_NO) NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
    AND
      CL_END_DT = '9999-12-31'
  ) WKAM
WHERE
  HLNM.USER_NO  = WKAM.USER_NO
AND
  HLNM.EMAIL_CL = WKAM.EMAIL_CL
;

/*******************************************************************************
  #03 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分)「処理#03」
*******************************************************************************/
--販売局リスト背番号マスタへ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       EMAIL_CL
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
      EMAIL_CL
  ) LATEST
ON
  BUSR.EMAIL_CL  = LATEST.EMAIL_CL
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.NIKKEI_MEMBER_NO AND MASTER_TYPE = '2001' AND CODE = '1' AND VALUE1 = '1')
AND
  NOT EXISTS (SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '2' AND BUSR.EMAIL_CL = VALUE2)
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
;

--メールアドレスで名寄せされたレコードのうち、販売局リスト背番号管理に存在しないレコードを
--販売局リスト背番号管理へ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   HLN.LIST_NO
  ,WKBM.USER_NO
  ,WKBM.NIKKEI_MEMBER_NO
  ,WKBM.EMAIL_CL
  ,WKBM.ADDR_CL_ADDR
  ,WKBM.TELNO_CL
  ,WKBM.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC TMP
    WHERE
      (EMAIL_CL) IN (SELECT EMAIL_CL FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND NOT EXISTS (
        SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG MNG
        WHERE TMP.EMAIL_CL = MNG.EMAIL_CL AND TMP.USER_NO = MNG.USER_NO
    )
    AND
      CL_END_DT = '9999-12-31'
  ) WKBM
ON
  HLN.USER_NO = WKBM.USER_NO
;

/*******************************************************************************
  #04 リスト背番号発番済名寄せ(メールアドレス)処理(除外対象挿入分)
*******************************************************************************/
--前回のリスト背番号発番が除外済の場合、前回のリスト背番号設定(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       USER_NO
      ,EMAIL_CL
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    WHERE
      USE_FLG = TRUE
    GROUP BY
      USER_NO
     ,EMAIL_CL
  ) LATEST
ON
  BUSR.USER_NO  = LATEST.USER_NO
AND
  BUSR.EMAIL_CL  = LATEST.EMAIL_CL
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  BUSR.EMAIL_CL IN (SELECT VALUE2 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '2' AND VALUE1 = '0')
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
;

/*******************************************************************************
  #05 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理「処理#05」
*******************************************************************************/
--販売局リスト背番号マスタへ挿入(住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
       ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
  ) LATEST
ON
  BUSR.ADDR_CL_ADDR = LATEST.ADDR_CL_ADDR
AND
  BUSR.TELNO_CL = LATEST.TELNO_CL
AND
  BUSR.NAME_COMPANY_NM_CL_NM = LATEST.NAME_COMPANY_NM_CL_NM
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.NIKKEI_MEMBER_NO AND MASTER_TYPE = '2001' AND CODE = '1' AND VALUE1 = '1')
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.EMAIL_CL AND MASTER_TYPE = '2001' AND CODE = '2' AND VALUE1 = '1')
AND
  NOT EXISTS(SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '3' AND BUSR.ADDR_CL_ADDR = VALUE2 AND BUSR.TELNO_CL = VALUE3 AND BUSR.NAME_COMPANY_NM_CL_NM = VALUE4)
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
AND
  BUSR.EMAIL_CL IS NULL
;

--住所・電話番号・氏名／会社名で名寄せされたレコードのうち、販売局リスト背番号管理に存在しないレコードを
--販売局リスト背番号管理へ挿入(住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   HLN.LIST_NO
  ,WKBA.USER_NO
  ,WKBA.NIKKEI_MEMBER_NO
  ,WKBA.EMAIL_CL
  ,WKBA.ADDR_CL_ADDR
  ,WKBA.TELNO_CL
  ,WKBA.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC TMP
    WHERE
             (ADDR_CL_ADDR, TELNO_CL, NAME_COMPANY_NM_CL_NM) IN
      (SELECT ADDR_CL_ADDR, TELNO_CL, NAME_COMPANY_NM_CL_NM FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND
      NOT EXISTS (
          SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG MNG
          WHERE TMP.ADDR_CL_ADDR = MNG.ADDR_CL_ADDR AND TMP.TELNO_CL = MNG.TELNO_CL AND TMP.NAME_COMPANY_NM_CL_NM = MNG.NAME_COMPANY_NM_CL_NM AND TMP.USER_NO = MNG.USER_NO
      )
    AND
      CL_END_DT = '9999-12-31'
  ) WKBA
ON
  HLN.USER_NO = WKBA.USER_NO
;

/*******************************************************************************
  #06 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理(除外対象挿入分)
*******************************************************************************/
--前回のリスト背番号発番が除外済の場合、前回のリスト背番号設定(住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       USER_NO
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    WHERE
      USE_FLG = TRUE
    GROUP BY
      USER_NO
     ,ADDR_CL_ADDR
     ,TELNO_CL
     ,NAME_COMPANY_NM_CL_NM
  ) LATEST
ON
  BUSR.USER_NO  = LATEST.USER_NO
AND
  BUSR.ADDR_CL_ADDR  = LATEST.ADDR_CL_ADDR
AND
  BUSR.TELNO_CL  = LATEST.TELNO_CL
AND
  BUSR.NAME_COMPANY_NM_CL_NM  = LATEST.NAME_COMPANY_NM_CL_NM
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  (BUSR.ADDR_CL_ADDR, BUSR.TELNO_CL, BUSR.NAME_COMPANY_NM_CL_NM) IN 
    (SELECT VALUE2, VALUE3, VALUE4 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '3' AND VALUE1 = '0')
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
AND
  BUSR.EMAIL_CL IS NULL
;

/*******************************************************************************
  #07 リスト背番号新規発番(日経ID)処理
*******************************************************************************/
--リスト背番号発番一時テーブル(日経ID)
INSERT INTO INDEXING_NIKKEI_ID_TMP
(
   USER_NO
  ,LIST_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
)
SELECT
   BUSR.USER_NO
  ,CAST(DENSE_RANK() OVER (ORDER BY BUSR.NIKKEI_MEMBER_NO NULLS FIRST ) +
        CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
  ,BUSR.NIKKEI_MEMBER_NO
  ,BUSR.EMAIL_CL
  ,BUSR.ADDR_CL_ADDR
  ,BUSR.TELNO_CL
  ,BUSR.NAME_COMPANY_NM_CL_NM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
WHERE
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  BUSR.NIKKEI_MEMBER_NO IS NOT NULL
AND
  BUSR.CL_END_DT = '9999-12-31'
AND
  NOT EXISTS(SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '1' AND VALUE2 = BUSR.NIKKEI_MEMBER_NO)
;

--販売局リスト背番号管理へ挿入(新規日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   INTP.LIST_NO
  ,INTP.USER_NO
  ,INTP.NIKKEI_MEMBER_NO
  ,INTP.EMAIL_CL
  ,INTP.ADDR_CL_ADDR
  ,INTP.TELNO_CL
  ,INTP.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_NIKKEI_ID_TMP INTP
;
--販売局リスト背番号マスタへ挿入(新規日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   INTP.LIST_NO
  ,INTP.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_NIKKEI_ID_TMP INTP
;

/*******************************************************************************
  #08 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分)「処理#03」
*******************************************************************************/
--販売局リスト背番号マスタへ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       EMAIL_CL
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
      EMAIL_CL
  ) LATEST
ON
  BUSR.EMAIL_CL  = LATEST.EMAIL_CL
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.NIKKEI_MEMBER_NO AND MASTER_TYPE = '2001' AND CODE = '1' AND VALUE1 = '1')
AND
  NOT EXISTS (SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '2' AND BUSR.EMAIL_CL = VALUE2)
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
;

--メールアドレスで名寄せされたレコードのうち、販売局リスト背番号管理に存在しないレコードを
--販売局リスト背番号管理へ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   HLN.LIST_NO
  ,WKBM.USER_NO
  ,WKBM.NIKKEI_MEMBER_NO
  ,WKBM.EMAIL_CL
  ,WKBM.ADDR_CL_ADDR
  ,WKBM.TELNO_CL
  ,WKBM.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC TMP
    WHERE
      (EMAIL_CL) IN (SELECT EMAIL_CL FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND NOT EXISTS (
        SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG MNG
        WHERE TMP.EMAIL_CL = MNG.EMAIL_CL AND TMP.USER_NO = MNG.USER_NO
    )
    AND
      CL_END_DT = '9999-12-31'
  ) WKBM
ON
  HLN.USER_NO = WKBM.USER_NO
;

/*******************************************************************************
  #09 リスト背番号新規発番(メールアドレス)処理
*******************************************************************************/
--リスト背番号発番一時テーブル(メールアドレス)
INSERT INTO INDEXING_MAIL_TMP
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
)
SELECT
   CAST(DENSE_RANK() OVER (ORDER BY BUSR.EMAIL_CL NULLS FIRST) +
        CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,BUSR.NIKKEI_MEMBER_NO
  ,BUSR.EMAIL_CL
  ,BUSR.ADDR_CL_ADDR
  ,BUSR.TELNO_CL
  ,BUSR.NAME_COMPANY_NM_CL_NM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
WHERE
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  BUSR.EMAIL_CL IS NOT NULL
AND
  BUSR.CL_END_DT = '9999-12-31'
AND
  NOT EXISTS (SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '2' AND VALUE2 = BUSR.EMAIL_CL)
;

--販売局リスト背番号管理へ挿入(新規メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IMTP.LIST_NO
  ,IMTP.USER_NO
  ,IMTP.NIKKEI_MEMBER_NO
  ,IMTP.EMAIL_CL
  ,IMTP.ADDR_CL_ADDR
  ,IMTP.TELNO_CL
  ,IMTP.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_MAIL_TMP IMTP
;
--販売局リスト背番号マスタへ挿入(新規メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IMTP.LIST_NO
  ,IMTP.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_MAIL_TMP IMTP
;

/*******************************************************************************
  #10 リスト背番号発番済名寄せ(住所・電話番号・氏名／会社名)処理「処理#05」
*******************************************************************************/
--販売局リスト背番号マスタへ挿入(住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
       ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
  ) LATEST
ON
  BUSR.ADDR_CL_ADDR = LATEST.ADDR_CL_ADDR
AND
  BUSR.TELNO_CL = LATEST.TELNO_CL
AND
  BUSR.NAME_COMPANY_NM_CL_NM = LATEST.NAME_COMPANY_NM_CL_NM
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.NIKKEI_MEMBER_NO AND MASTER_TYPE = '2001' AND CODE = '1' AND VALUE1 = '1')
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.EMAIL_CL AND MASTER_TYPE = '2001' AND CODE = '2' AND VALUE1 = '1')
AND
  NOT EXISTS(SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '3' AND BUSR.ADDR_CL_ADDR = VALUE2 AND BUSR.TELNO_CL = VALUE3 AND BUSR.NAME_COMPANY_NM_CL_NM = VALUE4)
AND
  BUSR.NIKKEI_MEMBER_NO IS NULL
AND
  BUSR.EMAIL_CL IS NULL
;

--住所・電話番号・氏名／会社名で名寄せされたレコードのうち、販売局リスト背番号管理に存在しないレコードを
--販売局リスト背番号管理へ挿入(住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   HLN.LIST_NO
  ,WKBA.USER_NO
  ,WKBA.NIKKEI_MEMBER_NO
  ,WKBA.EMAIL_CL
  ,WKBA.ADDR_CL_ADDR
  ,WKBA.TELNO_CL
  ,WKBA.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
INNER JOIN
  (
    SELECT
       USER_NO
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,TELNO_CL
      ,NAME_COMPANY_NM_CL_NM
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC TMP
    WHERE
             (ADDR_CL_ADDR, TELNO_CL, NAME_COMPANY_NM_CL_NM) IN
      (SELECT ADDR_CL_ADDR, TELNO_CL, NAME_COMPANY_NM_CL_NM FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG)
    AND
      NOT EXISTS (
          SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG MNG
          WHERE TMP.ADDR_CL_ADDR = MNG.ADDR_CL_ADDR AND TMP.TELNO_CL = MNG.TELNO_CL AND TMP.NAME_COMPANY_NM_CL_NM = MNG.NAME_COMPANY_NM_CL_NM AND TMP.USER_NO = MNG.USER_NO
      )
    AND
      CL_END_DT = '9999-12-31'
  ) WKBA
ON
  HLN.USER_NO = WKBA.USER_NO
;

/*******************************************************************************
  #11 リスト背番号新規発番(住所・電話番号・氏名／会社名)処理
*******************************************************************************/
--リスト背番号発番一時テーブル作成(住所・電話番号・氏名／会社名)
INSERT INTO INDEXING_ADDR_TMP
(
   USER_NO
  ,LIST_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
)
SELECT
   BUSR.USER_NO
  ,CAST(DENSE_RANK() OVER (ORDER BY BUSR.ADDR_CL_ADDR NULLS FIRST, BUSR.TELNO_CL NULLS FIRST, BUSR.NAME_COMPANY_NM_CL_NM NULLS FIRST) +
        CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
  ,BUSR.NIKKEI_MEMBER_NO
  ,BUSR.EMAIL_CL
  ,BUSR.ADDR_CL_ADDR
  ,BUSR.TELNO_CL
  ,BUSR.NAME_COMPANY_NM_CL_NM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
WHERE
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  BUSR.ADDR_CL_ADDR IS NOT NULL
AND
  BUSR.TELNO_CL IS NOT NULL
AND
  BUSR.NAME_COMPANY_NM_CL_NM IS NOT NULL
AND
  BUSR.CL_END_DT = '9999-12-31'
AND
  NOT EXISTS ( SELECT 1 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE MASTER_TYPE = '2001' AND CODE = '3' AND BUSR.ADDR_CL_ADDR = VALUE2 AND BUSR.TELNO_CL = VALUE3 AND BUSR.NAME_COMPANY_NM_CL_NM = VALUE4)
;

--販売局リスト背番号管理へ挿入(新規住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IATP.LIST_NO
  ,IATP.USER_NO
  ,IATP.NIKKEI_MEMBER_NO
  ,IATP.EMAIL_CL
  ,IATP.ADDR_CL_ADDR
  ,IATP.TELNO_CL
  ,IATP.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_ADDR_TMP IATP
;
--販売局リスト背番号マスタへ挿入(新規住所・電話番号・氏名／会社名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IATP.LIST_NO
  ,IATP.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_ADDR_TMP IATP
;

/*******************************************************************************
  #12 リスト背番号新規発番(その他背番号未済)処理
*******************************************************************************/
--リスト背番号は発番済で名寄せされていないレコードを読者番号による名寄せを行う。
--販売局リスト背番号マスタへ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
  ,BUSR.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
INNER JOIN
  (
    SELECT
       USER_NO
      ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
    GROUP BY
      USER_NO
  ) LATEST
ON
  BUSR.USER_NO  = LATEST.USER_NO
WHERE
  BUSR.CL_END_DT = '9999-12-31'
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.NIKKEI_MEMBER_NO AND MASTER_TYPE = '2001' AND CODE = '1')
AND
  NOT EXISTS (SELECT 'X' FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL WHERE VALUE2 = BUSR.EMAIL_CL AND MASTER_TYPE = '2001' AND CODE = '2')
AND
  NOT EXISTS (
        SELECT
            'X'
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL
        WHERE
            VALUE2 = BUSR.ADDR_CL_ADDR
        AND VALUE3 = BUSR.TELNO_CL
        AND VALUE4 = BUSR.NAME_COMPANY_NM_CL_NM
        AND MASTER_TYPE = '2001'
        AND CODE = '3'
  )
AND
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
;

--リスト背番号発番一時テーブル(その他背番号未済)
INSERT INTO INDEXING_OTHER_TMP
(
   USER_NO
  ,LIST_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
)
SELECT
   BUSR.USER_NO
  ,CAST(DENSE_RANK() OVER (ORDER BY BUSR.USER_NO NULLS FIRST) +
        CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
  ,BUSR.NIKKEI_MEMBER_NO
  ,BUSR.EMAIL_CL
  ,BUSR.ADDR_CL_ADDR
  ,BUSR.TELNO_CL
  ,BUSR.NAME_COMPANY_NM_CL_NM
FROM
  TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
WHERE
  BUSR.USER_NO NOT IN (SELECT USER_NO FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO)
AND
  BUSR.CL_END_DT = '9999-12-31'
;

--販売局リスト背番号管理へ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO_MNG
(
   LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,TELNO_CL
  ,NAME_COMPANY_NM_CL_NM
  ,USE_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IOTP.LIST_NO
  ,IOTP.USER_NO
  ,IOTP.NIKKEI_MEMBER_NO
  ,IOTP.EMAIL_CL
  ,IOTP.ADDR_CL_ADDR
  ,IOTP.TELNO_CL
  ,IOTP.NAME_COMPANY_NM_CL_NM
  ,TRUE
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_OTHER_TMP IOTP
;
--販売局リスト背番号マスタへ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO
(
   LIST_NO
  ,USER_NO
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IOTP.LIST_NO
  ,IOTP.USER_NO
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_OTHER_TMP IOTP
;

/*******************************************************************************
  #13 販売局リスト作成
*******************************************************************************/
--販売局リストへ挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.D_IMS_HANBAIKYOKU_LIST
(
   LIST_ID
  ,LIST_NO
  ,USER_NO
  ,NIKKEI_MEMBER_NO
  ,NIKKEI_ENTRY_DATE
  ,NIKKEI_NEW_CREATE_FLG
  ,CHARGE_CUST_NO
  ,ADDRESS_CD
  ,HON_SHISHA_CD
  ,ZIPCODE
  ,ZIPCODE_CL
  ,PREFECTURE_NM
  ,SHIKUTYOUSON_NM
  ,TSUSHO_NM
  ,CHOME_NM
  ,BANTI
  ,BUILDING
  ,ADDR_CL_ADDR
  ,ADDR_CL_PREFEC
  ,ADDR_CL_CITY
  ,ADDR_CL_TSUSHO
  ,ADDR_CL_CHOME
  ,ADDR_CL_ADDR1
  ,ADDR_CL_ADDR2
  ,ADDR_CL_ADDR3
  ,ADDR_CL_ADDR_CD
  ,NAME_COMPANY_NM
  ,NAME_COMPANY_NM_YOMI
  ,DEPARTMENT_NM
  ,NAME_COMPANY_NM_CL_LAST_NM
  ,NAME_COMPANY_NM_CL_FIRST_NM
  ,NAME_COMPANY_NM_CL_NM
  ,NAME_COMPANY_NM_CL_CORP_NM
  ,NAME_COMPANY_NM_CL_DEPT_NM
  ,SUBSCRIBER
  ,TELNO
  ,TELNO_CL
  ,FAXNO
  ,DAYTIME_CONTACT
  ,DAYTIME_CONTACT_CL
  ,EMAIL
  ,EMAIL_CL
  ,EMAIL_2
  ,EMAIL_2_CL
  ,SUBSCRIPTION_TYPE_CD
  ,SECONDARY_USE_SIGN
  ,NAYOSE_KEY
  ,UPDATE_KBN
  ,SEX
  ,BIRTHDAY
  ,ADD_DEPARTMENT_NM
  ,COMPANY_NM_CL_CORP_NM
  ,POST_NM
  ,COLLEGE_NM
  ,COURSE_NM
  ,COURSE_DETAIL_NM
  ,OCCUPATION_NM
  ,OCCUPATION_NM_CL
  ,SECONDARY_READING
  ,SECONDARY_READING_CL
  ,NK_SUBSCRIPTION_COUNT
  ,NK_TRIAL_COUNT
  ,NK_LATEST_SUBSCRIPTION_DATE
  ,SS_SUBSCRIPTION_COUNT
  ,SS_TRIAL_COUNT
  ,MJ_SUBSCRIPTION_COUNT
  ,MJ_TRIAL_COUNT
  ,VS_SUBSCRIPTION_COUNT
  ,VS_TRIAL_COUNT
  ,E_TRIAL_COUNT
  ,UPDATE_DATE
  ,LATEST_SUBSCRIPTION_NO
  ,LATEST_SUBSCRIPTION_KBN
  ,LATEST_TRIAL_STORE_EXTEND_FLG
  ,LATEST_RECEPTION_CLASS_CD
  ,LATEST_RECEPTION_DATE
  ,LATEST_STORE_CD
  ,LATEST_YUDAI_MUDAI_FLG
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
--リスト背番号最新の読者情報
SELECT
   LIST.LIST_ID
  ,LIST.LIST_NO
  ,LIST.USER_NO
  ,LIST.NIKKEI_MEMBER_NO
  ,LIST.NIKKEI_ENTRY_DATE
  ,LIST.NIKKEI_NEW_CREATE_FLG
  ,LIST.CHARGE_CUST_NO
  ,LIST.ADDRESS_CD
  ,LIST.HON_SHISHA_CD
  ,LIST.ZIPCODE
  ,LIST.ZIPCODE_CL
  ,LIST.PREFECTURE_NM
  ,LIST.SHIKUTYOUSON_NM
  ,LIST.TSUSHO_NM
  ,LIST.CHOME_NM
  ,LIST.BANTI
  ,LIST.BUILDING
  ,LIST.ADDR_CL_ADDR
  ,LIST.ADDR_CL_PREFEC
  ,LIST.ADDR_CL_CITY
  ,LIST.ADDR_CL_TSUSHO
  ,LIST.ADDR_CL_CHOME
  ,LIST.ADDR_CL_ADDR1
  ,LIST.ADDR_CL_ADDR2
  ,LIST.ADDR_CL_ADDR3
  ,LIST.ADDR_CL_ADDR_CD
  ,LIST.NAME_COMPANY_NM
  ,LIST.NAME_COMPANY_NM_YOMI
  ,LIST.DEPARTMENT_NM
  ,LIST.NAME_COMPANY_NM_CL_LAST_NM
  ,LIST.NAME_COMPANY_NM_CL_FIRST_NM
  ,LIST.NAME_COMPANY_NM_CL_NM
  ,LIST.NAME_COMPANY_NM_CL_CORP_NM
  ,LIST.NAME_COMPANY_NM_CL_DEPT_NM
  ,LIST.SUBSCRIBER
  ,LIST.TELNO
  ,LIST.TELNO_CL
  ,LIST.FAXNO
  ,LIST.DAYTIME_CONTACT
  ,LIST.DAYTIME_CONTACT_CL
  ,LIST.EMAIL
  ,LIST.EMAIL_CL
  ,LIST.EMAIL_2
  ,LIST.EMAIL_2_CL
  ,LIST.SUBSCRIPTION_TYPE_CD
  ,LIST.SECONDARY_USE_SIGN
  ,LIST.NAYOSE_KEY
  ,LIST.UPDATE_KBN
  ,LIST.SEX
  ,LIST.BIRTHDAY
  ,LIST.ADD_DEPARTMENT_NM
  ,LIST.COMPANY_NM_CL_CORP_NM
  ,LIST.POST_NM
  ,LIST.COLLEGE_NM
  ,LIST.COURSE_NM
  ,LIST.COURSE_DETAIL_NM
  ,LIST.OCCUPATION_NM
  ,LIST.OCCUPATION_NM_CL
  ,LIST.SECONDARY_READING
  ,LIST.SECONDARY_READING_CL
  ,LIST.NK_SUBSCRIPTION_COUNT
  ,LIST.NK_TRIAL_COUNT
  ,LIST.NK_LATEST_SUBSCRIPTION_DATE
  ,LIST.SS_SUBSCRIPTION_COUNT
  ,LIST.SS_TRIAL_COUNT
  ,LIST.MJ_SUBSCRIPTION_COUNT
  ,LIST.MJ_TRIAL_COUNT
  ,LIST.VS_SUBSCRIPTION_COUNT
  ,LIST.VS_TRIAL_COUNT
  ,LIST.E_TRIAL_COUNT
  ,LIST.UPDATE_DATE
  ,LIST.SUBSCRIPTION_NO
  ,LIST.SUBSCRIPTION_KBN
  ,LIST.TRIAL_STORE_EXTEND_FLG
  ,LIST.RECEPTION_CLASS_CD
  ,LIST.RECEPTION_DATE
  ,LIST.STORE_CD
  ,LIST.YUDAI_MUDAI_FLG
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  (
    SELECT
       {{ params.list_id }} AS LIST_ID
      ,HLN.LIST_NO
      ,HLN.USER_NO
      ,LIST_LATEST_NKID.NIKKEI_MEMBER_NO
       -- 日経ID_入会日
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN BUSR.NIKKEI_ENTRY_DATE
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.NIKKEI_ENTRY_DATE
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.NIKKEI_ENTRY_DATE
            ELSE NULL
       END AS NIKKEI_ENTRY_DATE
       -- 日経ID_新規登録フラグ
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN BUSR.NIKKEI_NEW_CREATE_FLG
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.NIKKEI_NEW_CREATE_FLG
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.NIKKEI_NEW_CREATE_FLG
            ELSE NULL
       END AS NIKKEI_NEW_CREATE_FLG
      ,BUSR.CHARGE_CUST_NO
      ,BUSR.ADDRESS_CD
      ,BUSR.HON_SHISHA_CD
      ,BUSR.ZIPCODE
      ,BUSR.ZIPCODE_CL
      ,BUSR.PREFECTURE_NM
      ,BUSR.SHIKUTYOUSON_NM
      ,BUSR.TSUSHO_NM
      ,BUSR.CHOME_NM
      ,BUSR.BANTI
      ,BUSR.BUILDING
      ,BUSR.ADDR_CL_ADDR
      ,BUSR.ADDR_CL_PREFEC
      ,BUSR.ADDR_CL_CITY
      ,BUSR.ADDR_CL_TSUSHO
      ,BUSR.ADDR_CL_CHOME
      ,BUSR.ADDR_CL_ADDR1
      ,BUSR.ADDR_CL_ADDR2
      ,BUSR.ADDR_CL_ADDR3
      ,BUSR.ADDR_CL_ADDR_CD
      ,BUSR.NAME_COMPANY_NM
      ,BUSR.NAME_COMPANY_NM_YOMI
      ,SUBSTRING(BUSR.DEPARTMENT_NM, 1, 80) AS DEPARTMENT_NM
      ,BUSR.NAME_COMPANY_NM_CL_LAST_NM
      ,BUSR.NAME_COMPANY_NM_CL_FIRST_NM
      ,BUSR.NAME_COMPANY_NM_CL_NM
      ,BUSR.NAME_COMPANY_NM_CL_CORP_NM
      ,BUSR.NAME_COMPANY_NM_CL_DEPT_NM
      ,BUSR.SUBSCRIBER
      ,BUSR.TELNO
      ,BUSR.TELNO_CL
       -- ＦＡＸ番号
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN BUSR.FAXNO
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.FAXNO
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.FAXNO
            ELSE NULL
       END AS FAXNO
       -- 日中連絡先
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN BUSR.DAYTIME_CONTACT
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.DAYTIME_CONTACT
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.DAYTIME_CONTACT
            ELSE NULL
       END AS DAYTIME_CONTACT
       -- 日中連絡先_CL電話番号
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN BUSR.DAYTIME_CONTACT_CL
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.DAYTIME_CONTACT_CL
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.DAYTIME_CONTACT_CL
            ELSE NULL
       END AS DAYTIME_CONTACT_CL
      ,BUSR.EMAIL
      ,BUSR.EMAIL_CL
      ,BUSR.EMAIL_2
      ,BUSR.EMAIL_2_CL
      ,BUSR.SUBSCRIPTION_TYPE_CD
      ,HLNPROP.SECONDARY_USE_SIGN
      ,BUSR.NAYOSE_KEY
      ,BUSR.UPDATE_KBN
       -- 性別
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN AUSR.SEX
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.SEX
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.SEX
            ELSE NULL
       END AS SEX
       -- 生年月日
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN AUSR.BIRTHDAY
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.BIRTHDAY
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.BIRTHDAY
            ELSE NULL
       END AS BIRTHDAY
      ,AUSR.DEPARTMENT_NM AS ADD_DEPARTMENT_NM
      ,AUSR.COMPANY_NM_CL_CORP_NM
      ,AUSR.POST_NM
      ,AUSR.COLLEGE_NM
      ,AUSR.COURSE_NM
      ,AUSR.COURSE_DETAIL_NM
       -- 職業名
      ,LATEST_SI.OCCUPATION_NM
       -- 職業名_CL辞書利用
      ,LATEST_SI.OCCUPATION_NM_CL
       -- 併読紙
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN AUSR.SECONDARY_READING
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.SECONDARY_READING
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.SECONDARY_READING
            ELSE NULL
       END AS SECONDARY_READING
       -- 併読紙_CL辞書利用
      ,CASE WHEN BUSR.SYSTEM_FROM = 1 THEN AUSR.SECONDARY_READING_CL
            WHEN BUSR.SYSTEM_FROM = 2 THEN ABI.SECONDARY_READING_CL
            WHEN BUSR.SYSTEM_FROM = 3 THEN ABIW.SECONDARY_READING_CL
            ELSE NULL
       END AS SECONDARY_READING_CL
      ,SUBCNT.NK_SUBSCRIPTION_COUNT         -- 本紙購読回数
      ,TRICNT.NK_TRIAL_COUNT                -- 本紙試読回数
      ,SUBCNT.NK_LATEST_SUBSCRIPTION_DATE   -- 本紙直近購読日付
      ,SUBCNT.SS_SUBSCRIPTION_COUNT         -- SS購読回数
      ,TRICNT.SS_TRIAL_COUNT                -- SS試読回数
      ,SUBCNT.MJ_SUBSCRIPTION_COUNT         -- MJ購読回数
      ,TRICNT.MJ_TRIAL_COUNT                -- MJ試読回数
      ,SUBCNT.VS_SUBSCRIPTION_COUNT         -- VS購読回数
      ,TRICNT.VS_TRIAL_COUNT                -- VS試読回数
      ,ETRICNT.E_TRIAL_COUNT                -- 電試回数
      ,BUSR.UPDATE_DATE
      ,LATEST_SI.SUBSCRIPTION_NO            -- 最新_購読・試読・移転・継続番号
      ,LATEST_SI.SUBSCRIPTION_KBN           -- 最新_購読・試読・移転・継続区分
      ,LATEST_SI.TRIAL_STORE_EXTEND_FLG     -- 最新_試読販売店拡張フラグ
      ,LATEST_SI.RECEPTION_CLASS_CD         -- 最新_受付種別コード
      ,LATEST_SI.RECEPTION_DATE             -- 最新_受付日
      ,LATEST_SI.STORE_CD                   -- 最新_販売店コード
      ,LATEST_SI.YUDAI_MUDAI_FLG            -- 最新_有代無代フラグ
      ,ROW_NUMBER() OVER (PARTITION BY HLN.LIST_NO
                          ORDER BY LATEST_INFO.RECEPTION_DATE DESC NULLS LAST, LATEST_INFO.CREATE_UPDATE_DATE DESC NULLS LAST,
                                   BUSR.UPDATE_DATE DESC NULLS LAST, HLN.USER_NO DESC NULLS LAST) AS RECEPTION_ORDER
    FROM
      TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
    INNER JOIN
    -- 販売局リスト背番号マスタ
      {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
    ON
      BUSR.USER_NO   = HLN.USER_NO
    LEFT JOIN
    -- 読者追加情報
      (
        SELECT
           USER_NO
          ,SEX
          ,BIRTHDAY
          ,DEPARTMENT_NM
          ,COMPANY_NM_CL_CORP_NM
          ,POST_NM
          ,SUBSTRING(COLLEGE_NM, 1, 40) AS COLLEGE_NM
          ,SUBSTRING(COURSE_NM, 1, 40) AS COURSE_NM
          ,COURSE_DETAIL_NM
          ,SUBSTRING(SECONDARY_READING, 1, 255) AS SECONDARY_READING
          ,SECONDARY_READING_CL
          ,CL_END_DT
        FROM
          TEMP_T_HK_ADDITIONAL_INFO_USER_CL_AC
      ) AUSR
    ON
      BUSR.USER_NO   = AUSR.USER_NO
    AND
      AUSR.CL_END_DT = '9999-12-31'
    LEFT JOIN
    --【A1: 集約処理（最新の応募者基本情報）】
      (
        SELECT
           ABI.APPLICANT_MNG_NO
          ,ABI.NIKKEI_ENTRY_DATE
          ,ABI.NIKKEI_NEW_CREATE_FLG
          ,ABI.FAXNO
          ,ABI.DAYTIME_CONTACT
          ,ABI.DAYTIME_CONTACT_CL
          ,ABI.SEX
          ,ABI.BIRTHDAY
          ,ABI.SECONDARY_READING
          ,ABI.SECONDARY_READING_CL
        FROM
          (
            SELECT
              APPLICANT_MNG_NO
             ,TO_TIMESTAMP(NIKKEI_ENTRY_DATE, 'YYYYMMDDHH24MISSUS') AS NIKKEI_ENTRY_DATE
             ,CAST(NIKKEI_NEW_CREATE_FLG AS SMALLINT) AS NIKKEI_NEW_CREATE_FLG
             ,FAXNO
             ,DAYTIME_CONTACT
             ,DAYTIME_CONTACT_CL
             ,SEX
             ,TO_TIMESTAMP(BIRTHDAY, 'YYYYMMDD') AS BIRTHDAY
             ,SECONDARY_READING
             ,SECONDARY_READING_CL
             ,ROW_NUMBER() OVER (PARTITION BY APPLICANT_MNG_NO
                                 ORDER BY RECEPTION_DT_TM DESC NULLS LAST, FORM_ID DESC NULLS LAST, APPLICANT_ID DESC NULLS LAST) AS RECEPTION_ORDER
           FROM
             {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_BASIC_INFO_CL_AC
           WHERE
             CL_END_DT  = '9999-12-31'
           ) ABI
         WHERE
           RECEPTION_ORDER = 1
       ) ABI
    ON
      BUSR.USER_NO = ABI.APPLICANT_MNG_NO
    LEFT JOIN
    --【A9: 集約処理（最新の応募者基本情報(DKP2)）】
      (
        SELECT
           ABIW.APPLICANT_MNG_NO
          ,ABIW.NIKKEI_ENTRY_DATE
          ,ABIW.NIKKEI_NEW_CREATE_FLG
          ,ABIW.FAXNO
          ,ABIW.DAYTIME_CONTACT
          ,ABIW.DAYTIME_CONTACT_CL
          ,ABIW.SEX
          ,ABIW.BIRTHDAY
          ,ABIW.SECONDARY_READING
          ,ABIW.SECONDARY_READING_CL
        FROM
          (
            SELECT
              'W' || APPLICANT_MNG_NO AS APPLICANT_MNG_NO
             ,TO_TIMESTAMP(NIKKEI_ENTRY_DATE, 'YYYYMMDDHH24MISSUS') AS NIKKEI_ENTRY_DATE
             ,CAST(NIKKEI_NEW_CREATE_FLG AS SMALLINT) AS NIKKEI_NEW_CREATE_FLG
             ,FAXNO
             ,DAYTIME_CONTACT
             ,DAYTIME_CONTACT_CL
             ,SEX
             ,TO_TIMESTAMP(BIRTHDAY, 'YYYYMMDD') AS BIRTHDAY
             ,SECONDARY_READING
             ,SECONDARY_READING_CL
             ,ROW_NUMBER() OVER (PARTITION BY APPLICANT_MNG_NO
                                 ORDER BY RECEPTION_DT_TM DESC NULLS LAST, FORM_ID DESC NULLS LAST, APPLICANT_ID DESC NULLS LAST) AS RECEPTION_ORDER
           FROM
             {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO_CL_AC
           WHERE
             CL_END_DT  = '9999-12-31'
           ) ABIW
         WHERE
           RECEPTION_ORDER = 1
       ) ABIW
    ON
      BUSR.USER_NO = ABIW.APPLICANT_MNG_NO
    LEFT JOIN
    --【A2: 集約処理（読者番号／応募者管理番号単位の最新情報）】
      (
        SELECT
           TMP.USER_NO
          ,TMP.RECEPTION_DATE
          ,TMP.CREATE_UPDATE_DATE
        FROM
          (
            SELECT
               BUSR.USER_NO
              ,BINFO.RECEPTION_DATE
              ,BINFO.CREATE_UPDATE_DATE
              ,ROW_NUMBER() OVER (PARTITION BY BUSR.USER_NO
                                  ORDER BY BINFO.RECEPTION_DATE DESC NULLS LAST, BINFO.CREATE_UPDATE_DATE DESC NULLS LAST) AS RECEPTION_ORDER
            FROM
              TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
            INNER JOIN
              {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
            ON
              BUSR.USER_NO = HLN.USER_NO
            LEFT JOIN
              (
                -- 購読申込基本情報蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 試読申込基本情報蓄積、試読申込追加情報蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 移転申込基本情報蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 継続申込基本情報蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_CONTINUE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 電試申込基本情報蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_E_TRIAL_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 購読申込基本情報（紙課金システム連携用）蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 移転申込基本情報（紙課金システム連携用）蓄積
                SELECT
                   USER_NO
                  ,RECEPTION_DATE
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_MOVE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 応募者管理情報クレンジング蓄積
                SELECT
                   APPLICANT_MNG_NO     AS USER_NO
                  ,CREATE_UPDATE_DT_TM  AS RECEPTION_DATE
                  ,CREATE_UPDATE_DT_TM  AS CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_CL_AC
                WHERE
                  CL_END_DT  = '9999-12-31'
                UNION ALL
                -- 応募者管理情報(DKP2)クレンジング蓄積
                SELECT
                   'W' || APPLICANT_MNG_NO     AS USER_NO
                  ,CREATE_UPDATE_DT_TM         AS RECEPTION_DATE
                  ,CREATE_UPDATE_DT_TM         AS CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_MNG_INFO_CL_AC
                WHERE
                  CL_END_DT  = '9999-12-31'
              ) BINFO
            ON
              BUSR.USER_NO    = BINFO.USER_NO
            WHERE
              BUSR.CL_END_DT  = '9999-12-31'
            AND
              NVL(BUSR.UPDATE_KBN, 0) <> 3
          ) TMP
        WHERE
          TMP.RECEPTION_ORDER = 1
      ) LATEST_INFO
    ON
      HLN.USER_NO = LATEST_INFO.USER_NO
    LEFT JOIN
    --【A3: 集約処理（最新申込情報）】
      (
        SELECT
           TMP.LIST_NO
          ,TMP.SUBSCRIPTION_NO
          ,TMP.SUBSCRIPTION_KBN
          -- 試読申込が最新で販売店拡張結果が1:拡張完了の場合、TRUE、それ以外、FALSE
          ,CASE
             WHEN (TMP.SUBSCRIPTION_KBN = 2 AND TMP.STORE_EXTEND_RESULT = 1)
               OR (TMP.SUBSCRIPTION_KBN = 5 AND TMP.STORE_EXTEND_RESULT = 1)
             THEN TRUE
             ELSE FALSE
           END AS TRIAL_STORE_EXTEND_FLG
          ,TMP.RECEPTION_CLASS_CD
          ,TMP.RECEPTION_DATE
          ,TMP.STORE_CD
          ,TMP.YUDAI_MUDAI_FLG
          ,TMP.OCCUPATION_NM
          ,TMP.OCCUPATION_NM_CL
          ,TMP.RECEPTION_ORDER
        FROM
          (
            SELECT
               HLN.LIST_NO
              ,BINFO.SUBSCRIPTION_NO
              ,BINFO.SUBSCRIPTION_KBN
              ,BINFO.STORE_EXTEND_RESULT
              ,BINFO.RECEPTION_CLASS_CD
              ,BINFO.RECEPTION_DATE
              ,BINFO.STORE_CD
              ,BINFO.YUDAI_MUDAI_FLG
              ,AUSR.OCCUPATION_NM
              ,AUSR.OCCUPATION_NM_CL
              ,ROW_NUMBER() OVER (PARTITION BY HLN.LIST_NO
                                  ORDER BY BINFO.RECEPTION_DATE DESC NULLS LAST, BINFO.CREATE_UPDATE_DATE DESC NULLS LAST,
                                           BUSR.UPDATE_DATE DESC NULLS LAST, HLN.USER_NO DESC NULLS LAST) AS RECEPTION_ORDER
            FROM
              TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
            INNER JOIN
              {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
            ON
              BUSR.USER_NO = HLN.USER_NO
            LEFT JOIN
              (
                SELECT
                   USER_NO
                  ,SUBSTRING(OCCUPATION_NM, 1, 40) AS OCCUPATION_NM
                  ,OCCUPATION_NM_CL
                  ,CL_END_DT
                FROM
                  TEMP_T_HK_ADDITIONAL_INFO_USER_CL_AC
              ) AUSR
            ON
              BUSR.USER_NO = AUSR.USER_NO
            AND
              AUSR.CL_END_DT = '9999-12-31'
            LEFT JOIN
              (
                -- 購読申込基本情報蓄積
                SELECT
                   USER_NO
                  ,SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                  ,1               AS SUBSCRIPTION_KBN
                  ,CAST(NULL AS INT) AS STORE_EXTEND_RESULT
                  ,RECEPTION_CLASS_CD
                  ,RECEPTION_DATE
                  ,STORE_CD
                  ,YUDAI_MUDAI_FLG
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 試読申込基本情報蓄積、試読申込追加情報蓄積
                SELECT
                   BITS.USER_NO
                  ,BITS.TRIAL_NO   AS SUBSCRIPTION_NO
                  ,2               AS SUBSCRIPTION_KBN
                  ,AITS.STORE_EXTEND_RESULT
                  ,BITS.RECEPTION_CLASS_CD
                  ,BITS.RECEPTION_DATE
                  ,BITS.STORE_CD
                  ,BITS.YUDAI_MUDAI_FLG
                  ,BITS.CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION_AC BITS
                INNER JOIN
                  {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_TRIAL_SUBSCRIPTION_AC AITS
                ON
                  BITS.TRIAL_NO = AITS.TRIAL_NO
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 移転申込基本情報蓄積
                SELECT
                   USER_NO
                  ,MOVE_NO         AS SUBSCRIPTION_NO
                  ,3               AS SUBSCRIPTION_KBN
                  ,CAST(NULL AS INT) AS STORE_EXTEND_RESULT
                  ,RECEPTION_CLASS_CD
                  ,RECEPTION_DATE
                  ,NEW_STORE_CD    AS STORE_CD
                  ,CAST( NULL AS BOOLEAN ) AS YUDAI_MUDAI_FLG
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 継続申込基本情報蓄積
                SELECT
                   USER_NO
                  ,CONTINUE_NO     AS SUBSCRIPTION_NO
                  ,4               AS SUBSCRIPTION_KBN
                  ,CAST(NULL AS INT) AS STORE_EXTEND_RESULT
                  ,RECEPTION_CLASS_CD
                  ,RECEPTION_DATE
                  ,STORE_CD
                  ,YUDAI_MUDAI_FLG
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_CONTINUE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 電試申込基本情報蓄積
                SELECT
                   USER_NO
                  ,BIETS.SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                  ,5                     AS SUBSCRIPTION_KBN
                  ,AIETS.STORE_EXTEND_RESULT
                  ,BIETS.RECEPTION_CLASS_CD
                  ,BIETS.RECEPTION_DATE
                  ,BIETS.STORE_CD
                  ,BIETS.YUDAI_MUDAI_FLG
                  ,BIETS.CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_E_TRIAL_SUBSCRIPTION_AC BIETS
                INNER JOIN
                  {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_E_TRIAL_SUBSCRIPTION_AC AIETS
                ON
                  BIETS.SUBSCRIPTION_NO = AIETS.SUBSCRIPTION_NO
                WHERE
                  BIETS.UPDATE_KBN <> 3
                UNION ALL
                -- 購読申込基本情報（紙課金システム連携用）蓄積
                SELECT
                   USER_NO
                  ,SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                  ,6               AS SUBSCRIPTION_KBN
                  ,CAST(NULL AS INT) AS STORE_EXTEND_RESULT
                  ,RECEPTION_CLASS_CD
                  ,RECEPTION_DATE
                  ,STORE_CD
                  ,YUDAI_MUDAI_FLG
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
                UNION ALL
                -- 移転申込基本情報（紙課金システム連携用）蓄積
                SELECT
                   USER_NO
                  ,MOVE_NO         AS SUBSCRIPTION_NO
                  ,7               AS SUBSCRIPTION_KBN
                  ,CAST(NULL AS INT) AS STORE_EXTEND_RESULT
                  ,RECEPTION_CLASS_CD
                  ,RECEPTION_DATE
                  ,NEW_STORE_CD    AS STORE_CD
                  ,CAST( NULL AS BOOLEAN ) AS YUDAI_MUDAI_FLG
                  ,CREATE_UPDATE_DATE
                FROM
                  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_MOVE_SUBSCRIPTION_AC
                WHERE
                  UPDATE_KBN <> 3
              ) BINFO
            ON
              BUSR.USER_NO    = BINFO.USER_NO
            WHERE
              BUSR.CL_END_DT  = '9999-12-31'
            AND
              NVL(BUSR.UPDATE_KBN, 0) <> 3
            AND
              BUSR.SYSTEM_FROM = 1
          ) TMP
        WHERE
          TMP.RECEPTION_ORDER = 1
      ) LATEST_SI
    ON
      HLN.LIST_NO = LATEST_SI.LIST_NO
    LEFT JOIN
    --【A4: 集計処理（購読申込回数）】
      (
        SELECT 
           GRP_SUBCNT.LIST_NO
          ,MAX(GRP_SUBCNT.NK_SUBSCRIPTION_COUNT)       AS NK_SUBSCRIPTION_COUNT
          ,MAX(GRP_SUBCNT.SS_SUBSCRIPTION_COUNT)       AS SS_SUBSCRIPTION_COUNT
          ,MAX(GRP_SUBCNT.MJ_SUBSCRIPTION_COUNT)       AS MJ_SUBSCRIPTION_COUNT
          ,MAX(GRP_SUBCNT.VS_SUBSCRIPTION_COUNT)       AS VS_SUBSCRIPTION_COUNT
          ,MAX(GRP_SUBCNT.NK_LATEST_SUBSCRIPTION_DATE) AS NK_LATEST_SUBSCRIPTION_DATE
        FROM 
          (
             SELECT 
                HLN.LIST_NO
               ,CASE
                  WHEN TMP.BAITAI_CD = '10' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS NK_SUBSCRIPTION_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '30' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS SS_SUBSCRIPTION_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '40' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS MJ_SUBSCRIPTION_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '50' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS VS_SUBSCRIPTION_COUNT
               ,MAX(
                     CASE
                       WHEN TMP.BAITAI_CD = '10' THEN TMP.RECEPTION_DATE
                       ELSE NULL
                     END
                   ) AS NK_LATEST_SUBSCRIPTION_DATE
             FROM
               {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
             INNER JOIN
               (
                 SELECT
                    BINFO.USER_NO         AS USER_NO
                   ,BINFO.SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                   ,CASE
                      WHEN SB.BAITAI_CD = '20' THEN '10'
                      ELSE SB.BAITAI_CD
                    END AS BAITAI_CD
                   ,MAX(BINFO.RECEPTION_DATE) AS RECEPTION_DATE
                 FROM
                 (
                   -- 購読申込基本情報蓄積
                   SELECT
                      BIS.USER_NO         AS USER_NO
                     ,BIS.SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                     ,BIS.RECEPTION_DATE  AS RECEPTION_DATE
                   FROM
                     {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_SUBSCRIPTION_AC BIS
                   WHERE
                     BIS.UPDATE_KBN <> 3
                   UNION ALL
                   -- 試読申込基本情報蓄積、試読申込追加情報蓄積
                   SELECT
                      BITS.USER_NO           AS USER_NO
                     ,BITS.TRIAL_NO          AS SUBSCRIPTION_NO
                     ,AITS.STORE_REPORT_DATE AS RECEPTION_DATE
                   FROM
                     {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION_AC BITS
                   INNER JOIN
                     {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_TRIAL_SUBSCRIPTION_AC AITS
                   ON
                     BITS.TRIAL_NO = AITS.TRIAL_NO
                   -- 販売店拡張結果が1:拡張完了の場合対象
                   WHERE
                     AITS.STORE_EXTEND_RESULT = 1
                   AND
                     BITS.UPDATE_KBN <> 3
                   UNION ALL
                   -- 購読申込基本情報（紙課金システム連携用）蓄積
                   SELECT
                      BIPKS.USER_NO         AS USER_NO
                     ,BIPKS.SUBSCRIPTION_NO AS SUBSCRIPTION_NO
                     ,BIPKS.RECEPTION_DATE  AS RECEPTION_DATE
                   FROM
                     {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION_AC BIPKS
                   WHERE
                     BIPKS.UPDATE_KBN <> 3
                 ) BINFO
                 INNER JOIN
                 (
                   --申込媒体蓄積
                   SELECT
                      SUBSCRIPTION_NO
                     ,BAITAI_CD
                   FROM
                     {{ var.value.redshift_ims_schema_name }}.M_HK_SUBSCRIPTION_BAITAI_AC
                   UNION ALL
                   --申込媒体（紙課金システム連携用）蓄積
                   SELECT
                      SUBSCRIPTION_NO
                     ,BAITAI_CD
                   FROM
                     {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI_AC
                 ) SB
                 ON
                   BINFO.SUBSCRIPTION_NO = SB.SUBSCRIPTION_NO
                 GROUP BY
                    BINFO.USER_NO
                   ,BINFO.SUBSCRIPTION_NO
                   ,CASE
                      WHEN SB.BAITAI_CD = '20' THEN '10'
                      ELSE SB.BAITAI_CD
                    END
               ) TMP
             ON
               HLN.USER_NO = TMP.USER_NO
             WHERE
               HLN.USER_NO IN (
                   SELECT USER_NO FROM TEMP_T_HK_BASIC_INFO_USER_CL_AC 
                                  WHERE CL_END_DT = '9999-12-31' AND NVL(UPDATE_KBN, 0) <> 3
               )
             GROUP BY
                HLN.LIST_NO
               ,TMP.BAITAI_CD
          ) GRP_SUBCNT
        GROUP BY
          GRP_SUBCNT.LIST_NO
      ) SUBCNT
    ON
      HLN.LIST_NO = SUBCNT.LIST_NO
    LEFT JOIN
    --【A5: 集計処理（試読申込回数）】
      (
        SELECT 
           GRP_TRICNT.LIST_NO
          ,MAX(GRP_TRICNT.NK_TRIAL_COUNT) AS NK_TRIAL_COUNT
          ,MAX(GRP_TRICNT.SS_TRIAL_COUNT) AS SS_TRIAL_COUNT
          ,MAX(GRP_TRICNT.MJ_TRIAL_COUNT) AS MJ_TRIAL_COUNT
          ,MAX(GRP_TRICNT.VS_TRIAL_COUNT) AS VS_TRIAL_COUNT
        FROM 
          (
             SELECT 
                HLN.LIST_NO
               ,CASE
                  WHEN TMP.BAITAI_CD = '10' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS NK_TRIAL_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '30' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS SS_TRIAL_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '40' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS MJ_TRIAL_COUNT
               ,CASE
                  WHEN TMP.BAITAI_CD = '50' THEN COUNT(TMP.BAITAI_CD)
                  ELSE 0
                END AS VS_TRIAL_COUNT
             FROM
               {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
             INNER JOIN
               (
                 SELECT
                    BITS.USER_NO
                   ,BITS.TRIAL_NO
                   ,CASE
                      WHEN SB.BAITAI_CD = '20' THEN '10'
                      ELSE SB.BAITAI_CD
                    END AS BAITAI_CD
                   ,MAX(BITS.RECEPTION_DATE) AS RECEPTION_DATE
                 FROM
                   {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION_AC BITS
                 INNER JOIN
                   {{ var.value.redshift_ims_schema_name }}.M_HK_SUBSCRIPTION_BAITAI_AC SB
                 ON
                   BITS.TRIAL_NO = SB.SUBSCRIPTION_NO
                 WHERE
                   BITS.UPDATE_KBN <> 3
                 GROUP BY
                    BITS.USER_NO
                   ,BITS.TRIAL_NO
                   ,CASE
                      WHEN SB.BAITAI_CD = '20' THEN '10'
                      ELSE SB.BAITAI_CD
                    END
               ) TMP
             ON
               HLN.USER_NO = TMP.USER_NO
             WHERE
               HLN.USER_NO IN (
                   SELECT USER_NO FROM TEMP_T_HK_BASIC_INFO_USER_CL_AC 
                                  WHERE CL_END_DT = '9999-12-31' AND NVL(UPDATE_KBN, 0) <> 3
               )
             GROUP BY
                HLN.LIST_NO
               ,TMP.BAITAI_CD
          ) GRP_TRICNT
        GROUP BY
          GRP_TRICNT.LIST_NO
      ) TRICNT
    ON
      HLN.LIST_NO = TRICNT.LIST_NO
    LEFT JOIN
    --【A6: 集計処理（電試申込回数）】
      (
        SELECT
          HLN.LIST_NO
         ,COUNT(*) AS E_TRIAL_COUNT
        FROM
          {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
        INNER JOIN
          {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_E_TRIAL_SUBSCRIPTION_AC BIETS
        ON
          HLN.USER_NO = BIETS.USER_NO
        AND
          BIETS.UPDATE_KBN <> 3
        WHERE
          HLN.USER_NO IN (
              SELECT USER_NO FROM TEMP_T_HK_BASIC_INFO_USER_CL_AC 
                             WHERE CL_END_DT = '9999-12-31' AND NVL(UPDATE_KBN, 0) <> 3
          )
        GROUP BY
          HLN.LIST_NO
      ) ETRICNT
    ON
      HLN.LIST_NO = ETRICNT.LIST_NO
    LEFT JOIN
    --【A7: 集約処理（リスト背番号単位の属性）】
      (
        SELECT
          HLNPROP.LIST_NO
         ,CASE WHEN (HLNPROP.SECONDARY_USE_SIGN_0 = 1 OR HLNPROP.SECONDARY_USE_SIGN_1 = 0) THEN 0
               WHEN HLNPROP.SECONDARY_USE_SIGN_1 = 1 THEN 1 
               ELSE 0
          END AS SECONDARY_USE_SIGN
        FROM
          (
             SELECT 
                HLN.LIST_NO
               ,MAX(CASE WHEN BUSR.SECONDARY_USE_SIGN = 0 THEN 1 ELSE 0 END) AS SECONDARY_USE_SIGN_0
               ,MAX(CASE WHEN BUSR.SECONDARY_USE_SIGN = 1 THEN 1 ELSE 0 END) AS SECONDARY_USE_SIGN_1
             FROM
               TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
             INNER JOIN
               {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
             ON
               BUSR.USER_NO = HLN.USER_NO
             WHERE
               BUSR.CL_END_DT = '9999-12-31'
             AND
               NVL(BUSR.UPDATE_KBN, 0) <> 3
             GROUP BY
               HLN.LIST_NO
          ) HLNPROP
      ) HLNPROP
    ON
      HLN.LIST_NO = HLNPROP.LIST_NO
    LEFT JOIN
    --【リスト背番号単位の直近の日経ID情報】
      (
        SELECT
           HLN.LIST_NO
          ,MAX(BUSR.NIKKEI_MEMBER_NO) AS NIKKEI_MEMBER_NO
        FROM
          TEMP_T_HK_BASIC_INFO_USER_CL_AC BUSR
        INNER JOIN
          {{ var.value.redshift_ims_schema_name }}.M_IMS_HANBAIKYOKU_LIST_NO HLN
        ON
          BUSR.USER_NO = HLN.USER_NO
        WHERE
          BUSR.CL_END_DT  = '9999-12-31'
        AND
          NVL(BUSR.UPDATE_KBN, 0) <> 3
        AND
          BUSR.NIKKEI_MEMBER_NO IS NOT NULL
        GROUP BY
          HLN.LIST_NO
      ) LIST_LATEST_NKID
    ON
      HLN.LIST_NO = LIST_LATEST_NKID.LIST_NO
    WHERE
      BUSR.CL_END_DT = '9999-12-31'
    AND
      NVL(BUSR.UPDATE_KBN, 0) <> 3
  ) LIST
WHERE
  LIST.RECEPTION_ORDER = 1
;

--リスト管理更新
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_LIST_MNG
SET
   LIST_RECORD_COUNT = (SELECT COUNT(*) FROM {{ var.value.redshift_ims_schema_name }}.D_IMS_HANBAIKYOKU_LIST)
  ,UPD_PGM_ID = '{{ dag.dag_id }}'
  ,UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
  LIST_ID = {{ params.list_id }}
;

--汎用マスタ更新
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_GENERAL
SET
   VALUE1 = '0'
  ,UPD_PGM_ID = '{{ dag.dag_id }}'
  ,UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
  MASTER_TYPE = '2001'
AND
  VALUE1 = '1'
;
