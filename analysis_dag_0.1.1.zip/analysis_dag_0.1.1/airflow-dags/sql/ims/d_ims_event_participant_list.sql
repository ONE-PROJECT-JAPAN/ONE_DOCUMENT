
/*******************************************************************************
  SQL名:
    イベント参加者リスト作成

  処理概要:
       下記の順で処理を実施する
       #01 リスト背番号発番済名寄せ(日経ID)処理
       #02 リスト背番号発番済名寄せ(メールアドレス)処理(更新分)
       #03 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分) 「処理#03」
       #04 リスト背番号発番済名寄せ(住所・電話番号・氏名)処理 「処理#04」
       #05 リスト背番号新規発番(日経ID)処理
       #06 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分) 「処理#03」
       #07 リスト背番号新規発番(メールアドレス)処理
       #08 リスト背番号発番済名寄せ(住所・電話番号・氏名)処理 「処理#04」
       #09 リスト背番号新規発番(住所・電話番号・氏名)処理
       #10 リスト背番号新規発番(その他背番号未済)処理
       #11 イベント参加者リスト作成
*******************************************************************************/

/*******************************************************************************
  #01 リスト背番号発番済名寄せ(日経ID)処理
*******************************************************************************/
--リスト背番号発番一時テーブル作成(日経ID)
CREATE TEMP TABLE INDEXING_NIKKEI_ID_TMP (
    LIST_NO               VARCHAR(120)
   ,PARTICIPANT_ID        BIGINT
   ,NIKKEI_MEMBER_NO      BIGINT
   ,EMAIL_CL              VARCHAR(1024)
   ,NAME_CL_NM            VARCHAR(2040)
   ,PHONE_CL              VARCHAR(1020)
   ,ADDR_CL_ADDR          VARCHAR(5296)
);

--リスト背番号発番一時テーブル作成(メールアドレス)
CREATE TEMP TABLE INDEXING_MAIL_TMP (
    LIST_NO               VARCHAR(120)
   ,PARTICIPANT_ID        BIGINT
   ,NIKKEI_MEMBER_NO      BIGINT
   ,EMAIL_CL              VARCHAR(1024)
   ,NAME_CL_NM            VARCHAR(2040)
   ,PHONE_CL              VARCHAR(1020)
   ,ADDR_CL_ADDR          VARCHAR(5296)
);

--リスト背番号発番一時テーブル作成(住所・電話番号・氏名)
CREATE TEMP TABLE INDEXING_ADDR_TMP (
    LIST_NO               VARCHAR(120)
   ,PARTICIPANT_ID        BIGINT
   ,NIKKEI_MEMBER_NO      BIGINT
   ,EMAIL_CL              VARCHAR(1024)
   ,NAME_CL_NM            VARCHAR(2040)
   ,PHONE_CL              VARCHAR(1020)
   ,ADDR_CL_ADDR          VARCHAR(5296)
);

--リスト背番号発番一時テーブル作成(その他背番号未済)
CREATE TEMP TABLE INDEXING_OTHER_TMP (
    LIST_NO               VARCHAR(120)
   ,PARTICIPANT_ID        BIGINT
   ,NIKKEI_MEMBER_NO      BIGINT
   ,EMAIL_CL              VARCHAR(1024)
   ,NAME_CL_NM            VARCHAR(2040)
   ,PHONE_CL              VARCHAR(1020)
   ,ADDR_CL_ADDR          VARCHAR(5296)
);

--イベント参加者データ一時テーブル作成
CREATE TEMP TABLE TEMP_T_BJ_EVENT_PARTICIPANT_CL
AS
SELECT
    EPCL.EVENT_ID
   ,EPCL.PARTICIPANT_ID
   ,EPCL.EMAIL
   ,EPCL.EMAIL_CL
   ,EPCL.NIKKEI_MEMBER_NO
   ,EPCL.LAST_NAME
   ,EPCL.FIRST_NAME
   ,EPCL.NAME_CL_LAST_NM
   ,EPCL.NAME_CL_FIRST_NM
   ,EPCL.NAME_CL_NM
   ,EPCL.LAST_KANA_NAME
   ,EPCL.FIRST_KANA_NAME
   ,EPCL.HOME_PHONE
   ,EPCL.HOME_FAX
   ,EPCL.HOME_COUNTRY
   ,EPCL.HOME_ZIPCODE
   ,EPCL.HOME_ADDR1
   ,EPCL.HOME_ADDR2
   ,EPCL.INDUSTRY
   ,EPCL.JOB
   ,EPCL.COMPANY
   ,EPCL.WORK_EMAIL
   ,EPCL.WORK_COUNTRY
   ,EPCL.WORK_ZIPCODE
   ,EPCL.ZIPCODE_CL
   ,EPCL.WORK_ADDR1
   ,EPCL.WORK_ADDR2
   ,EPCL.ADDR_CL_ADDR
   ,EPCL.ADDR_CL_PREFEC
   ,EPCL.ADDR_CL_CITY
   ,EPCL.ADDR_CL_TSUSHO
   ,EPCL.ADDR_CL_CHOME
   ,EPCL.ADDR_CL_ADDR1
   ,EPCL.ADDR_CL_ADDR2
   ,EPCL.ADDR_CL_ADDR3
   ,EPCL.ADDR_CL_ADDR_CD
   ,EPCL.WORK_PHONE
   ,EPCL.PHONE_CL
   ,EPCL.WORK_FAX
   ,EPCL.WORK_DEPARTMENT
   ,EPCL.WORK_TITLE_CODE
   ,EPCL.WORK_TITLE
   ,EPCL.GENDER
   ,EPCL.BIRTHDAY
   ,EPCL.SECONDARY_USE_SIGN
   ,EPCL.ACQUISITION_DATE
   ,E.EVENT_DATE_START
FROM
    {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
    {{ var.value.redshift_ims_schema_name }}.M_BJ_EVENT E
ON
    EPCL.EVENT_ID = E.EVENT_ID
AND
    E.DELETE_FLG = FALSE
;

--イベント参加者リスト全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.D_IMS_EVENT_PARTICIPANT_LIST
;

--イベント参加者リスト背番号マスタ全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
;

--イベント参加者リストイベント管理全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_MNG
;

--最新の情報でイベント参加者リスト背番号管理の更新(日経ID)
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG EPLNM
SET
    EMAIL_CL     = WKAN.EMAIL_CL
   ,ADDR_CL_ADDR = WKAN.ADDR_CL_ADDR
   ,PHONE_CL     = WKAN.PHONE_CL
   ,NAME_CL_NM   = WKAN.NAME_CL_NM
   ,UPD_PGM_ID   = '{{ dag.dag_id }}'
   ,UPD_DT_TM    = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM
  (
    SELECT
        PARTICIPANT_ID
       ,NIKKEI_MEMBER_NO
       ,EMAIL_CL
       ,PHONE_CL
       ,ADDR_CL_ADDR
       ,NAME_CL_NM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL
    WHERE
       (NIKKEI_MEMBER_NO, PARTICIPANT_ID) IN (
                                                 SELECT NIKKEI_MEMBER_NO, PARTICIPANT_ID 
                                                 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
                                             )
  ) WKAN
WHERE
    EPLNM.NIKKEI_MEMBER_NO = WKAN.NIKKEI_MEMBER_NO
AND
    EPLNM.PARTICIPANT_ID = WKAN.PARTICIPANT_ID
;

--イベント参加者リスト背番号マスタへ挿入(日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        NIKKEI_MEMBER_NO
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        NIKKEI_MEMBER_NO
  ) LATEST
ON
    EPCL.NIKKEI_MEMBER_NO = LATEST.NIKKEI_MEMBER_NO
;

--日経IDで名寄せされたレコードのうち、イベント参加者リスト背番号管理に存在しない参加者IDのレコードを
--イベント参加者リスト背番号管理へ挿入(日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    EPLN.LIST_NO
   ,WKBN.PARTICIPANT_ID
   ,WKBN.NIKKEI_MEMBER_NO
   ,WKBN.EMAIL_CL
   ,WKBN.ADDR_CL_ADDR
   ,WKBN.PHONE_CL
   ,WKBN.NAME_CL_NM
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
INNER JOIN
  (
    SELECT
        PARTICIPANT_ID
       ,NIKKEI_MEMBER_NO
       ,EMAIL_CL
       ,ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL TMP
    WHERE
       (NIKKEI_MEMBER_NO) IN (
                                 SELECT NIKKEI_MEMBER_NO 
                                 FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
                             )
    AND
       NOT EXISTS (
           SELECT 1 
           FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG MNG 
           WHERE 
               TMP.NIKKEI_MEMBER_NO = MNG.NIKKEI_MEMBER_NO 
               AND TMP.PARTICIPANT_ID = MNG.PARTICIPANT_ID
       )
  ) WKBN
ON
    WKBN.PARTICIPANT_ID = EPLN.PARTICIPANT_ID
;

/*******************************************************************************
  #02 リスト背番号発番済名寄せ(メールアドレス)処理(更新分)
*******************************************************************************/
--最新の情報でイベント参加者リスト背番号管理の更新(メールアドレス)
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG EPLNM
SET
    ADDR_CL_ADDR = WKAM.ADDR_CL_ADDR
   ,PHONE_CL     = WKAM.PHONE_CL
   ,NAME_CL_NM   = WKAM.NAME_CL_NM
   ,UPD_PGM_ID   = '{{ dag.dag_id }}'
   ,UPD_DT_TM    = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM
  (
    SELECT
        PARTICIPANT_ID
       ,NIKKEI_MEMBER_NO
       ,EMAIL_CL
       ,ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL
    WHERE
       (EMAIL_CL, PARTICIPANT_ID) IN (
                                         SELECT EMAIL_CL, PARTICIPANT_ID 
                                         FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
                                     )
    AND
       (PARTICIPANT_ID) NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
  ) WKAM
WHERE
    EPLNM.EMAIL_CL = WKAM.EMAIL_CL
AND
    EPLNM.PARTICIPANT_ID = WKAM.PARTICIPANT_ID
;

/*******************************************************************************
  #03 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分) 「処理#03」
*******************************************************************************/
--イベント参加者リスト背番号マスタへ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        EMAIL_CL
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        EMAIL_CL
  ) LATEST
ON
    EPCL.EMAIL_CL = LATEST.EMAIL_CL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
AND
    EPCL.NIKKEI_MEMBER_NO IS NULL
;

--メールアドレスで名寄せされたレコードのうち、イベント参加者リスト背番号管理に存在しないレコードを
--イベント参加者リスト背番号管理へ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    EPLN.LIST_NO
   ,WKBM.PARTICIPANT_ID
   ,WKBM.NIKKEI_MEMBER_NO
   ,WKBM.EMAIL_CL
   ,WKBM.ADDR_CL_ADDR
   ,WKBM.PHONE_CL
   ,WKBM.NAME_CL_NM
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
INNER JOIN
  (
    SELECT
        PARTICIPANT_ID
       ,NIKKEI_MEMBER_NO
       ,EMAIL_CL
       ,ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL TMP
    WHERE
       (EMAIL_CL) IN (SELECT EMAIL_CL FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG)
    AND
       NOT EXISTS (
                      SELECT 1 
                      FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG MNG 
                      WHERE TMP.EMAIL_CL = MNG.EMAIL_CL 
                      AND TMP.PARTICIPANT_ID = MNG.PARTICIPANT_ID
                  )
  ) WKBM
ON
    WKBM.PARTICIPANT_ID = EPLN.PARTICIPANT_ID
;

/*******************************************************************************
  #04 リスト背番号発番済名寄せ(住所・電話番号・氏名)処理 「処理#04」
*******************************************************************************/
--イベント参加者リスト背番号マスタへ挿入(住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
  ) LATEST
ON
    EPCL.ADDR_CL_ADDR = LATEST.ADDR_CL_ADDR
AND
    EPCL.PHONE_CL = LATEST.PHONE_CL
AND
    EPCL.NAME_CL_NM = LATEST.NAME_CL_NM
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
AND
    EPCL.NIKKEI_MEMBER_NO IS NULL
AND
    EPCL.EMAIL_CL IS NULL
;

--住所・電話番号・氏名で名寄せされたレコードのうち、イベント参加者リスト背番号管理に存在しないレコードを
--イベント参加者リスト背番号管理へ挿入(住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
   LIST_NO
  ,PARTICIPANT_ID
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,PHONE_CL
  ,NAME_CL_NM
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   EPLN.LIST_NO
  ,WKBA.PARTICIPANT_ID
  ,WKBA.NIKKEI_MEMBER_NO
  ,WKBA.EMAIL_CL
  ,WKBA.ADDR_CL_ADDR
  ,WKBA.PHONE_CL
  ,WKBA.NAME_CL_NM
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
INNER JOIN
  (
    SELECT
       PARTICIPANT_ID
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,PHONE_CL
      ,NAME_CL_NM
    FROM
      TEMP_T_BJ_EVENT_PARTICIPANT_CL TMP
    WHERE
             (ADDR_CL_ADDR, PHONE_CL, NAME_CL_NM) IN
      (
          SELECT 
               ADDR_CL_ADDR
              ,PHONE_CL, NAME_CL_NM 
          FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
      )
    AND NOT EXISTS
      (
          SELECT 1 
          FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG MNG
          WHERE TMP.ADDR_CL_ADDR = MNG.ADDR_CL_ADDR 
          AND TMP.PHONE_CL = MNG.PHONE_CL 
          AND TMP.NAME_CL_NM = MNG.NAME_CL_NM 
          AND TMP.PARTICIPANT_ID = MNG.PARTICIPANT_ID
      )
  ) WKBA
ON
  EPLN.PARTICIPANT_ID = WKBA.PARTICIPANT_ID
;

/*******************************************************************************
  #05 リスト背番号新規発番(日経ID)処理
*******************************************************************************/
--リスト背番号発番一時テーブル(日経ID)
INSERT INTO INDEXING_NIKKEI_ID_TMP
(
    PARTICIPANT_ID
   ,LIST_NO
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
)
SELECT
    EPCL.PARTICIPANT_ID
   ,CAST(DENSE_RANK() OVER (ORDER BY EPCL.NIKKEI_MEMBER_NO) +
         CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
   ,EPCL.NIKKEI_MEMBER_NO
   ,EPCL.EMAIL_CL
   ,EPCL.ADDR_CL_ADDR
   ,EPCL.PHONE_CL
   ,EPCL.NAME_CL_NM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
AND
    EPCL.NIKKEI_MEMBER_NO IS NOT NULL
;

--イベント参加者リスト背番号管理へ挿入(新規日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,NAME_CL_NM
   ,PHONE_CL
   ,ADDR_CL_ADDR
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    INTP.LIST_NO
   ,INTP.PARTICIPANT_ID
   ,INTP.NIKKEI_MEMBER_NO
   ,INTP.EMAIL_CL
   ,INTP.NAME_CL_NM
   ,INTP.PHONE_CL
   ,INTP.ADDR_CL_ADDR
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_NIKKEI_ID_TMP INTP
;

--イベント参加者リスト背番号マスタへ挿入(新規日経ID)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    INTP.LIST_NO
   ,INTP.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_NIKKEI_ID_TMP INTP
;

/*******************************************************************************
  #06 リスト背番号発番済名寄せ(メールアドレス)処理(挿入分) 「処理#03」
*******************************************************************************/
--イベント参加者リスト背番号マスタへ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        EMAIL_CL
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        EMAIL_CL
  ) LATEST
ON
    EPCL.EMAIL_CL = LATEST.EMAIL_CL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
AND
    EPCL.NIKKEI_MEMBER_NO IS NULL
;

--メールアドレスで名寄せされたレコードのうち、イベント参加者リスト背番号管理に存在しないレコードを
--イベント参加者リスト背番号管理へ挿入(メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    EPLN.LIST_NO
   ,WKBM.PARTICIPANT_ID
   ,WKBM.NIKKEI_MEMBER_NO
   ,WKBM.EMAIL_CL
   ,WKBM.ADDR_CL_ADDR
   ,WKBM.PHONE_CL
   ,WKBM.NAME_CL_NM
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
INNER JOIN
  (
    SELECT
        PARTICIPANT_ID
       ,NIKKEI_MEMBER_NO
       ,EMAIL_CL
       ,ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL TMP
    WHERE
       (EMAIL_CL) IN (
                         SELECT EMAIL_CL 
                         FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
                     )
    AND
       NOT EXISTS (
                      SELECT 1 
                      FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG MNG 
                      WHERE TMP.EMAIL_CL = MNG.EMAIL_CL 
                      AND TMP.PARTICIPANT_ID = MNG.PARTICIPANT_ID
                  )
  ) WKBM
ON
    WKBM.PARTICIPANT_ID = EPLN.PARTICIPANT_ID
;

/*******************************************************************************
  #07 リスト背番号新規発番(メールアドレス)処理
*******************************************************************************/
--リスト背番号発番一時テーブル(メールアドレス)
INSERT INTO INDEXING_MAIL_TMP
(
    PARTICIPANT_ID
   ,LIST_NO
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
)
SELECT
    EPCL.PARTICIPANT_ID
   ,CAST(DENSE_RANK() OVER (ORDER BY EPCL.EMAIL_CL) +
         CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
   ,EPCL.NIKKEI_MEMBER_NO
   ,EPCL.EMAIL_CL
   ,EPCL.ADDR_CL_ADDR
   ,EPCL.PHONE_CL
   ,EPCL.NAME_CL_NM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
    AND EPCL.EMAIL_CL IS NOT NULL
;

--イベント参加者リスト背番号管理へ挿入(新規メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,NAME_CL_NM
   ,PHONE_CL
   ,ADDR_CL_ADDR
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    IMTP.LIST_NO
   ,IMTP.PARTICIPANT_ID
   ,IMTP.NIKKEI_MEMBER_NO
   ,IMTP.EMAIL_CL
   ,IMTP.NAME_CL_NM
   ,IMTP.PHONE_CL
   ,IMTP.ADDR_CL_ADDR
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_MAIL_TMP IMTP
;

--イベント参加者リスト背番号マスタへ挿入(新規メールアドレス)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
   LIST_NO
  ,PARTICIPANT_ID
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   IMTP.LIST_NO
  ,IMTP.PARTICIPANT_ID
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  INDEXING_MAIL_TMP IMTP
;

/*******************************************************************************
  #08 リスト背番号発番済名寄せ(住所・電話番号・氏名)処理 「処理#04」
*******************************************************************************/
--イベント参加者リスト背番号マスタへ挿入(住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        ADDR_CL_ADDR
       ,PHONE_CL
       ,NAME_CL_NM
  ) LATEST
ON
    EPCL.ADDR_CL_ADDR = LATEST.ADDR_CL_ADDR
AND
    EPCL.PHONE_CL = LATEST.PHONE_CL
AND
    EPCL.NAME_CL_NM = LATEST.NAME_CL_NM
WHERE
    EPCL.PARTICIPANT_ID NOT IN (
                                   SELECT PARTICIPANT_ID 
                                   FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
                               )
    AND EPCL.NIKKEI_MEMBER_NO IS NULL
    AND EPCL.EMAIL_CL IS NULL
;

--住所・電話番号・氏名で名寄せされたレコードのうち、イベント参加者リスト背番号管理に存在しないレコードを
--イベント参加者リスト背番号管理へ挿入(住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
   LIST_NO
  ,PARTICIPANT_ID
  ,NIKKEI_MEMBER_NO
  ,EMAIL_CL
  ,ADDR_CL_ADDR
  ,PHONE_CL
  ,NAME_CL_NM
  ,INS_PGM_ID
  ,INS_DT_TM
  ,UPD_PGM_ID
  ,UPD_DT_TM
)
SELECT
   EPLN.LIST_NO
  ,WKBA.PARTICIPANT_ID
  ,WKBA.NIKKEI_MEMBER_NO
  ,WKBA.EMAIL_CL
  ,WKBA.ADDR_CL_ADDR
  ,WKBA.PHONE_CL
  ,WKBA.NAME_CL_NM
  ,'{{ dag.dag_id }}' AS INS_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
  ,'{{ dag.dag_id }}' AS UPD_PGM_ID
  ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
INNER JOIN
  (
    SELECT
       PARTICIPANT_ID
      ,NIKKEI_MEMBER_NO
      ,EMAIL_CL
      ,ADDR_CL_ADDR
      ,PHONE_CL
      ,NAME_CL_NM
    FROM
      TEMP_T_BJ_EVENT_PARTICIPANT_CL TMP
    WHERE
    (ADDR_CL_ADDR, PHONE_CL, NAME_CL_NM) IN
      (
          SELECT 
              ADDR_CL_ADDR
              , PHONE_CL
              , NAME_CL_NM 
          FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
      )
    AND NOT EXISTS
      (
          SELECT 1 
          FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG MNG
          WHERE TMP.ADDR_CL_ADDR = MNG.ADDR_CL_ADDR 
          AND TMP.PHONE_CL = MNG.PHONE_CL 
          AND TMP.NAME_CL_NM = MNG.NAME_CL_NM 
          AND TMP.PARTICIPANT_ID = MNG.PARTICIPANT_ID
      )
  ) WKBA
ON
  EPLN.PARTICIPANT_ID = WKBA.PARTICIPANT_ID
;

/*******************************************************************************
  #09 リスト背番号新規発番(住所・電話番号・氏名)処理
*******************************************************************************/
--リスト背番号発番一時テーブル(住所・電話番号・氏名)
INSERT INTO INDEXING_ADDR_TMP
(
    PARTICIPANT_ID
   ,LIST_NO
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
)
SELECT
    EPCL.PARTICIPANT_ID
   ,CAST(DENSE_RANK() OVER (ORDER BY EPCL.ADDR_CL_ADDR, EPCL.PHONE_CL, EPCL.NAME_CL_NM) +
         CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
   ,EPCL.NIKKEI_MEMBER_NO
   ,EPCL.EMAIL_CL
   ,EPCL.ADDR_CL_ADDR
   ,EPCL.PHONE_CL
   ,EPCL.NAME_CL_NM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (SELECT PARTICIPANT_ID FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO)
AND
    EPCL.ADDR_CL_ADDR IS NOT NULL
AND
    EPCL.PHONE_CL IS NOT NULL
AND
    EPCL.NAME_CL_NM IS NOT NULL
;

--イベント参加者リスト背番号管理へ挿入(新規住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,NAME_CL_NM
   ,PHONE_CL
   ,ADDR_CL_ADDR
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    IATP.LIST_NO
   ,IATP.PARTICIPANT_ID
   ,IATP.NIKKEI_MEMBER_NO
   ,IATP.EMAIL_CL
   ,IATP.NAME_CL_NM
   ,IATP.PHONE_CL
   ,IATP.ADDR_CL_ADDR
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_ADDR_TMP IATP
;

--イベント参加者リスト背番号マスタへ挿入(新規住所・電話番号・氏名)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    IATP.LIST_NO
   ,IATP.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_ADDR_TMP IATP
;

/*******************************************************************************
  #10 リスト背番号新規発番(その他背番号未済)処理
*******************************************************************************/
--リスト背番号は発番済で名寄せされていないレコードを参加者IDによる名寄せを行う。
--イベント参加者リスト背番号マスタへ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    CAST(LATEST.LIST_NO AS VARCHAR(120)) AS LIST_NO
   ,EPCL.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
  (
    SELECT
        PARTICIPANT_ID
       ,MAX(CAST(LIST_NO AS BIGINT)) AS LIST_NO
    FROM
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
    GROUP BY
        PARTICIPANT_ID
  ) LATEST
ON
    EPCL.PARTICIPANT_ID = LATEST.PARTICIPANT_ID
WHERE
    EPCL.PARTICIPANT_ID NOT IN (SELECT PARTICIPANT_ID FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO)
;

--リスト背番号発番一時テーブル(その他背番号未済)
INSERT INTO INDEXING_OTHER_TMP
(
    PARTICIPANT_ID
   ,LIST_NO
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,ADDR_CL_ADDR
   ,PHONE_CL
   ,NAME_CL_NM
)
SELECT
    EPCL.PARTICIPANT_ID
   ,CAST(DENSE_RANK() OVER (ORDER BY EPCL.PARTICIPANT_ID) +
         CAST((SELECT NVL(MAX(CAST(LIST_NO AS BIGINT)),'0') FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG) AS BIGINT) AS VARCHAR(120)) AS LIST_NO
   ,EPCL.NIKKEI_MEMBER_NO
   ,EPCL.EMAIL_CL
   ,EPCL.ADDR_CL_ADDR
   ,EPCL.PHONE_CL
   ,EPCL.NAME_CL_NM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
WHERE
    EPCL.PARTICIPANT_ID NOT IN (SELECT PARTICIPANT_ID FROM {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO)
;

--イベント参加者リスト背番号管理へ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO_MNG
(
    LIST_NO
   ,PARTICIPANT_ID
   ,NIKKEI_MEMBER_NO
   ,EMAIL_CL
   ,NAME_CL_NM
   ,PHONE_CL
   ,ADDR_CL_ADDR
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    IOTP.LIST_NO
   ,IOTP.PARTICIPANT_ID
   ,IOTP.NIKKEI_MEMBER_NO
   ,IOTP.EMAIL_CL
   ,IOTP.NAME_CL_NM
   ,IOTP.PHONE_CL
   ,IOTP.ADDR_CL_ADDR
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_OTHER_TMP IOTP
;

--イベント参加者リスト背番号マスタへ挿入(その他背番号未済)
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO
(
    LIST_NO
   ,PARTICIPANT_ID
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT
    IOTP.LIST_NO
   ,IOTP.PARTICIPANT_ID
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    INDEXING_OTHER_TMP IOTP
;

/*******************************************************************************
  #11 イベント参加者リスト作成
*******************************************************************************/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.D_IMS_EVENT_PARTICIPANT_LIST
(
    LIST_ID
   ,LIST_NO
   ,PARTICIPANT_ID
   ,EMAIL
   ,EMAIL_CL
   ,NIKKEI_MEMBER_NO
   ,NIKKEI_MEMBER_NO_0PAD
   ,LAST_NAME
   ,FIRST_NAME
   ,NAME_CL_LAST_NM
   ,NAME_CL_FIRST_NM
   ,NAME_CL_NM
   ,LAST_KANA_NAME
   ,FIRST_KANA_NAME
   ,HOME_PHONE
   ,HOME_FAX
   ,HOME_COUNTRY
   ,HOME_ZIPCODE
   ,HOME_ADDR1
   ,HOME_ADDR2
   ,INDUSTRY
   ,JOB
   ,COMPANY
   ,WORK_EMAIL
   ,WORK_COUNTRY
   ,WORK_ZIPCODE
   ,ZIPCODE_CL
   ,WORK_ADDR1
   ,WORK_ADDR2
   ,ADDR_CL_ADDR
   ,ADDR_CL_PREFEC
   ,ADDR_CL_CITY
   ,ADDR_CL_TSUSHO
   ,ADDR_CL_CHOME
   ,ADDR_CL_ADDR1
   ,ADDR_CL_ADDR2
   ,ADDR_CL_ADDR3
   ,ADDR_CL_ADDR_CD
   ,WORK_PHONE
   ,PHONE_CL
   ,WORK_FAX
   ,WORK_DEPARTMENT
   ,WORK_TITLE_CODE
   ,WORK_TITLE
   ,GENDER
   ,BIRTHDAY
   ,DIVIDE_AGE
   ,AGE
   ,SECONDARY_USE_SIGN
   ,LATEST_SECONDARY_USE_SIGN
   ,ACQUISITION_DATE
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
--リスト背番号最新の参加者情報
SELECT
    LIST.LIST_ID
   ,LIST.LIST_NO
   ,LIST.PARTICIPANT_ID
   ,LIST.EMAIL
   ,LIST.EMAIL_CL
   ,LIST.NIKKEI_MEMBER_NO
   ,LIST.NIKKEI_MEMBER_NO_0PAD
   ,LIST.LAST_NAME
   ,LIST.FIRST_NAME
   ,LIST.NAME_CL_LAST_NM
   ,LIST.NAME_CL_FIRST_NM
   ,LIST.NAME_CL_NM
   ,LIST.LAST_KANA_NAME
   ,LIST.FIRST_KANA_NAME
   ,LIST.HOME_PHONE
   ,LIST.HOME_FAX
   ,LIST.HOME_COUNTRY
   ,LIST.HOME_ZIPCODE
   ,LIST.HOME_ADDR1
   ,LIST.HOME_ADDR2
   ,LIST.INDUSTRY
   ,LIST.JOB
   ,LIST.COMPANY
   ,LIST.WORK_EMAIL
   ,LIST.WORK_COUNTRY
   ,LIST.WORK_ZIPCODE
   ,LIST.ZIPCODE_CL
   ,LIST.WORK_ADDR1
   ,LIST.WORK_ADDR2
   ,LIST.ADDR_CL_ADDR
   ,LIST.ADDR_CL_PREFEC
   ,LIST.ADDR_CL_CITY
   ,LIST.ADDR_CL_TSUSHO
   ,LIST.ADDR_CL_CHOME
   ,LIST.ADDR_CL_ADDR1
   ,LIST.ADDR_CL_ADDR2
   ,LIST.ADDR_CL_ADDR3
   ,LIST.ADDR_CL_ADDR_CD
   ,LIST.WORK_PHONE
   ,LIST.PHONE_CL
   ,LIST.WORK_FAX
   ,LIST.WORK_DEPARTMENT
   ,LIST.WORK_TITLE_CODE
   ,LIST.WORK_TITLE
   ,LIST.GENDER
   ,LIST.BIRTHDAY
   ,LIST.DIVIDE_AGE
   ,LIST.AGE
   ,LIST.SECONDARY_USE_SIGN
   ,LIST.LATEST_SECONDARY_USE_SIGN
   ,LIST.ACQUISITION_DATE
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
  (
    SELECT
        {{ params.list_id }} AS LIST_ID
       ,EPLN.LIST_NO
       ,EPCL.PARTICIPANT_ID
       ,EPCL.EMAIL
       ,EPCL.EMAIL_CL
       ,EPCL.NIKKEI_MEMBER_NO
       ,LPAD(CAST(EPCL.NIKKEI_MEMBER_NO AS VARCHAR), 10, '0') AS NIKKEI_MEMBER_NO_0PAD
       ,EPCL.LAST_NAME
       ,EPCL.FIRST_NAME
       ,EPCL.NAME_CL_LAST_NM
       ,EPCL.NAME_CL_FIRST_NM
       ,EPCL.NAME_CL_NM
       ,EPCL.LAST_KANA_NAME
       ,EPCL.FIRST_KANA_NAME
       ,EPCL.HOME_PHONE
       ,EPCL.HOME_FAX
       ,EPCL.HOME_COUNTRY
       ,EPCL.HOME_ZIPCODE
       ,EPCL.HOME_ADDR1
       ,EPCL.HOME_ADDR2
       ,EPCL.INDUSTRY
       ,EPCL.JOB
       ,EPCL.COMPANY
       ,EPCL.WORK_EMAIL
       ,EPCL.WORK_COUNTRY
       ,EPCL.WORK_ZIPCODE
       ,EPCL.ZIPCODE_CL
       ,EPCL.WORK_ADDR1
       ,EPCL.WORK_ADDR2
       ,EPCL.ADDR_CL_ADDR
       ,EPCL.ADDR_CL_PREFEC
       ,EPCL.ADDR_CL_CITY
       ,EPCL.ADDR_CL_TSUSHO
       ,EPCL.ADDR_CL_CHOME
       ,EPCL.ADDR_CL_ADDR1
       ,EPCL.ADDR_CL_ADDR2
       ,EPCL.ADDR_CL_ADDR3
       ,EPCL.ADDR_CL_ADDR_CD
       ,EPCL.WORK_PHONE
       ,EPCL.PHONE_CL
       ,EPCL.WORK_FAX
       ,EPCL.WORK_DEPARTMENT
       ,EPCL.WORK_TITLE_CODE
       ,EPCL.WORK_TITLE
       ,EPCL.GENDER
       ,EPCL.BIRTHDAY
       ,A.AGE AS DIVIDE_AGE
       ,A.AGE2 AS AGE
       ,ABI.SECONDARY_USE_SIGN
       ,NVL(EPCL.SECONDARY_USE_SIGN,0) AS LATEST_SECONDARY_USE_SIGN
       ,EPCL.ACQUISITION_DATE
       ,ROW_NUMBER() OVER (PARTITION BY EPLN.LIST_NO ORDER BY EPCL.EVENT_DATE_START DESC, EPCL.PARTICIPANT_ID DESC) AS ROWNUM
    FROM
        TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
    INNER JOIN
    -- イベント参加者リスト背番号マスタ
        {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
    ON
        EPCL.PARTICIPANT_ID = EPLN.PARTICIPANT_ID
    LEFT JOIN
        {{ var.value.redshift_ims_schema_name }}.V_M_IS_AGE A
    ON
        TO_CHAR(EPCL.BIRTHDAY, 'YYYYMMDD') >= A.AGE_FROM2
    AND
        TO_CHAR(EPCL.BIRTHDAY, 'YYYYMMDD') <= A.AGE_TO2
    LEFT JOIN
    --【A1: 集約処理（リスト背番号単位の属性）】
      (
        SELECT
            ABI.LIST_NO
           ,CASE WHEN (ABI.SECONDARY_USE_SIGN_0 = 1 OR ABI.SECONDARY_USE_SIGN_1 = 0) THEN 0
                 WHEN ABI.SECONDARY_USE_SIGN_1 = 1 THEN 1
                 ELSE 0
            END SECONDARY_USE_SIGN
        FROM
          (
            SELECT
                LIST_NO
               ,MAX(CASE WHEN EPCL.SECONDARY_USE_SIGN = 0 THEN 1 ELSE 0 END) AS SECONDARY_USE_SIGN_0
               ,MAX(CASE WHEN EPCL.SECONDARY_USE_SIGN = 1 THEN 1 ELSE 0 END) AS SECONDARY_USE_SIGN_1
            FROM
                TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
            INNER JOIN
                {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
            ON
                EPLN.PARTICIPANT_ID = EPCL.PARTICIPANT_ID
            GROUP BY
                EPLN.LIST_NO
          ) ABI
      ) ABI
    ON
        EPLN.LIST_NO = ABI.LIST_NO
  ) LIST
WHERE
    LIST.ROWNUM = 1
;

--イベント参加者リストイベント管理へ挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_MNG
(
    EVENT_ID
   ,LIST_NO
   ,INS_PGM_ID
   ,INS_DT_TM
   ,UPD_PGM_ID
   ,UPD_DT_TM
)
SELECT DISTINCT
    EPCL.EVENT_ID
   ,EPLN.LIST_NO
   ,'{{ dag.dag_id }}' AS INS_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
   ,'{{ dag.dag_id }}' AS UPD_PGM_ID
   ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_BJ_EVENT_PARTICIPANT_CL EPCL
INNER JOIN
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EVENT_PARTICIPANT_LIST_NO EPLN
ON
    EPCL.PARTICIPANT_ID = EPLN.PARTICIPANT_ID
;

--リスト管理更新
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_LIST_MNG
SET
    LIST_RECORD_COUNT = (SELECT COUNT(*) FROM {{ var.value.redshift_ims_schema_name }}.D_IMS_EVENT_PARTICIPANT_LIST)
   ,UPD_PGM_ID = '{{ dag.dag_id }}'
   ,UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
WHERE
    LIST_ID = {{ params.list_id }}
;
