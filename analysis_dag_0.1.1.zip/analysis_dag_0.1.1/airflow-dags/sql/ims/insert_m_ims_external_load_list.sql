
/*******************************************************************************
  SQL名:
    外部リストデータクレンジング・取込

  処理概要:
       下記の順で処理を実施する
       #01 外部取込リストワーク削除
       #02 外部取込リストワークロード
       #03 リスト属性表示管理一時外部テーブル作成
       #04 リスト属性表示管理一時外部テーブルロード
       #05 外部リスト取込管理更新
       #06 リスト管理更新
       #07 オブジェクト更新
       #08 外部取込リスト挿入
       #09 リスト属性表示管理挿入

*******************************************************************************/


/*******************************************************************************
  #01 外部取込リストワーク削除
*******************************************************************************/
-- 外部取込リストワークから全件削除する
delete from {{ var.value.redshift_ims_schema_name }}.W_IMS_EXTERNAL_LOAD_LIST;


/*******************************************************************************
  #02 外部取込リストワークロード
*******************************************************************************/
-- 外部リストデータファイルのデータを外部取込リストワークにロードする
copy {{ var.value.redshift_ims_schema_name }}.W_IMS_EXTERNAL_LOAD_LIST
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/W_IMS_EXTERNAL_LOAD_LIST_CL/W_IMS_EXTERNAL_LOAD_LIST_'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER ','
QUOTE '"'
;


/*******************************************************************************
  #03 リスト属性表示管理一時外部テーブル作成
*******************************************************************************/
-- 汎用属性項目表示データファイルを元に、リスト属性表示管理外部テーブルを作成する
CREATE TEMP TABLE TEMP_IMS_LIST_ATTRIBUTE_DISP_MNG_EXT
(
     DISP_NM               VARCHAR(1020)
     , COLUMN_NM          VARCHAR(1020)
)
;


/*******************************************************************************
  #04 リスト属性表示管理一時外部テーブルロード
*******************************************************************************/
-- 
copy TEMP_IMS_LIST_ATTRIBUTE_DISP_MNG_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/external/M_IMS_EXTERNAL_LOAD_LIST/GENERAL_ATTRIBUTE_DISP'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER '\t'
QUOTE '"'
;


/*******************************************************************************
  #05 外部リスト取込管理更新
*******************************************************************************/
-- 取込対象外部リストデータ検索処理で取得したリストIDをキーにして外部リスト取込管理を正常更新する
UPDATE {{ var.value.redshift_ims_schema_name }}.T_EDL_LOAD_MNG
SET
     LOAD_STATUS_CD = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='load_status_cd') }}
     , LOAD_COMP_TIMESTAMP = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
     , LOAD_SUCCESS_NUM = ( select count(*) from {{ var.value.redshift_ims_schema_name }}.W_IMS_EXTERNAL_LOAD_LIST )
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
WHERE
     LIST_ID = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
;


/*******************************************************************************
  #06 リスト管理更新
*******************************************************************************/
-- 取込対象外部リストデータ検索処理で取得したリストIDをキーにしてリスト管理を更新する
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_LIST_MNG
SET
     LIST_CREATE_DATE = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
     , LIST_RECORD_COUNT = (select count(*) from {{ var.value.redshift_ims_schema_name }}.W_IMS_EXTERNAL_LOAD_LIST)
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
WHERE
     LIST_ID = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
;


/*******************************************************************************
  #07 オブジェクト更新
*******************************************************************************/
-- 取込対象外部リストデータ検索処理で取得したリストIDをキーにしてオブジェクトを更新する
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_OBJECT
SET
     DELETE_FLG = FALSE
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
WHERE
     OBJECT_ID = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
;


/*******************************************************************************
  #08 外部取込リスト挿入
*******************************************************************************/
-- 外部取込リストワークのデータを外部取込リストに全件挿入する
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_EXTERNAL_LOAD_LIST
(
     LIST_ID
     , LIST_INTERNAL_ID
     , NAME
     , NAME_CL_LAST_NM
     , NAME_CL_FIRST_NM
     , NAME_CL_NM
     , EMAIL
     , EMAIL_CL
     , ADDRESS
     , ADDRESS_CL_ADDR
     , ADDRESS_CL_ADDR_CD
     , ADDRESS_CL_PREFEC
     , ADDRESS_CL_CITY
     , ADDRESS_CL_TSUSHO
     , ADDRESS_CL_CHOME
     , ADDRESS_CL_ADDR1
     , ADDRESS_CL_ADDR2
     , ADDRESS_CL_ADDR3
     , TELNO
     , TELNO_CL
     , GENERAL_ATTRIBUTE_1
     , GENERAL_ATTRIBUTE_2
     , GENERAL_ATTRIBUTE_3
     , GENERAL_ATTRIBUTE_4
     , GENERAL_ATTRIBUTE_5
     , INS_PGM_ID
     , INS_DT_TM
     , UPD_PGM_ID
     , UPD_DT_TM
)
SELECT
     {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
     , LIST_INTERNAL_ID
     , NAME
     , NAME_CL_LAST_NM
     , NAME_CL_FIRST_NM
     , NAME_CL_NM
     , EMAIL
     , EMAIL
     , ADDRESS
     , ADDRESS_CL_ADDR
     , ADDRESS_CL_ADDR_CD
     , ADDRESS_CL_PREFEC
     , ADDRESS_CL_CITY
     , ADDRESS_CL_TSUSHO
     , ADDRESS_CL_CHOME
     , ADDRESS_CL_ADDR1
     , ADDRESS_CL_ADDR2
     , ADDRESS_CL_ADDR3
     , TELNO
     , TELNO_CL
     , GENERAL_ATTRIBUTE_1
     , GENERAL_ATTRIBUTE_2
     , GENERAL_ATTRIBUTE_3
     , GENERAL_ATTRIBUTE_4
     , GENERAL_ATTRIBUTE_5
     , '{{ dag.dag_id }}'
     , CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
     , '{{ dag.dag_id }}'
     , CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM
     {{ var.value.redshift_ims_schema_name }}.W_IMS_EXTERNAL_LOAD_LIST
;


/*******************************************************************************
  #09 リスト属性表示管理挿入
*******************************************************************************/
-- 項目名データファイルの項目数分汎用属性項目表示データをリスト属性表示管理に挿入する
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_IMS_LIST_ATTRIBUTE_DISP_MNG
(
      LIST_ATTRIBUTE_ID
     , LIST_ID
     , DISP_NM
     , INS_PGM_ID
     , INS_DT_TM
     , UPD_PGM_ID
     , UPD_DT_TM
)
SELECT
     M.LIST_ATTRIBUTE_ID
     , {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
     , NULLIF(E.DISP_NM, '') AS DISP_NM
     , '{{ dag.dag_id }}'
     , CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
     , '{{ dag.dag_id }}'
     , CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM
     {{ var.value.redshift_ims_schema_name }}.M_IMS_LIST_ATTRIBUTE_MNG M
     , TEMP_IMS_LIST_ATTRIBUTE_DISP_MNG_EXT E
WHERE
     M.CATEGORY_ID = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_category_id') }}
AND
     M.COLUMN_NM = E.COLUMN_NM
;

