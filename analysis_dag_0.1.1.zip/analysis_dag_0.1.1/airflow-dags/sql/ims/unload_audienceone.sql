-- ヘッダの大文字・小文字混在を可とする
SET enable_case_sensitive_identifier TO true;

UNLOAD ($$
SELECT
      CUSTMERID AS "SerialID"
    , A150 AS "EstimatedIncome"
    , A200 AS "UserType"
    , A201 AS "WithdrawalFlag"
    , A202 AS "ResidentAbroad"
    , A203 AS "Prefectures"
    , A204 AS "Sex"
    , A205 AS "DivideAge"
    , A055 AS "Age"
    , A056 AS "Occupation"
    , A057 AS "Employees"
    , A058 AS "Business"
    , A059 AS "Job"
    , A060 AS "Position"
    , DECODE(A061,'000',NULL,A061) AS "Income"
    , A161 AS "InterestEntertainment"
    , A162 AS "InterestFood&Health"
    , A163 AS "InterestSelfDevelopment"
    , A164 AS "InterestShopping"
    , A165 AS "InterestHousingInterior"
    , A166 AS "InterestMoney"
    , A167 AS "InterestHousing&Family"
    , A168 AS "InterestCulture"
    , A169 AS "InterestTravel&Sports&Outdoor"
    , A170 AS "InterestBusiness&Management"
    , A171 AS "InterestCar"
    , A172 AS "InterestFashion"
    , A173 AS "InterestComputer&Technology"
    , A063 AS "NewsSubscrptionNS"
    , A064 AS "NewsSubscrptionSS"
    , A065 AS "NewsSubscrptionMJ"
    , A066 AS "NewsSubscrptionVS"
    , A206 AS "NewsSubscrptionTNW"
    , A207 AS "NewsSubscrptionSummaryFlag"
    , A053 AS "Country"
    , A208 AS "DSYKindPricepln"
    , A209 AS "DSYKindContract"
    , A210 AS "DSYKindOverSea"
    , A119 AS "MigrationFrom"
    , A120 AS "MigrationStatus"
    , A211 AS "NikkeiIDEntryDate"
FROM
    {{var.value.redshift_ims_schema_name}}.M_IMS_GENERAL_DATA
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
HEADER
DELIMITER AS '\t'
GZIP
NULL AS ''
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
