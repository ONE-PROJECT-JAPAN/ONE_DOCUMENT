
/*******************************************************************************
  SQL名:
    外部取込リストの過去データ削除

  処理概要:
       外部取込リストの2年以上の過去データを削除する。

       参照テーブル:
         M_IMS_OBJECT
         M_IMS_EXTERNAL_LOAD_LIST
         M_IMS_EXCLUDE_LIST_MNG
*******************************************************************************/

--M_IMS_OBJECTの論理削除
UPDATE
  {{ var.value.redshift_ims_schema_name }}.M_IMS_OBJECT
SET
  DELETE_FLG = 1
  , DELETE_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
  , UPD_PGM_ID = '{{ dag.dag_id }}'
  , UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
  OBJECT_ID IN (
  SELECT
    DISTINCT LIST_ID
  FROM
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EXTERNAL_LOAD_LIST
  WHERE
    UPD_DT_TM < DATE(CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())) - INTERVAL '2 YEAR'
    AND LIST_ID NOT IN (
    SELECT
      LIST_ID
    FROM
      {{ var.value.redshift_ims_schema_name }}.M_IMS_EXCLUDE_LIST_MNG)
    AND DELETE_FLG = 0)
;

--M_IMS_EXTERNAL_LOAD_LISTの削除
DELETE
FROM
  {{ var.value.redshift_ims_schema_name }}.M_IMS_EXTERNAL_LOAD_LIST
WHERE
  UPD_DT_TM < DATE(CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())) - INTERVAL '2 YEAR'
  AND LIST_ID NOT IN (
  SELECT
    LIST_ID
  FROM
    {{ var.value.redshift_ims_schema_name }}.M_IMS_EXCLUDE_LIST_MNG)
;
