UNLOAD ($$
SELECT
   '"' || NVL(B.SERIAL_ID, '')   || '"' AS "user_serial_id"
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_ACC_ACCOUNTCODE__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS "account_code"
FROM {{var.value.redshift_ims_schema_name}}.T_BB_AGREEMENT_LIST A
  INNER JOIN (
        SELECT
          VALUE1 AS RP_ID
          , VALUE2 AS SERVICE_ID
        FROM
          {{var.value.redshift_ims_schema_name}}.M_CRM_CODE CODE
        WHERE
          MASTER_TYPE = 'MST630'
          AND YUKO_FLG = '1'
      ) CODE
    ON A.RP_ID = CODE.RP_ID
       AND A.SERVICE_ID = CODE.SERVICE_ID
  INNER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
IAM_ROLE '{{params.redshift_role_arn}}'
HEADER
DELIMITER AS ','
GZIP
NULL AS ''
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 5GB
ALLOWOVERWRITE
;
