UNLOAD ($$
SELECT
     '''' || REPLACE(REPLACE(REPLACE(A.TRIAL_CAMPAIGN_MANAGEMENT_NO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || ''''
    ,'''' || REPLACE(REPLACE(REPLACE(A.TRIAL_DAYS_REMAINING_MEMO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || ''''
    ,'''' || REPLACE(REPLACE(REPLACE(A.TRIAL_IN_PAY_INDUCED_MEMO_1, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || ''''
    ,'''' || REPLACE(REPLACE(REPLACE(A.TRIAL_IN_PAY_INDUCED_MEMO_2, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_IN_PAY_INDUCED_MEMO_SPARE_1, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_IN_PAY_INDUCED_MEMO_SPARE_2, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_END_INFO_MEMO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_AFTER_PAY_INDUCED_MEMO_1, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_AFTER_PAY_INDUCED_MEMO_2, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_AFTER_PAY_INDUCED_MEMO_SPARE_1, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_AFTER_PAY_INDUCED_MEMO_SPARE_2, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.CHARGE_GUIDE_URL, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_STATUS_NAME, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_CAMPAIGN_STATUS_ADD_INFO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || A.TRIAL_CAMPAIGN_DELIVERY_TM || ''''
    ,'''' || A.REGIST_TM || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.REGISTRANT_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || A.INS_DT_TM || ''''
    ,'''' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
    ,'''' || A.UPD_DT_TM || ''''
FROM
    {{var.value.redshift_ims_schema_name}}.T_IMS_TRIAL_CAMPAIGN_ADD_INFO A
WHERE
    A.TRIAL_CAMPAIGN_STATUS_ADD_INFO = '030'
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d"), convUTC2JST(next_execution_date, "%Y%m%d%H%M%S")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS '\t'
NULL AS ''
GZIP
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
