/*******************************************************************************
  SQL名:
    外部リストデータロード処理(異常処理)

  処理概要:
       取込管理のステータスを更新する

*******************************************************************************/

UPDATE {{ var.value.redshift_ims_schema_name }}.T_EDL_LOAD_MNG
SET
     LOAD_STATUS_CD = -1
     , LOAD_COMP_TIMESTAMP = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
     , LOAD_SUCCESS_NUM = 0
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
WHERE
     LIST_ID = {{ ti.xcom_pull(task_ids='edit_w_ims_external_load_list', key='db_list_id') }}
;
