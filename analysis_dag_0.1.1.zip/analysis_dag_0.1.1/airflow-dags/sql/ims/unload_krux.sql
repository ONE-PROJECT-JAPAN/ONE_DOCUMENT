-- ヘッダの大文字・小文字混在を可とする
SET enable_case_sensitive_identifier TO true;

UNLOAD ($$
SELECT
    NI.IS_シリアルID                                                                 AS "SerialID"
   ,CASE WHEN EI.SCORE_VALUE_NUMERIC_1 >= 80 THEN EI.SCORE_VALUE_CD_1 ELSE NULL END  AS "EstimatedIncome"
   ,NX.USER_TYPE                                                                     AS "UserType"
   ,NX.WITHDRAWAL_FLAG                                                               AS "WithdrawalFlag"
   ,NX.RESIDENT_ABROAD                                                               AS "ResidentAbroad"
   ,PREF.VALUE                                                                       AS "Prefectures"
   ,NX.SEX                                                                           AS "Sex"
   ,AGE.VALUE3                                                                       AS "DivideAge"
   ,TRANSLATE(NI.IS_年齢,'歳','')                                                    AS "Age"
   ,NI.IS_職業NO                                                                     AS "Occupation"
   ,NI.IS_従業員規模NO                                                               AS "Employees"
   ,NI.IS_業種NO                                                                     AS "Business"
   ,NI.IS_職種NO                                                                     AS "Job"
   ,NI.IS_役職NO                                                                     AS "Position"
   ,DECODE(NI.IS_世帯収入NO,'000',NULL,NI.IS_世帯収入NO)                             AS "Income"
   ,NX.INTEREST1                                                                     AS "InterestEntertainment"
   ,NX.INTEREST2                                                                     AS "InterestFood&Health"
   ,NX.INTEREST3                                                                     AS "InterestSelfDevelopment"
   ,NX.INTEREST4                                                                     AS "InterestShopping"
   ,NX.INTEREST5                                                                     AS "InterestHousingInterior"
   ,NX.INTEREST6                                                                     AS "InterestMoney"
   ,NX.INTEREST7                                                                     AS "InterestHousing&Family"
   ,NX.INTEREST8                                                                     AS "InterestCulture"
   ,NX.INTEREST9                                                                     AS "InterestTravel&Sports&Outdoor"
   ,NX.INTEREST10                                                                    AS "InterestBusiness&Management"
   ,NX.INTEREST11                                                                    AS "InterestCar"
   ,NX.INTEREST12                                                                    AS "InterestFashion"
   ,NX.INTEREST13                                                                    AS "InterestComputer&Technology"
   ,NX.NEWS_SUBSCRIPTION1                                                            AS "NewsSubscrptionNS"
   ,NX.NEWS_SUBSCRIPTION2                                                            AS "NewsSubscrptionSS"
   ,NX.NEWS_SUBSCRIPTION3                                                            AS "NewsSubscrptionMJ"
   ,NX.NEWS_SUBSCRIPTION4                                                            AS "NewsSubscrptionVS"
   ,NX.NEWS_SUBSCRIPTION5                                                            AS "NewsSubscrptionTNW"
   ,NX.NEWS_SUBSCRIPTION_SUMMARY_FLAG                                                AS "NewsSubscrptionSummaryFlag"
   ,NI.IS_居住国コード                                                               AS "Country"
   ,CRM_RKN_KBN.PRICEPLN_KBN                                                         AS "DSYKindPricepln"
   ,CRM_RKN_KBN.PRICEPLN_KEI                                                         AS "DSYKindContract"
   ,CRM_RKN_KBN.PRICEPLN_AB                                                          AS "DSYKindOverSea"
   ,NVL(RP_REGIST.NIKKEI_RP,'0')                                                     AS "NKRPRegFlag"
   ,NVL(RP_REGIST.BP_RP,'0')                                                         AS "BPRPRegFlag"
FROM
    {{var.value.redshift_ims_schema_name}}.M_AD_NIKKEI_ID NI

LEFT JOIN
--年収予測/Mosaic
(
    SELECT
         LIST_INTERNAL_ID
        ,MAX(CASE
            WHEN SCORE_ID = 1 THEN SCORE_VALUE_CD
            ELSE NULL
            END)  AS SCORE_VALUE_CD_1
        ,MAX(CASE
            WHEN SCORE_ID = 1 THEN SCORE_VALUE_NUMERIC
            ELSE NULL
            END) AS SCORE_VALUE_NUMERIC_1
        ,MAX(CASE
            WHEN SCORE_ID = 2 THEN SCORE_VALUE_CD
            ELSE NULL
            END) AS SCORE_VALUE_CD_2
        ,MAX(CASE
            WHEN SCORE_ID = 2 THEN SCORE_VALUE_NUMERIC
            ELSE NULL
            END) AS SCORE_VALUE_NUMERIC_2
    FROM
        {{var.value.redshift_ims_schema_name}}.M_IMS_SCORE
    WHERE
        SCORE_ID IN (1, 2)
    AND LIST_ID = 1001
    GROUP BY
        LIST_INTERNAL_ID
) EI
ON NI.IS_会員番号 = EI.LIST_INTERNAL_ID::BIGINT

LEFT JOIN
--共通属性
(
    SELECT
         NX_ATTR.USER_NO
        ,NX_ATTR.INTEREST1
        ,NX_ATTR.INTEREST2
        ,NX_ATTR.INTEREST3
        ,NX_ATTR.INTEREST4
        ,NX_ATTR.INTEREST5
        ,NX_ATTR.INTEREST6
        ,NX_ATTR.INTEREST7
        ,NX_ATTR.INTEREST8
        ,NX_ATTR.INTEREST9
        ,NX_ATTR.INTEREST10
        ,NX_ATTR.INTEREST11
        ,NX_ATTR.INTEREST12
        ,NX_ATTR.INTEREST13
        ,NX_ATTR.NEWS_SUBSCRIPTION1
        ,NX_ATTR.NEWS_SUBSCRIPTION2
        ,NX_ATTR.NEWS_SUBSCRIPTION3
        ,NX_ATTR.NEWS_SUBSCRIPTION4
        ,NX_ATTR.NEWS_SUBSCRIPTION5
        ,NX_ATTR.NEWS_SUBSCRIPTION_SUMMARY_FLAG
        ,NX_ATTR.NIKKEI_MAIL_FLAG
        ,NX_ATTR.THIRDPARTY_MAIL_FLAG
        ,NX_ATTR.NIKKEI_MONITOR_FLAG
        ,NX_ATTR.USER_TYPE
        ,NX_ATTR.WITHDRAWAL_FLAG
        ,NX_ATTR.RESIDENT_ABROAD
        ,NX_ATTR.SEX
        ,NX_ATTR.ZIP_CODE
        ,NX_ATTR.ADDRESS_CODE
    FROM
        {{var.value.redshift_ims_schema_name}}.M_IS_NX_ATTRIBUTE NX_ATTR
) NX
ON NI.IS_会員番号 = NX.USER_NO

LEFT JOIN
--都道府県マスタテーブル
(SELECT VALUE ,LABEL FROM {{var.value.redshift_ims_schema_name}}.M_IS_MM_PREFECTURE) PREF
ON NI.IS_都道府県郵便番号 = PREF.LABEL

LEFT JOIN
--CRM用コードマスタ
(SELECT VALUE1 ,VALUE3 FROM {{var.value.redshift_ims_schema_name}}.M_CRM_CODE WHERE MASTER_TYPE = 'MST100' AND MASTER_GRP_TYPE = 'GCRM015') AGE
ON NI.IS_年齢 = AGE.VALUE1

LEFT JOIN
--有料会員分類
(
    SELECT
        PRICEPLN_SYSTEM_ID
        ,PRICEPLN_CD
        ,PLN_KBN_SORT_ORDER1_AS AS PRICEPLN_KBN
        ,CONTRACT_SORT_ORDER_AS AS PRICEPLN_KEI
        ,'000' AS PRICEPLN_AB
    FROM
        {{var.value.redshift_ims_schema_name}}.V_M_CRM_RKN_PLN
) CRM_RKN_KBN
ON NI.料金プランコード = CRM_RKN_KBN.PRICEPLN_CD
   AND NI.料金プランシステムID = CRM_RKN_KBN.PRICEPLN_SYSTEM_ID

LEFT JOIN (
    --RP利用状態テーブルのRP利用のフラグ設定したデータを取得
    SELECT
         REG.USER_NO
        ,MAX(CASE
            WHEN M_NIKKEI.RP_ID IS NOT NULL THEN
                1
            ELSE
                0
            END) AS NIKKEI_RP          --日経サービスRP
        ,MAX(CASE
            WHEN M_BP.RP_ID IS NOT NULL THEN
                1
            ELSE
                0
            END) AS BP_RP              --BPサービスRP
    FROM
        {{var.value.redshift_ims_schema_name}}.M_IS_NX_RP_REGISTRATION REG    --RP利用状態テーブル
    LEFT JOIN
        {{var.value.redshift_ims_schema_name}}.M_IMS_RP M_NIKKEI
    ON REG.RP_ID = M_NIKKEI.RP_ID  AND M_NIKKEI.RP_TYPE = '1' AND M_NIKKEI.DELETE_FLG = '0'
    LEFT JOIN
        {{var.value.redshift_ims_schema_name}}.M_IMS_RP M_BP
    ON REG.RP_ID = M_BP.RP_ID AND M_BP.RP_TYPE = '2' AND M_BP.DELETE_FLG = '0'
    WHERE
         REG.REG_STATUS = '1'          --ステータス
    GROUP BY REG.USER_NO
    ) RP_REGIST
        ON NI.IS_会員番号 = RP_REGIST.USER_NO
WHERE
    NI.IS_シリアルID IS NOT NULL
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
HEADER
DELIMITER AS '\t'
GZIP
NULL AS ''
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
