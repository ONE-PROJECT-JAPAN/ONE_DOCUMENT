DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_IMS_HK_DAILY_REPORT_SS
WHERE SNAPSHOT_DATE = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))
;


INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_HK_DAILY_REPORT_SS
(
      SNAPSHOT_DATE
    , DSP_USERNUM_KBN
    , HON_SHISHA_CD
    , SUBSCRIPTION_NUM
    , SUBSCRIPTION_NUM_MONTH
    , SUBSCRIPTION_NUM_MONTH_YEAR_AGO
    , INS_PGM_ID
    , INS_DT_TM
    , UPD_PGM_ID
    , UPD_DT_TM
)
SELECT 
      A.SNAPSHOT_DATE
    , A.DSP_USERNUM_KBN
    , A.HON_SHISHA_CD
    , SUM(A.SUBSCRIPTION_NUM)                AS SUBSCRIPTION_NUM
    , SUM(A.SUBSCRIPTION_NUM_MONTH)          AS SUBSCRIPTION_NUM_MONTH 
    , SUM(A.SUBSCRIPTION_NUM_MONTH_YEAR_AGO) AS SUBSCRIPTION_NUM_MONTH_YEAR_AGO 
    
    , '{{ dag.dag_id }}'
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    , '{{ dag.dag_id }}'
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM (
SELECT
      DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}')) AS SNAPSHOT_DATE
    , S.DSP_USERNUM_KBN
    , S.HON_SHISHA_CD
    , CASE
             WHEN TO_CHAR(S.RECEPTION_DATE, 'yyyyMMdd') = TO_CHAR({{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() - 1, 'yyyyMMdd')
             THEN 1
             ELSE 0
         END AS SUBSCRIPTION_NUM
    , CASE
             WHEN TO_CHAR(S.RECEPTION_DATE, 'yyyyMM') = TO_CHAR({{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() - 1, 'yyyyMM')
             THEN 1
             ELSE 0
         END AS SUBSCRIPTION_NUM_MONTH
    , CASE
             WHEN TO_CHAR(S.RECEPTION_DATE, 'yyyyMM') = TO_CHAR(ADD_MONTHS({{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() - 1, -12), 'yyyyMM')
             THEN 1
             ELSE 0
         END AS SUBSCRIPTION_NUM_MONTH_YEAR_AGO
FROM
    (
     SELECT
         '01' AS DSP_USERNUM_KBN
         , S1.SUBSCRIPTION_NO
         , C.HON_SHISHA_CD
         , S1.RECEPTION_DATE
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL C LEFT OUTER JOIN
            (
            SELECT
                S.SUBSCRIPTION_NO
                , S.RECEPTION_DATE
                , U.ADDRESS_CD
            FROM
                {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_SUBSCRIPTION S
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_HK_SUBSCRIPTION_BAITAI B ON
                S.SUBSCRIPTION_NO = B.SUBSCRIPTION_NO
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER U ON
                S.USER_NO = U.USER_NO
            WHERE
                S.RECEPTION_PLACE_CD IN ('1001','1100','1200','1300')
            AND S.SUBSCRIPTION_KBN_CD <= 7
            AND S.RECEPTION_CLASS_CD IN (1, 2, 3, 5, 6, 7, 8)
            AND S.UPDATE_KBN <> 3
            AND U.UPDATE_KBN <> 3
            AND B.BAITAI_CD = 10
            ) S1
    ON C.PREFECTURE_CD || C.SHIKUTYOUSON_CD = SUBSTRING(S1.ADDRESS_CD, 1, 5)
    UNION
    
    SELECT
        '01' AS DSP_USERNUM_KBN
        , S1.SUBSCRIPTION_NO
        , C.HON_SHISHA_CD
        , S1.RECEPTION_DATE
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL C LEFT OUTER JOIN
            (
            SELECT
                S.SUBSCRIPTION_NO
                , S.RECEPTION_DATE
                , U.ADDRESS_CD
            FROM
                {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION S
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI B ON
                S.SUBSCRIPTION_NO = B.SUBSCRIPTION_NO
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_USER U ON
                S.USER_NO = U.USER_NO
            WHERE
                S.RECEPTION_PLACE_CD = '1001'
            AND S.SUBSCRIPTION_KBN_CD = 3
            AND S.RECEPTION_CLASS_CD IN (200, 206, 207, 220, 226, 227)
            AND S.UPDATE_KBN <> 3
            AND U.UPDATE_KBN <> 3
            AND B.BAITAI_CD = 10
            ) S1
    ON C.PREFECTURE_CD || C.SHIKUTYOUSON_CD = SUBSTRING(S1.ADDRESS_CD, 1, 5)
    UNION
    
    SELECT
        '02' AS DSP_USERNUM_KBN
        , S1.SUBSCRIPTION_NO
        , C.HON_SHISHA_CD
        , S1.RECEPTION_DATE
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL C LEFT OUTER JOIN
            (
            SELECT
                T.TRIAL_NO AS SUBSCRIPTION_NO
                , T.RECEPTION_DATE
                , U.ADDRESS_CD
            FROM
                {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION T
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.M_HK_SUBSCRIPTION_BAITAI B ON
                T.TRIAL_NO = B.SUBSCRIPTION_NO
            INNER JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER U ON
                T.USER_NO = U.USER_NO
            WHERE
                T.RECEPTION_PLACE_CD IN ('1001','1100','1200','1300')
            AND T.SUBSCRIPTION_KBN_CD <= 7
            AND T.RECEPTION_CLASS_CD IN (1, 4, 5, 6)
            AND T.UPDATE_KBN <> 3
            AND U.UPDATE_KBN <> 3
            AND B.BAITAI_CD = 10
            ) S1
    ON C.PREFECTURE_CD || C.SHIKUTYOUSON_CD = SUBSTRING(S1.ADDRESS_CD, 1, 5)
    UNION
    
    SELECT
        CASE
            WHEN AC.PRODUCT_CD IN ('20101','20102','20301') AND AC.GENDOKU_KBN = 0 THEN '03'
            WHEN AC.PRODUCT_CD IN ('20101','20102','20301') AND AC.GENDOKU_KBN = 1 THEN '04'
            WHEN AC.PRODUCT_CD IN ('20101','20102','20301') AND AC.GENDOKU_KBN = 2 THEN '05'
            WHEN AC.PRODUCT_CD IN ('20201','20203','20401') AND AC.GENDOKU_KBN = 0 THEN '06'
            WHEN AC.PRODUCT_CD IN ('20201','20203','20401') AND AC.GENDOKU_KBN = 1 THEN '07'
            WHEN AC.PRODUCT_CD IN ('20201','20203','20401') AND AC.GENDOKU_KBN = 2 THEN '08'
        END AS DSP_USERNUM_KBN
        , CAST(AC.CONTRACT_SPECIFIC_NO AS VARCHAR(40)) AS SUBSCRIPTION_NO
        , C.HON_SHISHA_CD
        , AC.SUBSCRIPTION_DATE AS RECEPTION_DATE
    FROM
        {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO_CL_AC AC
    LEFT OUTER JOIN {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_CONTROL C
    ON SUBSTRING(NVL(AC.DELIVERY_ADDRESS_CD,'     '), 1, 5) = C.PREFECTURE_CD || C.SHIKUTYOUSON_CD
    WHERE   AC.CONTRACT_FLG = '1'
    AND AC.CL_END_DT = '9999/12/31'
    AND AC.PRODUCT_CD IN ('20101','20102','20301','20201','20203','20401')
    AND AC.GENDOKU_KBN IN ('0', '1', '2')
    AND AC.SUBSCRIPTION_DATE IS NOT NULL
    AND AC.SUBSCRIPTION_CLASS_CD IN ('A','B')
    ) S
)A
GROUP BY
  A.SNAPSHOT_DATE
, A.DSP_USERNUM_KBN
, A.HON_SHISHA_CD
;