/*******************************************************************************
  SQL名:
    イベント参加者データクレンジング・取込

  処理概要:
       下記の順で処理を実施する
       #01 一時イベント参加者クレンジング　作成
       #02 一時イベント参加者クレンジング　ロード
       #03 イベント参加者取込管理　更新
       #04 イベント参加者クレンジング　削除
       #05 イベント参加者クレンジング　挿入
       #06 シーケンス番号　更新

*******************************************************************************/


/*******************************************************************************
  #01 一時イベント参加者クレンジング　作成
*******************************************************************************/
CREATE TEMP TABLE T_BJ_EVENT_PARTICIPANT_CL_EXT
(
     ROWID_IF          BIGINT
    ,NAME              VARCHAR(2040)
    ,ZIPCODE           VARCHAR(40)
    ,ADDRESS           VARCHAR(3020)
    ,PHONE             VARCHAR(180)
    ,ADDR_CL_ADDR      VARCHAR(5296)
    ,ADDR_CL_PREFEC    VARCHAR(16)
    ,ADDR_CL_CITY      VARCHAR(80)
    ,ADDR_CL_TSUSHO    VARCHAR(400)
    ,ADDR_CL_CHOME     VARCHAR(2000)
    ,ADDR_CL_ADDR1     VARCHAR(5296)
    ,ADDR_CL_ADDR2     VARCHAR(5296)
    ,ADDR_CL_ADDR3     VARCHAR(5296)
    ,ADDR_CL_ADDR_CD   VARCHAR(80)
    ,ZIPCODE_CL        VARCHAR(44)
    ,PHONE_CL          VARCHAR(1020)
    ,NAME_CL_LAST_NM   VARCHAR(1020)
    ,NAME_CL_FIRST_NM  VARCHAR(1020)
    ,NAME_CL_NM        VARCHAR(1020)
    ,NAME_CL_CORP_NM   VARCHAR(1020)
    ,NAME_CL_DEPT_NM   VARCHAR(400)
)
;


/*******************************************************************************
  #02 一時イベント参加者クレンジング　ロード
*******************************************************************************/
copy T_BJ_EVENT_PARTICIPANT_CL_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/W_BJ_EVENT_PARTICIPANT_CL_CL/W_BJ_EVENT_PARTICIPANT_CL_'
iam_role '{{ var.value.redshift_default_role_arn }}'
format as csv
delimiter ','
quote '"'
;


/*******************************************************************************
  #03 イベント参加者取込管理　更新
*******************************************************************************/
UPDATE {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_LOAD_MNG
SET
     LOAD_STATUS_CD = 1
     , LOAD_COMP_TIMESTAMP = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
     , LOAD_SUCCESS_NUM = ( select count(*) from T_BJ_EVENT_PARTICIPANT_CL_EXT )
     , UPD_PGM_ID = '{{ dag.dag_id }}'
     , UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE
     EVENT_ID = '{{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='event_id') }}'
;


/*******************************************************************************
  #04 イベント参加者クレンジング　削除
*******************************************************************************/
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL
WHERE
     EVENT_ID = '{{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='event_id') }}'
;


/*******************************************************************************
  #05 イベント参加者クレンジング　挿入
*******************************************************************************/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL
(
     EVENT_ID
    ,PARTICIPANT_ID
    ,EMAIL
    ,CLKEY_EMAIL
    ,EMAIL_CL
    ,NIKKEI_MEMBER_NO
    ,LAST_NAME
    ,FIRST_NAME
    ,CLKEY_LAST_NAME
    ,CLKEY_FIRST_NAME
    ,NAME_CL_LAST_NM
    ,NAME_CL_FIRST_NM
    ,NAME_CL_NM
    ,LAST_KANA_NAME
    ,FIRST_KANA_NAME
    ,HOME_PHONE
    ,HOME_FAX
    ,HOME_COUNTRY
    ,HOME_ZIPCODE
    ,HOME_ADDR1
    ,HOME_ADDR2
    ,INDUSTRY
    ,JOB
    ,COMPANY
    ,WORK_EMAIL
    ,WORK_COUNTRY
    ,WORK_ZIPCODE
    ,CLKEY_ZIPCODE
    ,ZIPCODE_CL
    ,WORK_ADDR1
    ,WORK_ADDR2
    ,CLKEY_ADDR1
    ,CLKEY_ADDR2
    ,ADDR_CL_ADDR
    ,ADDR_CL_PREFEC
    ,ADDR_CL_CITY
    ,ADDR_CL_TSUSHO
    ,ADDR_CL_CHOME
    ,ADDR_CL_ADDR1
    ,ADDR_CL_ADDR2
    ,ADDR_CL_ADDR3
    ,ADDR_CL_ADDR_CD
    ,WORK_PHONE
    ,CLKEY_PHONE
    ,PHONE_CL
    ,WORK_FAX
    ,WORK_DEPARTMENT
    ,WORK_TITLE_CODE
    ,WORK_TITLE
    ,GENDER
    ,BIRTHDAY
    ,SECONDARY_USE_SIGN
    ,CHECKIN_STATUS
    ,ACQUISITION_DATE
    ,GENERAL_ITEM_1
    ,GENERAL_ITEM_2
    ,GENERAL_ITEM_3
    ,GENERAL_ITEM_4
    ,GENERAL_ITEM_5
    ,GENERAL_ITEM_6
    ,GENERAL_ITEM_7
    ,GENERAL_ITEM_8
    ,GENERAL_ITEM_9
    ,GENERAL_ITEM_10
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
 SELECT
     M.EVENT_ID
    ,ROW_NUMBER() OVER(ORDER BY EVENT_ID ASC) + S.SEQ_NO AS PARTICIPANT_ID
    ,W.EMAIL
    ,W.EMAIL
    ,LOWER(W.EMAIL)
    ,W.NIKKEI_MEMBER_NO
    ,W.LAST_NAME
    ,W.FIRST_NAME
    ,W.LAST_NAME
    ,W.FIRST_NAME
    ,NULLIF(EXT.NAME_CL_LAST_NM, '') AS NAME_CL_LAST_NM
    ,NULLIF(EXT.NAME_CL_FIRST_NM, '') AS NAME_CL_FIRST_NM
    ,NULLIF(EXT.NAME_CL_NM, '') AS NAME_CL_NM
    ,W.LAST_KANA_NAME
    ,W.FIRST_KANA_NAME
    ,W.HOME_PHONE
    ,W.HOME_FAX
    ,W.HOME_COUNTRY
    ,W.HOME_ZIPCODE
    ,W.HOME_ADDR1
    ,W.HOME_ADDR2
    ,W.INDUSTRY
    ,W.JOB
    ,W.COMPANY
    ,W.WORK_EMAIL
    ,W.WORK_COUNTRY
    ,W.WORK_ZIPCODE
    ,CASE WHEN W.WORK_ADDR1 IS NULL THEN W.HOME_ZIPCODE ELSE W.WORK_ZIPCODE END AS CLKEY_ZIPCODE
    ,NULLIF(EXT.ZIPCODE_CL, '') AS ZIPCODE_CL
    ,W.WORK_ADDR1
    ,W.WORK_ADDR2
    ,CASE WHEN W.WORK_ADDR1 IS NULL THEN W.HOME_ADDR1 ELSE W.WORK_ADDR1 END AS CLKEY_ADDR1
    ,CASE WHEN W.WORK_ADDR1 IS NULL THEN W.HOME_ADDR2 ELSE W.WORK_ADDR2 END AS CLKEY_ADDR2
    ,NULLIF(EXT.ADDR_CL_ADDR, '') AS ADDR_CL_ADDR
    ,NULLIF(EXT.ADDR_CL_PREFEC, '') AS ADDR_CL_PREFEC
    ,NULLIF(EXT.ADDR_CL_CITY, '') AS ADDR_CL_CITY
    ,NULLIF(EXT.ADDR_CL_TSUSHO, '') AS ADDR_CL_TSUSHO
    ,NULLIF(EXT.ADDR_CL_CHOME, '') AS ADDR_CL_CHOME
    ,NULLIF(EXT.ADDR_CL_ADDR1, '') AS ADDR_CL_ADDR1
    ,NULLIF(EXT.ADDR_CL_ADDR2, '') AS ADDR_CL_ADDR2
    ,NULLIF(EXT.ADDR_CL_ADDR3, '') AS ADDR_CL_ADDR3
    ,NULLIF(EXT.ADDR_CL_ADDR_CD, '') AS ADDR_CL_ADDR_CD
    ,W.WORK_PHONE
    ,CASE WHEN W.WORK_ADDR1 IS NULL THEN W.HOME_PHONE ELSE W.WORK_PHONE END AS CLKEY_PHONE
    ,NULLIF(EXT.PHONE_CL, '') AS PHONE_CL
    ,W.WORK_FAX
    ,W.WORK_DEPARTMENT
    ,W.WORK_TITLE_CODE
    ,W.WORK_TITLE
    ,W.GENDER
    ,TO_DATE(W.BIRTHDAY,'yyyy-mm-dd') as BIRTHDAY
    ,W.SECONDARY_USE_SIGN
    ,W.CHECKIN_STATUS
    ,TO_DATE(W.ACQUISITION_DATE,'yyyy-mm-dd') as ACQUISITION_DATE
    ,W.GENERAL_ITEM_1
    ,W.GENERAL_ITEM_2
    ,W.GENERAL_ITEM_3
    ,W.GENERAL_ITEM_4
    ,W.GENERAL_ITEM_5
    ,W.GENERAL_ITEM_6
    ,W.GENERAL_ITEM_7
    ,W.GENERAL_ITEM_8
    ,W.GENERAL_ITEM_9
    ,W.GENERAL_ITEM_10
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    (
      SELECT 
         EVENT_ID 
      FROM 
         {{ var.value.redshift_ims_schema_name }}.M_BJ_EVENT 
      WHERE 
          DELETE_FLG = FALSE
      AND
          EVENT_ID = '{{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='event_id') }}'
     ) AS M
    ,(
      SELECT 
         SEQ_NO 
      FROM 
         {{ var.value.redshift_ims_schema_name }}.M_IMS_SEQUENCE 
      WHERE 
          SEQ_NAME = 'SEQ_BJ_PARTICIPANT_ID01'
     ) AS S
     ,{{ var.value.redshift_ims_schema_name }}.W_BJ_EVENT_PARTICIPANT W
INNER JOIN
    T_BJ_EVENT_PARTICIPANT_CL_EXT EXT
ON
    W.ROWID = EXT.ROWID_IF
;


/*******************************************************************************
  #06 シーケンス番号　更新
*******************************************************************************/
UPDATE {{ var.value.redshift_ims_schema_name }}.M_IMS_SEQUENCE
SET SEQ_NO = (SELECT max(PARTICIPANT_ID) FROM {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL WHERE EVENT_ID = '{{ ti.xcom_pull(task_ids='edit_t_bj_event_participant_cl', key='event_id') }}')
WHERE SEQ_NAME = 'SEQ_BJ_PARTICIPANT_ID01' 
;

