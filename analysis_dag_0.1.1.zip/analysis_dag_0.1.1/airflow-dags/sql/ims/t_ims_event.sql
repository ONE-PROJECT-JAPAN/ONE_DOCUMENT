
/*******************************************************************************
  SQL名:
    統合イベント情報作成

  処理概要:
       統合イベント情報ビューを元に、統合イベント情報を作成する。
*******************************************************************************/

--全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_IMS_EVENT
;

--挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_EVENT
(
     EVENT_SYSTEM_ID
    ,EVENT_ID
    ,EVENT_NAME
    ,CATEGORY_NAME
    ,SUB_CATEGORY_NAME
    ,EVENT_START_DATE
    ,FREE_EVENT_FLG
)
SELECT
     EVENT_SYSTEM_ID
    ,EVENT_ID
    ,EVENT_NAME
    ,CATEGORY_NAME
    ,SUB_CATEGORY_NAME
    ,EVENT_START_DATE
    ,FREE_EVENT_FLG
FROM
    {{ var.value.redshift_ims_schema_name }}.V_IMS_EVENT
;
