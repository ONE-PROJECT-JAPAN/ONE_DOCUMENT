-- shift-jis, CRLF
UNLOAD ($$
SELECT
    SUBSCRIPTION_MONTH
  , SUBSCRIPTION_DATE
  , SUBSCRIPTION_TIME
  , NIKKEI_MEMBER_NO
  , PRODUCT_CD
  , CHOISES_1
  , ANSWER_1
  , CHOISES_2
  , ANSWER_2
  , CHOISES_3
  , ANSWER_3
  , CHOISES_4
  , ANSWER_4
  , CHOISES_5
  , ANSWER_5
  , CHOISES_6
  , ANSWER_6
  , CHOISES_7
  , ANSWER_7
  , CHOISES_8
  , ANSWER_8
  , CHOISES_9
  , ANSWER_9
  , CHOISES_10
  , ANSWER_10
  , CHOISES_11
  , ANSWER_11
  , CHOISES_12
  , ANSWER_12
  , CHOISES_13
  , ANSWER_13
  , CHOISES_14
  , ANSWER_14
  , CHOISES_15
  , ANSWER_15
  , CHOISES_16
  , ANSWER_16
  , CHOISES_17
  , ANSWER_17
  , CHOISES_18
  , ANSWER_18
  , CHOISES_19
  , ANSWER_19
  , CHOISES_20
  , ANSWER_20
  , ANSWER_21
  , ADDRESS_CD
  , STORE_CD
  , CONTRACT_SPECIFIC_ID
  , PREFEC
  , SEX
  , AGE
  , OCCUPATION_NAME
  , PRICEPLN_NAME
FROM (
  SELECT
       '申込月'                                                                 AS SUBSCRIPTION_MONTH
    ,  '申込日'                                                                 AS SUBSCRIPTION_DATE
    ,  '申込時'                                                                 AS SUBSCRIPTION_TIME
    ,  '日経ID内部会員番号'                                                     AS NIKKEI_MEMBER_NO
    ,  '商品CD'                                                                 AS PRODUCT_CD
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910001' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_1
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910001' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_1
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910002' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_2
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910002' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_2
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910003' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_3
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910003' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_3
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910004' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_4
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910004' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_4
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910005' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_5
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910005' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_5
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910006' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_6
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910006' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_6
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910007' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_7
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910007' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_7
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910008' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_8
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910008' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_8
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910009' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_9
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910009' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_9
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910010' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_10
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910010' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_10
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910011' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_11
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910011' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_11
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910012' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_12
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910012' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_12
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910013' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_13
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910013' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_13
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910014' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_14
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910014' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_14
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910015' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_15
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910015' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_15
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910016' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_16
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910016' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_16
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910017' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_17
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910017' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_17
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910018' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_18
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910018' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_18
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910019' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_19
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910019' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_19
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910020' THEN CODE_NAME1 ELSE NULL END),'') AS CHOISES_20
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5910020' THEN CODE_NAME2 ELSE NULL END),'') AS ANSWER_20
    ,  NVL(MAX(CASE WHEN CODE = 'CRM5930001' THEN CODE_NAME1 ELSE NULL END),'') AS ANSWER_21
    ,  '住所CD'                                                                 AS ADDRESS_CD
    ,  '販売店CD'                                                               AS STORE_CD
    ,  '契約特定番号'                                                           AS CONTRACT_SPECIFIC_ID
    ,  'IS_都道府県'                                                            AS PREFEC
    ,  'IS_性別'                                                                AS SEX
    ,  'IS_年齢'                                                                AS AGE
    ,  'IS_職業名'                                                              AS OCCUPATION_NAME
    ,  '料金プラン名'                                                           AS PRICEPLN_NAME
    ,  1                                                                        AS SORT_ORDER
  FROM
    {{var.value.redshift_ims_schema_name}}.M_CRM_CODE
  WHERE
    MASTER_TYPE = 'MST590'
  GROUP BY
      SUBSCRIPTION_MONTH
    , SUBSCRIPTION_DATE
    , SUBSCRIPTION_TIME
    , NIKKEI_MEMBER_NO
    , PRODUCT_CD
    , ADDRESS_CD
    , STORE_CD
    , CONTRACT_SPECIFIC_ID
    , PREFEC
    , SEX
    , AGE
    , OCCUPATION_NAME
    , PRICEPLN_NAME

  UNION ALL
  (
  SELECT
      E.SUBSCRIPTION_MONTH                                                                                                                                                                    AS SUBSCRIPTION_MONTH
    , TO_DATE(E.SUBSCRIPTION_DATE,'YYYYMMDD')::VARCHAR                                                                                                                                        AS SUBSCRIPTION_DATE
    , E.SUBSCRIPTION_TIME                                                                                                                                                                     AS SUBSCRIPTION_TIME
    , E.NIKKEI_MEMBER_NO::VARCHAR                                                                                                                                                             AS NIKKEI_MEMBER_NO
    , E.PRODUCT_CD                                                                                                                                                                            AS PRODUCT_CD
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910001' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_1
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910001' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_1
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910002' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_2
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910002' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_2
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910003' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_3
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910003' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_3
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910004' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_4
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910004' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_4
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910005' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_5
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910005' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_5
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910006' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_6
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910006' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_6
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910007' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_7
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910007' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_7
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910008' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_8
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910008' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_8
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910009' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_9
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910009' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_9
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910010' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_10
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910010' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_10
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910011' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_11
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910011' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_11
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910012' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_12
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910012' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_12
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910013' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_13
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910013' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_13
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910014' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_14
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910014' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_14
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910015' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_15
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910015' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_15
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910016' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_16
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910016' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_16
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910017' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_17
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910017' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_17
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910018' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_18
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910018' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_18
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910019' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_19
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910019' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_19
    , NVL(MAX(CASE WHEN C.CODE = 'CRM5910020' THEN E.ANSWER_1 ELSE NULL END),'')                                                                                                              AS CHOISES_20
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5910020' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_20
    , NVL(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(MAX(CASE WHEN C.CODE = 'CRM5930001' THEN E.ANSWER_2 ELSE NULL END),CHR(34),''),CHR(44),''),CHR(13)||CHR(10),''),CHR(10),''),CHR(13),''),'') AS ANSWER_21
    , E.ADDRESS_CD                                                                                                                                                                            AS ADDRESS_CD
    , E.STORE_CD                                                                                                                                                                              AS STORE_CD
    , E.CONTRACT_SPECIFIC_ID::VARCHAR                                                                                                                                                         AS CONTRACT_SPECIFIC_ID
    , NVL(M.IS_都道府県郵便番号,'')                                                                                                                                                           AS PREFEC
    , NVL(M.IS_性別,'')                                                                                                                                                                       AS SEX
    , NVL(M.IS_年齢,'')                                                                                                                                                                       AS AGE
    , NVL(M.IS_職業名,'')                                                                                                                                                                     AS OCCUPATION_NAME
    , NVL(M.料金プラン名,'')                                                                                                                                                                  AS PRICEPLN_NAME
    , 2                                                                                                                                                                                       AS SORT_ORDER
  FROM
    {{var.value.redshift_ims_schema_name}}.T_PK_CLOSE_ENQUETE E
    INNER JOIN {{var.value.redshift_ims_schema_name}}.M_AD_NIKKEI_ID M
      ON M.IS_会員番号 = E.NIKKEI_MEMBER_NO
    LEFT JOIN (
      SELECT
         CODE
        ,VALUE1
      FROM
        {{var.value.redshift_ims_schema_name}}.M_CRM_CODE
      WHERE
        MASTER_TYPE = 'MST590'
    ) C
      ON C.VALUE1 = E.ANSWER_DISPLAY_ORDER
  WHERE
    E.SUBSCRIPTION_MONTH = TO_CHAR(ADD_MONTHS('{{convUTC2JST(next_execution_date, "%Y-%m-%d")}}', -1), 'YYYYMM')
  GROUP BY
      E.SUBSCRIPTION_MONTH
    , E.SUBSCRIPTION_DATE
    , E.SUBSCRIPTION_TIME
    , E.NIKKEI_MEMBER_NO
    , E.PRODUCT_CD
    , E.ADDRESS_CD
    , E.STORE_CD
    , E.CONTRACT_SPECIFIC_ID
    , M.IS_都道府県郵便番号
    , M.IS_性別
    , M.IS_年齢
    , M.IS_職業名
    , M.料金プラン名
  )
) SUB
ORDER BY
    SORT_ORDER
  , SUBSCRIPTION_DATE
$$)
TO 's3://{{ params.s3_path.format(var.value.sharedfs_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS ','
ADDQUOTES
NULL AS ''
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
