/*

   参照テーブル:
      T_PK_V_CONTRACT_INFO_CL_AC
      T_KK_V_CONTRACT_ANALYZE

*/
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_IMS_DS_PK_SUBSCRIPTION_NUM_SS
WHERE INS_DT_TM = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))
;


INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_DS_PK_SUBSCRIPTION_NUM_SS
(
    SUBSCRIPTION_DATE
    , DATA_KBN
    , DW_NEW_COUNT
    , DDDW_COUNT
    , NS_NEW_COUNT
    , DDNS_COUNT
    , INS_DT_TM
)
WITH base AS (
  SELECT DISTINCT
    NIKKEI_MEMBER_NO
  FROM
    {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO
  WHERE
    DATEADD(day, 1, FIRST_SUBSCRIPTION_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}')) -- 初回申込日：前日
    AND SUBSCRIPTION_CLASS_CD = 'A'               -- 申込種別_C：A（新規申込）
    AND BAITAI_KBN_CD = 'NS'                      -- 媒体区分：NS（日経本紙）
    AND CONTRACT_FLG = '1'                        -- 契約フラグ：１（契約中）
    AND FIRST_GENDOKU_KBN = '0'                   -- 申込時現読区分：0（未読）
) 
, kk_base AS (
  SELECT DISTINCT
    NIKKEI_ID_INTERNAL_MEMBER_NO
    , CASE
      WHEN (
        DATEADD(day, 1, PLAN_START_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))     -- プラン適用開始日が前日
        OR DATEADD(day, 2, PLAN_START_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))  -- プラン適用開始日が前々日
      )
      THEN FALSE
      ELSE TRUE
      END AS UPSEL_FLG
  FROM
    {{ var.value.redshift_ims_schema_name }}.T_KK_V_CONTRACT_ANALYZE
  WHERE
    SERVICE_ID = 'DS00000000001'                  -- サービスＩＤ(日経電子版)
    AND PLAN_FLG = 1                              -- プラン種別(有料)
    AND PLAN_ID = 'DS00000000000002'              -- 料金プランＩＤ(月ぎめプラン)
) 
, kk_out AS (
  SELECT DISTINCT
    NIKKEI_ID_INTERNAL_MEMBER_NO
  FROM
    {{ var.value.redshift_ims_schema_name }}.T_KK_V_CONTRACT_ANALYZE
  WHERE
    DATEADD(day, 1, CHARGED_PLAN_END_REQUEST_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}')) -- 有料プラン解約申込日が前日
    AND DS_REQUEST_TYPE = 9                       -- 電子版操作区分9（解約）
    AND SERVICE_ID = 'DS00000000001'              -- サービスＩＤ(日経電子版)
    AND PLAN_FLG = 1                              -- プラン種別(有料)
    AND PLAN_ID = 'DS00000000000002'              -- 料金プランＩＤ(月ぎめプラン)
) 
SELECT
  DATEADD(day, -1, DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))) AS SUBSCRIPTION_DATE
  , 0 AS DATA_KBN                                 -- 通常
  , (
    SELECT
      count(a.NIKKEI_MEMBER_NO)
    FROM
      base a
      INNER JOIN kk_base b
        ON a.NIKKEI_MEMBER_NO = b.NIKKEI_ID_INTERNAL_MEMBER_NO
        AND UPSEL_FLG = FALSE                     -- 本紙と電子版同時契約
    WHERE
      a.NIKKEI_MEMBER_NO NOT IN (SELECT NIKKEI_ID_INTERNAL_MEMBER_NO FROM kk_out)
  ) AS DW_NEW_COUNT
  , ( 
    SELECT
      COUNT(a.NIKKEI_MEMBER_NO)
    FROM
      base a
      INNER JOIN kk_base b
        ON a.NIKKEI_MEMBER_NO = b.NIKKEI_ID_INTERNAL_MEMBER_NO
        AND UPSEL_FLG = TRUE                      -- 電子版契約が2日以上早い
    WHERE
      a.NIKKEI_MEMBER_NO NOT IN (SELECT NIKKEI_ID_INTERNAL_MEMBER_NO FROM kk_out)
  ) AS DDDW_COUNT
  , ( 
    SELECT
      COUNT(a.NIKKEI_MEMBER_NO)
    FROM
      base a
    WHERE
      a.NIKKEI_MEMBER_NO NOT IN (SELECT NIKKEI_ID_INTERNAL_MEMBER_NO FROM kk_base)
      AND a.NIKKEI_MEMBER_NO NOT IN (SELECT NIKKEI_ID_INTERNAL_MEMBER_NO FROM kk_out)
  ) AS NS_NEW_COUNT
  , ( 
    SELECT
      COUNT(a.NIKKEI_MEMBER_NO)
    FROM
      base a
      INNER JOIN kk_out b
        ON a.NIKKEI_MEMBER_NO = b.NIKKEI_ID_INTERNAL_MEMBER_NO
  ) AS DDNS_COUNT
  , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_DS_PK_SUBSCRIPTION_NUM_SS
(
    SUBSCRIPTION_DATE
    , DATA_KBN
    , DW_NEW_COUNT
    , DDDW_COUNT
    , NS_NEW_COUNT
    , DDNS_COUNT
    , INS_DT_TM
)
WITH base AS (
  SELECT DISTINCT
    NIKKEI_MEMBER_NO
  FROM
    {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO
  WHERE
    DATEADD(day, 2, FIRST_SUBSCRIPTION_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}')) -- 初回申込日：前々日
    AND SUBSCRIPTION_CLASS_CD = 'A'               -- 申込種別_C：A（新規申込）
    AND BAITAI_KBN_CD = 'NS'                      -- 媒体区分：NS（日経本紙）
    AND CONTRACT_FLG = '1'                        -- 契約フラグ：１（契約中）
    AND FIRST_GENDOKU_KBN = '0'                   -- 申込時現読区分：0（未読）
) 
, kk_base AS (
  SELECT DISTINCT
    NIKKEI_ID_INTERNAL_MEMBER_NO
  FROM
    {{ var.value.redshift_ims_schema_name }}.T_KK_V_CONTRACT_ANALYZE
  WHERE
    SERVICE_ID = 'DS00000000001'                  -- サービスＩＤ(日経電子版)
    AND PLAN_FLG = 1                              -- プラン種別(有料)
    AND PLAN_ID = 'DS00000000000002'              -- 料金プランＩＤ(月ぎめプラン)
    AND DATEADD(day, 1, PLAN_START_DATE) = DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))     -- プラン適用開始日が前日
) 
SELECT
  DATEADD(day, -2, DATE(convert_timezone('UTC', 'JST', '{{ next_execution_date }}'))) AS SUBSCRIPTION_DATE
  , 1 AS DATA_KBN                                 -- 調整
  , count(a.NIKKEI_MEMBER_NO) AS DW_NEW_COUNT
  , 0 AS DDDW_COUNT
  , 0 - count(a.NIKKEI_MEMBER_NO) AS DW_NEW_COUNT
  , 0 AS DDNS_COUNT
  ,  CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM 
FROM
  base a
  INNER JOIN kk_base b
    ON a.NIKKEI_MEMBER_NO = b.NIKKEI_ID_INTERNAL_MEMBER_NO
;
