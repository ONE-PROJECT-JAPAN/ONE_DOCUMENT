-- テーブル構築管理更新
MERGE
    {{params.dataset_name}}.T_IMS_TABLE_UPDATE_MNG DST
USING
    (
        SELECT '{{params.table_name}}' AS TABLE_NAME
    ) SRC 
ON
    DST.TABLE_NAME = SRC.TABLE_NAME
WHEN MATCHED THEN
    UPDATE SET
        EXEC_BATCH_DATE = {{params.dataset_name}}.F_BATCH_DATE()
      , UPD_DT_TM = CURRENT_DATETIME('Asia/Tokyo')
WHEN NOT MATCHED THEN
    INSERT
    (
        TABLE_NAME
      , EXEC_BATCH_DATE
      , UPD_DT_TM
    )
    VALUES
    (
        '{{params.table_name}}'
      , {{params.dataset_name}}.F_BATCH_DATE()
      , CURRENT_DATETIME('Asia/Tokyo')
    )
;