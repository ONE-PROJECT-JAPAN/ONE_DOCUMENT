UNLOAD ($$
SELECT
      NVL(m3.OUTER_SEMINAR_ID || ':' || m3.MAIN_TITLE    ::VARCHAR, '') AS "VF_日経ビジネススクール講座申込"
    , NVL(m2."IS_日経ID会員番号_表示用"                  ::VARCHAR, '') AS "IS_日経ID会員番号_表示用"
    , NVL(m2."IS_性別"                                   ::VARCHAR, '') AS "IS_性別"
    , NVL(m2."VF_年齢"                                   ::VARCHAR, '') AS "VF_年齢"
    , NVL(m2."IS_都道府県(郵便番号)"                     ::VARCHAR, '') AS "IS_都道府県(郵便番号)"
    , NVL(m2."IS_職業名"                                 ::VARCHAR, '') AS "IS_職業名"
    , NVL(m2."IS_職種名"                                 ::VARCHAR, '') AS "IS_職種名"
    , NVL(m2."IS_業種名"                                 ::VARCHAR, '') AS "IS_業種名"
    , NVL(m2."IS_役職名"                                 ::VARCHAR, '') AS "IS_役職名"
    , NVL(m2."IS_従業員規模"                             ::VARCHAR, '') AS "IS_従業員規模"
    , NVL(m2."IS_勤務先・学校"                           ::VARCHAR, '') AS "IS_勤務先・学校"
    , NVL(m1.COMPANY_BUSINESS_UNIT                       ::VARCHAR, '') AS "所属される部署名"
    , NVL(m1.SYSTEM_SEMINAR_ID                           ::VARCHAR, '') AS "講座内部ID"
    , NVL(m1.PAYMENT_DATE                                ::VARCHAR, '') AS "申し込み日時"
    , NVL(m1.PAYMENT_ID                                  ::VARCHAR, '') AS "申し込みID"
    , NVL(m3.PRICE_WITH_TAX                              ::VARCHAR, '') AS "受講料（税込）"
    , NVL(m3.SEMINAR_DATE                                ::VARCHAR, '') AS "開催日"
    , NVL(m3.DISPLAY_CAPACITY                            ::VARCHAR, '') AS "定員数（表示用）"
FROM {{var.value.redshift_ims_schema_name}}.T_BA_V_SEMINAR_PAYMENT_ACCUM AS m1
LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.T_BA_V_SEMINAR_HONBAN AS m3
    ON m1.SYSTEM_SEMINAR_ID = m3.SYSTEM_SEMINAR_ID
LEFT OUTER JOIN
    (
        SELECT
              ATTR_INTERNAL_ID                                                   AS "日経ＩＤ会員番号"
            , MAX(CASE WHEN ATTR_ID = 2 THEN ATTR_VALUE_CHAR ELSE NULL END)      AS "オープン化ユーザID"
            , MAX(CASE WHEN ATTR_ID = 3 THEN ATTR_VALUE_CHAR ELSE NULL END)      AS "ビジネススクールメールの配信"
            , MAX(CASE WHEN ATTR_ID = 4 THEN ATTR_VALUE_CHAR ELSE NULL END)      AS "解約フラグ"
            , MAX(CASE WHEN ATTR_ID = 5 THEN ATTR_VALUE_TIMESTAMP ELSE NULL END) AS "登録日時"
            , MAX(CASE WHEN ATTR_ID = 6 THEN ATTR_VALUE_TIMESTAMP ELSE NULL END) AS "更新日時"
        FROM
            {{var.value.redshift_ims_schema_name}}.T_GP_ATTR_AC
        WHERE
            TABLE_ID = 6
        GROUP BY
            ATTR_INTERNAL_ID
    ) AS m2a
ON m2a."オープン化ユーザID" = m1.SITE_MEMBER_ID
LEFT OUTER JOIN
       (
         SELECT
              TRIM(TO_CHAR(m2t.USER_NO,'0000000000')) AS "IS_日経ID会員番号_表示用"
            , m2s."IS_性別"
            , CASE WHEN m2s."IS_生年月日" <> '18680101' THEN TRUNC((TO_CHAR(current_date,'YYYYMMDD') - TO_CHAR(to_date(m2s."IS_生年月日",'YYYYMMDD'), 'YYYYMMDD')) /10000, 0) ELSE NULL END AS "VF_年齢"
            , m2s."IS_都道府県郵便番号" AS "IS_都道府県(郵便番号)"
            , m2s."IS_職業名"
            , m2s."IS_職種名"
            , m2s."IS_業種名"
            , m2s."IS_役職名"
            , m2s."IS_従業員規模"
            , m2t.COMPANY_NAME AS "IS_勤務先・学校"
            , m2s."IS_会員番号"
               FROM {{var.value.redshift_ims_schema_name}}.M_AD_NIKKEI_ID AS m2s
               INNER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_ATTRIBUTE AS m2t
                   ON m2s."IS_会員番号" = m2t.USER_NO
       ) AS m2
ON m2."IS_会員番号" = m2a."日経ＩＤ会員番号"
WHERE
    m3.OUTER_SEMINAR_ID IS NOT NULL AND m3.MAIN_TITLE IS NOT NULL
$$)
TO 's3://{{ params.s3_path.format(var.value.sharedfs_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS ','
ADDQUOTES
NULL AS ''
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
