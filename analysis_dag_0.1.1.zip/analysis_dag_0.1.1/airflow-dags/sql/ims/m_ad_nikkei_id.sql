
/*******************************************************************************
  SQL名:
    広告配信新日経統合IDマスタ

  処理概要:
       V_新日経統合ＩＤマスタビュー、シリアルIDテーブル、
       全配信先不達管理、メール設定情報ビューを元に集約し、
       広告配信新日経統合IDマスタにデータを蓄積する
*******************************************************************************/

CREATE TEMPORARY TABLE TEMP_AD_NIKKEI_ID (
    "IS_会員番号" BIGINT ,
    "IS_メールアドレスID" VARCHAR(1024) ,
    "IS_姓漢字" VARCHAR(240) ,
    "IS_名漢字" VARCHAR(240) ,
    "IS_海外居住フラグ" VARCHAR(32) ,
    "IS_居住国コード" VARCHAR(12) ,
    "IS_国名" VARCHAR(400) ,
    "IS_性別" VARCHAR(16) ,
    "IS_生年月日" VARCHAR(32) ,
    "IS_職業NO" VARCHAR(12) ,
    "IS_職業名" VARCHAR(200) ,
    "IS_業種NO" VARCHAR(12) ,
    "IS_業種名" VARCHAR(200) ,
    "IS_職種NO" VARCHAR(12) ,
    "IS_職種名" VARCHAR(200) ,
    "IS_役職NO" VARCHAR(12) ,
    "IS_役職名" VARCHAR(200) ,
    "IS_従業員規模NO" VARCHAR(12) ,
    "IS_従業員規模" VARCHAR(1020) ,
    "IS_世帯収入NO" VARCHAR(12) ,
    "IS_世帯収入" VARCHAR(1020) ,
    "IS_新聞購読状況１" VARCHAR(24) ,
    "IS_新聞購読状況２" VARCHAR(24) ,
    "IS_新聞購読状況３" VARCHAR(24) ,
    "IS_新聞購読状況４" VARCHAR(24) ,
    "IS_新聞購読状況５" VARCHAR(24) ,
    "IS_新聞購読状況サマリフラグ" VARCHAR(112) ,
    "IS_興味関心項目１" VARCHAR(40) ,
    "IS_興味関心項目２" VARCHAR(40) ,
    "IS_興味関心項目３" VARCHAR(40) ,
    "IS_興味関心項目４" VARCHAR(40) ,
    "IS_興味関心項目５" VARCHAR(40) ,
    "IS_興味関心項目６" VARCHAR(40) ,
    "IS_興味関心項目７" VARCHAR(40) ,
    "IS_興味関心項目８" VARCHAR(40) ,
    "IS_興味関心項目９" VARCHAR(40) ,
    "IS_興味関心項目１０" VARCHAR(40) ,
    "IS_興味関心項目１１" VARCHAR(40) ,
    "IS_興味関心項目１２" VARCHAR(40) ,
    "IS_興味関心項目１３" VARCHAR(40) ,
    "IS_日経メール許諾フラグ" VARCHAR(56) ,
    "IS_第三者メール許諾フラグ" VARCHAR(64) ,
    "IS_日経IDリサーチモニターフラグ" VARCHAR(72) ,
    "IS_ユーザタイプ" VARCHAR(56) ,
    "IS_入会日" TIMESTAMP ,
    "IS_退会日" TIMESTAMP ,
    "IS_退会フラグ" VARCHAR(32) ,
    "料金プランシステムID" VARCHAR(8) ,
    "料金プランコード" VARCHAR(64) ,
    "料金プラン名" VARCHAR(720) ,
    "料金プラン区分" VARCHAR(8) ,
    "料金プラン区分名" VARCHAR(360) ,
    "解約申込予約フラグ" VARCHAR(80) ,
    "変更解約申込予約フラグ" VARCHAR(80) ,
    "IS_都道府県郵便番号" VARCHAR(16) ,
    "IS_シリアルID" VARCHAR(40) ,
    "IS_年代" VARCHAR(80) ,
    "IS_年齢" VARCHAR(80) ,
    "MC_不達メールフラグ" INTEGER ,
    "DSYM_ニュースメール情報速報フラグ_PC" INTEGER ,
    "DSYM_ニュースメール情報速報フラグ_CP" INTEGER ,
    "DSYM_ニュースメール情報主要ニュースフラグ_PC" INTEGER ,
    "DSYM_ニュースメール情報主要ニュースフラグ_CP" INTEGER ,
    "DSYM_ニュースメール情報日経ニュースフラグ_PC" INTEGER ,
    "DSYM_ニュースメール情報日経ニュースフラグ_CP" INTEGER ,
    "DSYM_MY日経メールフラグ_PC" INTEGER ,
    "DSYM_MY日経メールフラグ_CP" INTEGER ,
    "DSYM_ニュースメール情報速報夜間無しフラグ_PC" INTEGER ,
    "DSYM_ニュースメール情報速報夜間無しフラグ_CP" INTEGER ,
    "DSYM_メールマガジン情報電子版フラグ_PC" INTEGER ,
    "DSYM_メールマガジン情報電子版フラグ_CP" INTEGER ,
    "DSYM_電子版お知らせ許諾フラグ" INTEGER ,
    "DSYM_NIKKEI_Briefingメール許諾フラグ" INTEGER ,
    "DSG_Myグループ更新通知メール送信フラグ_PC" INTEGER ,
    "IS_移行元サイト" VARCHAR(40) ,
    "IS_移行ステータス" VARCHAR(4) ,
    "BIZアカデミー会員フラグ" INTEGER ,
    "お試し会員フラグ" INTEGER ,
    "お試し利用実績フラグ" INTEGER ,
    "日経ストア会員フラグ" INTEGER ,
    "SS区分" INTEGER ,
    "SS解約申込予約フラグ" INTEGER ,
    "MJ区分" INTEGER ,
    "MJ解約申込予約フラグ" INTEGER ,
    "NB区分" INTEGER ,
    "NB解約申込予約フラグ" INTEGER ,
    "オプション契約フラグ" INTEGER ,
    "JW区分" INTEGER ,
    "JW解約申込予約フラグ" INTEGER ,
    "PRV区分" INTEGER ,
    "PRV解約申込予約フラグ" INTEGER ,
    "グループライセンス料金プランコード" VARCHAR(64) ,
    "グループ機能利用可能フラグ" INTEGER ,
    "課金開始日" DATE ,
    "課金区分" INTEGER ,
    "初回申込無料期間中フラグ" INTEGER ,
    INS_BATCH_ID VARCHAR(100) ,
    INS_DT_TM TIMESTAMP ,
    UPD_BATCH_ID VARCHAR(100) ,
    UPD_DT_TM TIMESTAMP )
    DISTSTYLE KEY 
    DISTKEY ("IS_会員番号") 
;

INSERT INTO TEMP_AD_NIKKEI_ID
(
     "IS_会員番号"
    ,"IS_メールアドレスID"
    ,"IS_姓漢字"
    ,"IS_名漢字"
    ,"IS_海外居住フラグ"
    ,"IS_居住国コード"
    ,"IS_国名"
    ,"IS_性別"
    ,"IS_生年月日"
    ,"IS_職業NO"
    ,"IS_職業名"
    ,"IS_業種NO"
    ,"IS_業種名"
    ,"IS_職種NO"
    ,"IS_職種名"
    ,"IS_役職NO"
    ,"IS_役職名"
    ,"IS_従業員規模NO"
    ,"IS_従業員規模"
    ,"IS_世帯収入NO"
    ,"IS_世帯収入"
    ,"IS_新聞購読状況１"
    ,"IS_新聞購読状況２"
    ,"IS_新聞購読状況３"
    ,"IS_新聞購読状況４"
    ,"IS_新聞購読状況５"
    ,"IS_新聞購読状況サマリフラグ"
    ,"IS_興味関心項目１"
    ,"IS_興味関心項目２"
    ,"IS_興味関心項目３"
    ,"IS_興味関心項目４"
    ,"IS_興味関心項目５"
    ,"IS_興味関心項目６"
    ,"IS_興味関心項目７"
    ,"IS_興味関心項目８"
    ,"IS_興味関心項目９"
    ,"IS_興味関心項目１０"
    ,"IS_興味関心項目１１"
    ,"IS_興味関心項目１２"
    ,"IS_興味関心項目１３"
    ,"IS_日経メール許諾フラグ"
    ,"IS_第三者メール許諾フラグ"
    ,"IS_日経IDリサーチモニターフラグ"
    ,"IS_ユーザタイプ"
    ,"IS_入会日"
    ,"IS_退会日"
    ,"IS_退会フラグ"
    ,"料金プランシステムID"
    ,"料金プランコード"
    ,"料金プラン名"
    ,"料金プラン区分"
    ,"料金プラン区分名"
    ,"解約申込予約フラグ"
    ,"変更解約申込予約フラグ"
    ,"IS_都道府県郵便番号"
    ,"IS_シリアルID"
    ,"IS_年代"
    ,"IS_年齢"
    ,"MC_不達メールフラグ"
    ,"DSYM_ニュースメール情報速報フラグ_PC"
    ,"DSYM_ニュースメール情報速報フラグ_CP"
    ,"DSYM_ニュースメール情報主要ニュースフラグ_PC"  -- 廃止につき0固定
    ,"DSYM_ニュースメール情報主要ニュースフラグ_CP"  -- 廃止につき0固定
    ,"DSYM_ニュースメール情報日経ニュースフラグ_PC"
    ,"DSYM_ニュースメール情報日経ニュースフラグ_CP"
    ,"DSYM_MY日経メールフラグ_PC"
    ,"DSYM_MY日経メールフラグ_CP"
    ,"DSYM_ニュースメール情報速報夜間無しフラグ_PC"
    ,"DSYM_ニュースメール情報速報夜間無しフラグ_CP"
    ,"DSYM_メールマガジン情報電子版フラグ_PC"  -- 廃止につき0固定
    ,"DSYM_メールマガジン情報電子版フラグ_CP"  -- 廃止につき0固定
    ,"DSYM_電子版お知らせ許諾フラグ"
    ,"DSYM_NIKKEI_Briefingメール許諾フラグ"
    ,"DSG_Myグループ更新通知メール送信フラグ_PC"
    ,"IS_移行元サイト"
    ,"IS_移行ステータス"
    ,"BIZアカデミー会員フラグ"
    ,"お試し会員フラグ"
    ,"お試し利用実績フラグ"
    ,"日経ストア会員フラグ"
    ,"SS区分"
    ,"SS解約申込予約フラグ"
    ,"MJ区分"
    ,"MJ解約申込予約フラグ"
    ,"NB区分"
    ,"NB解約申込予約フラグ"
    ,"オプション契約フラグ"
    ,"JW区分"
    ,"JW解約申込予約フラグ"
    ,"PRV区分"
    ,"PRV解約申込予約フラグ"
    ,"グループライセンス料金プランコード"
    ,"グループ機能利用可能フラグ"
    ,"課金開始日"
    ,"課金区分"
    ,"初回申込無料期間中フラグ"
    ,INS_BATCH_ID
    ,INS_DT_TM
    ,UPD_BATCH_ID
    ,UPD_DT_TM
)
SELECT
     M_IS_NX_ATTRIBUTE.USER_NO AS "IS_会員番号"
    ,M_IS_NX_ATTRIBUTE.EMAIL AS "IS_メールアドレスID"
    ,M_IS_NX_ATTRIBUTE.LAST_NAME AS "IS_姓漢字"
    ,M_IS_NX_ATTRIBUTE.FIRST_NAME AS "IS_名漢字"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.RESIDENT_ABROAD = '1'
        THEN '海外居住'
        ELSE '日本国内'
        END AS "IS_海外居住フラグ"
    ,M_IS_NX_ATTRIBUTE.COUNTRY_CODE AS "IS_居住国コード"
    ,M_IS_MM_COUNTRY.COUNTRY_NAME AS "IS_国名"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.SEX = '0'
        THEN '指定なし'
        WHEN M_IS_NX_ATTRIBUTE.SEX = '1'
        THEN '男性'
        WHEN M_IS_NX_ATTRIBUTE.SEX = '2'
        THEN '女性'
        WHEN M_IS_NX_ATTRIBUTE.SEX = '3'
        THEN 'その他'
        WHEN M_IS_NX_ATTRIBUTE.SEX = '4'
        THEN '回答しない'
        ELSE '不明'
        END AS "IS_性別"
    ,M_IS_NX_ATTRIBUTE.BIRTH AS "IS_生年月日"
    ,M_IS_NX_ATTRIBUTE.OCCUPATION_NO AS "IS_職業NO"
    ,M_IS_MM_OCCUPATION.OCCUPATION_NAME AS "IS_職業名"
    ,M_IS_NX_ATTRIBUTE.BUSINESS_NO AS "IS_業種NO"
    ,M_IS_MM_BUSINESS.BUSINESS_NAME AS "IS_業種名"
    ,M_IS_NX_ATTRIBUTE.JOB_NO AS "IS_職種NO"
    ,M_IS_MM_JOB.JOB_NAME AS "IS_職種名"
    ,M_IS_NX_ATTRIBUTE.POSITION_NO AS "IS_役職NO"
    ,M_IS_MM_POSITION.POSITION_NAME AS "IS_役職名"
    ,M_IS_NX_ATTRIBUTE.EMPLOYEES_NO AS "IS_従業員規模NO"
    ,M_IS_MM_CODE_J.LABEL AS "IS_従業員規模"
    ,M_IS_NX_ATTRIBUTE.INCOME_NO AS "IS_世帯収入NO"
    ,M_IS_MM_CODE_I.LABEL AS "IS_世帯収入"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION1 = '1'
        THEN '購読中'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION1 = '9'
        THEN '未指定'
        ELSE '未購読'
        END AS "IS_新聞購読状況１"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION2 = '1'
        THEN '購読中'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION2 = '9'
        THEN '未指定'
        ELSE '未購読'
        END AS "IS_新聞購読状況２"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION3 = '1'
        THEN '購読中'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION3 = '9'
        THEN '未指定'
        ELSE '未購読'
        END AS "IS_新聞購読状況３"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION4 = '1'
        THEN '購読中'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION4 = '9'
        THEN '未指定'
        ELSE '未購読'
        END AS "IS_新聞購読状況４"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION5 = '1'
        THEN '購読中'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION5 = '9'
        THEN '未指定'
        ELSE '未購読'
        END AS "IS_新聞購読状況５"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION_SUMMARY_FLAG = '0'
        THEN '1つも購読していない'
        WHEN M_IS_NX_ATTRIBUTE.NEWS_SUBSCRIPTION_SUMMARY_FLAG = '1'
        THEN '少なくとも一つは購読している'
        ELSE '不明'
        END AS "IS_新聞購読状況サマリフラグ"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST1 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目１"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST2 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目２"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST3 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目３"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST4 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目４"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST5 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目５"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST6 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目６"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST7 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目７"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST8 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目８"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST9 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目９"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST10 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目１０"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST11 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目１１"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST12 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目１２"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.INTEREST13 = '1'
        THEN '関心がある'
        ELSE '関心がない'
        END AS "IS_興味関心項目１３"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NIKKEI_MAIL_FLAG = '1'
        THEN '日経メール許諾'
        WHEN M_IS_NX_ATTRIBUTE.NIKKEI_MAIL_FLAG = '0'
        THEN '拒否'
        ELSE '不明'
        END AS "IS_日経メール許諾フラグ"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.THIRDPARTY_MAIL_FLAG = '1'
        THEN '第三者メール許諾'
        WHEN M_IS_NX_ATTRIBUTE.THIRDPARTY_MAIL_FLAG = '0'
        THEN '拒否'
        ELSE '不明'
        END AS "IS_第三者メール許諾フラグ"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.NIKKEI_MONITOR_FLAG = '1'
        THEN 'モニターを希望する'
        WHEN M_IS_NX_ATTRIBUTE.NIKKEI_MONITOR_FLAG = '0'
        THEN '希望しない'
        ELSE '不明'
        END AS "IS_日経IDリサーチモニターフラグ"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.USER_TYPE = '0'
        THEN '一般ユーザー'
        WHEN M_IS_NX_ATTRIBUTE.USER_TYPE = '1'
        THEN 'テストユーザー'
        WHEN M_IS_NX_ATTRIBUTE.USER_TYPE = '2'
        THEN '管理者ユーザー'
        ELSE '不明'
        END AS "IS_ユーザタイプ"
    ,M_IS_NX_ATTRIBUTE.ENTRY_DATE AS "IS_入会日"
    ,M_IS_NX_ATTRIBUTE.WITHDRAWAL_DATE AS "IS_退会日"
    ,CASE
        WHEN M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG = '1'
        THEN '退会済み'
        WHEN M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG = '0'
        THEN '会員'
        ELSE M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG
        END AS "IS_退会フラグ"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_SYSTEM_ID AS "料金プランシステムID"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_CD AS "料金プランコード"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_NM AS "料金プラン名"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN AS "料金プラン区分"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM AS "料金プラン区分名"
    ,CASE
        WHEN V_BI_USER_ID_DS_PRIORITY_PLN.CANCEL_FLG = 0
        THEN '解約予約無し'
        ELSE '解約予約'
        END AS "解約申込予約フラグ"
    ,CASE
        WHEN V_BI_USER_ID_DS_PRIORITY_PLN.CHANGE_FLG= 0
        THEN '解約予約無し'
        ELSE '解約予約'
        END AS "変更解約申込予約フラグ"
    ,T_PREF_NAME.PREFEC AS "IS_都道府県郵便番号"
    ,M_IS_NX_USER_SERIAL_ID.SERIAL_ID AS "IS_シリアルID"
    ,V_M_IS_AGE.AGE "IS_年代"
    ,V_M_IS_AGE.AGE2 "IS_年齢"
    ,CASE
        WHEN T_MC_T_ALL_NOT_DESTINATION.NOT_DESTINATION_KBN = '1'
        THEN 1
        ELSE 0
        END AS "MC_不達メールフラグ"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00001SKT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.MAIN_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報速報フラグ_PC"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00001SKT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.SUB_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報速報フラグ_CP"
    ,0 AS "DSYM_ニュースメール情報主要ニュースフラグ_PC"  -- 廃止につき0固定
    ,0 AS "DSYM_ニュースメール情報主要ニュースフラグ_CP"  -- 廃止につき0固定
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00020NST0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.MAIN_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報日経ニュースフラグ_PC"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00020NST0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.SUB_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報日経ニュースフラグ_CP"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00026MYT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.MAIN_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_MY日経メールフラグ_PC"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00026MYT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.SUB_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_MY日経メールフラグ_CP"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00001SHT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.MAIN_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報速報夜間無しフラグ_PC"
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '00001SHT0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.SUB_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_ニュースメール情報速報夜間無しフラグ_CP"
    ,0 AS "DSYM_メールマガジン情報電子版フラグ_PC" -- 廃止につき0固定
    ,0 AS "DSYM_メールマガジン情報電子版フラグ_CP" -- 廃止につき0固定
    ,MAX(
        CASE
            WHEN MAIL_SET.SEND_MAIL_KIND = '01001DSK0'
            AND (
                (MAIL_SET.MAIL_AUTH_KIND = '00')
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '01')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('バンドル','電子新聞'))
                    AND (PLNKBN.DSR3_FLG = '1')
                )
                OR (
                    (MAIL_SET.MAIL_AUTH_KIND = '02')
                    AND (V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_KBN_NM IN ('無料＋本紙','無料'))
                    AND (PLNKBN.DSR2_FLG = '1')
                )
            )
            AND MAIL_SET.MAIN_SEND_FLG = 1
            THEN 1
            ELSE 0
            END
    ) AS "DSYM_電子版お知らせ許諾フラグ"
    ,MAX( 
        CASE 
            WHEN MAIL_SET_BR.BR_FLG = 1 
            AND MAIL_SET_BR.MAIN_SEND_FLG = 1 
            THEN 1 
            ELSE 0 
            END
    ) AS "DSYM_NIKKEI_Briefingメール許諾フラグ"
    ,CASE
        WHEN T_DSG_T_DS_USER.UPDATE_NOTICE_MAIL_PC = '1'
        THEN 1
        ELSE 0
        END AS "DSG_Myグループ更新通知メール送信フラグ_PC"
    ,CASE
        -- NO.3 BP移行中会員（重複なし）有効会員
        WHEN (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') IN ('3','9')
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        -- NO.3 BP移行中会員（重複なし）退会済
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
        )
        OR
        -- NO.7 BP移行中会員（BP側）有効会員
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '2'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        -- NO.7  BP移行中会員（BP側）退会済
        -- NO.12 分離中会員（アドレズ有効）BP側 退会済
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NMID.MRG_ORG_SITE IS NULL
        )
        OR
        -- NO.9 分離済会員（アドレズ無効）日経ID側 有効会員
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') <> 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') IN ('0','1','9')
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        -- NO.9 分離済会員（アドレズ無効）日経ID側 退会済
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') <> 'BPPM'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
        )
        OR
        -- NO.11 分離済会員（アドレズ無効）BP側 有効会員
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        -- NO.11 分離済会員（アドレズ無効）BP側 退会済
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
        )
        OR
        -- NO.12 分離中会員（アドレズ有効）BP側 有効会員
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        THEN '9'
        WHEN (
            -- NS（日経専売店クレジット決済）
            -- 本会員 の場合は統合済み会員
            NVL(NMBP.ORIGINAL_SITE,'NID') = 'NS'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.MERGE_STATUS_DETAIL,'000') = '090'
            AND NVL(NMBP.ATTR_STATUS,'0') = '9'
            AND NVL(NMBP.PASSWD_STATUS,'0') = '9'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '9'
        )
        THEN '1'
            -- NS（日経専売店クレジット決済）
            -- 本会員 以外の場合は統合移行中会員
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'NS'
        THEN '9'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2014'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2015'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2016'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2017'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2018'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2019'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2020'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'JOB2021'
        THEN '1'
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPP'
        OR NVL(NMBP.ORIGINAL_SITE,'NID') LIKE 'JOB2%'
        OR NVL(NMBP.ORIGINAL_SITE,'NID') = 'CAREERCON'
        THEN NMBP.ORIGINAL_SITE
        ELSE '1'
        END AS "IS_移行元サイト"
    ,CASE
        -- IS_移行元サイト = '9' の場合
        WHEN (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') IN ('3','9')
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '2'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NMID.MRG_ORG_SITE IS NULL
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') <> 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') IN ('0','1','9')
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') <> 'BPPM'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') = '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '1'
        )
        OR
        (
            NVL(M_IS_NX_ATTRIBUTE.WITHDRAWAL_FLAG,'0') <> '1'
            AND NVL(NMBP.MERGE_STATUS,'0') = '9'
            AND NVL(NMBP.ORIGINAL_SITE,'NID') = 'BPPM'
            AND NVL(NMBP.ATTR_STATUS,'0') = '1'
            AND NVL(NMBP.EMAIL_STATUS,'0') <> '1'
            AND NVL(NMBP.MRG_ORG_SITE,'NID') = 'NID'
        )
        THEN '1'
        WHEN (
            -- NS（日経専売店クレジット決済）
            -- 本会員 の場合は移行完了
            NVL(NMBP.ORIGINAL_SITE,'NID') = 'NS'
            AND NVL(NMBP.MERGE_STATUS,'0') = '0'
            AND NVL(NMBP.MERGE_STATUS_DETAIL,'000') = '090'
            AND NVL(NMBP.ATTR_STATUS,'0') = '9'
            AND NVL(NMBP.PASSWD_STATUS,'0') = '9'
            AND NVL(NMBP.EMAIL_STATUS,'0') = '9'
        )
        THEN '9'
            -- NS（日経専売店クレジット決済）
            -- 本会員 以外の場合は移行中
        WHEN NVL(NMBP.ORIGINAL_SITE,'NID') = 'NS'
        THEN '1'
        WHEN NMBP.ORIGINAL_SITE = 'BPP'
        THEN '9'
        WHEN (
              NMBP.ORIGINAL_SITE LIKE 'JOB2%'
              OR NMBP.ORIGINAL_SITE = 'CAREERCON'
             )
        AND NMBP.ATTR_STATUS = '9'
        THEN '9'
        WHEN (
              NMBP.ORIGINAL_SITE LIKE 'JOB2%'
              OR NMBP.ORIGINAL_SITE = 'CAREERCON'
             )
        AND NMBP.ATTR_STATUS = '1'
        AND NMBP.PASSWD_STATUS = '9'
        THEN '1'
        WHEN (
              NMBP.ORIGINAL_SITE LIKE 'JOB2%'
              OR NMBP.ORIGINAL_SITE = 'CAREERCON'
             )
        AND NMBP.ATTR_STATUS = '1'
        AND NMBP.PASSWD_STATUS = '1'
        THEN '0'
        ELSE '9'
        END AS "IS_移行ステータス"
    ,CASE
        WHEN EDU.USER_NO IS NULL
        THEN 0
        ELSE 1
        END AS "BIZアカデミー会員フラグ"
    ,CASE
        WHEN TRIAL.TRIAL_NOW >= 1
        THEN 1
        ELSE 0
        END AS "お試し会員フラグ"
    ,CASE
        WHEN TRIAL.TRIAL_ALREADY = 1
        OR TRIAL_PAST.TRIAL_PAST_USE >= 1
        THEN 1
        ELSE 0
        END AS "お試し利用実績フラグ"
    ,0 AS "日経ストア会員フラグ"
    ,CASE
        WHEN OPTION.SS_FLG IS NULL
        THEN 0
        ELSE OPTION.SS_FLG
        END AS "SS区分"
    ,CASE
        WHEN OPTION.SS_CANCEL_FLG IS NULL
        THEN 0
        ELSE OPTION.SS_CANCEL_FLG
        END AS "SS解約申込予約フラグ"
    ,CASE
        WHEN OPTION.MJ_FLG IS NULL
        THEN 0
        ELSE OPTION.MJ_FLG
        END AS "MJ区分"
    ,CASE
        WHEN OPTION.MJ_CANCEL_FLG IS NULL
        THEN 0
        ELSE OPTION.MJ_CANCEL_FLG
        END AS "MJ解約申込予約フラグ"
    ,CASE
        WHEN OPTION.NB_OPTION_FLG IS NULL
        THEN 0
        ELSE OPTION.NB_OPTION_FLG
        END AS "NB区分"
    ,CASE
        WHEN OPTION.NB_OPTION_CANCEL_FLG IS NULL
        THEN 0
        ELSE OPTION.NB_OPTION_CANCEL_FLG
        END AS "NB解約申込予約フラグ"
    ,CASE
        WHEN OPTION.OPTION_FLG IS NULL
        THEN 0
        ELSE OPTION.OPTION_FLG
        END AS "オプション契約フラグ"
    ,CASE
        WHEN OPTION.JW_FLG IS NULL
        THEN 0
        ELSE OPTION.JW_FLG
        END AS "JW区分"
    ,CASE
        WHEN OPTION.JW_CANCEL_FLG IS NULL
        THEN 0
        ELSE OPTION.JW_CANCEL_FLG
        END AS "JW解約申込予約フラグ"
    ,CASE
        WHEN OPTION.PRV_OPTION_FLG IS NULL
        THEN 0
        ELSE OPTION.PRV_OPTION_FLG
        END AS "PRV区分"
    ,CASE
        WHEN OPTION.PRV_OPTION_CANCEL_FLG IS NULL
        THEN 0
        ELSE OPTION.PRV_OPTION_CANCEL_FLG
        END AS "PRV解約申込予約フラグ"
    ,GRP.PLAN_ID AS "グループライセンス料金プランコード"
    ,CASE
        WHEN AVAILABLE.USER_NO IS NULL
        THEN 0
        ELSE 1
        END AS "グループ機能利用可能フラグ"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.CHARGE_START_DATE AS "課金開始日"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.CHARGE_KBN AS "課金区分"
    ,V_BI_USER_ID_DS_PRIORITY_PLN.FARST_FREE_FLG AS "初回申込無料期間中フラグ"
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
    ,'{{ dag.dag_id }}'
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_MM_COUNTRY
        ON M_IS_NX_ATTRIBUTE.COUNTRY_CODE = M_IS_MM_COUNTRY.CODE_NUMERIC
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_MM_OCCUPATION
        ON M_IS_NX_ATTRIBUTE.OCCUPATION_NO = M_IS_MM_OCCUPATION.OCCUPATION_NO
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_MM_BUSINESS
        ON M_IS_NX_ATTRIBUTE.BUSINESS_NO = M_IS_MM_BUSINESS.BUSINESS_NO
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_MM_JOB
        ON M_IS_NX_ATTRIBUTE.JOB_NO = M_IS_MM_JOB.JOB_NO
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_MM_POSITION
        ON M_IS_NX_ATTRIBUTE.POSITION_NO = M_IS_MM_POSITION.POSITION_NO
    LEFT JOIN (
        SELECT
             VALUE
            ,LABEL
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IS_MM_CODE
        WHERE
            MASTER_TYPE = 'EMPLOYEES_NO'
    ) AS M_IS_MM_CODE_J
        ON M_IS_NX_ATTRIBUTE.EMPLOYEES_NO = M_IS_MM_CODE_J.VALUE
    LEFT JOIN (
        SELECT
             VALUE
            ,LABEL
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IS_MM_CODE
        WHERE
            MASTER_TYPE = 'INCOME_NO'
    ) AS M_IS_MM_CODE_I
        ON M_IS_NX_ATTRIBUTE.INCOME_NO = M_IS_MM_CODE_I.VALUE
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_DS_PRIORITY_PLN
        ON M_IS_NX_ATTRIBUTE.USER_NO = V_BI_USER_ID_DS_PRIORITY_PLN.USER_NO
    LEFT JOIN (
        SELECT
            ZIPCODE
            ,MIN(PREFEC) AS PREFEC
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IS_MM_ADDRESS
        WHERE
            DELETE_FLG = 0
        AND NOT ZIPCODE IS NULL
        GROUP BY
            ZIPCODE
    ) AS T_PREF_NAME
        ON M_IS_NX_ATTRIBUTE.ZIP_CODE = T_PREF_NAME.ZIPCODE
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_USER_SERIAL_ID
        ON M_IS_NX_ATTRIBUTE.USER_NO = M_IS_NX_USER_SERIAL_ID.USER_NO
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.V_M_IS_AGE
        ON M_IS_NX_ATTRIBUTE.BIRTH >= V_M_IS_AGE.AGE_FROM2
        AND M_IS_NX_ATTRIBUTE.BIRTH <= V_M_IS_AGE.AGE_TO2
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.T_MC_T_ALL_NOT_DESTINATION
        ON M_IS_NX_ATTRIBUTE.EMAIL = T_MC_T_ALL_NOT_DESTINATION.EMAIL
    LEFT JOIN (
        SELECT
             T_DSU_T_DS_MAIL_SET_INFO.NIKKEI_MEMBER_NO AS NIKKEI_MEMBER_NO
            ,T_DSU_T_DS_MAIL_SET_INFO.MAIN_SEND_FLG AS MAIN_SEND_FLG
            ,T_DSU_T_DS_MAIL_SET_INFO.SUB_SEND_FLG AS SUB_SEND_FLG
            ,M_DSU_M_SEND_MAIL_KIND.SEND_MAIL_KIND AS SEND_MAIL_KIND
            ,M_DSU_M_SEND_MAIL_KIND.MAIL_AUTH_KIND AS MAIL_AUTH_KIND
            ,CASE 
                WHEN M_DSU_M_SEND_MAIL_KIND.SEND_MAIL_KIND IN (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE 
                    WHERE
                        MASTER_TYPE = 'MST620' 
                        AND MASTER_GRP_TYPE = 'GCRM62001'
                        AND YUKO_FLG = '1'
                )
                THEN 1
                ELSE 0
                END AS BR_FLG
        FROM
             {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_MAIL_SET_INFO
            ,{{ var.value.redshift_ims_schema_name }}.M_DSU_M_SEND_MAIL_KIND
        WHERE
            T_DSU_T_DS_MAIL_SET_INFO.SEND_MAIL_KIND = M_DSU_M_SEND_MAIL_KIND.SEND_MAIL_KIND
        AND T_DSU_T_DS_MAIL_SET_INFO.DEL_FLG = '0'
        AND M_DSU_M_SEND_MAIL_KIND.DEL_FLG = '0'
    ) AS MAIL_SET
        ON M_IS_NX_ATTRIBUTE.USER_NO = MAIL_SET.NIKKEI_MEMBER_NO
    LEFT JOIN (
        -- メール許諾情報
        SELECT
             V_APP_USER_MAIL_AUTH.USER_NO                        AS NIKKEI_MEMBER_NO
            ,CAST(V_APP_USER_MAIL_AUTH.IS_ENABLED AS VARCHAR(4)) AS MAIN_SEND_FLG
            ,'0'                                                 AS SUB_SEND_FLG
            ,V_APP_MAIL_SEND_KIND.SEND_MAIL_KIND                 AS SEND_MAIL_KIND
            ,V_APP_MAIL_SEND_KIND.MAIL_AUTH_KIND                 AS MAIL_AUTH_KIND
            ,CASE 
                WHEN V_APP_MAIL_SEND_KIND.SEND_MAIL_KIND IN (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE 
                    WHERE
                        MASTER_TYPE = 'MST620' 
                        AND MASTER_GRP_TYPE = 'GCRM62001'
                        AND YUKO_FLG = '1'
                )
                THEN 1
                ELSE 0
                END AS BR_FLG
        FROM
             {{ var.value.redshift_ims_schema_name }}.V_APP_USER_MAIL_AUTH
            ,{{ var.value.redshift_ims_schema_name }}.V_APP_MAIL_SEND_KIND
        WHERE
            V_APP_USER_MAIL_AUTH.SUB_CATEGORY = V_APP_MAIL_SEND_KIND.SEND_MAIL_KIND
        AND V_APP_MAIL_SEND_KIND.DEL_FLG = '0' 
    ) AS MAIL_SET_BR
        ON M_IS_NX_ATTRIBUTE.USER_NO = MAIL_SET_BR.NIKKEI_MEMBER_NO
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.T_DSG_T_DS_USER
        ON M_IS_NX_ATTRIBUTE.USER_NO = T_DSG_T_DS_USER.NIKKEI_MEMBER_NO
    LEFT JOIN (
        SELECT
             CRM_PLN.PRICEPLN_CD
            --電子版有料会員
            ,MAX(
                CASE
                    WHEN CRM_CODE.MASTER_TYPE = 'MST060'
                    AND CRM_CODE.CODE = 'CRM06003'
                    THEN 1
                    ELSE 0
                    END
            ) AS DSR3_FLG
            --電子版登録会員
            ,MAX(
                CASE
                    WHEN CRM_CODE.MASTER_TYPE = 'MST060'
                    AND CRM_CODE.CODE = 'CRM06004'
                    THEN 1
                    ELSE 0
                    END
            ) AS DSR2_FLG
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE CRM_CODE
        INNER JOIN 
            {{ var.value.redshift_ims_schema_name }}.M_CRM_RKN_PLN CRM_PLN
        ON
            CRM_CODE.CODE = CRM_PLN.PLNSUM_CD
        WHERE
            CRM_CODE.YUKO_FLG = '1'
        GROUP BY
            CRM_PLN.PRICEPLN_CD
    ) PLNKBN
        ON V_BI_USER_ID_DS_PRIORITY_PLN.PRICEPLN_CD = PLNKBN.PRICEPLN_CD
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_MIGRATION NMBP
        ON {{ var.value.redshift_ims_schema_name }}.M_IS_NX_ATTRIBUTE.USER_NO = NMBP.C_LOCAL_USER_ID
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_IS_NX_MIGRATION NMID
        ON NMBP.EST_IDENTICAL_UID = NMID.C_LOCAL_USER_ID
    LEFT JOIN (
        --Bizアカデミー
        SELECT
            RPR.USER_NO
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IS_NX_RP_REGISTRATION RPR
        WHERE
            RPR.RP_ID = 7
    ) AS EDU
        ON M_IS_NX_ATTRIBUTE.USER_NO = EDU.USER_NO
    LEFT JOIN (
        --お試し
        SELECT
            NIKKEI_ID_INTERNAL_MEMBER_NO
            ,SUM(
                CASE
                    WHEN 
                        CAST(T_KK_V_TRIAL_CAMPAIGN_APPLY.ACTIVATE_DATETIME AS DATE) <= {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
                    AND CAST(NVL(T_KK_V_TRIAL_CAMPAIGN_APPLY.TRIAL_END_DATETIME,
                            T_KK_V_TRIAL_CAMPAIGN_APPLY.TRIAL_END_ESTIMATE_DATETIME) AS DATE) >= {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
                    THEN 1
                    ELSE 0
                    END
            ) AS TRIAL_NOW
            ,1 AS TRIAL_ALREADY
        FROM
             {{ var.value.redshift_ims_schema_name }}.T_KK_V_TRIAL_CAMPAIGN_APPLY
            ,{{ var.value.redshift_ims_schema_name }}.M_KK_M_TRIAL_CAMPAIGN
        WHERE
            T_KK_V_TRIAL_CAMPAIGN_APPLY.TRIAL_CAMPAIGN_MANAGEMENT_NO = M_KK_M_TRIAL_CAMPAIGN.TRIAL_CAMPAIGN_MANAGEMENT_NO
            -- 施策ステータスが1であるものを対象とする
            AND M_KK_M_TRIAL_CAMPAIGN.TRIAL_CAMPAIGN_STATUS = '1'
        GROUP BY
            T_KK_V_TRIAL_CAMPAIGN_APPLY.NIKKEI_ID_INTERNAL_MEMBER_NO
    ) AS TRIAL
        ON M_IS_NX_ATTRIBUTE.USER_NO = TRIAL.NIKKEI_ID_INTERNAL_MEMBER_NO
    LEFT JOIN (
        --お試し過去利用
        SELECT
            NIKKEI_ID_INTERNAL_MEMBER_NO
            ,SUM(
                CASE
                    WHEN 
                        CAST(NVL(T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM.TRIAL_END_DATETIME,
                        T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM.TRIAL_END_ESTIMATE_DATETIME) AS DATE) <= {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
                    THEN 1
                    ELSE 0
                    END
            ) AS TRIAL_PAST_USE
        FROM
             {{ var.value.redshift_ims_schema_name }}.T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM
        GROUP BY
            T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM.NIKKEI_ID_INTERNAL_MEMBER_NO
    ) AS TRIAL_PAST
        ON M_IS_NX_ATTRIBUTE.USER_NO = TRIAL_PAST.NIKKEI_ID_INTERNAL_MEMBER_NO
    LEFT JOIN (
        --日経ID別サービス優先判定ビュー
        --法人契約のキャンセルフラグは0のため、SS、MJ、NB、JWの解約申込予約フラグは法人契約の場合のロジックを入れないで0にする
        SELECT
             USER_NO
            ,MAX(
                CASE
                WHEN IND_SS.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '1'
                THEN 1
                WHEN CORP_SS.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '2'
                THEN 2
                ELSE 0
                END
            ) AS SS_FLG
            ,MAX(
                CASE
                WHEN IND_SS.VALUE1 IS NOT NULL
                AND OPTION_KEI.CANCEL_FLG = 1
                THEN 1
                ELSE 0
                END
            ) AS SS_CANCEL_FLG
            ,MAX(
                CASE
                WHEN IND_MJ.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '1'
                THEN 1
                WHEN CORP_MJ.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '2'
                THEN 2
                ELSE 0
                END
            ) AS MJ_FLG
            ,MAX(
                CASE
                WHEN IND_MJ.VALUE1 IS NOT NULL
                AND OPTION_KEI.CANCEL_FLG = 1
                THEN 1
                ELSE 0
                END
            ) AS MJ_CANCEL_FLG
            ,MAX(
                CASE
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06103'
                AND OPTION_KEI.CORP_FLG = '1'
                THEN 1
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06103'
                AND OPTION_KEI.CORP_FLG = '2'
                THEN 2
                ELSE 0
                END
            ) AS NB_OPTION_FLG
            ,MAX(
                CASE
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06103'
                AND OPTION_KEI.CANCEL_FLG = 1
                THEN 1
                ELSE 0
                END
            ) AS NB_OPTION_CANCEL_FLG
            ,MAX(
                CASE
                WHEN OPTION_KEI.MASTER_GRP_TYPE IN ('GCRM06103','GCRM06105')
                THEN 1
                ELSE 0
                END
            )AS OPTION_FLG
            ,MAX(
                CASE
                WHEN IND_JW.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '1'
                THEN 1
                WHEN CORP_JW.VALUE1 IS NOT NULL
                AND OPTION_KEI.CORP_FLG = '2'
                THEN 2
                ELSE 0
                END
            ) AS JW_FLG
            ,MAX(
                CASE
                WHEN IND_JW.VALUE1 IS NOT NULL
                AND OPTION_KEI.CANCEL_FLG = 1
                THEN 1
                ELSE 0
                END
            ) AS JW_CANCEL_FLG
            ,MAX(
                CASE
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06105'
                AND OPTION_KEI.CORP_FLG = '1'
                THEN 1
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06105'
                AND OPTION_KEI.CORP_FLG = '2'
                THEN 2
                ELSE 0
                END
            ) AS PRV_OPTION_FLG
            ,MAX(
                CASE
                WHEN OPTION_KEI.MASTER_GRP_TYPE = 'GCRM06105'
                AND OPTION_KEI.CANCEL_FLG = 1
                THEN 1
                ELSE 0
                END
            ) AS PRV_OPTION_CANCEL_FLG
        FROM (
                SELECT
                     V_BI_USER_ID_SERVICE_PRIORITY_PLN.USER_NO AS USER_NO
                    ,V_BI_USER_ID_SERVICE_PRIORITY_PLN.PLAN_ID AS PLAN_ID
                    ,V_BI_USER_ID_SERVICE_PRIORITY_PLN.CANCEL_FLG AS CANCEL_FLG
                    ,V_BI_USER_ID_SERVICE_PRIORITY_PLN.CORP_FLG AS CORP_FLG
                    ,M_OPTION_KEI.MASTER_GRP_TYPE  AS MASTER_GRP_TYPE
                FROM
                    {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_SERVICE_PRIORITY_PLN 
                LEFT JOIN
                (
                    SELECT
                     DISTINCT
                     CRM_CODE.MASTER_GRP_TYPE AS MASTER_GRP_TYPE
                    ,CRM_OPTION.OP_CD AS OP_CD
                    FROM
                     {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE CRM_CODE
                    ,{{ var.value.redshift_ims_schema_name }}.M_CRM_OPTION CRM_OPTION
                    WHERE
                    CRM_CODE.YUKO_FLG = '1'
                    AND CRM_CODE.MASTER_TYPE = 'MST061'
                    AND CRM_CODE.CODE = CRM_OPTION.OPSUM_CD
                ) AS M_OPTION_KEI
                ON
                    V_BI_USER_ID_SERVICE_PRIORITY_PLN.PLAN_ID = M_OPTION_KEI.OP_CD
            ) OPTION_KEI
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                        MASTER_TYPE = 'MST440'
                        AND MASTER_GRP_TYPE = 'GCRM440'
                        AND CODE = 'CRM44009'
                ) IND_SS
            ON
                OPTION_KEI.PLAN_ID = IND_SS.VALUE1
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                    MASTER_TYPE = 'MST440'
                    AND MASTER_GRP_TYPE = 'GCRM440'
                    AND CODE IN ('CRM44011', 'CRM44012', 'CRM44013')
                ) CORP_SS
            ON
                OPTION_KEI.PLAN_ID = CORP_SS.VALUE1
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                        MASTER_TYPE = 'MST440'
                        AND MASTER_GRP_TYPE = 'GCRM440'
                        AND CODE = 'CRM44008'
                ) IND_MJ
            ON
                OPTION_KEI.PLAN_ID = IND_MJ.VALUE1
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                    MASTER_TYPE = 'MST440'
                    AND MASTER_GRP_TYPE = 'GCRM440'
                    AND CODE IN ('CRM44014', 'CRM44015', 'CRM44016')
                ) CORP_MJ
            ON
                OPTION_KEI.PLAN_ID = CORP_MJ.VALUE1
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                        MASTER_TYPE = 'MST440'
                        AND MASTER_GRP_TYPE = 'GCRM440'
                        AND CODE = 'CRM44001'
                ) IND_JW
            ON
                OPTION_KEI.PLAN_ID = IND_JW.VALUE1
            LEFT JOIN
                (
                    SELECT
                        VALUE1
                    FROM
                        {{ var.value.redshift_ims_schema_name }}.M_CRM_CODE
                    WHERE
                    MASTER_TYPE = 'MST440'
                    AND MASTER_GRP_TYPE = 'GCRM440'
                    AND CODE IN ('CRM44017', 'CRM44018', 'CRM44019')
                ) CORP_JW
            ON
                OPTION_KEI.PLAN_ID = CORP_JW.VALUE1
            GROUP BY 
                USER_NO
        ) OPTION
        ON M_IS_NX_ATTRIBUTE.USER_NO = OPTION.USER_NO
    LEFT JOIN (
        --会員ID別グループ契約優先判定ビュー
        --プランIDを取得
        SELECT
             USER_NO, PLAN_ID
        FROM
            {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_GRP_PRIORITY_PLN
        ) GRP
        ON M_IS_NX_ATTRIBUTE.USER_NO = GRP.USER_NO
    LEFT JOIN (
        --会員ID別グループ機能利用可能判定ビュー
        --グループ機能利用可能な会員を取得
        SELECT
             USER_NO
        FROM
            {{ var.value.redshift_ims_schema_name }}.V_BI_USER_ID_GRP_AVAILABLE
        ) AVAILABLE
        ON M_IS_NX_ATTRIBUTE.USER_NO = AVAILABLE.USER_NO
GROUP BY
     "IS_会員番号"
    ,"IS_メールアドレスID"
    ,"IS_姓漢字"
    ,"IS_名漢字"
    ,"IS_海外居住フラグ"
    ,"IS_居住国コード"
    ,"IS_国名"
    ,"IS_性別"
    ,"IS_生年月日"
    ,"IS_職業NO"
    ,"IS_職業名"
    ,"IS_業種NO"
    ,"IS_業種名"
    ,"IS_職種NO"
    ,"IS_職種名"
    ,"IS_役職NO"
    ,"IS_役職名"
    ,"IS_従業員規模NO"
    ,"IS_従業員規模"
    ,"IS_世帯収入NO"
    ,"IS_世帯収入"
    ,"IS_新聞購読状況１"
    ,"IS_新聞購読状況２"
    ,"IS_新聞購読状況３"
    ,"IS_新聞購読状況４"
    ,"IS_新聞購読状況５"
    ,"IS_新聞購読状況サマリフラグ"
    ,"IS_興味関心項目１"
    ,"IS_興味関心項目２"
    ,"IS_興味関心項目３"
    ,"IS_興味関心項目４"
    ,"IS_興味関心項目５"
    ,"IS_興味関心項目６"
    ,"IS_興味関心項目７"
    ,"IS_興味関心項目８"
    ,"IS_興味関心項目９"
    ,"IS_興味関心項目１０"
    ,"IS_興味関心項目１１"
    ,"IS_興味関心項目１２"
    ,"IS_興味関心項目１３"
    ,"IS_日経メール許諾フラグ"
    ,"IS_第三者メール許諾フラグ"
    ,"IS_日経IDリサーチモニターフラグ"
    ,"IS_ユーザタイプ"
    ,"IS_入会日"
    ,"IS_退会日"
    ,"IS_退会フラグ"
    ,"料金プランシステムID"
    ,"料金プランコード"
    ,"料金プラン名"
    ,"料金プラン区分"
    ,"料金プラン区分名"
    ,"解約申込予約フラグ"
    ,"変更解約申込予約フラグ"
    ,"IS_都道府県郵便番号"
    ,"IS_シリアルID"
    ,"IS_年代"
    ,"IS_年齢"
    ,"MC_不達メールフラグ"
    ,"DSG_Myグループ更新通知メール送信フラグ_PC"
    ,"IS_移行元サイト"
    ,"IS_移行ステータス"
    ,"BIZアカデミー会員フラグ"
    ,"お試し会員フラグ"
    ,"お試し利用実績フラグ"
    ,"日経ストア会員フラグ"
    ,"SS区分"
    ,"SS解約申込予約フラグ"
    ,"MJ区分"
    ,"MJ解約申込予約フラグ"
    ,"NB区分"
    ,"NB解約申込予約フラグ"
    ,"オプション契約フラグ"
    ,"JW区分"
    ,"JW解約申込予約フラグ"
    ,"PRV区分"
    ,"PRV解約申込予約フラグ"
    ,"グループライセンス料金プランコード"
    ,"グループ機能利用可能フラグ"
    ,"課金開始日"
    ,"課金区分"
    ,"初回申込無料期間中フラグ"
;

-- delete
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_AD_NIKKEI_ID
;
-- insert
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_AD_NIKKEI_ID
(
    "IS_会員番号"
    ,"IS_メールアドレスID"
    ,"IS_姓漢字"
    ,"IS_名漢字"
    ,"IS_海外居住フラグ"
    ,"IS_居住国コード"
    ,"IS_国名"
    ,"IS_性別"
    ,"IS_生年月日"
    ,"IS_職業NO"
    ,"IS_職業名"
    ,"IS_業種NO"
    ,"IS_業種名"
    ,"IS_職種NO"
    ,"IS_職種名"
    ,"IS_役職NO"
    ,"IS_役職名"
    ,"IS_従業員規模NO"
    ,"IS_従業員規模"
    ,"IS_世帯収入NO"
    ,"IS_世帯収入"
    ,"IS_新聞購読状況１"
    ,"IS_新聞購読状況２"
    ,"IS_新聞購読状況３"
    ,"IS_新聞購読状況４"
    ,"IS_新聞購読状況５"
    ,"IS_新聞購読状況サマリフラグ"
    ,"IS_興味関心項目１"
    ,"IS_興味関心項目２"
    ,"IS_興味関心項目３"
    ,"IS_興味関心項目４"
    ,"IS_興味関心項目５"
    ,"IS_興味関心項目６"
    ,"IS_興味関心項目７"
    ,"IS_興味関心項目８"
    ,"IS_興味関心項目９"
    ,"IS_興味関心項目１０"
    ,"IS_興味関心項目１１"
    ,"IS_興味関心項目１２"
    ,"IS_興味関心項目１３"
    ,"IS_日経メール許諾フラグ"
    ,"IS_第三者メール許諾フラグ"
    ,"IS_日経IDリサーチモニターフラグ"
    ,"IS_ユーザタイプ"
    ,"IS_入会日"
    ,"IS_退会日"
    ,"IS_退会フラグ"
    ,"料金プランシステムID"
    ,"料金プランコード"
    ,"料金プラン名"
    ,"料金プラン区分"
    ,"料金プラン区分名"
    ,"解約申込予約フラグ"
    ,"変更解約申込予約フラグ"
    ,"IS_都道府県郵便番号"
    ,"IS_シリアルID"
    ,"IS_年代"
    ,"IS_年齢"
    ,"MC_不達メールフラグ"
    ,"DSYM_ニュースメール情報速報フラグ_PC"
    ,"DSYM_ニュースメール情報速報フラグ_CP"
    ,"DSYM_ニュースメール情報主要ニュースフラグ_PC"
    ,"DSYM_ニュースメール情報主要ニュースフラグ_CP"
    ,"DSYM_ニュースメール情報日経ニュースフラグ_PC"
    ,"DSYM_ニュースメール情報日経ニュースフラグ_CP"
    ,"DSYM_MY日経メールフラグ_PC"
    ,"DSYM_MY日経メールフラグ_CP"
    ,"DSYM_ニュースメール情報速報夜間無しフラグ_PC"
    ,"DSYM_ニュースメール情報速報夜間無しフラグ_CP"
    ,"DSYM_メールマガジン情報電子版フラグ_PC"
    ,"DSYM_メールマガジン情報電子版フラグ_CP"
    ,"DSYM_電子版お知らせ許諾フラグ"
    ,"DSYM_NIKKEI_Briefingメール許諾フラグ"
    ,"DSG_Myグループ更新通知メール送信フラグ_PC"
    ,"IS_移行元サイト"
    ,"IS_移行ステータス"
    ,"BIZアカデミー会員フラグ"
    ,"お試し会員フラグ"
    ,"お試し利用実績フラグ"
    ,"日経ストア会員フラグ"
    ,"SS区分"
    ,"SS解約申込予約フラグ"
    ,"MJ区分"
    ,"MJ解約申込予約フラグ"
    ,"NB区分"
    ,"NB解約申込予約フラグ"
    ,"オプション契約フラグ"
    ,"JW区分"
    ,"JW解約申込予約フラグ"
    ,"PRV区分"
    ,"PRV解約申込予約フラグ"
    ,"グループライセンス料金プランコード"
    ,"グループ機能利用可能フラグ"
    ,"日経サービス利用フラグ"
    ,"BPサービス利用フラグ"
    ,"課金開始日"
    ,"課金区分"
    ,"初回申込無料期間中フラグ"
    ,"BPP一次統合フラグ"
    ,"BPP二次統合フラグ"
    ,"プラン適用開始日"
    ,"プラン適用終了日"
    ,"有料プラン開始日"
    ,"有料プラン解約日"
    ,INS_BATCH_ID
    ,INS_DT_TM
    ,UPD_BATCH_ID
    ,UPD_DT_TM
)
    SELECT
        A.IS_会員番号                                                        AS IS_会員番号
        ,A.IS_メールアドレスID                                               AS IS_メールアドレスID
        ,A.IS_姓漢字                                                         AS IS_姓漢字
        ,A.IS_名漢字                                                         AS IS_名漢字
        ,A.IS_海外居住フラグ                                                 AS IS_海外居住フラグ
        ,A.IS_居住国コード                                                   AS IS_居住国コード
        ,A.IS_国名                                                           AS IS_国名
        ,A.IS_性別                                                           AS IS_性別
        ,A.IS_生年月日                                                       AS IS_生年月日
        ,A.IS_職業NO                                                         AS IS_職業NO
        ,A.IS_職業名                                                         AS IS_職業名
        ,A.IS_業種NO                                                         AS IS_業種NO
        ,A.IS_業種名                                                         AS IS_業種名
        ,A.IS_職種NO                                                         AS IS_職種NO
        ,A.IS_職種名                                                         AS IS_職種名
        ,A.IS_役職NO                                                         AS IS_役職NO
        ,A.IS_役職名                                                         AS IS_役職名
        ,A.IS_従業員規模NO                                                   AS IS_従業員規模NO
        ,A.IS_従業員規模                                                     AS IS_従業員規模
        ,A.IS_世帯収入NO                                                     AS IS_世帯収入NO
        ,A.IS_世帯収入                                                       AS IS_世帯収入
        ,A.IS_新聞購読状況１                                                 AS IS_新聞購読状況１
        ,A.IS_新聞購読状況２                                                 AS IS_新聞購読状況２
        ,A.IS_新聞購読状況３                                                 AS IS_新聞購読状況３
        ,A.IS_新聞購読状況４                                                 AS IS_新聞購読状況４
        ,A.IS_新聞購読状況５                                                 AS IS_新聞購読状況５
        ,A.IS_新聞購読状況サマリフラグ                                       AS IS_新聞購読状況サマリフラグ
        ,A.IS_興味関心項目１                                                 AS IS_興味関心項目１
        ,A.IS_興味関心項目２                                                 AS IS_興味関心項目２
        ,A.IS_興味関心項目３                                                 AS IS_興味関心項目３
        ,A.IS_興味関心項目４                                                 AS IS_興味関心項目４
        ,A.IS_興味関心項目５                                                 AS IS_興味関心項目５
        ,A.IS_興味関心項目６                                                 AS IS_興味関心項目６
        ,A.IS_興味関心項目７                                                 AS IS_興味関心項目７
        ,A.IS_興味関心項目８                                                 AS IS_興味関心項目８
        ,A.IS_興味関心項目９                                                 AS IS_興味関心項目９
        ,A.IS_興味関心項目１０                                               AS IS_興味関心項目１０
        ,A.IS_興味関心項目１１                                               AS IS_興味関心項目１１
        ,A.IS_興味関心項目１２                                               AS IS_興味関心項目１２
        ,A.IS_興味関心項目１３                                               AS IS_興味関心項目１３
        ,A.IS_日経メール許諾フラグ                                           AS IS_日経メール許諾フラグ
        ,A.IS_第三者メール許諾フラグ                                         AS IS_第三者メール許諾フラグ
        ,A.IS_日経IDリサーチモニターフラグ                                   AS IS_日経IDリサーチモニターフラグ
        ,A.IS_ユーザタイプ                                                   AS IS_ユーザタイプ
        ,A.IS_入会日                                                         AS IS_入会日
        ,A.IS_退会日                                                         AS IS_退会日
        ,A.IS_退会フラグ                                                     AS IS_退会フラグ
        ,A.料金プランシステムID                                              AS 料金プランシステムID
        ,A.料金プランコード                                                  AS 料金プランコード
        ,A.料金プラン名                                                      AS 料金プラン名
        ,A.料金プラン区分                                                    AS 料金プラン区分
        ,A.料金プラン区分名                                                  AS 料金プラン区分名
        ,A.解約申込予約フラグ                                                AS 解約申込予約フラグ
        ,A.変更解約申込予約フラグ                                            AS 変更解約申込予約フラグ
        ,A.IS_都道府県郵便番号                                               AS IS_都道府県郵便番号
        ,A.IS_シリアルID                                                     AS IS_シリアルID
        ,A.IS_年代                                                           AS IS_年代
        ,A.IS_年齢                                                           AS IS_年齢
        ,A.MC_不達メールフラグ                                               AS MC_不達メールフラグ
        ,A.DSYM_ニュースメール情報速報フラグ_PC                              AS DSYM_ニュースメール情報速報フラグ_PC
        ,A.DSYM_ニュースメール情報速報フラグ_CP                              AS DSYM_ニュースメール情報速報フラグ_CP
        ,A.DSYM_ニュースメール情報主要ニュースフラグ_PC                      AS DSYM_ニュースメール情報主要ニュースフラグ_PC
        ,A.DSYM_ニュースメール情報主要ニュースフラグ_CP                      AS DSYM_ニュースメール情報主要ニュースフラグ_CP
        ,A.DSYM_ニュースメール情報日経ニュースフラグ_PC                      AS DSYM_ニュースメール情報日経ニュースフラグ_PC
        ,A.DSYM_ニュースメール情報日経ニュースフラグ_CP                      AS DSYM_ニュースメール情報日経ニュースフラグ_CP
        ,A.DSYM_MY日経メールフラグ_PC                                        AS DSYM_MY日経メールフラグ_PC
        ,A.DSYM_MY日経メールフラグ_CP                                        AS DSYM_MY日経メールフラグ_CP
        ,A.DSYM_ニュースメール情報速報夜間無しフラグ_PC                      AS DSYM_ニュースメール情報速報夜間無しフラグ_PC
        ,A.DSYM_ニュースメール情報速報夜間無しフラグ_CP                      AS DSYM_ニュースメール情報速報夜間無しフラグ_CP
        ,A.DSYM_メールマガジン情報電子版フラグ_PC                            AS DSYM_メールマガジン情報電子版フラグ_PC
        ,A.DSYM_メールマガジン情報電子版フラグ_CP                            AS DSYM_メールマガジン情報電子版フラグ_CP
        ,A.DSYM_電子版お知らせ許諾フラグ                                     AS DSYM_電子版お知らせ許諾フラグ
        ,A.DSYM_NIKKEI_Briefingメール許諾フラグ                              AS DSYM_NIKKEI_Briefingメール許諾フラグ
        ,A.DSG_Myグループ更新通知メール送信フラグ_PC                         AS DSG_Myグループ更新通知メール送信フラグ_PC
        ,A.IS_移行元サイト                                                   AS IS_移行元サイト
        ,A.IS_移行ステータス                                                 AS IS_移行ステータス
        ,A.BIZアカデミー会員フラグ                                           AS BIZアカデミー会員フラグ
        ,A.お試し会員フラグ                                                  AS お試し会員フラグ
        ,A.お試し利用実績フラグ                                              AS お試し利用実績フラグ
        ,A.日経ストア会員フラグ                                              AS 日経ストア会員フラグ
        ,A.SS区分                                                            AS SS区分
        ,A.SS解約申込予約フラグ                                              AS SS解約申込予約フラグ
        ,A.MJ区分                                                            AS MJ区分
        ,A.MJ解約申込予約フラグ                                              AS MJ解約申込予約フラグ
        ,A.NB区分                                                            AS NB区分
        ,A.NB解約申込予約フラグ                                              AS NB解約申込予約フラグ
        ,A.オプション契約フラグ                                              AS オプション契約フラグ
        ,A.JW区分                                                            AS JW区分
        ,A.JW解約申込予約フラグ                                              AS JW解約申込予約フラグ
        ,A.PRV区分                                                           AS PRV区分
        ,A.PRV解約申込予約フラグ                                             AS PRV解約申込予約フラグ
        ,A.グループライセンス料金プランコード                                AS グループライセンス料金プランコード
        ,A.グループ機能利用可能フラグ                                        AS グループ機能利用可能フラグ
        ,NVL(RP_REGIST.NIKKEI_RP::INT, 0)                                    AS 日経サービス利用フラグ
        ,NVL(RP_REGIST.BP_RP::INT, 0)                                        AS BPサービス利用フラグ
        ,A.課金開始日                                                        AS PRV解約申込予約フラグ
        ,A.課金区分                                                          AS グループライセンス料金プランコード
        ,A.初回申込無料期間中フラグ                                          AS グループ機能利用可能フラグ
        ,NVL(B.BPPM_FLG::INT, 0)                                             AS BPP一次統合フラグ
        ,NVL(B.BPPM2_FLG::INT, 0)                                            AS BPP二次統合フラグ
        ,CASE
         WHEN A.料金プランコード IN ('DS00000000000001', 'DS00000000000002', 'DS00000000000003', 'DS00000000000006') THEN --電子版 無料プラン、月ぎめプラン、Wプラン、auかんたん決済プラン
           NVL(C.PLAN_START_DATE::DATE, NULL)
         WHEN A.料金プランコード IN ('DS00000000001001', 'DS00000000001002', 'DS00000000000005') THEN --電子版 GooglePlayプラン,Appleプラン,ApplePayプラン
           NVL(D.PLAN_START_DATE::DATE, NULL)
         ELSE 
           NULL
         END AS プラン適用開始日
        ,CASE
         WHEN A.料金プランコード IN ('DS00000000000001', 'DS00000000000002', 'DS00000000000003', 'DS00000000000006') THEN --電子版 無料プラン、月ぎめプラン、Wプラン、auかんたん決済プラン
           NVL(C.PLAN_END_DATE::DATE, NULL)
         WHEN A.料金プランコード IN ('DS00000000001001', 'DS00000000001002', 'DS00000000000005') THEN --電子版 GooglePlayプラン,Appleプラン,ApplePayプラン
           NVL(D.PLAN_END_DATE::DATE, NULL)
         ELSE 
           NULL
         END AS プラン適用終了日
        ,CASE
         WHEN A.料金プランコード IN ('DS00000000000001', 'DS00000000000002', 'DS00000000000003','DS00000000001001', 'DS00000000001002', 'DS00000000000005', 'DS00000000000006') THEN  --電子版
           --「有料プラン開始日」が直近のデータを採用する
           (CASE
            WHEN NVL(C.CHARGED_PLAN_START_DATE,'1900-01-01') >= NVL(D.CHARGED_PLAN_START_DATE,'1900-01-01') THEN
              NVL(C.CHARGED_PLAN_START_DATE::DATE, NULL)
            ELSE
              NVL(D.CHARGED_PLAN_START_DATE::DATE, NULL)
            END)
         ELSE 
           NULL
         END AS 有料プラン開始日
        ,CASE
         WHEN A.料金プランコード IN ('DS00000000000001', 'DS00000000000002', 'DS00000000000003','DS00000000001001', 'DS00000000001002', 'DS00000000000005', 'DS00000000000006') THEN  --電子版
           --「有料プラン開始日」が直近のデータを採用する
           (CASE
            WHEN NVL(C.CHARGED_PLAN_START_DATE,'1900-01-01') >= NVL(D.CHARGED_PLAN_START_DATE,'1900-01-01') THEN
              NVL(C.CHARGED_PLAN_END_DATE::DATE, NULL)
            ELSE
              NVL(D.CHARGED_PLAN_END_DATE::DATE, NULL)
            END)
         ELSE 
           NULL
         END AS 有料プラン解約日取得
        ,A.INS_BATCH_ID                                                      AS INS_BATCH_ID
        ,A.INS_DT_TM                                                         AS INS_DT_TM
        ,A.UPD_BATCH_ID                                                      AS UPD_BATCH_ID
        ,A.UPD_DT_TM                                                         AS UPD_DT_TM
    FROM TEMP_AD_NIKKEI_ID A
    LEFT JOIN (
        --RP利用状態テーブルのRP利用のフラグ設定したデータを取得
        SELECT
             REG.USER_NO
            ,MAX(CASE
                WHEN M_NIKKEI.RP_ID IS NOT NULL THEN
                    1
                ELSE
                    0
                END) AS NIKKEI_RP          --日経サービスRP
            ,MAX(CASE
                WHEN M_BP.RP_ID IS NOT NULL THEN
                    1
                ELSE
                    0
                END) AS BP_RP              --BPサービスRP
        FROM
            {{ var.value.redshift_ims_schema_name }}.M_IS_NX_RP_REGISTRATION REG    --RP利用状態テーブル
        LEFT JOIN
            {{ var.value.redshift_ims_schema_name }}.M_IMS_RP M_NIKKEI
        ON REG.RP_ID = M_NIKKEI.RP_ID  AND M_NIKKEI.RP_TYPE = 1 AND M_NIKKEI.DELETE_FLG = '0'
        LEFT JOIN
            {{ var.value.redshift_ims_schema_name }}.M_IMS_RP M_BP
        ON REG.RP_ID = M_BP.RP_ID AND M_BP.RP_TYPE = 2 AND M_BP.DELETE_FLG = '0'
        WHERE
             REG.REG_STATUS = '1'          --ステータス
        GROUP BY REG.USER_NO
        ) RP_REGIST
            ON A.IS_会員番号 = RP_REGIST.USER_NO
    -- BPP一次統合フラグ／BPP二次統合フラグ取得
    LEFT JOIN 
        (SELECT
             ATTACH.C_LOCAL_USER_ID
            ,MAX(CASE WHEN ATTACH.KEY = 'BPPM'  THEN 1 ELSE 0 END) AS BPPM_FLG
            ,MAX(CASE WHEN ATTACH.KEY = 'BPPM2' THEN 1 ELSE 0 END) AS BPPM2_FLG
         FROM {{ var.value.redshift_ims_schema_name }}.M_IS_NX_USER_ATTACHMENT_ACCUM ATTACH
         WHERE
             ATTACH.CATEGORY = 'migration'
         GROUP BY ATTACH.C_LOCAL_USER_ID
        ) B
    ON
        A.IS_会員番号 = B.C_LOCAL_USER_ID
    -- プラン適用開始日／プラン適用終了日／有料プラン開始日／有料プラン解約日取得
    LEFT JOIN 
        (SELECT
             C.NIKKEI_ID_INTERNAL_MEMBER_NO
            ,C.PLAN_START_DATE
            ,C.PLAN_END_DATE
            ,C.CHARGED_PLAN_START_DATE
            ,C.CHARGED_PLAN_END_DATE
         FROM {{ var.value.redshift_ims_schema_name }}.T_KK_V_CONTRACT_ANALYZE C
         WHERE
             C.PLAN_ID IN ('DS00000000000001', 'DS00000000000002', 'DS00000000000003', 'DS00000000000006') --電子版 無料プラン、月ぎめプラン、Wプラン、auかんたん決済プラン
         AND
             C.CONTRACT_NO = C.LATEST_CONTRACT_NO --直近の契約
        ) C
    ON
    A.IS_会員番号 = C.NIKKEI_ID_INTERNAL_MEMBER_NO
    LEFT JOIN 
        (SELECT
             EX2.NIKKEI_ID_INTERNAL_MEMBER_NO
            ,EX2.FIRST_ENTRY_DATETIME::DATE AS PLAN_START_DATE
            ,EX2.PERMIT_END_DATETIME::DATE  AS PLAN_END_DATE
            ,EX2.FIRST_ENTRY_DATETIME::DATE AS CHARGED_PLAN_START_DATE
            ,EX2.PERMIT_END_DATETIME::DATE  AS CHARGED_PLAN_END_DATE
         FROM (SELECT
                 EX.NIKKEI_ID_INTERNAL_MEMBER_NO
                ,EX.FIRST_ENTRY_DATETIME
                ,EX.PERMIT_END_DATETIME
                ,ROW_NUMBER() OVER(
                    PARTITION BY
                      EX.NIKKEI_ID_INTERNAL_MEMBER_NO
                   -- 契約やデータ重複する場合は「初回登録日時」が直近のものを採用
                   ORDER BY
                      EX.FIRST_ENTRY_DATETIME DESC
                ) AS RANK
               FROM {{ var.value.redshift_ims_schema_name }}.T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING EX
               WHERE
                   EX.PLAN_ID IN ('DS00000000001001', 'DS00000000001002', 'DS00000000000005') --電子版 GooglePlayプラン,Appleプラン,ApplePayプラン
               AND EX.LATEST_EXTERNAL_SERVICE_PERMIT_KEY = EX.EXTERNAL_SERVICE_PERMIT_KEY --直近の契約
               ) EX2
         WHERE EX2.RANK = 1
        ) D
    ON
        A.IS_会員番号 = D.NIKKEI_ID_INTERNAL_MEMBER_NO
;
