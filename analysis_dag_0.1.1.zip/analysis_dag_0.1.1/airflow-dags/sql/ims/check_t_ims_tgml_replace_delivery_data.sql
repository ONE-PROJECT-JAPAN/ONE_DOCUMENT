/*******************************************************************************
  SQL名:
    TGML見積り洗替え管理　定期実行分完了チェック

  処理概要:
    本日のTGML見積り洗替え定期処理が完了しているかをチェックする

*******************************************************************************/

SELECT 
    COUNT(*) = 0
FROM 
    {{ var.value.redshift_ims_schema_name }}.T_IMS_TGML_REPLACE_DELIVERY_DATA
WHERE
    DATA_SOURCE = '1'
AND REPLACE_FLG = '0'
AND TO_CHAR(INS_DT_TM, 'YYYYMMDD') = TO_CHAR(date(convert_timezone('UTC', 'JST', '{{ next_execution_date }}')), 'YYYYMMDD')
;
