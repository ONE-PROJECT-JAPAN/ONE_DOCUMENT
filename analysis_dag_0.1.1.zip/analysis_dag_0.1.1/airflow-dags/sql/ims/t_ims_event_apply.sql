
/*******************************************************************************
  SQL名:
    統合イベント申込情報作成

  処理概要:
       統合イベント申込情報ビューを元に、統合イベント申込情報を作成する。
*******************************************************************************/

--全件削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_IMS_EVENT_APPLY
;

--挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_IMS_EVENT_APPLY
(
     NIKKEI_MEMBER_NO
    ,EVENT_NAME
    ,CATEGORY_NAME
    ,SUB_CATEGORY_NAME
    ,EVENT_START_DATE
    ,FREE_EVENT_FLG
)
SELECT
     NIKKEI_MEMBER_NO
    ,EVENT_NAME
    ,CATEGORY_NAME
    ,SUB_CATEGORY_NAME
    ,EVENT_START_DATE
    ,FREE_EVENT_FLG
FROM
    {{ var.value.redshift_ims_schema_name }}.V_IMS_EVENT_APPLY
WHERE
     NIKKEI_MEMBER_NO IS NOT NULL
;
