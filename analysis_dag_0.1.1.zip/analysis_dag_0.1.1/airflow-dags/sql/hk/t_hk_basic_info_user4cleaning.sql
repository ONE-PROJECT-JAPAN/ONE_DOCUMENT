
/*******************************************************************************
  SQL名:
    読者基本情報データ差分ファイル作成

  処理概要:
       クレンジングのためにIFテーブルのデータをクレンジング用テーブルに追加する
       読者基本情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by USER_NO) AS ROWID
    ,USER_NO
    ,NIKKEI_MEMBER_NO
    ,NIKKEI_ENTRY_DATE
    ,NIKKEI_NEW_CREATE_FLG
    ,CHARGE_CUST_NO
    ,ADDRESS_CD
    ,HON_SHISHA_CD
    ,ZIPCODE
    ,PREFECTURE_NM
    ,SHIKUTYOUSON_NM
    ,TSUSHO_NM
    ,CHOME_NM
    ,BANTI
    ,BUILDING
    ,NAME_COMPANY_NM
    ,NAME_COMPANY_NM_YOMI
    ,DEPARTMENT_NM
    ,SUBSCRIBER
    ,TELNO
    ,FAXNO
    ,DAYTIME_CONTACT
    ,EMAIL
    ,EMAIL_2
    ,SUBSCRIPTION_TYPE_CD
    ,NAYOSE_KEY
    ,SECONDARY_USE_SIGN
    ,UPDATE_KBN
    ,CREATE_UPDATE_USER
    ,CREATE_DATE
    ,UPDATE_DATE
    ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER
;

-- 読者基本情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
UNLOAD ($$
SELECT
   T.ROWID                              AS ROWID_IF
  ,T.USER_NO                            AS USER_NO
  ,NVL(T.ZIPCODE,'')                    AS ZIPCODE
  ,NVL(M.PREFECTURE_NM,'')       ||
       NVL(M.SHIKUTYOUSON_NM,'') ||
       NVL(M.TSUSHO_NM,'')       ||
       NVL(M.CHOME_NM,'')        ||
       NVL(T.BANTI,'')           ||
       NVL(T.BUILDING,'')              AS ADDRESS
  ,NVL(T.NAME_COMPANY_NM,'')           AS NAME_COMPANY_NM
  ,NVL(T.TELNO,'')                     AS TELNO
  ,NVL(T.DAYTIME_CONTACT,'')           AS DAYTIME_CONTACT
FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER_TEMP_CLEANSING T 
LEFT JOIN
  (SELECT
          ADDRESS_CD
         ,PREFECTURE_NM
         ,SHIKUTYOUSON_NM
         ,TSUSHO_NM
         ,CHOME_NM
   FROM {{ var.value.redshift_ims_schema_name }}.M_HK_ADDRESS
  ) M
ON
  T.ADDRESS_CD = M.ADDRESS_CD
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_USER_CL_AC AC
    WHERE
      T.USER_NO = AC.USER_NO
    AND
      NVL(T.ADDRESS_CD, '') = NVL(AC.ADDRESS_CD, '')
    AND
      NVL(T.ZIPCODE, '') = NVL(AC.ZIPCODE, '')
    AND
      NVL(M.PREFECTURE_NM, '') = NVL(AC.CLKEY_PREFECTURE_NM, '')
    AND
      NVL(M.SHIKUTYOUSON_NM, '') = NVL(AC.CLKEY_SHIKUTYOUSON_NM, '')
    AND
      NVL(M.TSUSHO_NM, '') = NVL(AC.CLKEY_TSUSHO_NM, '')
    AND
      NVL(M.CHOME_NM, '') = NVL(AC.CLKEY_CHOME_NM, '')
    AND
      NVL(T.BANTI, '') = NVL(AC.BANTI, '')
    AND
      NVL(T.BUILDING, '') = NVL(AC.BUILDING, '')
    AND
      NVL(T.NAME_COMPANY_NM, '') = NVL(AC.NAME_COMPANY_NM, '')
    AND
      NVL(T.TELNO, '') = NVL(AC.TELNO, '')
    AND
      NVL(T.DAYTIME_CONTACT, '') = NVL(AC.DAYTIME_CONTACT, '')
    AND
      NVL(T.EMAIL, '') = NVL(AC.EMAIL, '')
    AND
      NVL(T.EMAIL_2, '') = NVL(AC.EMAIL_2, '')
    AND
      AC.CL_END_DT = '9999-12-31'
  )
ORDER BY
  T.ADDRESS_CD
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_BASIC_INFO_USER/T_HK_BASIC_INFO_USER_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
