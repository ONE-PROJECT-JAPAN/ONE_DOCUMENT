/*******************************************************************************
  SQL名:
    試読お知らせ情報（リファレンス）データ差分ファイル作成

  処理概要:
       試読お知らせ情報（リファレンス）を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by HON_SHISHA_CD) AS ROWID
    ,HON_SHISHA_CD
    ,EXTEND_RESULT_ENQ_5
    ,INC_AND_DEC_TELNO
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF
;

-- 試読お知らせ情報（リファレンス）を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ('
SELECT
   M.ROWID             AS ROWID_IF
  ,M.HON_SHISHA_CD     AS HON_SHISHA_CD
  ,M.INC_AND_DEC_TELNO AS INC_AND_DEC_TELNO
FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING M
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC AC
    WHERE
      M.HON_SHISHA_CD = AC.HON_SHISHA_CD
    AND
      NVL(M.INC_AND_DEC_TELNO,\'\') = NVL(AC.INC_AND_DEC_TELNO,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_TRIAL_NOTICE_REF/T_HK_TRIAL_NOTICE_REF_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
