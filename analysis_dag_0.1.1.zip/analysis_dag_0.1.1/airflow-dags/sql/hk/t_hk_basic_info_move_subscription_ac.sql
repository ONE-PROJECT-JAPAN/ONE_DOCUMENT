
/*******************************************************************************
  SQL名:
    移転申込基本情報データ蓄積

  処理概要:
       移転申込基本情報テーブルにロードしたIFデータを元に
       移転申込基本情報蓄積テーブルにデータを蓄積する。

       蓄積キー:
         MOVE_NO
*******************************************************************************/
--差分削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION_AC
WHERE
(    MOVE_NO
)
IN
(
SELECT
     MOVE_NO
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION
)
;

--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION_AC
(
     MOVE_NO
    ,USER_NO
    ,RECEPTION_DATE
    ,NOW_STORE_CD
    ,NOW_STORE_SALES_METHOD
    ,NOW_HON_SHISHA_CD
    ,NOW_CONTACT_DATE
    ,NOW_CONTACT_PERSON
    ,ST_DATE
    ,ST_KBN_CD
    ,NEW_STORE_CD
    ,NEW_STORE_SALES_METHOD
    ,NEW_HON_SHISHA_CD
    ,NEW_STORE_FAXNO
    ,PAY_METHOD_CD
    ,MOVE_FROM_RECEPTION_PLACE_CD
    ,RECEPTION_PLACE_CD
    ,SUBSCRIPTION_KBN_CD
    ,RECEPTION_CLASS_CD
    ,REMARK
    ,FAX_STATUS
    ,FAX_STATUS_UPDATE_DATE
    ,APPROPRIATE_YMD
    ,UPDATE_KBN
    ,MEMO
    ,THANKYOUMAIL_SEND_DATE
    ,FOLLOWMAIL_SEND_DATE
    ,NOTICE_MAIL_SEND_DATE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     MOVE_NO
    ,USER_NO
    ,RECEPTION_DATE
    ,NOW_STORE_CD
    ,NOW_STORE_SALES_METHOD
    ,NOW_HON_SHISHA_CD
    ,NOW_CONTACT_DATE
    ,NOW_CONTACT_PERSON
    ,ST_DATE
    ,ST_KBN_CD
    ,NEW_STORE_CD
    ,NEW_STORE_SALES_METHOD
    ,NEW_HON_SHISHA_CD
    ,NEW_STORE_FAXNO
    ,PAY_METHOD_CD
    ,MOVE_FROM_RECEPTION_PLACE_CD
    ,RECEPTION_PLACE_CD
    ,SUBSCRIPTION_KBN_CD
    ,RECEPTION_CLASS_CD
    ,REMARK
    ,FAX_STATUS
    ,FAX_STATUS_UPDATE_DATE
    ,APPROPRIATE_YMD
    ,UPDATE_KBN
    ,MEMO
    ,THANKYOUMAIL_SEND_DATE
    ,FOLLOWMAIL_SEND_DATE
    ,NOTICE_MAIL_SEND_DATE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_MOVE_SUBSCRIPTION
;
