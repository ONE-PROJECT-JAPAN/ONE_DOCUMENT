--アンケート回答（紙課金システム連携用）ヘッダ・明細
CREATE TEMPORARY TABLE PK_ENQ_PIVOT
(
    seq SMALLINT -- 1～20
);


INSERT INTO PK_ENQ_PIVOT VALUES (1);
INSERT INTO PK_ENQ_PIVOT VALUES (2);
INSERT INTO PK_ENQ_PIVOT VALUES (3);
INSERT INTO PK_ENQ_PIVOT VALUES (4);
INSERT INTO PK_ENQ_PIVOT VALUES (5);
INSERT INTO PK_ENQ_PIVOT VALUES (6);
INSERT INTO PK_ENQ_PIVOT VALUES (7);
INSERT INTO PK_ENQ_PIVOT VALUES (8);
INSERT INTO PK_ENQ_PIVOT VALUES (9);
INSERT INTO PK_ENQ_PIVOT VALUES (10);
INSERT INTO PK_ENQ_PIVOT VALUES (11);
INSERT INTO PK_ENQ_PIVOT VALUES (12);
INSERT INTO PK_ENQ_PIVOT VALUES (13);
INSERT INTO PK_ENQ_PIVOT VALUES (14);
INSERT INTO PK_ENQ_PIVOT VALUES (15);
INSERT INTO PK_ENQ_PIVOT VALUES (16);
INSERT INTO PK_ENQ_PIVOT VALUES (17);
INSERT INTO PK_ENQ_PIVOT VALUES (18);
INSERT INTO PK_ENQ_PIVOT VALUES (19);
INSERT INTO PK_ENQ_PIVOT VALUES (20);


-- 一時テーブル: アンケート回答（紙課金システム連携用）ワーク
CREATE TEMPORARY TABLE W_HK_PK_ENQ_REPLY_TMP
(
    ENQ_NO             VARCHAR(44) NOT NULL ,
    USER_NO            VARCHAR(40) NOT NULL ,
    CAMP_CD            VARCHAR(40) ,
    COL_ID             VARCHAR(16) NOT NULL ,
    QUESTION           VARCHAR(1020) ,
    REPLY_NO           VARCHAR(16000) ,
    REPLY              VARCHAR(16000) ,
    CREATE_UPDATE_USER VARCHAR(40) ,
    CREATE_UPDATE_DATE TIMESTAMP NOT NULL ,
    UPDATE_CNT         BIGINT NOT NULL 
)
;


INSERT INTO W_HK_PK_ENQ_REPLY_TMP
SELECT
    sub.enq_no
   ,sub.user_no
   ,sub.camp_cd
   ,sub.col_id
   ,sub.question
   ,sub.reply_no
   ,sub.reply
   ,sub.create_update_user
   ,sub.create_update_date
   ,0
FROM
(
    SELECT
         enq.enq_no
        ,enq.user_no
        ,enq.camp_cd
        ,p.seq::VARCHAR as col_id
        ,CASE p.seq
            WHEN  1 THEN enq.question_1
            WHEN  2 THEN enq.question_2
            WHEN  3 THEN enq.question_3
            WHEN  4 THEN enq.question_4
            WHEN  5 THEN enq.question_5
            WHEN  6 THEN enq.question_6
            WHEN  7 THEN enq.question_7
            WHEN  8 THEN enq.question_8
            WHEN  9 THEN enq.question_9
            WHEN 10 THEN enq.question_10
            WHEN 11 THEN enq.question_11
            WHEN 12 THEN enq.question_12
            WHEN 13 THEN enq.question_13
            WHEN 14 THEN enq.question_14
            WHEN 15 THEN enq.question_15
            WHEN 16 THEN enq.question_16
            WHEN 17 THEN enq.question_17
            WHEN 18 THEN enq.question_18
            WHEN 19 THEN enq.question_19
            WHEN 20 THEN enq.question_20
        END AS question
       ,CASE p.seq
            WHEN  1 THEN enq.reply_no_1
            WHEN  2 THEN enq.reply_no_2
            WHEN  3 THEN enq.reply_no_3
            WHEN  4 THEN enq.reply_no_4
            WHEN  5 THEN enq.reply_no_5
            WHEN  6 THEN enq.reply_no_6
            WHEN  7 THEN enq.reply_no_7
            WHEN  8 THEN enq.reply_no_8
            WHEN  9 THEN enq.reply_no_9
            WHEN 10 THEN enq.reply_no_10
            WHEN 11 THEN enq.reply_no_11
            WHEN 12 THEN enq.reply_no_12
            WHEN 13 THEN enq.reply_no_13
            WHEN 14 THEN enq.reply_no_14
            WHEN 15 THEN enq.reply_no_15
            WHEN 16 THEN enq.reply_no_16
            WHEN 17 THEN enq.reply_no_17
            WHEN 18 THEN enq.reply_no_18
            WHEN 19 THEN enq.reply_no_19
            WHEN 20 THEN enq.reply_no_20
        END AS reply_no
       ,CASE p.seq
            WHEN  1 THEN enq.reply_1
            WHEN  2 THEN enq.reply_2
            WHEN  3 THEN enq.reply_3
            WHEN  4 THEN enq.reply_4
            WHEN  5 THEN enq.reply_5
            WHEN  6 THEN enq.reply_6
            WHEN  7 THEN enq.reply_7
            WHEN  8 THEN enq.reply_8
            WHEN  9 THEN enq.reply_9
            WHEN 10 THEN enq.reply_10
            WHEN 11 THEN enq.reply_11
            WHEN 12 THEN enq.reply_12
            WHEN 13 THEN enq.reply_13
            WHEN 14 THEN enq.reply_14
            WHEN 15 THEN enq.reply_15
            WHEN 16 THEN enq.reply_16
            WHEN 17 THEN enq.reply_17
            WHEN 18 THEN enq.reply_18
            WHEN 19 THEN enq.reply_19
            WHEN 20 THEN enq.reply_20
        END AS reply
       ,enq.create_update_user
       ,enq.create_update_date
       ,enq.update_cnt
    FROM
        {{ var.value.redshift_ims_schema_name }}.W_HK_PK_ENQ_REPLY AS enq
    CROSS JOIN
        PK_ENQ_PIVOT AS p
) sub
;


DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR;

DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR
(
     ENQ_NO
    ,USER_NO
    ,CAMP_CD
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
)
SELECT
     DISTINCT
     ENQ_NO
    ,USER_NO
    ,CAMP_CD
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
FROM
     W_HK_PK_ENQ_REPLY_TMP
;


INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL
(
     ENQ_NO
    ,COL_ID
    ,QUESTION
    ,REPLY_NO
    ,REPLY
)
SELECT
     ENQ_NO
    ,COL_ID
    ,QUESTION
    ,REPLY_NO
    ,REPLY
FROM
     W_HK_PK_ENQ_REPLY_TMP
;
