/*******************************************************************************
  SQL名:
    試読お知らせ情報（リファレンス）データクレンジング・蓄積

  処理概要:
       試読お知らせ情報（リファレンス）テーブルにロードしたIFデータを元に
       試読お知らせ情報（リファレンス）クレンジング蓄積テーブルにデータを蓄積する。
*******************************************************************************/

-- クレンジング後ファイルより、一時表テーブル作成
CREATE TEMP TABLE T_HK_TRIAL_NOTICE_REF_EXT
(
     ROWID_IF                      BIGINT
     ,HON_SHISHA_CD                SMALLINT
     ,INC_AND_DEC_TELNO            VARCHAR(80)
     ,INC_AND_DEC_TELNO_CL         VARCHAR(1020)
);

--一時表テーブル作成にクレンジング後ファイル挿入
COPY T_HK_TRIAL_NOTICE_REF_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_TRIAL_NOTICE_REF_CL/T_HK_TRIAL_NOTICE_REF_'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER ','
QUOTE '"'
;

--差分更新
UPDATE {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC CLAC
SET
     CL_END_DT  = TO_DATE(CONVERT_TIMEZONE ('Asia/Tokyo', DATEADD(DAY, -1, {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE())), 'YYYY-MM-DD')
    ,UPD_PGM_ID = '{{ dag.dag_id }}'
    ,UPD_DT_TM  = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
     T_HK_TRIAL_NOTICE_REF_EXT EXT
WHERE
     EXT.HON_SHISHA_CD         = CLAC.HON_SHISHA_CD
AND
     CLAC.CL_END_DT       = '9999-12-31'
;

--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC
(
     HON_SHISHA_CD
    ,EXTEND_RESULT_ENQ_5
    ,INC_AND_DEC_TELNO
    ,INC_AND_DEC_TELNO_CL
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     M.HON_SHISHA_CD
    ,M.EXTEND_RESULT_ENQ_5
    ,M.INC_AND_DEC_TELNO
    ,NULLIF(EXT.INC_AND_DEC_TELNO_CL, '') AS INC_AND_DEC_TELNO_CL
    ,M.CREATE_UPDATE_USER
    ,M.CREATE_UPDATE_DATE
    ,M.UPDATE_CNT
    ,{{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() AS CL_START_DT
    ,'9999-12-31' AS CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING M
INNER JOIN
     T_HK_TRIAL_NOTICE_REF_EXT EXT
ON
     M.ROWID = EXT.ROWID_IF
;

--クレンジング蓄積テーブルから一時表テーブルにコピー
CREATE TEMP TABLE TEMP_T_HK_TRIAL_NOTICE_REF_CL_AC AS
SELECT
     HON_SHISHA_CD
    ,EXTEND_RESULT_ENQ_5
    ,INC_AND_DEC_TELNO
    ,INC_AND_DEC_TELNO_CL
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC
;

--クレンジング蓄積テーブルからデータを削除
DELETE
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC
;

--クレンジング蓄積テーブルの一時表テーブルにIF元テーブルを外部結合し、クレンジング蓄積テーブルに挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_CL_AC
(
     HON_SHISHA_CD
    ,EXTEND_RESULT_ENQ_5
    ,INC_AND_DEC_TELNO
    ,INC_AND_DEC_TELNO_CL
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     CASE WHEN IF.HON_SHISHA_CD IS NULL THEN CLAC.HON_SHISHA_CD ELSE IF.HON_SHISHA_CD END AS HON_SHISHA_CD
    ,CASE WHEN IF.HON_SHISHA_CD IS NULL THEN CLAC.EXTEND_RESULT_ENQ_5 ELSE IF.EXTEND_RESULT_ENQ_5 END AS EXTEND_RESULT_ENQ_5
    ,CLAC.INC_AND_DEC_TELNO
    ,CLAC.INC_AND_DEC_TELNO_CL
    ,CASE WHEN IF.HON_SHISHA_CD IS NULL THEN CLAC.CREATE_UPDATE_USER ELSE IF.CREATE_UPDATE_USER END AS CREATE_UPDATE_USER
    ,CASE WHEN IF.HON_SHISHA_CD IS NULL THEN CLAC.CREATE_UPDATE_DATE ELSE IF.CREATE_UPDATE_DATE END AS CREATE_UPDATE_DATE
    ,CASE WHEN IF.HON_SHISHA_CD IS NULL THEN CLAC.UPDATE_CNT ELSE IF.UPDATE_CNT END AS UPDATE_CNT
    ,CLAC.CL_START_DT
    ,CLAC.CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_HK_TRIAL_NOTICE_REF_CL_AC CLAC
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING IF
ON
    CLAC.HON_SHISHA_CD = IF.HON_SHISHA_CD
;

/*******************************************************************************
  SQL名:
    一時テーブル削除
    「IF EXISTS」にて存在する場合のみテーブル削除を実施する
    後始末でエラー発生しないようにするためで、
    テーブルの作成時に存在していたらデータ削除してそのまま使用するように設計
*******************************************************************************/

DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_TRIAL_NOTICE_REF_TEMP_CLEANSING
;
