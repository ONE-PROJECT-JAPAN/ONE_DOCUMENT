/*******************************************************************************
  SQL名:
    THANKYOUMAIL送信ログデータ差分ファイル作成

  処理概要:
       THANKYOUMAIL送信ログを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by SEND_DT_TM, SUBSCRIPTION_NO) AS ROWID
   ,SEND_DT_TM
   ,SUBSCRIPTION_NO
   ,USER_NO
   ,SEND_TO_EMAIL
   ,SEND_FROM_EMAIL
   ,MAIL_SENDER_ID
   ,SEND_MAIL_CLASS
   ,SEND_MAIL_BODY
   ,SEND_MAIL_TITLE
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
   ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG
;

-- THANKYOUMAIL送信ログを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ('
SELECT
   T.ROWID           AS ROWID_IF
  ,T.SEND_DT_TM      AS USER_NO
  ,T.SUBSCRIPTION_NO AS SUBSCRIPTION_NO
FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING T
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC AC
    WHERE
      T.SEND_DT_TM = AC.SEND_DT_TM
    AND
      T.SUBSCRIPTION_NO = AC.SUBSCRIPTION_NO
    AND
      NVL(T.SEND_TO_EMAIL,\'\') = NVL(AC.SEND_TO_EMAIL,\'\')
    AND
      NVL(T.SEND_FROM_EMAIL,\'\') = NVL(AC.SEND_FROM_EMAIL,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_THANKYOUMAIL_SEND_LOG/T_HK_THANKYOUMAIL_SEND_LOG_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
