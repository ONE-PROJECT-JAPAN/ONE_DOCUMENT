/*******************************************************************************
  SQL名:
    苦情読者基本情報データ差分ファイル作成

  処理概要:
       苦情読者基本情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_COMPLAINT_USER_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_COMPLAINT_USER_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by ADDRESS_CD) AS ROWID
   ,USER_NO
   ,NIKKEI_MEMBER_NO
   ,NIKKEI_MEMBER_CREATE_DATE
   ,NIKKEI_MEMBER_SIGN_UP_FLG
   ,CHARGE_CUST_NO
   ,ADDRESS_CD
   ,HON_SHISHA_CD
   ,ZIPCODE
   ,PREFECTURE_NM
   ,SHIKUTYOUSON_NM
   ,TSUSHO_NM
   ,CHOME_NM
   ,BANTI
   ,BUILDING
   ,NAME_COMPANY_NM
   ,NAME_COMPANY_NM_YOMI
   ,DEPARTMENT_NM
   ,SUBSCRIBER
   ,TELNO
   ,FAXNO
   ,DAYTIME_CONTACT
   ,EMAIL
   ,EMAIL_2
   ,SUBSCRIPTION_TYPE_CD
   ,SECONDARY_USE_SIGN
   ,NAYOSE_KEY
   ,UPDATE_KBN
   ,CREATE_UPDATE_USER
   ,CREATE_DATE
   ,UPDATE_DATE
   ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_COMPLAINT_USER
;

-- 苦情読者基本情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ($$
SELECT
   T.ROWID                             AS ROWID_IF
  ,T.USER_NO                           AS USER_NO
  ,NVL(T.ZIPCODE,'')                   AS ZIPCODE
  ,NVL(T.PREFECTURE_NM,'')        ||
       NVL(T.SHIKUTYOUSON_NM,'')  ||
       NVL(T.TSUSHO_NM,'')        ||
       NVL(T.CHOME_NM,'')         ||
       NVL(T.BANTI,'')            ||
       NVL(T.BUILDING,'')              AS ADDRESS
  ,NVL(T.NAME_COMPANY_NM,'')           AS NAME_COMPANY_NM
  ,NVL(T.TELNO,'')                     AS TELNO
  ,NVL(T.DAYTIME_CONTACT,'')           AS DAYTIME_CONTACT
FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_COMPLAINT_USER_TEMP_CLEANSING T 
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_COMPLAINT_USER_CL_AC AC
    WHERE
      T.USER_NO = AC.USER_NO
    AND
      NVL(T.ZIPCODE,'') = NVL(AC.ZIPCODE,'')
    AND
      NVL(T.PREFECTURE_NM,'') = NVL(AC.PREFECTURE_NM,'')
    AND
      NVL(T.SHIKUTYOUSON_NM,'') = NVL(AC.SHIKUTYOUSON_NM,'')
    AND
      NVL(T.TSUSHO_NM,'') = NVL(AC.TSUSHO_NM,'')
    AND
      NVL(T.CHOME_NM,'') = NVL(AC.CHOME_NM,'')
    AND
      NVL(T.BANTI,'') = NVL(AC.BANTI,'')
    AND
      NVL(T.BUILDING,'') = NVL(AC.BUILDING,'')
    AND
      NVL(T.NAME_COMPANY_NM,'') = NVL(AC.NAME_COMPANY_NM,'')
    AND
      NVL(T.TELNO,'') = NVL(AC.TELNO,'')
    AND
      NVL(T.DAYTIME_CONTACT,'') = NVL(AC.DAYTIME_CONTACT,'')
    AND
      NVL(T.EMAIL,'') = NVL(AC.EMAIL,'')
    AND
      NVL(T.EMAIL_2,'') = NVL(AC.EMAIL_2,'')
    AND
      AC.CL_END_DT = '9999-12-31'
  )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_BASIC_INFO_COMPLAINT_USER/T_HK_BASIC_INFO_COMPLAINT_USER_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
