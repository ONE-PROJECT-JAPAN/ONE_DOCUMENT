/*******************************************************************************
  SQL名:
    町名番地データ差分ファイル作成

  処理概要:
       町名番地を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.M_HK_BANTI_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.M_HK_BANTI_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by PREFECTURE_CD, SHIKUTYOUSON_CD, TSUSHO_CD, CHOME_CD) AS ROWID
    ,PREFECTURE_CD
    ,SHIKUTYOUSON_CD
    ,TSUSHO_CD
    ,CHOME_CD
    ,ZIPCODE
    ,TSUSHO_NM
    ,CHOME_NM
    ,TSUSHO_NM_YOMI
    ,TSUSHO_NM_KANA
    ,CHOME_NM_YOMI
    ,CHOME_NM_KANA
    ,TSUSHO_SIKIBETSU
    ,DELETE_FLG
    ,DISP_FLG
    ,JUSHO_NM
    ,JUSHO_NM_YOMI
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.M_HK_BANTI
;

-- 町名番地を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ($$
SELECT
   M.ROWID                             AS ROWID_IF
  ,M.PREFECTURE_CD                     AS PREFECTURE_CD
  ,M.SHIKUTYOUSON_CD                   AS SHIKUTYOUSON_CD
  ,M.TSUSHO_CD                         AS TSUSHO_CD
  ,M.CHOME_CD                          AS CHOME_CD
  ,RTRIM(NVL(M.ZIPCODE,''))            AS ZIPCODE
  ,NVL(M.PREFECTURE_CD,'')       ||
       NVL(M.SHIKUTYOUSON_CD,'') ||
       NVL(M.TSUSHO_CD,'')       ||
       NVL(M.CHOME_CD,'')              AS ADDRESS_CD
FROM
  {{ var.value.redshift_ims_schema_name }}.M_HK_BANTI_TEMP_CLEANSING M 
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_BANTI_CL_AC AC
    WHERE
      M.PREFECTURE_CD   = AC.PREFECTURE_CD
    AND
      M.SHIKUTYOUSON_CD = AC.SHIKUTYOUSON_CD
    AND
      M.TSUSHO_CD       = AC.TSUSHO_CD
    AND
      M.CHOME_CD        = AC.CHOME_CD
    AND
      NVL(M.ZIPCODE,'') = NVL(AC.ZIPCODE,'')
    AND
      AC.CL_END_DT      = '9999-12-31'
  )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/M_HK_BANTI/M_HK_BANTI_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
