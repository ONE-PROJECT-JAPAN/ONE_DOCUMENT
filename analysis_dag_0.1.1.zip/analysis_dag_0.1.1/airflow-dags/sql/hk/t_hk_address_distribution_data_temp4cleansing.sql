/*******************************************************************************
  SQL名:
    住所配布データデータ差分ファイル作成

  処理概要:
       住所配布データを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_ADDRESS_DISTRIBUTION_DATA_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_ADDRESS_DISTRIBUTION_DATA_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by ADDRESS_CD, PREFECTURE_CD, SHIKUTYOUSON_CD) AS ROWID
    ,ADDRESS_CD
    ,PREFECTURE_CD
    ,SHIKUTYOUSON_CD
    ,TSUSHO_CD
    ,CHOME_CD
    ,NEW_ADDRESS_CD
    ,ADDRESS_TYPE
    ,ZIPCODE
    ,BCD_INFO
    ,BCD_MOJINUM
    ,ZIPCODE_INFO_1
    ,ZIPCODE_INFO_2
    ,OYAKO_SIKIBETSU_FLG
    ,OYAKO_CD
    ,PREFECTURE_FUYOU_CD
    ,PREFECTURE_KANA
    ,SHIKUTYOUSON_KANA
    ,TSUSHO_KANA
    ,CHOME_KANA
    ,PREFECTURE_KANA_MOJINUM
    ,SHIKUTYOUSON_KANA_MOJINUM
    ,TSUSHO_KANA_MOJINUM
    ,CHOME_KANA_MOJINUM
    ,TOTAL_KANA_MOJINUM
    ,PREFECTURE_NM
    ,SHIKUTYOUSON_NM
    ,TSUSHO_NM
    ,CHOME_NM
    ,PREFECTURE_NM_MOJINUM
    ,SHIKUTYOUSON_NM_MOJINUM
    ,TSUSHO_NM_MOJINUM
    ,CHOME_NM_MOJINUM
    ,TOTAL_MOJINUM
    ,JISHU_PREFECTURE
    ,JISHU_CITY_1
    ,JISHU_CITY_2
    ,JISHU_TOWN_1
    ,JISHU_TOWN_2
    ,JISHU_CHOME_1
    ,JISHU_CHOME_2
    ,OAZA_FLG_1
    ,OAZA_FLG_2
    ,TSUSHO_SIKIBETSU
    ,TSUSHO_FLG
    ,DATA_YM
    ,OLD_YM
    ,NEW_CD_YM
    ,KOSHO_YM
    ,ZIPCODE_YM
    ,BCD_YM
    ,OYAKO_YM
    ,TSUSHO_YM
    ,CHOME_YM
    ,OLD_ZIPCODE
    ,MODIFY_CD
    ,DISP_FLG
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_ADDRESS_DISTRIBUTION_DATA
;

-- 住所配布データを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ($$
SELECT
   M.ROWID                             AS ROWID_IF
  ,M.ADDRESS_CD                        AS ADDRESS_CD
  ,M.PREFECTURE_CD                     AS PREFECTURE_CD
  ,M.SHIKUTYOUSON_CD                   AS SHIKUTYOUSON_CD
  ,RTRIM(NVL(M.ZIPCODE,''))            AS ZIPCODE
  ,NVL(M.PREFECTURE_NM, '')       ||
       NVL(M.SHIKUTYOUSON_NM,'')  ||
       NVL(M.TSUSHO_NM,'')        ||
       NVL(M.CHOME_NM,'')              AS ADDRESS
FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_ADDRESS_DISTRIBUTION_DATA_TEMP_CLEANSING M
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM {{ var.value.redshift_ims_schema_name }}.T_HK_ADDRESS_DISTRIBUTION_DATA_CL_AC AC
    WHERE
      M.ADDRESS_CD = AC.ADDRESS_CD
    AND
      M.PREFECTURE_CD = AC.PREFECTURE_CD
    AND
      M.SHIKUTYOUSON_CD = AC.SHIKUTYOUSON_CD
    AND
      NVL(M.ZIPCODE,'') = NVL(AC.ZIPCODE,'')
    AND
      NVL(M.PREFECTURE_NM,'') = NVL(AC.PREFECTURE_NM,'')
    AND
      NVL(M.SHIKUTYOUSON_NM,'') = NVL(AC.SHIKUTYOUSON_NM,'')
    AND
      NVL(M.TSUSHO_NM,'') = NVL(AC.TSUSHO_NM,'')
    AND
      NVL(M.CHOME_NM,'') = NVL(AC.CHOME_NM,'')
    AND
      AC.CL_END_DT = '9999-12-31'
  )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_ADDRESS_DISTRIBUTION_DATA/T_HK_ADDRESS_DISTRIBUTION_DATA_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
