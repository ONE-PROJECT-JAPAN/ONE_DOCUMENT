/*******************************************************************************
  SQL名:
    苦情読者追加情報データ差分ファイル作成

  処理概要:
       苦情読者追加情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_COMPLAINT_USER_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_COMPLAINT_USER_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by USER_NO) AS ROWID
   ,USER_NO
   ,SEX
   ,BIRTHDAY
   ,COMPANY_NM
   ,DEPARTMENT_NM
   ,POST_NM
   ,COLLEGE_NM
   ,COURSE_NM
   ,COURSE_DETAIL_NM
   ,OCCUPATION_NM
   ,SECONDARY_READING
   ,UPDATE_KBN
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
   ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_COMPLAINT_USER
;

-- 苦情読者追加情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ('
SELECT
   T.ROWID              AS ROWID_IF
  ,T.USER_NO            AS USER_NO
  ,T.COMPANY_NM         AS COMPANY_NM

FROM
  {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_COMPLAINT_USER_TEMP_CLEANSING T 
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_COMPLAINT_USER_CL_AC AC
    WHERE
      T.USER_NO = AC.USER_NO
    AND
      NVL(T.COMPANY_NM,\'\') = NVL(AC.COMPANY_NM,\'\')
    AND
      NVL(T.OCCUPATION_NM,\'\') = NVL(AC.OCCUPATION_NM,\'\')
    AND
      NVL(T.SECONDARY_READING,\'\') = NVL(AC.SECONDARY_READING,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_ADDITIONAL_INFO_COMPLAINT_USER/T_HK_ADDITIONAL_INFO_COMPLAINT_USER_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;

