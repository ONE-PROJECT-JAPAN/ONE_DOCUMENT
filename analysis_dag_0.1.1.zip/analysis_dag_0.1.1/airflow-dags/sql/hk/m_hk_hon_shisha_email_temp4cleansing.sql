/*******************************************************************************
  SQL名:
    本支社メールアドレスデータ差分ファイル作成

  処理概要:
       本支社メールアドレスを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_EMAIL_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_EMAIL_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by HON_SHISHA_CD) AS ROWID
   ,HON_SHISHA_CD
   ,EMAIL
   ,SENDER_NM
   ,CREATE_UPDATE_USER
   ,CREATE_UPDATE_DATE
FROM {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_EMAIL
;

-- 本支社メールアドレスを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ('
SELECT
   M.ROWID         AS ROWID_IF
  ,M.HON_SHISHA_CD AS HON_SHISHA_CD
FROM
  {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_EMAIL_TEMP_CLEANSING M
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_HON_SHISHA_EMAIL_CL_AC AC
    WHERE
      M.HON_SHISHA_CD = AC.HON_SHISHA_CD
    AND
      NVL(M.EMAIL,\'\') = NVL(AC.EMAIL,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/M_HK_HON_SHISHA_EMAIL/M_HK_HON_SHISHA_EMAIL_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
