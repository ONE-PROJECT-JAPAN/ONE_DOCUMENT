--アンケート回答（紙課金システム連携用）ヘッダ・明細蓄積
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR_AC
WHERE
(    ENQ_NO
)
IN
(
SELECT
     ENQ_NO
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR
)
;

DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL_AC
WHERE
(    ENQ_NO
    ,COL_ID
)
IN
(
SELECT
     ENQ_NO
    ,COL_ID
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR_AC
(
     ENQ_NO
    ,USER_NO
    ,CAMP_CD
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     ENQ_NO
    ,USER_NO
    ,CAMP_CD
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,'{{ dag.dag_id }}' AS INS_BATCH_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_BATCH_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_HDR
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL_AC
(
     ENQ_NO
    ,COL_ID
    ,QUESTION
    ,REPLY_NO
    ,REPLY
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     ENQ_NO
    ,COL_ID
    ,QUESTION
    ,REPLY_NO
    ,REPLY
    ,'{{ dag.dag_id }}' AS INS_BATCH_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_BATCH_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_PK_ENQ_REPLY_DTL
;
