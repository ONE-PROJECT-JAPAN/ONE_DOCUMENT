
/*******************************************************************************
  SQL名:
    申込媒体（紙課金システム連携用）データ蓄積

  処理概要:
       申込媒体（紙課金システム連携用）テーブルにロードしたIFデータを元に申込媒体（紙課金システム連携用）蓄積テーブルに
       データを蓄積する。

       蓄積キー:
         SUBSCRIPTION_NO
         BAITAI_CD
*******************************************************************************/
--差分削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI_AC
WHERE (
         SUBSCRIPTION_NO
        ,BAITAI_CD
    ) IN (
            SELECT
                 SUBSCRIPTION_NO
                ,BAITAI_CD
            FROM {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI
        )
;

--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI_AC
(
     SUBSCRIPTION_NO
    ,BAITAI_CD
    ,CIRCULATION
    ,DELIVERY_STOP_IGNORE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
 SELECT
     SUBSCRIPTION_NO
    ,BAITAI_CD
    ,CIRCULATION
    ,DELIVERY_STOP_IGNORE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.M_HK_PK_SUBSCRIPTION_BAITAI
;
