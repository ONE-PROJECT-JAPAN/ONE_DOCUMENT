/*******************************************************************************
  SQL名:
    販売店住所データ差分ファイル作成

  処理概要:
       販売店住所を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/

-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.M_HK_STORE_ADDRESS_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.M_HK_STORE_ADDRESS_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by PREFECTURE_CD, ZIPCODE) AS ROWID
    ,STORE_CD
    ,ADDRESS_CLASS_CD
    ,SHINBUN_NM_YOMI
    ,SHINBUN_NM
    ,ADDRESSEE
    ,ZIPCODE
    ,PREFECTURE_CD
    ,CITY_NM_YOMI
    ,BANTI_YOMI
    ,CITY_NM
    ,BANTI
    ,TELNO
    ,FAXNO
    ,SEARCH_TELNO
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
FROM {{ var.value.redshift_ims_schema_name }}.M_HK_STORE_ADDRESS
;

-- 販売店住所を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ($$
SELECT
   M.ROWID                          AS ROWID_IF
  ,M.STORE_CD                       AS STORE_CD
  ,M.ADDRESS_CLASS_CD               AS ADDRESS_CLASS_CD
  ,NVL(M.ZIPCODE,'')                AS ZIPCODE
  ,NVL(A.PREFECTURE_NM, '')  ||
        NVL(M.CITY_NM,'')    ||
        NVL(M.BANTI,'')             AS ADDRESS
  ,NVL(M.TELNO,'')                  AS TELNO
FROM
  {{ var.value.redshift_ims_schema_name }}.M_HK_STORE_ADDRESS_TEMP_CLEANSING M
  -- 都道府県コードをキーに住所マスタテーブルから都道府県名を取得
LEFT JOIN
  (SELECT DISTINCT
          PREFECTURE_NM
         ,PREFECTURE_CD
   FROM {{ var.value.redshift_ims_schema_name }}.M_HK_ADDRESS
  ) A
ON
  M.PREFECTURE_CD = A.PREFECTURE_CD
WHERE
  NOT EXISTS(
    SELECT 'X'
    FROM {{ var.value.redshift_ims_schema_name }}.M_HK_STORE_ADDRESS_CL_AC AC
    WHERE
      M.STORE_CD = AC.STORE_CD
    AND
      M.ADDRESS_CLASS_CD = AC.ADDRESS_CLASS_CD
    AND
      NVL(M.ZIPCODE,'') = NVL(AC.ZIPCODE,'')
    AND
      NVL(M.PREFECTURE_CD,'') = NVL(AC.PREFECTURE_CD,'')
    AND
      NVL(M.CITY_NM,'') = NVL(AC.CITY_NM,'')
    AND
      NVL(M.BANTI,'') = NVL(AC.BANTI,'')
    AND
      NVL(M.TELNO,'') = NVL(AC.TELNO,'')
    AND
      AC.CL_END_DT = '9999-12-31'
  )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/M_HK_STORE_ADDRESS/M_HK_STORE_ADDRESS_'
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
