
/*******************************************************************************
  SQL名:
    読者追加情報データクレンジング・蓄積

  処理概要:
       読者追加情報テーブルにロードしたIFデータを元に
       読者追加情報クレンジング蓄積テーブルにデータを蓄積する。
       後始末としてデータクレンジング用の一時テーブルを削除する。
*******************************************************************************/
-- クレンジング後ファイルより、一時表テーブル作成
CREATE TEMP TABLE T_HK_ADDITIONAL_INFO_USER_EXT
(
     ROWID_IF                BIGINT
    ,USER_NO                 VARCHAR(40)
    ,COMPANY_NM              VARCHAR(120)
    ,COMPANY_NM_CL_LAST_NM   VARCHAR(484)
    ,COMPANY_NM_CL_FIRST_NM  VARCHAR(484)
    ,COMPANY_NM_CL_NM        VARCHAR(1440)
    ,COMPANY_NM_CL_CORP_NM   VARCHAR(1440)
    ,COMPANY_NM_CL_DEPT_NM   VARCHAR(400)
);

--一時表テーブル作成にクレンジング後ファイル挿入
copy T_HK_ADDITIONAL_INFO_USER_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_ADDITIONAL_INFO_USER_CL/T_HK_ADDITIONAL_INFO_USER_'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER ','
QUOTE '"'
;

--差分更新
UPDATE {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC CLAC
SET
     CL_END_DT  = TO_DATE(CONVERT_TIMEZONE ( 'Asia/Tokyo', DATEADD(DAY, -1, {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE())), 'YYYY-MM-DD')
    ,UPD_PGM_ID = '{{ dag.dag_id }}'
    ,UPD_DT_TM  = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM
     T_HK_ADDITIONAL_INFO_USER_EXT EXT
WHERE
     EXT.USER_NO     = CLAC.USER_NO
-- クレンジング蓄積テーブルの有効期間終了日が'9999-12-31'
AND
     CLAC.CL_END_DT  = '9999-12-31'
;

--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC
(
     USER_NO
    ,SEX
    ,BIRTHDAY
    ,COMPANY_NM
    ,DEPARTMENT_NM
    ,COMPANY_NM_CL_CORP_NM
    ,DEPARTMENT_NM_CL_DEPT_NM
    ,POST_NM
    ,COLLEGE_NM
    ,COURSE_NM
    ,COURSE_DETAIL_NM
    ,OCCUPATION_NM
    ,OCCUPATION_NM_CL
    ,SECONDARY_READING
    ,SECONDARY_READING_CL
    ,UPDATE_KBN
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     T.USER_NO
    ,T.SEX
    ,T.BIRTHDAY
    ,T.COMPANY_NM
    ,T.DEPARTMENT_NM
    ,NULLIF(EXT.COMPANY_NM_CL_CORP_NM, '') AS COMPANY_NM_CL_CORP_NM
    ,NULLIF(EXT.COMPANY_NM_CL_DEPT_NM, '') AS COMPANY_NM_CL_DEPT_NM
    ,T.POST_NM
    ,T.COLLEGE_NM
    ,T.COURSE_NM
    ,T.COURSE_DETAIL_NM
    ,T.OCCUPATION_NM
    ,DIC1.CONVERT_TO_VALUE AS OCCUPATION_NM_CL
    ,T.SECONDARY_READING
    ,SUBSTRING(DIC2.CONVERT_TO_VALUE,1,100) AS SECONDARY_READING_CL
    ,T.UPDATE_KBN
    ,T.CREATE_UPDATE_USER
    ,T.CREATE_UPDATE_DATE
    ,T.UPDATE_CNT
    ,{{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() AS CL_START_DT
    ,'9999-12-31' AS CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_TEMP_CLEANSING T
INNER JOIN
     T_HK_ADDITIONAL_INFO_USER_EXT EXT
ON
     T.ROWID = EXT.ROWID_IF
-- 辞書クレンジング（職業名）
LEFT JOIN
     {{ var.value.redshift_ims_schema_name }}.M_IMS_CL_DIC DIC1
ON
     DIC1.DIC_ID = {{ params.dic_id_occ }}
AND
     NVL(DIC1.CONVERT_FROM_VALUE,'') = NVL(T.OCCUPATION_NM,'')
-- 辞書クレンジング（併読紙）
-- 前方100文字までで一致する値を設定
LEFT JOIN
     {{ var.value.redshift_ims_schema_name }}.M_IMS_CL_DIC DIC2
ON
     DIC2.DIC_ID = {{ params.dic_id_sec }}
AND
     NVL(DIC2.CONVERT_FROM_VALUE,'') = SUBSTRING(NVL(T.SECONDARY_READING,''),1,100)
;

--クレンジング蓄積テーブルから一時表テーブルにコピー
CREATE TEMP TABLE TEMP_T_HK_ADDITIONAL_INFO_USER_CL_AC AS
SELECT
    USER_NO
    ,SEX
    ,BIRTHDAY
    ,COMPANY_NM
    ,DEPARTMENT_NM
    ,COMPANY_NM_CL_CORP_NM
    ,DEPARTMENT_NM_CL_DEPT_NM
    ,POST_NM
    ,COLLEGE_NM
    ,COURSE_NM
    ,COURSE_DETAIL_NM
    ,OCCUPATION_NM
    ,OCCUPATION_NM_CL
    ,SECONDARY_READING
    ,SECONDARY_READING_CL
    ,UPDATE_KBN
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC
;

--クレンジング蓄積テーブルからデータを削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC
;

--クレンジング蓄積テーブルの一時表テーブルにIF元テーブルを外部結合し、クレンジング蓄積テーブルに挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_CL_AC
(
    USER_NO
    ,SEX
    ,BIRTHDAY
    ,COMPANY_NM
    ,DEPARTMENT_NM
    ,COMPANY_NM_CL_CORP_NM
    ,DEPARTMENT_NM_CL_DEPT_NM
    ,POST_NM
    ,COLLEGE_NM
    ,COURSE_NM
    ,COURSE_DETAIL_NM
    ,OCCUPATION_NM
    ,OCCUPATION_NM_CL
    ,SECONDARY_READING
    ,SECONDARY_READING_CL
    ,UPDATE_KBN
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
    )
    SELECT
    CASE WHEN IF.USER_NO IS NULL THEN CLAC.USER_NO ELSE IF.USER_NO END AS USER_NO
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.SEX ELSE IF.SEX END AS SEX
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.BIRTHDAY ELSE IF.BIRTHDAY END AS BIRTHDAY
    ,CLAC.COMPANY_NM
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.DEPARTMENT_NM ELSE IF.DEPARTMENT_NM END AS DEPARTMENT_NM
    ,CLAC.COMPANY_NM_CL_CORP_NM
    ,CLAC.DEPARTMENT_NM_CL_DEPT_NM
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.POST_NM ELSE IF.POST_NM END AS POST_NM
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.COLLEGE_NM ELSE IF.COLLEGE_NM END AS COLLEGE_NM
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.COURSE_NM ELSE IF.COURSE_NM END AS COURSE_NM
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.COURSE_DETAIL_NM ELSE IF.COURSE_DETAIL_NM END AS COURSE_DETAIL_NM
    ,CLAC.OCCUPATION_NM
    ,CLAC.OCCUPATION_NM_CL
    ,CLAC.SECONDARY_READING
    ,CLAC.SECONDARY_READING_CL
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.UPDATE_KBN ELSE IF.UPDATE_KBN END AS UPDATE_KBN
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.CREATE_UPDATE_USER ELSE IF.CREATE_UPDATE_USER END AS CREATE_UPDATE_USER
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.CREATE_UPDATE_DATE ELSE IF.CREATE_UPDATE_DATE END AS CREATE_UPDATE_DATE
    ,CASE WHEN IF.USER_NO IS NULL THEN CLAC.UPDATE_CNT ELSE IF.UPDATE_CNT END AS UPDATE_CNT
    ,CLAC.CL_START_DT
    ,CLAC.CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_HK_ADDITIONAL_INFO_USER_CL_AC CLAC
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_TEMP_CLEANSING IF
ON
    CLAC.USER_NO = IF.USER_NO
;

/*******************************************************************************
  SQL名:
    一時テーブル削除
    「IF EXISTS」にて存在する場合のみテーブル削除を実施する
    後始末でエラー発生しないようにするためで、
    テーブルの作成時に存在していたらデータ削除してそのまま使用するように設計
*******************************************************************************/

DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_ADDITIONAL_INFO_USER_TEMP_CLEANSING
;
