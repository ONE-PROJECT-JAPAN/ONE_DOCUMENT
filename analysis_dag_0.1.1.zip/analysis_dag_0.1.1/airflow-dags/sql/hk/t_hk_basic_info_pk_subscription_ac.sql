
/*******************************************************************************
  SQL名:
    購読申込基本情報（紙課金システム連携用）データ蓄積

  処理概要:
       購読申込基本情報（紙課金システム連携用）テーブルにロードしたIFデータを
       元に購読申込基本情報（紙課金システム連携用）蓄積テーブルに
       データを蓄積する。

       蓄積キー:
         SUBSCRIPTION_NO
*******************************************************************************/
--差分削除
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION_AC
WHERE
    (SUBSCRIPTION_NO)
IN
(
SELECT
    SUBSCRIPTION_NO
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION
)
;

--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION_AC
(
     SUBSCRIPTION_NO
    ,USER_NO
    ,CARD_KBN_CD
    ,STORE_CD
    ,STORE_CONTACT_NM
    ,RECEPTION_DATE
    ,CONTRACT_ST_DATE
    ,CONTRACT_END_DATE
    ,ST_KBN_CD
    ,DELIVERY_ST_DATE
    ,SUBSCRIPTION_TERM
    ,RECEPTION_PLACE_CD
    ,SUBSCRIPTION_KBN_CD
    ,RECEPTION_CLASS_CD
    ,ADVERTISE_BAITAI_CD
    ,ADVERTISE_PRODUCT_CD
    ,YUDAI_MUDAI_FLG
    ,SALES_MAN_CD
    ,STORE_FAXNO
    ,PAY_METHOD_CD
    ,FAX_STATUS
    ,FAX_STATUS_UPDATE_DATE
    ,REMARK
    ,PROMOTION_CD
    ,CAMP_CD
    ,SHAREI
    ,SHAREI_TEHAI
    ,APPROPRIATE_YM
    ,UPDATE_KBN
    ,MEMO
    ,DSBS_YOBI
    ,THANKYOUMAIL_SEND_DATE
    ,FOLLOWMAIL_SEND_DATE
    ,NOTICE_MAIL_SEND_DATE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
 SELECT
     SUBSCRIPTION_NO
    ,USER_NO
    ,CARD_KBN_CD
    ,STORE_CD
    ,STORE_CONTACT_NM
    ,RECEPTION_DATE
    ,CONTRACT_ST_DATE
    ,CONTRACT_END_DATE
    ,ST_KBN_CD
    ,DELIVERY_ST_DATE
    ,SUBSCRIPTION_TERM
    ,RECEPTION_PLACE_CD
    ,SUBSCRIPTION_KBN_CD
    ,RECEPTION_CLASS_CD
    ,ADVERTISE_BAITAI_CD
    ,ADVERTISE_PRODUCT_CD
    ,YUDAI_MUDAI_FLG
    ,SALES_MAN_CD
    ,STORE_FAXNO
    ,PAY_METHOD_CD
    ,FAX_STATUS
    ,FAX_STATUS_UPDATE_DATE
    ,REMARK
    ,PROMOTION_CD
    ,CAMP_CD
    ,SHAREI
    ,SHAREI_TEHAI
    ,APPROPRIATE_YM
    ,UPDATE_KBN
    ,MEMO
    ,DSBS_YOBI
    ,THANKYOUMAIL_SEND_DATE
    ,FOLLOWMAIL_SEND_DATE
    ,NOTICE_MAIL_SEND_DATE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM {{ var.value.redshift_ims_schema_name }}.T_HK_BASIC_INFO_PK_SUBSCRIPTION
;
