/*******************************************************************************
  SQL名:
    THANKYOUMAIL送信ログデータクレンジング・蓄積

  処理概要:
       THANKYOUMAIL送信ログテーブルにロードしたIFデータを元に
       THANKYOUMAIL送信ログクレンジング蓄積テーブルにデータを蓄積する。
*******************************************************************************/

-- クレンジング後ファイルより、一時表テーブル作成
CREATE TEMP TABLE T_HK_THANKYOUMAIL_SEND_LOG_EXT
(
     ROWID_IF                BIGINT
    ,SEND_DT_TM            TIMESTAMP
    ,SUBSCRIPTION_NO       VARCHAR(44) 
);

--一時表テーブル作成にクレンジング後ファイル挿入
COPY T_HK_THANKYOUMAIL_SEND_LOG_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_HK_THANKYOUMAIL_SEND_LOG_CL/T_HK_THANKYOUMAIL_SEND_LOG_'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER ','
QUOTE '"'
;

--差分更新
UPDATE {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC CLAC
SET
     CL_END_DT  = TO_DATE(CONVERT_TIMEZONE ('Asia/Tokyo', DATEADD(DAY, -1, {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE())), 'YYYY-MM-DD')
    ,UPD_PGM_ID = '{{ dag.dag_id }}'
    ,UPD_DT_TM  = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
     T_HK_THANKYOUMAIL_SEND_LOG_EXT EXT
WHERE
     EXT.SEND_DT_TM     = CLAC.SEND_DT_TM
AND
     EXT.SUBSCRIPTION_NO = CLAC.SUBSCRIPTION_NO
AND
     CLAC.CL_END_DT  = '9999-12-31'
;
		
--差分挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC
(
    SEND_DT_TM         
    ,SUBSCRIPTION_NO    
    ,USER_NO            
    ,SEND_TO_EMAIL      
    ,SEND_TO_EMAIL_CL   
    ,SEND_FROM_EMAIL    
    ,SEND_FROM_EMAIL_CL 
    ,MAIL_SENDER_ID     
    ,SEND_MAIL_CLASS    
    ,SEND_MAIL_BODY     
    ,SEND_MAIL_TITLE    
    ,CREATE_UPDATE_USER 
    ,CREATE_UPDATE_DATE 
    ,UPDATE_CNT         
    ,CL_START_DT        
    ,CL_END_DT          
    ,INS_PGM_ID         
    ,INS_DT_TM          
    ,UPD_PGM_ID         
    ,UPD_DT_TM            
)
SELECT
     EXT.SEND_DT_TM
    ,NULLIF(EXT.SUBSCRIPTION_NO, '') AS SUBSCRIPTION_NO
    ,T.USER_NO            
    ,T.SEND_TO_EMAIL      
    ,LOWER(T.SEND_TO_EMAIL)    AS SEND_TO_EMAIL_CL   
    ,T.SEND_FROM_EMAIL    
    ,LOWER(T.SEND_FROM_EMAIL)  AS SEND_FROM_EMAIL_CL   
    ,T.MAIL_SENDER_ID     
    ,T.SEND_MAIL_CLASS    
    ,T.SEND_MAIL_BODY     
    ,T.SEND_MAIL_TITLE    
    ,T.CREATE_UPDATE_USER 
    ,T.CREATE_UPDATE_DATE 
    ,T.UPDATE_CNT         
    ,{{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() AS CL_START_DT
    ,'9999-12-31' AS CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
     {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING T
INNER JOIN
     T_HK_THANKYOUMAIL_SEND_LOG_EXT EXT
ON
     T.ROWID = EXT.ROWID_IF;

--クレンジング蓄積テーブルから一時表テーブルにコピー
CREATE TEMP TABLE TEMP_T_HK_THANKYOUMAIL_SEND_LOG_CL_AC AS
SELECT
     SEND_DT_TM
    ,SUBSCRIPTION_NO
    ,USER_NO
    ,SEND_TO_EMAIL
    ,SEND_TO_EMAIL_CL
    ,SEND_FROM_EMAIL
    ,SEND_FROM_EMAIL_CL
    ,MAIL_SENDER_ID
    ,SEND_MAIL_CLASS
    ,SEND_MAIL_BODY
    ,SEND_MAIL_TITLE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC
;

--クレンジング蓄積テーブルからデータを削除
DELETE
FROM
    {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC
;

--クレンジング蓄積テーブルの一時表テーブルにIF元テーブルを外部結合し、クレンジング蓄積テーブルに挿入
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_CL_AC
(
     SEND_DT_TM
    ,SUBSCRIPTION_NO
    ,USER_NO
    ,SEND_TO_EMAIL
    ,SEND_TO_EMAIL_CL
    ,SEND_FROM_EMAIL
    ,SEND_FROM_EMAIL_CL
    ,MAIL_SENDER_ID
    ,SEND_MAIL_CLASS
    ,SEND_MAIL_BODY
    ,SEND_MAIL_TITLE
    ,CREATE_UPDATE_USER
    ,CREATE_UPDATE_DATE
    ,UPDATE_CNT
    ,CL_START_DT
    ,CL_END_DT
    ,INS_PGM_ID
    ,INS_DT_TM
    ,UPD_PGM_ID
    ,UPD_DT_TM
)
SELECT
     CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.SEND_DT_TM ELSE IF.SEND_DT_TM END AS SEND_DT_TM
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.SUBSCRIPTION_NO ELSE IF.SUBSCRIPTION_NO END AS SUBSCRIPTION_NO
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.USER_NO ELSE IF.USER_NO END AS USER_NO
    ,CLAC.SEND_TO_EMAIL
    ,CLAC.SEND_TO_EMAIL_CL
    ,CLAC.SEND_FROM_EMAIL
    ,CLAC.SEND_FROM_EMAIL_CL
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.MAIL_SENDER_ID ELSE IF.MAIL_SENDER_ID END AS MAIL_SENDER_ID
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.SEND_MAIL_CLASS ELSE IF.SEND_MAIL_CLASS END AS SEND_MAIL_CLASS
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.SEND_MAIL_BODY ELSE IF.SEND_MAIL_BODY END AS SEND_MAIL_BODY
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.SEND_MAIL_TITLE ELSE IF.SEND_MAIL_TITLE END AS SEND_MAIL_TITLE
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.CREATE_UPDATE_USER ELSE IF.CREATE_UPDATE_USER END AS CREATE_UPDATE_USER
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.CREATE_UPDATE_DATE ELSE IF.CREATE_UPDATE_DATE END AS CREATE_UPDATE_DATE
    ,CASE WHEN IF.SEND_DT_TM IS NULL THEN CLAC.UPDATE_CNT ELSE IF.UPDATE_CNT END AS UPDATE_CNT
    ,CLAC.CL_START_DT
    ,CLAC.CL_END_DT
    ,'{{ dag.dag_id }}' AS INS_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    ,'{{ dag.dag_id }}' AS UPD_PGM_ID
    ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    TEMP_T_HK_THANKYOUMAIL_SEND_LOG_CL_AC CLAC
    LEFT JOIN {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING IF
ON
    CLAC.SEND_DT_TM = IF.SEND_DT_TM
AND
    CLAC.SUBSCRIPTION_NO = IF.SUBSCRIPTION_NO
;

/*******************************************************************************
  SQL名:
    一時テーブル削除
    「IF EXISTS」にて存在する場合のみテーブル削除を実施する
    後始末でエラー発生しないようにするためで、
    テーブルの作成時に存在していたらデータ削除してそのまま使用するように設計
*******************************************************************************/

DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_HK_THANKYOUMAIL_SEND_LOG_TEMP_CLEANSING
;
