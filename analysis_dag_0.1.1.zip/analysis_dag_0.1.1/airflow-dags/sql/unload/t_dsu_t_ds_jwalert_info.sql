UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR   || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR   || '"' AS UPDATEDATE
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || A.TONYU_NUM::VARCHAR   || '"' AS TONYU_NUM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIK_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NIK_CODE
  ,'"' || '"' AS PERSONAL_NAME
  ,'"' || '"' AS PERSONAL_NAME_SEARCH
  ,'"' || REPLACE(REPLACE(REPLACE(A.ALERT_MAIL_PATTERN_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS ALERT_MAIL_PATTERN_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.ALERT_MAIL_P_RECEIVE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS ALERT_MAIL_P_RECEIVE_FLG
  ,'"' || REPLACE(REPLACE(REPLACE(A.ALERT_MAIL_M_RECEIVE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS ALERT_MAIL_M_RECEIVE_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSU_T_DS_JWALERT_INFO A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;