UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.PERMISSION_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))     || '"' AS PERMISSION_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.PERMISSION_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS PERMISSION_NAME
  ,'"' || A.DISABLE_FLG::VARCHAR                                                                                 || '"' AS DISABLE_FLG
  ,'"' || A.CREATE_ON::VARCHAR                                                                                   || '"' AS CREATE_ON
  ,'"' || REPLACE(REPLACE(REPLACE(A.CREATE_BY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS CREATE_BY
  ,'"' || A.UPDATE_ON::VARCHAR                                                                                   || '"' AS UPDATE_ON
  ,'"' || REPLACE(REPLACE(REPLACE(A.UPDATE_BY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS UPDATE_BY
FROM
  {{var.value.redshift_ims_schema_name}}.M_BPP_M_PERMISSION A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;