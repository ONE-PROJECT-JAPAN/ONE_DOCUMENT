UNLOAD ($$
SELECT
   '"' || A.LIST_ID::VARCHAR                                                                                                                       || '"' AS LIST_ID
  ,'"' || REPLACE(REPLACE(REPLACE(SHA2(A.USER_NO::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))      || '"' AS USER_NO
  ,'"' || REPLACE(REPLACE(REPLACE(SHA2(A.USER_NO_0PAD::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || '"' AS USER_NO_0PAD
  ,'"' || ''                                                                                                                                       || '"' AS EMAIL
  ,'"' || ''                                                                                                                                       || '"' AS EMAIL_CL
  ,'"' || ''                                                                                                                                       || '"' AS SECOND_EMAIL
  ,'"' || ''                                                                                                                                       || '"' AS SECOND_EMAIL_CL
  ,'"' || ''                                                                                                                                       || '"' AS LAST_NAME
  ,'"' || ''                                                                                                                                       || '"' AS FIRST_NAME
  ,'"' || ''                                                                                                                                       || '"' AS NAME_CL_LAST_NM
  ,'"' || ''                                                                                                                                       || '"' AS NAME_CL_FIRST_NM
  ,'"' || ''                                                                                                                                       || '"' AS NAME_CL_NM
  ,'"' || ''                                                                                                                                       || '"' AS LAST_NAME_KANA
  ,'"' || ''                                                                                                                                       || '"' AS FIRST_NAME_KANA
  ,'"' || ''                                                                                                                                       || '"' AS RESIDENT_ABROAD
  ,'"' || ''                                                                                                                                       || '"' AS COUNTRY_CODE
  ,'"' || ''                                                                                                                                       || '"' AS ZIP_CODE
  ,'"' || ''                                                                                                                                       || '"' AS ZIP_CODE_CL
  ,'"' || ''                                                                                                                                       || '"' AS ZIP_CODE_SEND
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CODE
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS1
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS2
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_ADDR
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_PREFEC
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_CITY
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_TSUSHO
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_CHOME
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_ADDR1
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_ADDR2
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_ADDR3
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_CL_ADDR_CD
  ,'"' || ''                                                                                                                                       || '"' AS ADDRESS_SEND
  ,'"' || NVL(A.DELIVERY_ADDRESS_CREATE_FLG::VARCHAR, '')                                                                                          || '"' AS DELIVERY_ADDRESS_CREATE_FLG
  ,'"' || ''                                                                                                                                       || '"' AS TEL1
  ,'"' || ''                                                                                                                                       || '"' AS TEL2
  ,'"' || ''                                                                                                                                       || '"' AS TEL3
  ,'"' || ''                                                                                                                                       || '"' AS TEL_JOINT
  ,'"' || ''                                                                                                                                       || '"' AS TEL_JOINT_CL
  ,'"' || ''                                                                                                                                       || '"' AS OVERSEAS_ZIP_CODE
  ,'"' || ''                                                                                                                                       || '"' AS OVERSEAS_ADDRESS1
  ,'"' || ''                                                                                                                                       || '"' AS OVERSEAS_ADDRESS2
  ,'"' || ''                                                                                                                                       || '"' AS OVERSEAS_ADDRESS3
  ,'"' || ''                                                                                                                                       || '"' AS OVERSEAS_TEL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SEX, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                        || '"' AS SEX
  ,'"' || ''                                                                                                                                       || '"' AS BIRTH
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OCCUPATION_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                              || '"' AS OCCUPATION_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BUSINESS_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                || '"' AS BUSINESS_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.JOB_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                     || '"' AS JOB_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.POSITION_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                || '"' AS POSITION_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.EMPLOYEES_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                               || '"' AS EMPLOYEES_NO
  ,'"' || ''                                                                                                                                       || '"' AS INCOME_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_MAIL_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                           || '"' AS NIKKEI_MAIL_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.THIRDPARTY_MAIL_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                       || '"' AS THIRDPARTY_MAIL_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_MONITOR_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                        || '"' AS NIKKEI_MONITOR_FLAG
  ,'"' || ''                                                                                                                                       || '"' AS COMPANY_NAME
  ,'"' || ''                                                                                                                                       || '"' AS COMPANY_NAME_CL_CORP_NM
  ,'"' || ''                                                                                                                                       || '"' AS COMPANY_NAME_CL_DEPT_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.USER_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS USER_TYPE
  ,'"' || NVL(A.ENTRY_DATE::VARCHAR, '')                                                                                                           || '"' AS ENTRY_DATE
  ,'"' || NVL(A.WITHDRAWAL_DATE::VARCHAR, '')                                                                                                      || '"' AS WITHDRAWAL_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.WITHDRAWAL_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                            || '"' AS WITHDRAWAL_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRICEPLN_SYSTEM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS PRICEPLN_SYSTEM_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRICEPLN_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                || '"' AS PRICEPLN_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRICEPLN_KBN, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                               || '"' AS PRICEPLN_KBN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRICEPLN_KBN_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                            || '"' AS PRICEPLN_KBN_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PREFECTURE_ZIPCODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS PREFECTURE_ZIPCODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SERIAL_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS SERIAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DIVIDE_AGE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS DIVIDE_AGE
  ,'"' || ''                                                                                                                                       || '"' AS AGE
  ,'"' || NVL(A.DEAD_MAIL_FLG::VARCHAR, '')                                                                                                        || '"' AS DEAD_MAIL_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS NEWS_SUBSCRIPTION1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS NEWS_SUBSCRIPTION2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS NEWS_SUBSCRIPTION3
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION4, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS NEWS_SUBSCRIPTION4
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION5, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS NEWS_SUBSCRIPTION5
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_SUBSCRIPTION_SUMMARY_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')             || '"' AS NEWS_SUBSCRIPTION_SUMMARY_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST3
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST4, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST4
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST5, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST5
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST6, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST6
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST7, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST7
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST8, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST8
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST9, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS INTEREST9
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST10, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST10
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST11, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST11
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST12, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST12
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST13, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST13
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST14, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST14
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST15, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST15
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST16, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST16
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST17, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST17
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST18, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST18
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST19, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST19
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INTEREST20, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INTEREST20
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ORGSITE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                    || '"' AS ORGSITE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ORGSITE_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                             || '"' AS ORGSITE_STATUS
  ,'"' || NVL(A.EDU_FLG::VARCHAR, '')                                                                                                              || '"' AS EDU_FLG
  ,'"' || NVL(A.TRIAL_FLG::VARCHAR, '')                                                                                                            || '"' AS TRIAL_FLG
  ,'"' || NVL(A.TRIAL_RESULT_FLG::VARCHAR, '')                                                                                                     || '"' AS TRIAL_RESULT_FLG
  ,'"' || NVL(A.BPPM_FLG::VARCHAR, '')                                                                                                             || '"' AS BPPM_FLG
  ,'"' || NVL(A.BPPM2_FLG::VARCHAR, '')                                                                                                            || '"' AS BPPM2_FLG
  ,'"' || NVL(A.NIKKEI_RP::VARCHAR, '')                                                                                                            || '"' AS NIKKEI_RP
  ,'"' || NVL(A.BP_RP::VARCHAR, '')                                                                                                                || '"' AS BP_RP
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS INS_PGM_ID
  ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')                                                                                                            || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS UPD_PGM_ID
  ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')                                                                                                            || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.D_IMS_NIKKEI_MEMBER_NO_LIST A
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
