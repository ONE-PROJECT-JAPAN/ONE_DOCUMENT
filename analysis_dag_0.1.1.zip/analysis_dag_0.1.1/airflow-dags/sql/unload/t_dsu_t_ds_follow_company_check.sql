UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR   || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR   || '"' AS UPDATEDATE
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.FOLLOW_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FOLLOW_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.FOLLOW_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FOLLOW_ID
  ,'"' || NVL(A.FOLLOW_CHECK_TIME::VARCHAR, '')   || '"' AS FOLLOW_CHECK_TIME
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSU_T_DS_FOLLOW_COMPANY_CHECK A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;