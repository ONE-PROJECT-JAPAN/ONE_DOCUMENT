UNLOAD ($$
SELECT
   '"' || A.SUBSCRIPT_METHOD_CD::VARCHAR   || '"' AS SUBSCRIPT_METHOD_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SUBSCRIPT_METHOD_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SUBSCRIPT_METHOD_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CREATE_UPDATE_USER
  ,'"' || A.CREATE_UPDATE_DATE::VARCHAR   || '"' AS CREATE_UPDATE_DATE
  ,'"' || A.UPDATE_CNT::VARCHAR   || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HK_COMPLAINT_SUBSCRIPT_METHOD_REF A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;