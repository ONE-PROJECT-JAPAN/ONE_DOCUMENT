UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.ADDRESS_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                   || '"' AS ADDRESS_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.PREFECTURE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                || '"' AS PREFECTURE_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.SHIKUTYOUSON_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))              || '"' AS SHIKUTYOUSON_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.TSUSHO_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS TSUSHO_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.CHOME_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS CHOME_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.NEW_ADDRESS_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))               || '"' AS NEW_ADDRESS_CD
  ,'"' || A.ADDRESS_TYPE::VARCHAR                                                                                                || '"' AS ADDRESS_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.ZIPCODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                      || '"' AS ZIPCODE
  ,'"' || REPLACE(REPLACE(REPLACE(A.BCD_INFO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS BCD_INFO
  ,'"' || A.BCD_MOJINUM::VARCHAR                                                                                                 || '"' AS BCD_MOJINUM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ZIPCODE_INFO_1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')      || '"' AS ZIPCODE_INFO_1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ZIPCODE_INFO_2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')      || '"' AS ZIPCODE_INFO_2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OYAKO_SIKIBETSU_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS OYAKO_SIKIBETSU_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OYAKO_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            || '"' AS OYAKO_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.PREFECTURE_FUYOU_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))          || '"' AS PREFECTURE_FUYOU_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PREFECTURE_KANA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')     || '"' AS PREFECTURE_KANA
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SHIKUTYOUSON_KANA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SHIKUTYOUSON_KANA
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TSUSHO_KANA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS TSUSHO_KANA
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CHOME_KANA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS CHOME_KANA
  ,'"' || A.PREFECTURE_KANA_MOJINUM::VARCHAR                                                                                     || '"' AS PREFECTURE_KANA_MOJINUM
  ,'"' || A.SHIKUTYOUSON_KANA_MOJINUM::VARCHAR                                                                                   || '"' AS SHIKUTYOUSON_KANA_MOJINUM
  ,'"' || A.TSUSHO_KANA_MOJINUM::VARCHAR                                                                                         || '"' AS TSUSHO_KANA_MOJINUM
  ,'"' || A.CHOME_KANA_MOJINUM::VARCHAR                                                                                          || '"' AS CHOME_KANA_MOJINUM
  ,'"' || A.TOTAL_KANA_MOJINUM::VARCHAR                                                                                          || '"' AS TOTAL_KANA_MOJINUM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PREFECTURE_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')       || '"' AS PREFECTURE_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SHIKUTYOUSON_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')     || '"' AS SHIKUTYOUSON_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TSUSHO_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           || '"' AS TSUSHO_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CHOME_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            || '"' AS CHOME_NM
  ,'"' || A.PREFECTURE_NM_MOJINUM::VARCHAR                                                                                       || '"' AS PREFECTURE_NM_MOJINUM
  ,'"' || A.SHIKUTYOUSON_NM_MOJINUM::VARCHAR                                                                                     || '"' AS SHIKUTYOUSON_NM_MOJINUM
  ,'"' || A.TSUSHO_NM_MOJINUM::VARCHAR                                                                                           || '"' AS TSUSHO_NM_MOJINUM
  ,'"' || A.CHOME_NM_MOJINUM::VARCHAR                                                                                            || '"' AS CHOME_NM_MOJINUM
  ,'"' || A.TOTAL_MOJINUM::VARCHAR                                                                                               || '"' AS TOTAL_MOJINUM
  ,'"' || A.PREFECTURE_JISHU::VARCHAR                                                                                            || '"' AS PREFECTURE_JISHU
  ,'"' || A.CITY_JISHU_1::VARCHAR                                                                                                || '"' AS CITY_JISHU_1
  ,'"' || A.CITY_JISHU_2::VARCHAR                                                                                                || '"' AS CITY_JISHU_2
  ,'"' || A.TOWN_JISHU_1::VARCHAR                                                                                                || '"' AS TOWN_JISHU_1
  ,'"' || A.TOWN_JISHU_2::VARCHAR                                                                                                || '"' AS TOWN_JISHU_2
  ,'"' || A.CHOME_JISHU_1::VARCHAR                                                                                               || '"' AS CHOME_JISHU_1
  ,'"' || A.CHOME_JISHU_2::VARCHAR                                                                                               || '"' AS CHOME_JISHU_2
  ,'"' || A.OAZA_FLG_1::VARCHAR                                                                                                  || '"' AS OAZA_FLG_1
  ,'"' || A.OAZA_FLG_2::VARCHAR                                                                                                  || '"' AS OAZA_FLG_2
  ,'"' || A.TSUSHO_SIKIBETSU::VARCHAR                                                                                            || '"' AS TSUSHO_SIKIBETSU
  ,'"' || A.TSUSHO_FLG::VARCHAR                                                                                                  || '"' AS TSUSHO_FLG
  ,'"' || REPLACE(REPLACE(REPLACE(A.DATA_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                      || '"' AS DATA_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.OLD_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                       || '"' AS OLD_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.NEW_CD_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS NEW_CD_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.KOSHO_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS KOSHO_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.ZIPCODE_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                   || '"' AS ZIPCODE_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.BCD_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                       || '"' AS BCD_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.OYAKO_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS OYAKO_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.TSUSHO_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS TSUSHO_YM
  ,'"' || REPLACE(REPLACE(REPLACE(A.CHOME_YM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS CHOME_YM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OLD_ZIPCODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS OLD_ZIPCODE
  ,'"' || A.DISP_FLG::VARCHAR                                                                                                    || '"' AS DISP_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')  || '"' AS CREATE_UPDATE_USER
  ,'"' || A.CREATE_UPDATE_DATE::VARCHAR                                                                                          || '"' AS CREATE_UPDATE_DATE
  ,'"' || A.UPDATE_CNT::VARCHAR                                                                                                  || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HK_ADDRESS A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
