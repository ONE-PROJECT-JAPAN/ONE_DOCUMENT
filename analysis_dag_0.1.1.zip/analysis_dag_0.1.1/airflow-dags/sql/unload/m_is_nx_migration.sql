UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(SHA2(A.C_LOCAL_USER_ID::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')                                                                                                                        || '"' AS SERIAL_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.ORIGINAL_SITE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                                          || '"' AS ORIGINAL_SITE
  ,'"' || REPLACE(REPLACE(REPLACE(SHA2(A.ORG_EMAIL::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))       || '"' AS ORG_EMAIL
  ,'"' || '"' AS PASSWORD1
  ,'"' || '"' AS PASSWORD2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MERGE_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS MERGE_STATUS
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MERGE_STATUS_DETAIL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                           || '"' AS MERGE_STATUS_DETAIL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ATTR_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                   || '"' AS ATTR_STATUS
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PASSWD_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                 || '"' AS PASSWD_STATUS
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.EMAIL_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS EMAIL_STATUS
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MRG_ORG_SITE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                  || '"' AS MRG_ORG_SITE
  ,'"' || NVL(SHA2(A.EST_IDENTICAL_UID::VARCHAR || S.SEED::VARCHAR, 256), '')                                                                         || '"' AS EST_IDENTICAL_HASH_ID
  ,'"' || NVL(C.SERIAL_ID, '')                                                                                                                        || '"' AS EST_IDENTICAL_SERIAL_ID
  ,'"' || NVL(A.CREATE_DATE::VARCHAR, '')                                                                                                             || '"' AS CREATE_DATE
  ,'"' || '"' AS CREATE_USER
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')                                                                                                             || '"' AS UPDATE_DATE
  ,'"' || '"' AS UPDATE_USER
  ,'"' || NVL(A.DELETE_DATE::VARCHAR, '')                                                                                                             || '"' AS DELETE_DATE
  ,'"' || '"' AS DELETE_USER
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                    || '"' AS DELETE_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.M_IS_NX_MIGRATION A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.C_LOCAL_USER_ID
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID C
    ON C.USER_NO = A.EST_IDENTICAL_UID
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;