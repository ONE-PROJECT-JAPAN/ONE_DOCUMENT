UNLOAD ($$
SELECT
   '"' || NVL(REPLACE(REPLACE(REPLACE(MASTER_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')     || '"' AS MASTER_TYPE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(MASTER_GRP_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS MASTER_GRP_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                     || '"' AS CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(CODE_NAME1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')      || '"' AS CODE_NAME1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(CODE_NAME2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')      || '"' AS CODE_NAME2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(VALUE1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS VALUE1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(VALUE2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS VALUE2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(VALUE3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS VALUE3
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(VALUE4, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS VALUE4
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(VALUE5, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS VALUE5
  ,'"' || NVL(SORT_ORDER1::VARCHAR, '')                                                                               || '"' AS SORT_ORDER1
  ,'"' || NVL(SORT_ORDER2::VARCHAR, '')                                                                               || '"' AS SORT_ORDER2
  ,'"' || NVL(SORT_ORDER3::VARCHAR, '')                                                                               || '"' AS SORT_ORDER3
  ,'"' || NVL(SORT_ORDER4::VARCHAR, '')                                                                               || '"' AS SORT_ORDER4
  ,'"' || NVL(SORT_ORDER5::VARCHAR, '')                                                                               || '"' AS SORT_ORDER5
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(YUKO_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS YUKO_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(INS_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')    || '"' AS INS_BATCH_ID
  ,'"' || NVL(INS_DT_TM::VARCHAR, '')                                                                                 || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(UPD_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')    || '"' AS UPD_BATCH_ID
  ,'"' || NVL(UPD_DT_TM::VARCHAR, '')                                                                                 || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.M_CRM_CODE A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
