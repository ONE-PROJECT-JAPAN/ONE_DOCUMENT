UNLOAD ($$
SELECT
   '"' || SHA2(A.C_LOCAL_USER_ID::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.CATEGORY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS CATEGORY
  ,'"' || REPLACE(REPLACE(REPLACE(A.KEY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS KEY
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DETAIL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DETAIL
  ,'"' || NVL(A.ATTACHED_AT::VARCHAR, '')   || '"' AS ATTACHED_AT
  ,'"' || NVL(A.CREATE_DATE::VARCHAR, '')   || '"' AS CREATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CREATE_USER
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')   || '"' AS UPDATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_USER
  ,'"' || NVL(A.DELETE_DATE::VARCHAR, '')   || '"' AS DELETE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DELETE_USER
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DELETE_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_ATTACHMENT A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.C_LOCAL_USER_ID
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
