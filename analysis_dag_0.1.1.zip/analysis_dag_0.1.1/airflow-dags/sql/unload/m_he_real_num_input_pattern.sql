UNLOAD ($$
SELECT
   '"' || A.HON_SHISHA_CD::VARCHAR   || '"' AS HON_SHISHA_CD
  ,'"' || A.DEPARTMENT_CD::VARCHAR   || '"' AS DEPARTMENT_CD
  ,'"' || A.ST_DATE::VARCHAR   || '"' AS ST_DATE
  ,'"' || A.END_DATE::VARCHAR   || '"' AS END_DATE
  ,'"' || A.INPUT_PATTERN::VARCHAR   || '"' AS INPUT_PATTERN
  ,'"' || A.HDR_PATTERN::VARCHAR   || '"' AS HDR_PATTERN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.REAL_NUM_FORMULA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS REAL_NUM_FORMULA
  ,'"' || A.UPDATE_DATE::VARCHAR   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_REAL_NUM_INPUT_PATTERN A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;