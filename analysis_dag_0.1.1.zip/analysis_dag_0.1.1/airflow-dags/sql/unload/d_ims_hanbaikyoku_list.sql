UNLOAD ($$
SELECT
   '"' || A.LIST_ID::VARCHAR                                                                                                                  || '"' AS LIST_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.LIST_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                                        || '"' AS LIST_NO
  ,'"' || REPLACE(REPLACE(REPLACE(A.USER_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                                        || '"' AS USER_NO
  ,'"' || REPLACE(REPLACE(REPLACE(SHA2(A.NIKKEI_MEMBER_NO || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) || '"' AS NIKKEI_MEMBER_HASH_NO
  ,'"' || NVL(B.SERIAL_ID, '')                                                                                                                || '"' AS SERIAL_ID
  ,'"' || NVL(A.NIKKEI_ENTRY_DATE::VARCHAR, '')                                                                                               || '"' AS NIKKEI_ENTRY_DATE
  ,'"' || NVL(A.NIKKEI_NEW_CREATE_FLG::VARCHAR, '')                                                                                           || '"' AS NIKKEI_NEW_CREATE_FLG
  ,'"' || NVL(A.CHARGE_CUST_NO::VARCHAR, '')                                                                                                  || '"' AS CHARGE_CUST_NO
  ,'"' || ''                                                                                                                                  || '"' AS ADDRESS_CD
  ,'"' || ''                                                                                                                                  || '"' AS HON_SHISHA_CD
  ,'"' || ''                                                                                                                                  || '"' AS ZIPCODE
  ,'"' || ''                                                                                                                                  || '"' AS ZIPCODE_CL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PREFECTURE_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                         || '"' AS PREFECTURE_NM
  ,'"' || ''                                                                                                                                  || '"' AS SHIKUTYOUSON_NM
  ,'"' || ''                                                                                                                                  || '"' AS TSUSHO_NM
  ,'"' || ''                                                                                                                                  || '"' AS CHOME_NM
  ,'"' || ''                                                                                                                                  || '"' AS BANTI
  ,'"' || ''                                                                                                                                  || '"' AS BUILDING
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_ADDR
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_PREFEC
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_CITY
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_TSUSHO
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_CHOME
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_ADDR1
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_ADDR2
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_ADDR3
  ,'"' || ''                                                                                                                                  || '"' AS ADDR_CL_ADDR_CD
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_YOMI
  ,'"' || ''                                                                                                                                  || '"' AS DEPARTMENT_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_CL_LAST_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_CL_FIRST_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_CL_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_CL_CORP_NM
  ,'"' || ''                                                                                                                                  || '"' AS NAME_COMPANY_NM_CL_DEPT_NM
  ,'"' || ''                                                                                                                                  || '"' AS SUBSCRIBER
  ,'"' || ''                                                                                                                                  || '"' AS TELNO
  ,'"' || ''                                                                                                                                  || '"' AS TELNO_CL
  ,'"' || ''                                                                                                                                  || '"' AS FAXNO
  ,'"' || ''                                                                                                                                  || '"' AS DAYTIME_CONTACT
  ,'"' || ''                                                                                                                                  || '"' AS DAYTIME_CONTACT_CL
  ,'"' || ''                                                                                                                                  || '"' AS EMAIL
  ,'"' || ''                                                                                                                                  || '"' AS EMAIL_CL
  ,'"' || ''                                                                                                                                  || '"' AS EMAIL_2
  ,'"' || ''                                                                                                                                  || '"' AS EMAIL_2_CL
  ,'"' || NVL(A.SUBSCRIPTION_TYPE_CD::VARCHAR, '')                                                                                            || '"' AS SUBSCRIPTION_TYPE_CD
  ,'"' || NVL(A.SECONDARY_USE_SIGN::VARCHAR, '')                                                                                              || '"' AS SECONDARY_USE_SIGN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NAYOSE_KEY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                            || '"' AS NAYOSE_KEY
  ,'"' || NVL(A.UPDATE_KBN::VARCHAR, '')                                                                                                      || '"' AS UPDATE_KBN
  ,'"' || NVL(A.SEX::VARCHAR, '')                                                                                                             || '"' AS SEX
  ,'"' || ''                                                                                                                                  || '"' AS BIRTHDAY
  ,'"' || ''                                                                                                                                  || '"' AS ADD_DEPARTMENT_NM
  ,'"' || ''                                                                                                                                  || '"' AS COMPANY_NM_CL_CORP_NM
  ,'"' || ''                                                                                                                                  || '"' AS POST_NM
  ,'"' || ''                                                                                                                                  || '"' AS COLLEGE_NM
  ,'"' || ''                                                                                                                                  || '"' AS COURSE_NM
  ,'"' || ''                                                                                                                                  || '"' AS COURSE_DETAIL_NM
  ,'"' || ''                                                                                                                                  || '"' AS OCCUPATION_NM
  ,'"' || ''                                                                                                                                  || '"' AS OCCUPATION_NM_CL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SECONDARY_READING, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                     || '"' AS SECONDARY_READING
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SECONDARY_READING_CL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                  || '"' AS SECONDARY_READING_CL
  ,'"' || NVL(A.NK_SUBSCRIPTION_COUNT::VARCHAR, '')                                                                                           || '"' AS NK_SUBSCRIPTION_COUNT
  ,'"' || NVL(A.NK_TRIAL_COUNT::VARCHAR, '')                                                                                                  || '"' AS NK_TRIAL_COUNT
  ,'"' || NVL(A.NK_LATEST_SUBSCRIPTION_DATE::VARCHAR, '')                                                                                     || '"' AS NK_LATEST_SUBSCRIPTION_DATE
  ,'"' || NVL(A.SS_SUBSCRIPTION_COUNT::VARCHAR, '')                                                                                           || '"' AS SS_SUBSCRIPTION_COUNT
  ,'"' || NVL(A.SS_TRIAL_COUNT::VARCHAR, '')                                                                                                  || '"' AS SS_TRIAL_COUNT
  ,'"' || NVL(A.MJ_SUBSCRIPTION_COUNT::VARCHAR, '')                                                                                           || '"' AS MJ_SUBSCRIPTION_COUNT
  ,'"' || NVL(A.MJ_TRIAL_COUNT::VARCHAR, '')                                                                                                  || '"' AS MJ_TRIAL_COUNT
  ,'"' || NVL(A.VS_SUBSCRIPTION_COUNT::VARCHAR, '')                                                                                           || '"' AS VS_SUBSCRIPTION_COUNT
  ,'"' || NVL(A.VS_TRIAL_COUNT::VARCHAR, '')                                                                                                  || '"' AS VS_TRIAL_COUNT
  ,'"' || NVL(A.E_TRIAL_COUNT::VARCHAR, '')                                                                                                   || '"' AS E_TRIAL_COUNT
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')                                                                                                     || '"' AS UPDATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.LATEST_SUBSCRIPTION_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                || '"' AS LATEST_SUBSCRIPTION_NO
  ,'"' || NVL(A.LATEST_SUBSCRIPTION_KBN::VARCHAR, '')                                                                                         || '"' AS LATEST_SUBSCRIPTION_KBN
  ,CASE A.LATEST_TRIAL_STORE_EXTEND_FLG
       WHEN TRUE THEN  '"' || '1'|| '"'
       WHEN FALSE THEN '"' || '0'|| '"'
   END AS LATEST_TRIAL_STORE_EXTEND_FLG
  ,'"' || NVL(A.LATEST_RECEPTION_CLASS_CD::VARCHAR, '')                                                                                       || '"' AS LATEST_RECEPTION_CLASS_CD
  ,'"' || NVL(A.LATEST_RECEPTION_DATE::VARCHAR, '')                                                                                           || '"' AS LATEST_RECEPTION_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.LATEST_STORE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                       || '"' AS LATEST_STORE_CD
  ,CASE A.LATEST_YUDAI_MUDAI_FLG
       WHEN TRUE THEN  '"' || '1'|| '"'
       WHEN FALSE THEN '"' || '0'|| '"'
   END AS LATEST_YUDAI_MUDAI_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                            || '"' AS INS_PGM_ID
  ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')                                                                                                       || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                            || '"' AS UPD_PGM_ID
  ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')                                                                                                       || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.D_IMS_HANBAIKYOKU_LIST A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.USER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
