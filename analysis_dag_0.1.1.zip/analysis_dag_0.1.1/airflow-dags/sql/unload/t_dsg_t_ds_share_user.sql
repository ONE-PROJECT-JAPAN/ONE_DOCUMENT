UNLOAD ($$
SELECT
   '"' || A.SHARE_USER_ID::VARCHAR   || '"' AS SHARE_USER_ID
  ,'"' || A.GROUP_ID::VARCHAR   || '"' AS GROUP_ID
  ,'"' || A.SHARE_ID::VARCHAR   || '"' AS SHARE_ID
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || A.INSERT_DATE::VARCHAR   || '"' AS INSERT_DATE
  ,'"' || A.UPDATE_DATE::VARCHAR   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSG_T_DS_SHARE_USER A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;