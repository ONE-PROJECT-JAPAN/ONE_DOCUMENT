UNLOAD ($$
SELECT
     '"' || REPLACE(REPLACE(REPLACE(A.RP_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))               || '"' AS RP_ID
    ,'"' || REPLACE(REPLACE(REPLACE(A.RP_DISP_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))        || '"' AS RP_DISP_NAME
    ,'"' || REPLACE(REPLACE(REPLACE(A.DISP_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS DISP_FLG
    ,'"' || NVL(A.DISPLAY_ORDER::VARCHAR, '')                                                                        || '"' AS DISPLAY_ORDER
    ,'"' || NVL(A.RP_TYPE::VARCHAR, '')                                                                              || '"' AS RP_TYPE
    ,'"' || REPLACE(REPLACE(REPLACE(A.AWS_RS_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))          || '"' AS AWS_RS_FLG
    ,'"' || REPLACE(REPLACE(REPLACE(A.DELETE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))          || '"' AS DELETE_FLG
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS INS_PGM_ID
    ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')                                                                            || '"' AS INS_DT_TM
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS UPD_PGM_ID
    ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')                                                                            || '"' AS UPD_DT_TM
FROM
    {{var.value.redshift_ims_schema_name}}.M_IMS_RP A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
