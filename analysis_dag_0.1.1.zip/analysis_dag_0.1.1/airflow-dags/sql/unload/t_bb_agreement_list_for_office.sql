UNLOAD ($$
SELECT
   '"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.RP_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS RP_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.SERVICE_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS SERVICE_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS TRIAL_FLAG
  ,'"' || NVL(A.USESTART_DATE::VARCHAR, '')   || '"' AS USESTART_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.REPORT_CATEGORY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS REPORT_CATEGORY
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BBC_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS BBC_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_ACC_ACCOUNTCODE__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_ACC_ACCOUNTCODE__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTS_1__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTS_1__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTS_2__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTS_2__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTS_3__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTS_3__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTS_4__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTS_4__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTS_5__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTS_5__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTSCODE_1__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTSCODE_1__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTSCODE_2__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTSCODE_2__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTSCODE_3__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTSCODE_3__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTSCODE_4__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTSCODE_4__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FODEPTSCODE_5__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FODEPTSCODE_5__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FOCOUNTRY__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FOCOUNTRY__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FOSTATE__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FOSTATE__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FOCITY__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FOCITY__C
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.C_CON_FOBASE__C, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS C_CON_FOBASE__C
FROM
  {{var.value.redshift_ims_schema_name}}.T_BB_AGREEMENT_LIST A
  INNER JOIN (
        SELECT
          VALUE1 AS RP_ID
          , VALUE2 AS SERVICE_ID
        FROM
          {{var.value.redshift_ims_schema_name}}.M_CRM_CODE CODE
        WHERE
          MASTER_TYPE = 'MST630'
          AND YUKO_FLG = '1'
      ) CODE
    ON A.RP_ID = CODE.RP_ID
       AND A.SERVICE_ID = CODE.SERVICE_ID
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;