UNLOAD ($$
SELECT
   '"' || A.GROUP_ID::VARCHAR   || '"' AS GROUP_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GROUP_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GROUP_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.KEIYAKU_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS KEIYAKU_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DELETE_FLAG
  ,'"' || A.INSERT_DATE::VARCHAR   || '"' AS INSERT_DATE
  ,'"' || A.UPDATE_DATE::VARCHAR   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSG_T_DS_GROUP A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;