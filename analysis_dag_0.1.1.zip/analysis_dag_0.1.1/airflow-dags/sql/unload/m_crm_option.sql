UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(OPSUM_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))              || '"' AS OPSUM_CD
  ,'"' || REPLACE(REPLACE(REPLACE(OP_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                 || '"' AS OP_CD
  ,'"' || REPLACE(REPLACE(REPLACE(PRICEPLN_SYSTEM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))    || '"' AS PRICEPLN_SYSTEM_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(INS_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS INS_BATCH_ID
  ,'"' || NVL(INS_DT_TM::VARCHAR, '')                                                                              || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(UPD_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS UPD_BATCH_ID
  ,'"' || NVL(UPD_DT_TM::VARCHAR, '')                                                                              || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.M_CRM_OPTION A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
