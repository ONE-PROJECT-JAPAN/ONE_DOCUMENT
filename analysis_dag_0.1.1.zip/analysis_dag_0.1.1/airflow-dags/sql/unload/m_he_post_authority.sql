UNLOAD ($$
SELECT
   '"' || A.ID::VARCHAR   || '"' AS ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CARD_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CARD_TYPE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.POST_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS POST_CD
  ,'"' || NVL(A.HON_SHISHA_CD::VARCHAR, '')   || '"' AS HON_SHISHA_CD
  ,'"' || NVL(A.DEPARTMENT_CD::VARCHAR, '')   || '"' AS DEPARTMENT_CD
  ,'"' || NVL(A.SECTION_CD::VARCHAR, '')   || '"' AS SECTION_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.AUTHORITY_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS AUTHORITY_TYPE
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_POST_AUTHORITY A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;