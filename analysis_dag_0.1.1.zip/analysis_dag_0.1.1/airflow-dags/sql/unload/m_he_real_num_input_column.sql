UNLOAD ($$
SELECT
   '"' || A.INPUT_PATTERN::VARCHAR   || '"' AS INPUT_PATTERN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.COLUMN_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS COLUMN_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.REFERENCE_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS REFERENCE_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_COLUMN, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_COLUMN
  ,'"' || NVL(A.EXCEL_INPUT_ROW::VARCHAR, '')   || '"' AS EXCEL_INPUT_ROW
  ,'"' || NVL(A.EXCEL_LOAD_ROW::VARCHAR, '')   || '"' AS EXCEL_LOAD_ROW
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.HIDDEN_DISP, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS HIDDEN_DISP
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.HIDDEN_REAL_NUM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS HIDDEN_REAL_NUM
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_REAL_NUM_INPUT_COLUMN A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;