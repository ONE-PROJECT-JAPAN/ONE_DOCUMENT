UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR   || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR   || '"' AS UPDATEDATE
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CUST_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CUST_NO
  ,'"' || REPLACE(REPLACE(REPLACE(A.START_PAGE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS START_PAGE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.KEITAI_START_PAGE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS KEITAI_START_PAGE
  ,'"' || REPLACE(REPLACE(REPLACE(A.DESIGN_KIND, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS DESIGN_KIND
  ,'"' || REPLACE(REPLACE(REPLACE(A.AUTO_UPDATE_X, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS AUTO_UPDATE_X
  ,'"' || NVL(A.ETSURANZUMI_HONSU::VARCHAR, '')   || '"' AS ETSURANZUMI_HONSU
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSU_T_DS_USER_META A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;