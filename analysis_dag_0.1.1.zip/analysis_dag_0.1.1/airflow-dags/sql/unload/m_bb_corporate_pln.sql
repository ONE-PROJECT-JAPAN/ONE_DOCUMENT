UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(RP_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                         || '"' AS RP_ID
  ,'"' || REPLACE(REPLACE(REPLACE(SERVICE_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS SERVICE_ID
  ,'"' || REPLACE(REPLACE(REPLACE(REPORT_CATEGORY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))               || '"' AS REPORT_CATEGORY
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(RP_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')              || '"' AS RP_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(SERVICE_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS SERVICE_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(REPORT_CATEGORY_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS REPORT_CATEGORY_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(PLAN_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')              || '"' AS PLAN_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(YUKO_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')             || '"' AS YUKO_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(INS_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS INS_BATCH_ID
  ,'"' || NVL(INS_DT_TM::VARCHAR, '')                                                                                      || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(UPD_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS UPD_BATCH_ID
  ,'"' || NVL(UPD_DT_TM::VARCHAR, '')                                                                                      || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.M_BB_CORPORATE_PLN A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
