UNLOAD ($$
SELECT
     '"' || A.AGE::VARCHAR                                                                                             || '"' AS AGE
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS INS_BATCH_ID
    ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')                                                                              || '"' AS INS_DT_TM
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_BATCH_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS UPD_BATCH_ID
    ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')                                                                              || '"' AS VARCHAR
FROM
    {{var.value.redshift_ims_schema_name}}.M_BI_AGE A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
