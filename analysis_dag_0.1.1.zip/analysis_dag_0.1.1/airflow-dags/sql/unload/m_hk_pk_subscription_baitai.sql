UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.SUBSCRIPTION_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS SUBSCRIPTION_NO
  ,'"' || A.BAITAI_CD::VARCHAR   || '"' AS BAITAI_CD
  ,'"' || A.CIRCULATION::VARCHAR   || '"' AS CIRCULATION
  ,'"' || NVL(A.DELIVERY_STOP_IGNORE::VARCHAR, '')   || '"' AS DELIVERY_STOP_IGNORE
  ,'"' || '"' AS CREATE_UPDATE_USER
  ,'"' || A.CREATE_UPDATE_DATE::VARCHAR   || '"' AS CREATE_UPDATE_DATE
  ,'"' || A.UPDATE_CNT::VARCHAR   || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HK_PK_SUBSCRIPTION_BAITAI A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;