UNLOAD ($$
SELECT
   '"' || A.HON_SHISHA_CD::VARCHAR           || '"' AS HON_SHISHA_CD
  ,'"' || A.DEPARTMENT_CD::VARCHAR           || '"' AS DEPARTMENT_CD
  ,'"' || NVL(A.CALCULATE_CD::VARCHAR, '')   || '"' AS CALCULATE_CD
  ,'"' || NVL(A.ST_DATE::VARCHAR, '')        || '"' AS ST_DATE
  ,'"' || NVL(A.END_DATE::VARCHAR, '')       || '"' AS END_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_FORMULA_INFO_MNG A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;