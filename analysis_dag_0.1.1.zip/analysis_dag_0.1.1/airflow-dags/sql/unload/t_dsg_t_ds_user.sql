UNLOAD ($$
SELECT
   '"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(SHA2(A.USER_NAME::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS USER_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.USER_ICON, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS USER_ICON
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_NOTICE_MAIL_PC, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_NOTICE_MAIL_PC
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FILTERS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FILTERS
  ,'"' || A.INSERT_DATE::VARCHAR   || '"' AS INSERT_DATE
  ,'"' || A.UPDATE_DATE::VARCHAR   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSG_T_DS_USER A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;