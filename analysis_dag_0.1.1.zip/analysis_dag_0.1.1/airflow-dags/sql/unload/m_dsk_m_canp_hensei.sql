UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR                                                                                               || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR                                                                                            || '"' AS UPDATEDATE
  ,'"' || REPLACE(REPLACE(REPLACE(A.NIK_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS NIK_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TOSYO_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS TOSYO_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            || '"' AS CANP_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_RYAKU1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS CANP_RYAKU1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_RYAKU2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS CANP_RYAKU2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_RYAKU3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS CANP_RYAKU3
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_KANA_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')       || '"' AS CANP_KANA_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_ENG_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS CANP_ENG_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GYOSYU_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')        || '"' AS GYOSYU_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_URL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           || '"' AS CANP_URL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DANGER_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS DANGER_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEW_GENRE_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')     || '"' AS NEW_GENRE_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_KACHI_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NIKKEI_KACHI_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CANP_ADR, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           || '"' AS CANP_ADR
FROM
  {{var.value.redshift_ims_schema_name}}.M_DSK_M_CANP_HENSEI A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;