UNLOAD ($$
SELECT
   '"' || A.HON_SHISHA_CD::VARCHAR   || '"' AS HON_SHISHA_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.CAMP_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS CAMP_CD
  ,'"' || A.ENQ_NO::VARCHAR   || '"' AS ENQ_NO
  ,'"' || A.TRIAL_SUBSCRIPTION_SIGN::VARCHAR   || '"' AS TRIAL_SUBSCRIPTION_SIGN
  ,'"' || A.ENQ_EDABAN::VARCHAR   || '"' AS ENQ_EDABAN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.ENQ_SELECT_ITEM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS ENQ_SELECT_ITEM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SELECT_ITEM_RYAKU, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SELECT_ITEM_RYAKU
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CREATE_UPDATE_USER
  ,'"' || A.CREATE_UPDATE_DATE::VARCHAR   || '"' AS CREATE_UPDATE_DATE
  ,'"' || A.UPDATE_CNT::VARCHAR   || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HK_CAMP_ENQ_ITEM A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;