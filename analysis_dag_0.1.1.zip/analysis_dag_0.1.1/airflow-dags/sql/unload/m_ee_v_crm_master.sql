UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.フォームID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                || '"' AS フォームID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.フォームタイプ, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS フォームタイプ
  ,'"' || REPLACE(REPLACE(REPLACE(A.フォーム名, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                || '"' AS フォーム名
  ,'"' || REPLACE(REPLACE(REPLACE(A.フォーム項目ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS フォーム項目ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.項目名, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                    || '"' AS 項目名
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.表題部, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           || '"' AS 表題部
  ,'"' || REPLACE(REPLACE(REPLACE(A.入力形態ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                || '"' AS 入力形態ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.選択肢ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS 選択肢ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.選択肢名, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         || '"' AS 選択肢名
FROM
  {{var.value.redshift_ims_schema_name}}.M_EE_V_CRM_マスタ情報 A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;