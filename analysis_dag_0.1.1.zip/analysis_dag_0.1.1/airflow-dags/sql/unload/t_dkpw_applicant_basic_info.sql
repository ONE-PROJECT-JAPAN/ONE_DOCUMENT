UNLOAD ($$
SELECT
   '"' || ''   || '"' AS ROWID
  ,'"' || REPLACE(REPLACE(REPLACE(A.FORM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FORM_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.APPLICANT_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS APPLICANT_ID
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.APPLICANT_MNG_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS APPLICANT_MNG_NO
  ,'"' || '"' AS EMAIL
  ,'"' || '"' AS NAME
  ,'"' || '"' AS NAME_YOMI
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OVERSEAS_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS OVERSEAS_FLG
  ,'"' || '"' AS ZIPCODE
  ,'"' || '"' AS ADDRESS_CD
  ,'"' || '"' AS ADDRESS_CD_NAME
  ,'"' || '"' AS BANTI
  ,'"' || '"' AS BUILDING
  ,'"' || '"' AS TELNO
  ,'"' || '"' AS FAXNO
  ,'"' || '"' AS DAYTIME_CONTACT
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SEX, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SEX
  ,'"' || '"' AS BIRTHDAY
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OCCUPATION_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS OCCUPATION_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.STORE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS STORE_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SECONDARY_READING, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SECONDARY_READING
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.YOBI_1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS YOBI_1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.YOBI_2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS YOBI_2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.REMARK, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS REMARK
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MAILPROPRIETY_1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS MAILPROPRIETY_1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MAILPROPRIETY_2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS MAILPROPRIETY_2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_ENTRY_DATE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NIKKEI_ENTRY_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_NEW_CREATE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NIKKEI_NEW_CREATE_FLG
  ,'"' || NVL(A.RECEPTION_DT_TM::VARCHAR, '')   || '"' AS RECEPTION_DT_TM
  ,'"' || A.ACQUISITION_DT_TM::VARCHAR   || '"' AS ACQUISITION_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.WIN_LOSE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS WIN_LOSE_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.WIN_LOSE_MEMO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS WIN_LOSE_MEMO
  ,'"' || NVL(A.WIN_LOSE_DATE::VARCHAR, '')   || '"' AS WIN_LOSE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRIZE_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS PRIZE_NAME
  ,'"' || A.CREATE_UPDATE_DT_TM::VARCHAR   || '"' AS CREATE_UPDATE_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_USER
FROM
  {{var.value.redshift_ims_schema_name}}.T_DKPW_APPLICANT_BASIC_INFO A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;