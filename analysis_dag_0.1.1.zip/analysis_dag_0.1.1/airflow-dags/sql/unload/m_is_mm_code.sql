UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.MASTER_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS MASTER_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.VALUE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS VALUE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.LABEL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS LABEL
  ,'"' || NVL(A.SHOW_FLG::VARCHAR, '')   || '"' AS SHOW_FLG
  ,'"' || A.SORT_ORDER::VARCHAR   || '"' AS SORT_ORDER
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NOTE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NOTE
  ,'"' || NVL(A.CREATE_DATE::VARCHAR, '')   || '"' AS CREATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CREATE_USER
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')   || '"' AS UPDATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_USER
  ,'"' || NVL(A.DELETE_DATE::VARCHAR, '')   || '"' AS DELETE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DELETE_USER
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DELETE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DELETE_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.M_IS_MM_CODE A;
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;