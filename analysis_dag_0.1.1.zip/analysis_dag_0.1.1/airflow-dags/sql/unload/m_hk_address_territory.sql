UNLOAD ($$
SELECT
   '"' || NVL(REPLACE(REPLACE(REPLACE(A.PREFECTURE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')      || '"' AS PREFECTURE_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SHIKUTYOUSON_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')    || '"' AS SHIKUTYOUSON_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TSUSHO_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          || '"' AS TSUSHO_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CHOME_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)) , '')          || '"' AS CHOME_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.STORE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           || '"' AS STORE_CD
  ,'"' || A.TYPE_CD::VARCHAR                                                                                               || '"' AS TYPE_CD
  ,'"' || NVL(A.CHARGE_RATE::VARCHAR, '')                                                                                  || '"' AS CHARGE_RATE
  ,'"' || NVL(A.UPDATE_DATE::VARCHAR, '')                                                                                  || '"' AS UPDATE_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS CREATE_UPDATE_USER
  ,'"' || NVL(A.CREATE_UPDATE_DATE::VARCHAR, '')                                                                           || '"' AS CREATE_UPDATE_DATE
  ,'"' || NVL(A.UPDATE_CNT::VARCHAR, '')                                                                                   || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HK_ADDRESS_TERRITORY A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
