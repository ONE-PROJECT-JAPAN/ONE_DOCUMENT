UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.RECID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS RECID
  ,'"' || REPLACE(REPLACE(REPLACE(A.M_BUNRUI_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS M_BUNRUI_CODE
  ,'"' || NVL(A.SORT_NUMBER::VARCHAR, '')   || '"' AS SORT_NUMBER
  ,'"' || NVL(A.DATADATE::VARCHAR, '')   || '"' AS DATADATE
  ,'"' || REPLACE(REPLACE(REPLACE(A.MIJOJO_HUBAN_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS MIJOJO_HUBAN_FLAG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NAME_S, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NAME_S
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NAME_R, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NAME_R
  ,'"' || NVL(A.INSDATE::VARCHAR, '')   || '"' AS INSDATE
  ,'"' || NVL(A.UPDATEDATE::VARCHAR, '')   || '"' AS UPDATEDATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NAME_R_NKD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NAME_R_NKD
FROM
  {{var.value.redshift_ims_schema_name}}.M_MM_NEEDS_GYOSHU_MASTER_M A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;