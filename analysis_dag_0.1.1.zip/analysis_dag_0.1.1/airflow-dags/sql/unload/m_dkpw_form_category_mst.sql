UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.FORM_CATEGORY_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS FORM_CATEGORY_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FORM_CATEGORY_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FORM_CATEGORY_NM
FROM
  {{var.value.redshift_ims_schema_name}}.M_DKPW_FORM_CATEGORY_MST A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;