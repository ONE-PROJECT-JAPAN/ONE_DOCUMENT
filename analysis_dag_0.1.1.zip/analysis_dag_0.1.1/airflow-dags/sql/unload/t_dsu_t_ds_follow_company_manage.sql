UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR   || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR   || '"' AS UPDATEDATE
  ,'"' || REPLACE(REPLACE(REPLACE(A.FOLLOW_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FOLLOW_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.FOLLOW_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FOLLOW_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.FOLLOW_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FOLLOW_NAME
  ,'"' || NVL(A.NEWS_UPDATEDATE::VARCHAR, '')   || '"' AS NEWS_UPDATEDATE
  ,'"' || REPLACE(REPLACE(REPLACE(A.DELETE_FLAG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS DELETE_FLAG
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSU_T_DS_FOLLOW_COMPANY_MANAGE A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;