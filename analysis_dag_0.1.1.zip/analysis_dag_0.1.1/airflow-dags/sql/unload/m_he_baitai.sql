UNLOAD ($$
SELECT
   '"' || A.BAITAI_CD::VARCHAR   || '"' AS BAITAI_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BAITAI_RYAKU_YOMI, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS BAITAI_RYAKU_YOMI
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BAITAI_NM_YOMI, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS BAITAI_NM_YOMI
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BAITAI_RYAKU, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS BAITAI_RYAKU
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.BAITAI_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS BAITAI_NM
  ,'"' || REPLACE(REPLACE(REPLACE(A.BAITAI_MARK, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS BAITAI_MARK
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CREATE_UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CREATE_UPDATE_USER
  ,'"' || A.CREATE_UPDATE_DATE::VARCHAR   || '"' AS CREATE_UPDATE_DATE
  ,'"' || A.UPDATE_CNT::VARCHAR   || '"' AS UPDATE_CNT
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_BAITAI A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;