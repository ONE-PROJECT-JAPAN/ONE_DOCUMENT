UNLOAD ($$
SELECT
   '"' || A.INSDATE::VARCHAR   || '"' AS INSDATE
  ,'"' || A.UPDATEDATE::VARCHAR   || '"' AS UPDATEDATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_ADMIN_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS INS_ADMIN_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_ADMIN_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPD_ADMIN_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.SEND_MAIL_KIND, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS SEND_MAIL_KIND
  ,'"' || REPLACE(REPLACE(REPLACE(A.SEND_MAIL_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS SEND_MAIL_NM
  ,'"' || A.DSP_ORD::VARCHAR   || '"' AS DSP_ORD
  ,'"' || REPLACE(REPLACE(REPLACE(A.MAIL_AUTH_KIND, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS MAIL_AUTH_KIND
  ,'"' || REPLACE(REPLACE(REPLACE(A.DEL_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS DEL_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.M_DSU_M_SEND_MAIL_KIND A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
