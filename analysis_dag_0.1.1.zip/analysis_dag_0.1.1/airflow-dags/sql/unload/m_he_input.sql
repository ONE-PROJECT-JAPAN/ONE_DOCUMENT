UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.TANPYO_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS TANPYO_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_COLUMN, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_COLUMN
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CHOHYO_TATE_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CHOHYO_TATE_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CHOHYO_YOKO_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CHOHYO_YOKO_NAME
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.CSV_ROW_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS CSV_ROW_NO
  ,'"' || NVL(A.CSV_NO::VARCHAR, '')   || '"' AS CSV_NO
  ,'"' || NVL(A.SHOP_DATA_EXCEL::VARCHAR, '')   || '"' AS SHOP_DATA_EXCEL
  ,'"' || NVL(A.SHOP_DATA_TSUKIBETU::VARCHAR, '')   || '"' AS SHOP_DATA_TSUKIBETU
  ,'"' || NVL(A.INPUT_EXCEL_ROW::VARCHAR, '')   || '"' AS INPUT_EXCEL_ROW
  ,'"' || NVL(A.LOAD_EXCEL_ROW::VARCHAR, '')   || '"' AS LOAD_EXCEL_ROW
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_INPUT A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;