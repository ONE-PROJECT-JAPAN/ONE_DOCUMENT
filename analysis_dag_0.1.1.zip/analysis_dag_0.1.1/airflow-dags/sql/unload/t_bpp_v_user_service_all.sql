UNLOAD ($$
SELECT
    A.SERIALID::VARCHAR                                                                                                AS SERIALID
  , NVL(SHA2(A.NIKKEI_ID::VARCHAR || S.SEED::VARCHAR, 256), '')                                                         AS HASH_ID
  , NVL(A.BP_STATUS::VARCHAR, '')                                                                                       AS BP_STATUS
  , ''                                                                                                                  AS NICKNAME
  , NVL(REPLACE(REPLACE(REPLACE(A.ENTRY_SERVICEID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')       AS ENTRY_SERVICEID
  , NVL(A.ATTRIBUTE_UPDATED::VARCHAR, '')                                                                               AS ATTRIBUTE_UPDATED
  , NVL(A.CREATE_ON::VARCHAR, '')                                                                                       AS CREATE_ON
  , NVL(A.UPDATE_ON::VARCHAR, '')                                                                                       AS UPDATE_ON
  , ''                                                                                                                  AS MMAIL
  , ''                                                                                                                  AS MMAIL_LOWER
  , NVL(A.MMAIL_STATUS::VARCHAR, '')                                                                                    AS MMAIL_STATUS
  , NVL(A.MMAIL_NOTICE_STATUS::VARCHAR, '')                                                                             AS MMAIL_NOTICE_STATUS
  , NVL(A.MMAIL_NOTICE_UPDATED::VARCHAR, '')                                                                            AS MMAIL_NOTICE_UPDATED
  , ''                                                                                                                  AS MOBILE_UID1
  , ''                                                                                                                  AS MOBILE_UID2
  , NVL(A.MOBILE_ACTIVATE::VARCHAR, '')                                                                                 AS MOBILE_ACTIVATE
  , NVL(A.MOBILE_ACTIVATE_UPDATED::VARCHAR, '')                                                                         AS MOBILE_ACTIVATE_UPDATED
  , NVL(REPLACE(REPLACE(REPLACE(A.GROUP_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')              AS GROUP_ID
  , NVL(REPLACE(REPLACE(REPLACE(A.SERVICE_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            AS SERVICE_ID
  , ''                                                                                                                  AS DISP_NAME
  , NVL(REPLACE(REPLACE(REPLACE(A.SERVICE_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')          AS SERVICE_NAME
  , NVL(A.LINK_STATUS::VARCHAR, '')                                                                                     AS LINK_STATUS
  , NVL(REPLACE(REPLACE(REPLACE(A.SUBSCRIBER_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         AS SUBSCRIBER_CD
  , NVL(A.LINKENTRY_ON::VARCHAR, '')                                                                                    AS LINKENTRY_ON
  , NVL(A.LINKSTOP_ON::VARCHAR, '')                                                                                     AS LINKSTOP_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.SUBSCRIBER_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')     AS SUBSCRIBER_STATUS
  , NVL(REPLACE(REPLACE(REPLACE(A.OLD_SUBSCRIBER_STATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') AS OLD_SUBSCRIBER_STATUS
  , NVL(A.SUBSCRIBER_UPDATED::VARCHAR, '')                                                                              AS SUBSCRIBER_UPDATED
  , NVL(A.USER_SV_STATUS::VARCHAR, '')                                                                                  AS USER_SV_STATUS
  , NVL(A.USER_SV_STATUS_UPDATED::VARCHAR, '')                                                                          AS USER_SV_STATUS_UPDATED
  , NVL(A.LATEST_SUBMISSION::VARCHAR, '')                                                                               AS LATEST_SUBMISSION
  , NVL(A.SERVICE_UPDATE::VARCHAR, '')                                                                                  AS SERVICE_UPDATE
  , NVL(A.AGREEMENTSTATUS::VARCHAR, '')                                                                                 AS AGREEMENTSTATUS
  , NVL(A.AGREEMENTSTATUS_ON::VARCHAR, '')                                                                              AS AGREEMENTSTATUS_ON
  , NVL(A.NOTICE_STATUS::VARCHAR, '')                                                                                   AS NOTICE_STATUS
  , NVL(A.NOTICE_STATUS_ON::VARCHAR, '')                                                                                AS NOTICE_STATUS_ON
  , NVL(A.DMIN_STATUS::VARCHAR, '')                                                                                     AS DMIN_STATUS
  , NVL(A.DMIN_STATUS_ON::VARCHAR, '')                                                                                  AS DMIN_STATUS_ON
  , NVL(A.DMEXT_STATUS::VARCHAR, '')                                                                                    AS DMEXT_STATUS
  , NVL(A.DMEXT_STATUS_ON::VARCHAR, '')                                                                                 AS DMEXT_STATUS_ON
  , NVL(A.RESEARCH_STATUS::VARCHAR, '')                                                                                 AS RESEARCH_STATUS
  , NVL(A.RESEARCH_STATUS_ON::VARCHAR, '')                                                                              AS RESEARCH_STATUS_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.MARRIEDSTATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         AS MARRIEDSTATUS
  , NVL(A.MARRIEDSTATUS_CREATE::VARCHAR, '')                                                                            AS MARRIEDSTATUS_CREATE
  , NVL(A.MARRIEDSTATUS_ON::VARCHAR, '')                                                                                AS MARRIEDSTATUS_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.CHILDSTATUS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')           AS CHILDSTATUS
  , NVL(A.CHILDSTATUS_CREATE::VARCHAR, '')                                                                              AS CHILDSTATUS_CREATE
  , NVL(A.CHILDSTATUS_ON::VARCHAR, '')                                                                                  AS CHILDSTATUS_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.INDUSTRY_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')         AS INDUSTRY_TYPE
  , NVL(A.INDUSTRY_TYPE_CREATE::VARCHAR, '')                                                                            AS INDUSTRY_TYPE_CREATE
  , NVL(A.INDUSTRY_TYPE_ON::VARCHAR, '')                                                                                AS INDUSTRY_TYPE_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.OCCUPATION_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')       AS OCCUPATION_TYPE
  , NVL(A.OCCUPATION_TYPE_CREATE::VARCHAR, '')                                                                          AS OCCUPATION_TYPE_CREATE
  , NVL(A.OCCUPATION_TYPE_ON::VARCHAR, '')                                                                              AS OCCUPATION_TYPE_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.DEPARTMENT, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            AS DEPARTMENT
  , NVL(A.DEPARTMENT_CREATE::VARCHAR, '')                                                                               AS DEPARTMENT_CREATE
  , NVL(A.DEPARTMENT_ON::VARCHAR, '')                                                                                   AS DEPARTMENT_ON
  , NVL(REPLACE(REPLACE(REPLACE(A.S7, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                    AS S7
  , NVL(A.S7_CREATE::VARCHAR, '')                                                                                       AS S7_CREATE
  , NVL(A.S7_ON::VARCHAR, '')                                                                                           AS S7_ON
FROM
  {{var.value.redshift_ims_schema_name}}.T_BPP_V_USER_SERVICE_ALL A
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
ADDQUOTES
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
