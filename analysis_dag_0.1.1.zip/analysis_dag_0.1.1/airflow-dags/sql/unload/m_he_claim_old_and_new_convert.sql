UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.OLD_CATEGORY_L_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS OLD_CATEGORY_L_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.OLD_CATEGORY_S_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS OLD_CATEGORY_S_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEW_CATEGORY_L_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NEW_CATEGORY_L_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEW_CATEGORY_S_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NEW_CATEGORY_S_CD
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_CLAIM_OLD_AND_NEW_CONVERT A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;