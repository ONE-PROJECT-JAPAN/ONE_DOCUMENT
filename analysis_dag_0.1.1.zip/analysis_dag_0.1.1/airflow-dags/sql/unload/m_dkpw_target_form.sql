UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.FORM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS FORM_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FORM_NM, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FORM_NM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FORM_CATEGORY_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FORM_CATEGORY_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NIKKEI_ID_LINKAGE_CLASS, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NIKKEI_ID_LINKAGE_CLASS
  ,'"' || NVL(A.CREATE_TERM_FROM::VARCHAR, '')   || '"' AS CREATE_TERM_FROM
  ,'"' || NVL(A.CREATE_TERM_TO::VARCHAR, '')   || '"' AS CREATE_TERM_TO
  ,'"' || NVL(A.OPEN_DATE::VARCHAR, '')   || '"' AS OPEN_DATE
  ,'"' || NVL(A.CREATE_DT_TM::VARCHAR, '')   || '"' AS CREATE_DT_TM
  ,'"' || CASE WHEN A.DELETE_FLG = true THEN 'true' WHEN A.DELETE_FLG = false THEN 'false' ELSE '' END   || '"' AS DELETE_FLG
  ,'"' || A.CREATE_UPDATE_DT_TM::VARCHAR   || '"' AS CREATE_UPDATE_DT_TM
  ,'"' || NVL(A.LAST_GET_DT_TM::VARCHAR, '')   || '"' AS LAST_GET_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.M_DKPW_TARGET_FORM A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
