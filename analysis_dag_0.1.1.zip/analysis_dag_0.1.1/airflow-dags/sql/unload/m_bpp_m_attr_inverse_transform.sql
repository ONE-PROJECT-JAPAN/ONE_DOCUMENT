UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.NIKKKEI_M_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))       || '"' AS NIKKKEI_M_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.NIKKEIID_ATTR, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))        || '"' AS NIKKEIID_ATTR
  ,'"' || REPLACE(REPLACE(REPLACE(A.ATTRIBUTE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS ATTRIBUTE_CD
  ,'"' || REPLACE(REPLACE(REPLACE(A.ATTRIBUTE_VALUE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS ATTRIBUTE_VALUE_CD
  ,'"' || A.DISABLE_FLG::VARCHAR                                                                                    || '"' AS DISABLE_FLG
  ,'"' || A.CREATE_ON::VARCHAR                                                                                      || '"' AS CREATE_ON
  ,'"' || REPLACE(REPLACE(REPLACE(A.CREATE_BY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS CREATE_BY
  ,'"' || A.UPDATE_ON::VARCHAR                                                                                      || '"' AS UPDATE_ON
  ,'"' || REPLACE(REPLACE(REPLACE(A.UPDATE_BY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))            || '"' AS UPDATE_BY
FROM
  {{var.value.redshift_ims_schema_name}}.M_BPP_M_ATTR_INVERSE_TRANSFORM A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;