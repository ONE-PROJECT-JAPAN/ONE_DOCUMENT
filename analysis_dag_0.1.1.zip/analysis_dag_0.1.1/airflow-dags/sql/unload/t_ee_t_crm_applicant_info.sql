UNLOAD ($$
SELECT
   '"' || SHA2(A.日経ID会員番号::VARCHAR || S.SEED::VARCHAR, 256)                                                      || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')                                                                                         || '"' AS SERIAL_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.フォームID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))              || '"' AS フォームID
  ,'"' || REPLACE(REPLACE(REPLACE(A.応募者ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                || '"' AS 応募者ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.フォーム名, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))              || '"' AS フォーム名
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.デバイス情報, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS デバイス情報
  ,'"' || A.登録日時::VARCHAR                                                                                          || '"' AS 登録日時
FROM
  {{var.value.redshift_ims_schema_name}}.T_EE_T_CRM_応募者情報 A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.日経ID会員番号
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;