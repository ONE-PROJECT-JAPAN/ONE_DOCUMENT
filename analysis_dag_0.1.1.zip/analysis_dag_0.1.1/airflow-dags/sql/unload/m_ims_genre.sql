UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(GENRE_CODE1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_CODE1
  ,'"' || REPLACE(REPLACE(REPLACE(GENRE_CODE2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_CODE2
  ,'"' || REPLACE(REPLACE(REPLACE(GENRE_CODE3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_CODE3
  ,'"' || REPLACE(REPLACE(REPLACE(GENRE_NAME1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_NAME1
  ,'"' || REPLACE(REPLACE(REPLACE(GENRE_NAME2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_NAME2
  ,'"' || REPLACE(REPLACE(REPLACE(GENRE_NAME3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))         || '"' AS GENRE_NAME3
  ,'"' || DISPLAY_ORDER::VARCHAR                                                                                 || '"' AS DISPLAY_ORDER
  ,'"' || REPLACE(REPLACE(REPLACE(DELETE_FLG, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))          || '"' AS DELETE_FLG
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS INS_PGM_ID
  ,'"' || NVL(INS_DT_TM::VARCHAR, '')                                                                            || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || '"' AS UPD_PGM_ID
  ,'"' || NVL(UPD_DT_TM::VARCHAR, '')                                                                            || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.M_IMS_GENRE A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
