UNLOAD ($$
SELECT
   '"' || A.SHARE_ID::VARCHAR   || '"' AS SHARE_ID
  ,'"' || A.GROUP_ID::VARCHAR   || '"' AS GROUP_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SHARE_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SHARE_TYPE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.NEWS_ITEM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS NEWS_ITEM_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.URL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS URL
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.URL_HASH, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS URL_HASH
  ,'"' || A.LAST_SHARE_DATE::VARCHAR   || '"' AS LAST_SHARE_DATE
  ,'"' || A.INSERT_DATE::VARCHAR   || '"' AS INSERT_DATE
  ,'"' || A.UPDATE_DATE::VARCHAR   || '"' AS UPDATE_DATE
FROM
  {{var.value.redshift_ims_schema_name}}.T_DSG_T_DS_SHARE A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;