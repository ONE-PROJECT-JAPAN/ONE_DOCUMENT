UNLOAD ($$
SELECT
   '"' || A.CALCULATE_CD::VARCHAR                                                                                 || '"' AS CALCULATE_CD
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FORMULA, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FORMULA
FROM
  {{var.value.redshift_ims_schema_name}}.M_HE_FORMULA_PATTERN A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;