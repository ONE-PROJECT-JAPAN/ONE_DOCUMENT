UNLOAD ($$
SELECT
     '"' || A.LIST_ID::VARCHAR                                                                                                                                || '"' AS LIST_ID
    ,'"' || REPLACE(REPLACE(REPLACE(SHA2(A.LIST_INTERNAL_ID::VARCHAR || S.SEED::VARCHAR, 256), '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))      || '"' AS LIST_INTERNAL_ID
    ,'"' || NVL(B.SERIAL_ID, '')                                                                                                                              || '"' AS SERIAL_ID
    ,'"' || A.SCORE_ID::VARCHAR                                                                                                                               || '"' AS SCORE_ID
    ,'"' || NVL(A.SCORE_VALUE_NUMERIC::VARCHAR, '')                                                                                                           || '"' AS SCORE_VALUE_NUMERIC
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SCORE_VALUE_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                      || '"' AS SCORE_VALUE_CD
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                          || '"' AS INS_PGM_ID
    ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')                                                                                                                     || '"' AS INS_DT_TM
    ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                                          || '"' AS UPD_PGM_ID
    ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')                                                                                                                     || '"' AS UPD_DT_TM
FROM
    {{var.value.redshift_ims_schema_name}}.M_IMS_SCORE A
    LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.LIST_INTERNAL_ID
    , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
