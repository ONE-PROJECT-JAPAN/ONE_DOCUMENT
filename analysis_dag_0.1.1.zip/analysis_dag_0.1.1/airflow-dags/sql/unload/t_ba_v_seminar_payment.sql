UNLOAD ($$
SELECT
   '"' || REPLACE(REPLACE(REPLACE(A.PAYMENT_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS PAYMENT_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SYSTEM_SEMINAR_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SYSTEM_SEMINAR_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SITE_MEMBER_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SITE_MEMBER_ID
  ,'"' || NVL(A.PAYMENT_KIND::VARCHAR, '')   || '"' AS PAYMENT_KIND
  ,'"' || A.PAYMENT_DATE::VARCHAR   || '"' AS PAYMENT_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.RECEIPT_NUMBER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS RECEIPT_NUMBER
  ,'"' || '"' AS NAME
  ,'"' || '"' AS NAME_KANA
  ,'"' || '"' AS MAIL_ADDRESS
  ,'"' || '"' AS ZIP_CODE_HOME1
  ,'"' || '"' AS ZIP_CODE_HOME2
  ,'"' || '"' AS ADDRESS_HOME1
  ,'"' || '"' AS ADDRESS_HOME2
  ,'"' || '"' AS ADDRESS_HOME3
  ,'"' || '"' AS TEL_NUMBER_HOME1
  ,'"' || '"' AS TEL_NUMBER_HOME2
  ,'"' || '"' AS TEL_NUMBER_HOME3
  ,'"' || REPLACE(REPLACE(REPLACE(A.JOB_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS JOB_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.JOB, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS JOB
  ,'"' || REPLACE(REPLACE(REPLACE(A.INDUSTRY_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS INDUSTRY_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INDUSTRY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS INDUSTRY
  ,'"' || REPLACE(REPLACE(REPLACE(A.OCCUPATIONAL_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS OCCUPATIONAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.OCCUPATIONAL, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS OCCUPATIONAL
  ,'"' || REPLACE(REPLACE(REPLACE(A.POSITION_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS POSITION_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.POSITION_NAME, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS POSITION_NAME
  ,'"' || REPLACE(REPLACE(REPLACE(A.EMPLOYEES_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS EMPLOYEES_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.EMPLOYEES, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS EMPLOYEES
  ,'"' || '"' AS NAME_COMPANY
  ,'"' || REPLACE(REPLACE(REPLACE(A.COMPANY_TYPE_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS COMPANY_TYPE_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.COMPANY_TYPE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS COMPANY_TYPE
  ,'"' || REPLACE(REPLACE(REPLACE(A.COMPANY_TYPE_LOCATION, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS COMPANY_TYPE_LOCATION
  ,'"' || '"' AS COMPANY_BUSINESS_UNIT
  ,'"' || '"' AS ZIP_CODE_COMPANY1
  ,'"' || '"' AS ZIP_CODE_COMPANY2
  ,'"' || '"' AS ADDRESS_COMPANY
  ,'"' || '"' AS TEL_NUMBER_COMPANY1
  ,'"' || '"' AS TEL_NUMBER_COMPANY2
  ,'"' || '"' AS TEL_NUMBER_COMPANY3
  ,'"' || CASE WHEN A.PACKAGE_FLG = true THEN 'true' WHEN A.PACKAGE_FLG = false THEN 'false' ELSE '' END   || '"' AS PACKAGE_FLG
  ,'"' || CASE WHEN A.SEND_BILL_FLG = true THEN 'true' WHEN A.SEND_BILL_FLG = false THEN 'false' ELSE '' END   || '"' AS SEND_BILL_FLG
  ,'"' || NVL(A.SEMINAR_PRICE::VARCHAR, '')   || '"' AS SEMINAR_PRICE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.MAIN_TITLE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS MAIN_TITLE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SEMINAR_DATE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SEMINAR_DATE
  ,'"' || NVL(A.INSDATE::VARCHAR, '')   || '"' AS INSDATE
  ,'"' || NVL(A.REG_ID::VARCHAR, '')   || '"' AS REG_ID
  ,'"' || NVL(A.UPDATEDATE::VARCHAR, '')   || '"' AS UPDATEDATE
  ,'"' || NVL(A.UPD_ID::VARCHAR, '')   || '"' AS UPD_ID
  ,'"' || CASE WHEN A.DELETE_FLG = true THEN 'true' WHEN A.DELETE_FLG = false THEN 'false' ELSE '' END   || '"' AS DELETE_FLG
FROM
  {{var.value.redshift_ims_schema_name}}.T_BA_V_SEMINAR_PAYMENT A
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;