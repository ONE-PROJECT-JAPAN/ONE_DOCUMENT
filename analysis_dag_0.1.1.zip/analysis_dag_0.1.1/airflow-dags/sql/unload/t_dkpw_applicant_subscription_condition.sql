UNLOAD ($$
SELECT
   '"' || A.DATA_LOAD_ID::VARCHAR   || '"' AS DATA_LOAD_ID
  ,'"' || REPLACE(REPLACE(REPLACE(A.APPLICANT_MNG_NO, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS APPLICANT_MNG_NO
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.DATA_EXIST_LAST_DATE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS DATA_EXIST_LAST_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.SUBSCRIPTION_CONDITION, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS SUBSCRIPTION_CONDITION
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.PRICEPLN_CD, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS PRICEPLN_CD
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.FIRST_CONTRACT_ST_DATE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS FIRST_CONTRACT_ST_DATE
  ,'"' || NVL(A.CREATE_UPDATE_DT_TM::VARCHAR, '')   || '"' AS CREATE_UPDATE_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPDATE_USER, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPDATE_USER
FROM
  {{var.value.redshift_ims_schema_name}}.T_DKPW_APPLICANT_SUBSCRIPTION_CONDITION A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;