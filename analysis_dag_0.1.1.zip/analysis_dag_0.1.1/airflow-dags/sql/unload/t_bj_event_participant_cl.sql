UNLOAD ($$
SELECT
   '"' || A.ROWID::VARCHAR   || '"' AS ROWID
  ,'"' || REPLACE(REPLACE(REPLACE(A.EVENT_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))   || '"' AS EVENT_ID
  ,'"' || A.PARTICIPANT_ID::VARCHAR   || '"' AS PARTICIPANT_ID
  ,'"' || '"' AS EMAIL
  ,'"' || '"' AS CLKEY_EMAIL
  ,'"' || '"' AS EMAIL_CL
  ,'"' || SHA2(A.NIKKEI_MEMBER_NO::VARCHAR || S.SEED::VARCHAR, 256) || '"'  AS HASH_ID
  ,'"' || NVL(B.SERIAL_ID, '')   || '"' AS SERIAL_ID
  ,'"' || '"' AS LAST_NAME
  ,'"' || '"' AS FIRST_NAME
  ,'"' || '"' AS CLKEY_LAST_NAME
  ,'"' || '"' AS CLKEY_FIRST_NAME
  ,'"' || '"' AS NAME_CL_LAST_NM
  ,'"' || '"' AS NAME_CL_FIRST_NM
  ,'"' || '"' AS NAME_CL_NM
  ,'"' || '"' AS LAST_KANA_NAME
  ,'"' || '"' AS FIRST_KANA_NAME
  ,'"' || '"' AS HOME_PHONE
  ,'"' || '"' AS HOME_FAX
  ,'"' || '"' AS HOME_COUNTRY
  ,'"' || '"' AS HOME_ZIPCODE
  ,'"' || '"' AS HOME_ADDR1
  ,'"' || '"' AS HOME_ADDR2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INDUSTRY, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS INDUSTRY
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.JOB, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS JOB
  ,'"' || '"' AS COMPANY
  ,'"' || '"' AS WORK_EMAIL
  ,'"' || '"' AS WORK_COUNTRY
  ,'"' || '"' AS WORK_ZIPCODE
  ,'"' || '"' AS CLKEY_ZIPCODE
  ,'"' || '"' AS ZIPCODE_CL
  ,'"' || '"' AS WORK_ADDR1
  ,'"' || '"' AS WORK_ADDR2
  ,'"' || '"' AS CLKEY_ADDR1
  ,'"' || '"' AS CLKEY_ADDR2
  ,'"' || '"' AS ADDR_CL_ADDR
  ,'"' || '"' AS ADDR_CL_PREFEC
  ,'"' || '"' AS ADDR_CL_CITY
  ,'"' || '"' AS ADDR_CL_TSUSHO
  ,'"' || '"' AS ADDR_CL_CHOME
  ,'"' || '"' AS ADDR_CL_ADDR1
  ,'"' || '"' AS ADDR_CL_ADDR2
  ,'"' || '"' AS ADDR_CL_ADDR3
  ,'"' || '"' AS ADDR_CL_ADDR_CD
  ,'"' || '"' AS WORK_PHONE
  ,'"' || '"' AS CLKEY_PHONE
  ,'"' || '"' AS PHONE_CL
  ,'"' || '"' AS WORK_FAX
  ,'"' || '"' AS WORK_DEPARTMENT
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.WORK_TITLE_CODE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS WORK_TITLE_CODE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.WORK_TITLE, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS WORK_TITLE
  ,'"' || NVL(A.GENDER::VARCHAR, '')   || '"' AS GENDER
  ,'"' || '"' AS BIRTHDAY
  ,'"' || NVL(A.SECONDARY_USE_SIGN::VARCHAR, '')   || '"' AS SECONDARY_USE_SIGN
  ,'"' || NVL(A.CHECKIN_STATUS::VARCHAR, '')   || '"' AS CHECKIN_STATUS
  ,'"' || NVL(A.ACQUISITION_DATE::VARCHAR, '')   || '"' AS ACQUISITION_DATE
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_1, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_1
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_2, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_2
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_3, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_3
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_4, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_4
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_5, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_5
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_6, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_6
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_7, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_7
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_8, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_8
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_9, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_9
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.GENERAL_ITEM_10, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS GENERAL_ITEM_10
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.INS_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS INS_PGM_ID
  ,'"' || NVL(A.INS_DT_TM::VARCHAR, '')   || '"' AS INS_DT_TM
  ,'"' || NVL(REPLACE(REPLACE(REPLACE(A.UPD_PGM_ID, '"', '""'), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')   || '"' AS UPD_PGM_ID
  ,'"' || NVL(A.UPD_DT_TM::VARCHAR, '')   || '"' AS UPD_DT_TM
FROM
  {{var.value.redshift_ims_schema_name}}.T_BJ_EVENT_PARTICIPANT_CL A
  LEFT OUTER JOIN {{var.value.redshift_ims_schema_name}}.M_IS_NX_USER_SERIAL_ID B
    ON B.USER_NO = A.NIKKEI_MEMBER_NO
  , {{var.value.redshift_ims_schema_name}}.M_CRM_SEED S
$$)
TO 's3://{{params.s3_bucket_name}}/{{params.s3_full_prefix}}{{ts_nodash}}_'
IAM_ROLE '{{params.redshift_role_arn}}'
DELIMITER AS ','
GZIP
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;