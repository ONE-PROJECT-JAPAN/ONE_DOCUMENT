
/*******************************************************************************
  SQL名:
    参加者属性情報データ差分ファイル作成

  処理概要:
       クレンジングのためにIFテーブルのデータをクレンジング用テーブルに追加する(行番号追加)
       参加者属性情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。

*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_EVR_ATTENDEE_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_EVR_ATTENDEE_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by ATTENDEE_UID) AS ROWID
    ,ATTENDEE_UID
    ,USER_UID
    ,EVENT_UID
    ,NIKKEI_ID_USER_ID
    ,EMAIL
    ,LAST_NAME
    ,FIRST_NAME
    ,LAST_NAME_KANA
    ,FIRST_NAME_KANA
    ,HOME_PHONE
    ,HOME_COUNTRY
    ,HOME_ZIPCODE
    ,HOME_PREFECTURE
    ,HOME_CITY
    ,HOME_STREET_ADDRESS1
    ,HOME_STREET_ADDRESS2
    ,INDUSTRY
    ,JOB
    ,COMPANY
    ,WORK_EMAIL
    ,WORK_COUNTRY
    ,WORK_ZIPCODE
    ,WORK_PREFECTURE
    ,WORK_CITY
    ,WORK_STREET_ADDRESS1
    ,WORK_STREET_ADDRESS2
    ,WORK_PHONE
    ,WORK_DEPARTMENT
    ,WORK_TITLE
    ,GENDER
    ,BIRTHDAY
FROM {{ var.value.redshift_ims_schema_name }}.T_EVR_ATTENDEE
;

-- 参加者属性情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
UNLOAD ($$
SELECT
   T.ROWID                                                 AS ROWID_IF
  ,T.ATTENDEE_UID                                          AS ATTENDEE_UID
  ,NVL(T.LAST_NAME,'')  ||  NVL(T.FIRST_NAME,'')           AS NAME
  ,NVL(T.HOME_PHONE)                                       AS HOME_PHONE
  ,NVL(HOME_ZIPCODE)                                       AS HOME_ZIPCODE
  ,NVL(T.HOME_PREFECTURE,'')                       ||
                   NVL(T.HOME_CITY,'')             ||
                   NVL(T.HOME_STREET_ADDRESS1,'')  ||
                   NVL(T.HOME_STREET_ADDRESS2,'')          AS ADDRESS
FROM
    {{ var.value.redshift_ims_schema_name }}.T_EVR_ATTENDEE_TEMP_CLEANSING T
WHERE
    NOT EXISTS(
        SELECT 'X'
        FROM
            {{ var.value.redshift_ims_schema_name }}.T_EVR_ATTENDEE_CL_AC AC
        WHERE
            T.ATTENDEE_UID = AC.ATTENDEE_UID
        AND
            NVL(T.LAST_NAME, '') = NVL(AC.LAST_NAME, '')
        AND
            NVL(T.FIRST_NAME, '') = NVL(AC.FIRST_NAME, '')
        AND
            NVL(T.HOME_PHONE, '') = NVL(AC.HOME_PHONE, '')
        AND
            NVL(T.HOME_ZIPCODE, '') = NVL(AC.HOME_ZIPCODE, '')
        AND
            NVL(T.HOME_PREFECTURE, '') = NVL(AC.HOME_PREFECTURE, '')
        AND
            NVL(T.HOME_CITY, '') = NVL(AC.HOME_CITY, '')
        AND
            NVL(T.HOME_STREET_ADDRESS1, '') = NVL(AC.HOME_STREET_ADDRESS1, '')
        AND
            NVL(T.HOME_STREET_ADDRESS2, '') = NVL(AC.HOME_STREET_ADDRESS2, '')
        AND
            NVL(T.EMAIL, '') = NVL(AC.EMAIL, '')
        AND
            AC.CL_END_DT = '9999-12-31'
    )
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_EVR_ATTENDEE/T_EVR_ATTENDEE_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
