
/*******************************************************************************
  SQL名:
    契約情報連携ビューデータ差分ファイル作成

  処理概要:
       クレンジングのためにIFテーブルのデータをクレンジング用テーブルに追加する
       契約情報連携ビューを元に、差分ファイル(MDQクレンジング前)のファイルを作成する
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by NIKKEI_MEMBER_NO) AS ROWID
    ,NIKKEI_MEMBER_NO
    ,PRODUCT_CD
    ,CONTRACT_FLG
    ,CANCEL_FLG
    ,CHANGE_FLG
    ,CURRENT_MONTH_CANCEL_FLG
    ,BAITAI_KBN_CD
    ,KAMI_BAITAI_KBN_CD
    ,SET_ALLDAY_KBN
    ,W_DROP_FLG
    ,DELIVERY_NOT_ST_FLG
    ,CRM_CANCEL_EXCLUDE_FLG
    ,BAITAI_KBN_CONTRACT_ST_DATE
    ,BAITAI_KBN_CONTRACT_END_DATE
    ,DELIVERY_ST_DATE
    ,DELIVERY_END_DATE
    ,CANCEL_SUBSCRIPTION_DATE
    ,CHANGE_SUBSCRIPTION_DATE
    ,CANCEL_FIX_DATE
    ,DELIVERY_STORE_CD
    ,DELIVERY_ADDRESS_CD
    ,DELIVERY_ZIPCODE
    ,DELIVERY_ADDRESS
    ,DELIVERY_BANTI
    ,DELIVERY_BUILDING
    ,DELIVERY_PREFEC_CD
    ,DELIVERY_CITY_CD
    ,DELIVERY_TOWN_CD
    ,CUST_NO
    ,DELIVERY_CD
    ,BASIC_CONTRACT_NO
    ,CONTRACT_SPECIFIC_NO
    ,SUBSCRIPTION_NO
    ,SUBSCRIPTION_DATE
    ,GENDOKU_KBN
    ,SUBSCRIPTION_CLASS_CD
    ,DELIVERY_STOP_IGNORE
    ,FIRST_GENDOKU_KBN
    ,FIRST_SUBSCRIPTION_DATE
FROM {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO
;

-- 契約情報連携ビューを元に、差分ファイル(MDQクレンジング前)のファイルを作成する
UNLOAD ('
SELECT
    T.ROWID AS ROWID_IF
   ,T.CONTRACT_SPECIFIC_NO AS CONTRACT_SPECIFIC_NO
   ,T.DELIVERY_ZIPCODE AS DELIVERY_ZIPCODE
   ,NVL(T.DELIVERY_ADDRESS,\'\') || NVL(T.DELIVERY_BANTI,\'\') || NVL(T.DELIVERY_BUILDING,\'\')  AS DELIVERY_ADDRESS
FROM
  {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO_TEMP_CLEANSING T 
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_PK_V_CONTRACT_INFO_CL_AC AC
    WHERE
      T.CONTRACT_SPECIFIC_NO = AC.CONTRACT_SPECIFIC_NO
    AND
      NVL(T.DELIVERY_ZIPCODE,\'\') = NVL(AC.DELIVERY_ZIPCODE,\'\')
    AND
      NVL(T.DELIVERY_ADDRESS,\'\') = NVL(AC.DELIVERY_ADDRESS,\'\')
    AND
      NVL(T.DELIVERY_BANTI,\'\') = NVL(AC.DELIVERY_BANTI,\'\')
    AND
      NVL(T.DELIVERY_BUILDING,\'\') = NVL(AC.DELIVERY_BUILDING,\'\')
    AND
      AC.CL_END_DT = \'9999-12-31\'
  )
ORDER BY
  T.DELIVERY_ADDRESS_CD
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_PK_V_CONTRACT_INFO/T_PK_V_CONTRACT_INFO_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
