
/*******************************************************************************
  SQL名:
    CSシステムのインシデント情報を紙課金システムに連携用のUnload処理
  処理概要:
       ヘッダー付きでマスキングしたデータをUnloadする
       抽出対象は更新日時が処理日付の1日前から3日前のデータを対象とする
       JSTに変換後、比較
*******************************************************************************/
UNLOAD ('
SELECT
  col_1
  , col_2
  , col_3
  , col_4
  , col_5
  , col_6
  , col_7
  , col_8
  , col_9
  , col_10
  , col_11
  , col_12
  , col_13
  , col_14
  , col_15
  , col_16
  , col_17
  , col_18
  , col_19
  , col_20
  , col_21
  , col_22
  , col_23
  , col_24
  , col_25
  , col_26
  , col_27
  , col_28
  , col_29
  , col_30
  , col_31
  , col_32
  , col_33
  , col_34
  , col_35
  , col_36
  , col_37
  , col_38
  , col_39
  , col_40
  , col_41
  , col_42
  , col_43
  , col_44
  , col_45
  , col_46
  , col_47
  , col_48
  , col_49
  , col_50
  , col_51
  , col_52
  , col_53
  , col_54
  , col_55
  , col_56
  , col_57
  , col_58
  , col_59
  , col_60
  , col_61
  , col_62
  , col_63
  , col_64
  , col_65
  , col_66
  , col_67
  , col_68
  , col_69
  , col_70
  , col_71
  , col_72
  , col_73
  , col_74
  , col_75
  , col_76
  , col_77
  , col_78
  , col_79
  , col_80
  , col_81
  , col_82
  , col_83
  , col_84
  , col_85
  , col_86
  , col_87
  , col_88
  , col_89
  , col_90
  , col_91
  , col_92
  , col_93
  , col_94
  , col_95
  , col_96
  , col_97
  , col_98
  , col_99
  , col_100
  , col_101
FROM
(
    --ヘッダ
    SELECT 
      ''レコード番号''                        as col_1
      , ''登録日時''                          as col_2
      , ''登録者''                            as col_3
      , ''更新日時''                          as col_4
      , ''更新者''                            as col_5
      , ''受付番号''                          as col_6
      , ''受付日時''                          as col_7
      , ''緊急度''                            as col_8
      , ''受付案件種別''                      as col_9
      , ''受付内容''                          as col_10
      , ''受付場所''                          as col_11
      , ''課金処理パターン''                  as col_12
      , ''個人宛M''                           as col_13
      , ''処理ステータス''                    as col_14
      , ''処理ステ更新''                      as col_15
      , ''処理ステ更新部署''                  as col_16
      , ''処理ステ変更履歴''                  as col_17
      , ''ＮＤＳＣメモ''                      as col_18
      , ''カスタマーデスクメモ''              as col_19
      , ''ＮＤＳＣステ''                      as col_20
      , ''ＮＤＳＣ更新''                      as col_21
      , ''ＮＤＳＣ更新者''                    as col_22
      , ''購読Ｃメモ''                        as col_23
      , ''購読Ｃステ''                        as col_24
      , ''購読Ｃ更新''                        as col_25
      , ''購読Ｃ更新者''                      as col_26
      , ''ＤＳＢＳ情報''                      as col_27
      , ''申込日''                            as col_28
      , ''申込種別''                          as col_29
      , ''開始日''                            as col_30
      , ''中止日''                            as col_31
      , ''課金メモ''                          as col_32
      , ''課金ステ''                          as col_33
      , ''課金更新日時''                      as col_34
      , ''課金更新者''                        as col_35
      , ''顧客番号''                          as col_36
      , ''日経ID内部番号''                    as col_37
      , ''メールアドレス''                    as col_38
      , ''顧客名（自動）''                    as col_39
      , ''フリガナ（手動）''                  as col_40
      , ''ＤＳ申込日''                        as col_41
      , ''現在プラン''                        as col_42
      , ''料金プラン（自動）''                as col_43
      , ''顧客住所（現住所）''                as col_44
      , ''顧客電話番号（現住所）''            as col_45
      , ''販売店コード（現住所）''            as col_46
      , ''変更種別（自動）''                  as col_47
      , ''販売店名（現住所）''                as col_48
      , ''販売店電話番号（現住所）''          as col_49
      , ''販売店ＦＡＸ番号（現住所）''        as col_50
      , ''販売店備考（現住所）''              as col_51
      , ''変更後プラン''                      as col_52
      , ''顧客住所（変更後）''                as col_53
      , ''顧客電話番号（変更後）''            as col_54
      , ''販売店コード（変更後）''            as col_55
      , ''転居調整''                          as col_56
      , ''販売店名（変更後）''                as col_57
      , ''販売店電話番号（変更後）''          as col_58
      , ''販売店ＦＡＸ番号（変更後）''        as col_59
      , ''販売店備考（変更後）''              as col_60
      , ''収納代行金額（自動）''              as col_61
      , ''収納代行一時金（自動）''            as col_62
      , ''補足情報''                          as col_63
      , ''補足情報''                          as col_64
      , ''補足情報''                          as col_65
      , ''一時金入力年月''                    as col_66
      , ''一時金入力金額（電子）''            as col_67
      , ''一時金入力金額（購読料）''          as col_68
      , ''返金方法''                          as col_69
      , ''返金対象年月''                      as col_70
      , ''電子返金合計額''                    as col_71
      , ''購読料返金合計額''                  as col_72
      , ''購読料返金原資''                    as col_73
      , ''返金合計額''                        as col_74
      , ''返金方法''                          as col_75
      , ''返金対象年月''                      as col_76
      , ''電子返金合計額''                    as col_77
      , ''購読料返金合計額''                  as col_78
      , ''購読料返金原資''                    as col_79
      , ''返金合計額''                        as col_80
      , ''返金方法''                          as col_81
      , ''返金対象年月''                      as col_82
      , ''電子返金合計額''                    as col_83
      , ''購読料返金合計額''                  as col_84
      , ''購読料返金原資''                    as col_85
      , ''返金合計額''                        as col_86
      , ''返金方法''                          as col_87
      , ''電子返金合計額''                    as col_88
      , ''購読料返金合計額''                  as col_89
      , ''購読料返金原資''                    as col_90
      , ''返金合計額''                        as col_91
      , ''振込銀行''                          as col_92
      , ''振込銀行支店名''                    as col_93
      , ''振込口座種目''                      as col_94
      , ''振込口座番号''                      as col_95
      , ''振込口座名''                        as col_96
      , ''臨時調整対象''                      as col_97
      , ''臨時調整金額''                      as col_98
      , ''電子売上修正対象''                  as col_99
      , ''電子売上修正金額''                  as col_100
      , ''解約・プラン変更理由''              as col_101
      , 1 as sort_oder
  UNION ALL
    --データ
    SELECT 
      ref_no                                  as col_1
      , to_char(CONVERT_TIMEZONE(''Asia/Tokyo'', created_utc), ''YYYY/MM/DD HH24:MI'') as col_2
      , ''''                                  as col_3
      , to_char(CONVERT_TIMEZONE(''Asia/Tokyo'', updated_utc), ''YYYY/MM/DD HH24:MI'') as col_4
      , ''''                                  as col_5
      , ''''                                  as col_6
      , ''''                                  as col_7
      , ''''                                  as col_8
      , ''''                                  as col_9
      , subject                               as col_10
      , ''''                                  as col_11
      , ''''                                  as col_12
      , ''''                                  as col_13
      , status_name                           as col_14
      , ''''                                  as col_15
      , ''''                                  as col_16
      , ''''                                  as col_17
      , ''''                                  as col_18
      , ''''                                  as col_19
      , ''''                                  as col_20
      , ''''                                  as col_21
      , ''''                                  as col_22
      , ''''                                  as col_23
      , ''''                                  as col_24
      , ''''                                  as col_25
      , ''''                                  as col_26
      , ''''                                  as col_27
      , ''''                                  as col_28
      , ''''                                  as col_29
      , ''''                                  as col_30
      , ''''                                  as col_31
      , ''''                                  as col_32
      , ''''                                  as col_33
      , ''''                                  as col_34
      , ''''                                  as col_35
      , customer_id_paper_charges             as col_36
      , CAST(nikkei_member_no as VARCHAR)     as col_37
      , email                                 as col_38
      , name                                  as col_39
      , furigana                              as col_40
      , ''''                                  as col_41
      , ''''                                  as col_42
      , ''''                                  as col_43
      , address                               as col_44
      , phone                                 as col_45
      , ''''                                  as col_46
      , ''''                                  as col_47
      , ''''                                  as col_48
      , ''''                                  as col_49
      , ''''                                  as col_50
      , ''''                                  as col_51
      , ''''                                  as col_52
      , ''''                                  as col_53
      , ''''                                  as col_54
      , ''''                                  as col_55
      , ''''                                  as col_56
      , ''''                                  as col_57
      , ''''                                  as col_58
      , ''''                                  as col_59
      , ''''                                  as col_60
      , ''''                                  as col_61
      , ''''                                  as col_62
      , ''''                                  as col_63
      , ''''                                  as col_64
      , ''''                                  as col_65
      , ''''                                  as col_66
      , ''''                                  as col_67
      , ''''                                  as col_68
      , ''''                                  as col_69
      , ''''                                  as col_70
      , ''''                                  as col_71
      , ''''                                  as col_72
      , ''''                                  as col_73
      , ''''                                  as col_74
      , ''''                                  as col_75
      , ''''                                  as col_76
      , ''''                                  as col_77
      , ''''                                  as col_78
      , ''''                                  as col_79
      , ''''                                  as col_80
      , ''''                                  as col_81
      , ''''                                  as col_82
      , ''''                                  as col_83
      , ''''                                  as col_84
      , ''''                                  as col_85
      , ''''                                  as col_86
      , ''''                                  as col_87
      , ''''                                  as col_88
      , ''''                                  as col_89
      , ''''                                  as col_90
      , ''''                                  as col_91
      , ''''                                  as col_92
      , ''''                                  as col_93
      , ''''                                  as col_94
      , ''''                                  as col_95
      , ''''                                  as col_96
      , ''''                                  as col_97
      , ''''                                  as col_98
      , ''''                                  as col_99
      , ''''                                  as col_100
      , ''''                                  as col_101
      , 2                                     as sort_oder
    FROM {{ var.value.redshift_ims_schema_name }}.T_CS_INCIDENT
    WHERE (REF_NO, UPDATED_UTC) IN (
      SELECT REF_NO, MAX(UPDATED_UTC) 
      FROM {{ var.value.redshift_ims_schema_name }}.T_CS_INCIDENT
      WHERE 1=1 AND TRUNC(CONVERT_TIMEZONE(''Asia/Tokyo'', UPDATED_UTC)) 
        BETWEEN TRUNC(DATEADD(DAY,-3, CAST(''{{ convUTC2JST(next_execution_date, "%Y-%m-%d %H:%M:%S") }}'' as TIMESTAMP))) 
            AND TRUNC(DATEADD(DAY,-1, CAST(''{{ convUTC2JST(next_execution_date, "%Y-%m-%d %H:%M:%S") }}'' as TIMESTAMP))) 
      GROUP BY REF_NO
    )
  )
  ORDER BY
    sort_oder
    , col_1
')
to 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d")) }}'
iam_role '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS ','
ADDQUOTES 
NULL AS '' 
ESCAPE
ALLOWOVERWRITE
PARALLEL OFF 
MAXFILESIZE AS 5GB
;
