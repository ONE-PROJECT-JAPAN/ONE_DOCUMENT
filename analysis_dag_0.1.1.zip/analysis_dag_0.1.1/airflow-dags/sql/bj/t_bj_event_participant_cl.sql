/*******************************************************************************
  SQL名:
    イベント参加者データクレンジング更新

  処理概要:
       イベント参加者クレンジングのクレンジング対象項目と
       前回のクレンジング実施時のクレンジング項目の内容に
       差異がある場合、再クレンジングを行う。
*******************************************************************************/
-- クレンジング後ファイルより、一時表テーブル作成
CREATE TEMP TABLE T_BJ_EVENT_PARTICIPANT_CL_EXT
(
     ROWID_IF                         BIGINT
    ,PARTICIPANT_ID                   BIGINT
    ,EMAIL                            VARCHAR(1020)
    ,LAST_NAME                        VARCHAR(1020)
    ,FIRST_NAME                       VARCHAR(1020)
    ,NAME                             VARCHAR(2040)
    ,ZIPCODE                          VARCHAR(40)
    ,ADDR1                            VARCHAR(2000)
    ,ADDR2                            VARCHAR(1020)
    ,ADDRESS                          VARCHAR(3020)
    ,PHONE                            VARCHAR(180)
    ,ADDR_CL_ADDR                     VARCHAR(5296)
    ,ADDR_CL_PREFEC                   VARCHAR(16)
    ,ADDR_CL_CITY                     VARCHAR(80)
    ,ADDR_CL_TSUSHO                   VARCHAR(400)
    ,ADDR_CL_CHOME                    VARCHAR(2000)
    ,ADDR_CL_ADDR1                    VARCHAR(5296)
    ,ADDR_CL_ADDR2                    VARCHAR(5296)
    ,ADDR_CL_ADDR3                    VARCHAR(5296)
    ,ADDR_CL_ADDR_CD                  VARCHAR(80)
    ,ZIPCODE_CL                       VARCHAR(44)
    ,PHONE_CL                         VARCHAR(1020)
    ,NAME_CL_LAST_NM                  VARCHAR(2040)
    ,NAME_CL_FIRST_NM                 VARCHAR(2040)
    ,NAME_CL_NM                       VARCHAR(2040)
    ,NAME_CL_CORP_NM                  VARCHAR(2040)
    ,NAME_CL_DEPT_NM                  VARCHAR(400)
);

--一時表テーブル作成にクレンジング後ファイル挿入
copy T_BJ_EVENT_PARTICIPANT_CL_EXT
from 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_BJ_EVENT_PARTIC_FOR_LIST_CL_CL/T_BJ_EVENT_PARTIC_FOR_LIST_CL_'
iam_role '{{ var.value.redshift_default_role_arn }}'
FORMAT AS CSV
DELIMITER ','
QUOTE '"'
;

--差分更新
UPDATE {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL T
SET
     CLKEY_EMAIL = NULLIF(EXT.EMAIL, '')
    ,EMAIL_CL = LOWER(NULLIF(EXT.EMAIL, ''))
    ,CLKEY_LAST_NAME = NULLIF(EXT.LAST_NAME, '')
    ,CLKEY_FIRST_NAME = NULLIF(EXT.FIRST_NAME, '')
    ,NAME_CL_LAST_NM = NULLIF(EXT.NAME_CL_LAST_NM, '')
    ,NAME_CL_FIRST_NM = NULLIF(EXT.NAME_CL_FIRST_NM, '')
    ,NAME_CL_NM = NULLIF(EXT.NAME_CL_NM, '')
    ,CLKEY_ZIPCODE = NULLIF(EXT.ZIPCODE, '')
    ,ZIPCODE_CL = NULLIF(EXT.ZIPCODE_CL, '')
    ,CLKEY_ADDR1 = NULLIF(EXT.ADDR1, '')
    ,CLKEY_ADDR2 = NULLIF(EXT.ADDR2, '')
    ,ADDR_CL_ADDR = NULLIF(EXT.ADDR_CL_ADDR, '')
    ,ADDR_CL_PREFEC = NULLIF(EXT.ADDR_CL_PREFEC, '')
    ,ADDR_CL_CITY = NULLIF(EXT.ADDR_CL_CITY, '')
    ,ADDR_CL_TSUSHO = NULLIF(EXT.ADDR_CL_TSUSHO, '')
    ,ADDR_CL_CHOME = NULLIF(EXT.ADDR_CL_CHOME, '')
    ,ADDR_CL_ADDR1 = NULLIF(EXT.ADDR_CL_ADDR1, '')
    ,ADDR_CL_ADDR2 = NULLIF(EXT.ADDR_CL_ADDR2, '')
    ,ADDR_CL_ADDR3 = NULLIF(EXT.ADDR_CL_ADDR3, '')
    ,ADDR_CL_ADDR_CD = NULLIF(EXT.ADDR_CL_ADDR_CD, '')
    ,CLKEY_PHONE = NULLIF(EXT.PHONE, '')
    ,PHONE_CL = NULLIF(EXT.PHONE_CL, '')
    ,UPD_PGM_ID = '{{ dag.dag_id }}'
    ,UPD_DT_TM = CONVERT_TIMEZONE ( 'Asia/Tokyo', GETDATE())
FROM 
    T_BJ_EVENT_PARTICIPANT_CL_EXT EXT
WHERE
    T.ROWID = EXT.ROWID_IF
;
