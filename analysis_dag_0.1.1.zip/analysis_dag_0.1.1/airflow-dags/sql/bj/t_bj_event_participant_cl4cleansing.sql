
/*******************************************************************************
  SQL名:
    イベント参加者クレンジングデータ差分ファイル作成

  処理概要:
       イベント参加者クレンジングを元に、差分ファイル(MDQクレンジング前)のファイルを作成する。
*******************************************************************************/
UNLOAD ('
SELECT
   T.ROWID                                     AS ROWID_IF
  ,CAST(T.PARTICIPANT_ID AS VARCHAR)           AS PARTICIPANT_ID      --参加者ID
  ,NVL(T.EMAIL, \'\')                          AS EMAIL               --メールアドレス
  ,NVL(T.LAST_NAME, \'\')                      AS LAST_NAME           --姓
  ,NVL(T.FIRST_NAME, \'\')                     AS FIRST_NAME          --名
  ,NVL(T.LAST_NAME, \'\')        || 
    NVL(T.FIRST_NAME, \'\')                    AS NAME                --姓名
  ,CASE WHEN T.WORK_ADDR1 IS NULL THEN
    NVL(T.HOME_ZIPCODE, \'\')   
   ELSE
    NVL(T.WORK_ZIPCODE, \'\')    END           AS ZIPCODE             --郵便番号
  ,CASE WHEN T.WORK_ADDR1 IS NULL THEN
    NVL(T.HOME_ADDR1, \'\')      
   ELSE
    NVL(T.WORK_ADDR1, \'\')      END           AS ADDR1               --住所１
  ,CASE WHEN T.WORK_ADDR1 IS NULL THEN
    NVL(T.HOME_ADDR2, \'\')      
   ELSE
    NVL(T.WORK_ADDR2, \'\')      END           AS ADDR2               --住所２
  ,CASE WHEN T.WORK_ADDR1 IS NULL THEN
    NVL(T.HOME_ADDR1, \'\')      || 
    NVL(T.HOME_ADDR2, \'\')      
   ELSE
    NVL(T.WORK_ADDR1, \'\')      || 
    NVL(T.WORK_ADDR2, \'\')      END           AS ADDRESS             --住所
  ,CASE WHEN T.WORK_ADDR1 IS NULL THEN
    NVL(T.HOME_PHONE, \'\')     
   ELSE
    NVL(T.WORK_PHONE, \'\')      END           AS PHONE               --電話番号
FROM
  {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL T 
WHERE
  NOT EXISTS(
    SELECT \'X\'
    FROM
      {{ var.value.redshift_ims_schema_name }}.T_BJ_EVENT_PARTICIPANT_CL CL
    WHERE
      T.PARTICIPANT_ID = CL.PARTICIPANT_ID
    AND
      NVL(T.EMAIL, \'\') = NVL(CL.CLKEY_EMAIL, \'\')
    AND
      NVL(T.LAST_NAME, \'\') = NVL(CL.CLKEY_LAST_NAME, \'\')
    AND
      NVL(T.FIRST_NAME, \'\') = NVL(CL.CLKEY_FIRST_NAME, \'\')
    AND
      (CASE WHEN T.WORK_ADDR1 IS NULL THEN NVL(T.HOME_ZIPCODE, \'\') ELSE NVL(T.WORK_ZIPCODE, \'\') END) = NVL(CL.CLKEY_ZIPCODE, \'\')
    AND
      (CASE WHEN T.WORK_ADDR1 IS NULL THEN NVL(T.HOME_ADDR1, \'\') ELSE NVL(T.WORK_ADDR1, \'\') END) = NVL(CL.CLKEY_ADDR1, \'\')
    AND
      (CASE WHEN T.WORK_ADDR1 IS NULL THEN NVL(T.HOME_ADDR2, \'\') ELSE NVL(T.WORK_ADDR2, \'\') END) = NVL(CL.CLKEY_ADDR2, \'\')
    AND
      (CASE WHEN T.WORK_ADDR1 IS NULL THEN NVL(T.HOME_PHONE, \'\') ELSE NVL(T.WORK_PHONE, \'\') END) = NVL(CL.CLKEY_PHONE, \'\')
  )
ORDER BY
  ZIPCODE
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_BJ_EVENT_PARTIC_FOR_LIST_CL/T_BJ_EVENT_PARTIC_FOR_LIST_CL_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
