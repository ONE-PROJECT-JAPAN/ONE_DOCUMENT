
/*******************************************************************************
  SQL名:
     応募者管理情報データ差分ファイル作成

  処理概要:
       クレンジングのためにIFテーブルのデータをクレンジング用テーブルに追加する
       応募者管理情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by APPLICANT_MNG_NO) AS ROWID
    ,APPLICANT_MNG_NO
    ,NIKKEI_MEMBER_NO
    ,EMAIL
    ,NAME
    ,NAME_YOMI
    ,OVERSEAS_FLG
    ,ZIPCODE
    ,ADDRESS_CD
    ,ADDRESS_CD_NAME
    ,BANTI
    ,BUILDING
    ,TELNO
    ,STORE_CD
    ,SECONDARY_USE_SIGN
    ,CREATE_UPDATE_DT_TM
    ,UPDATE_USER
FROM {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO
;

-- 応募者管理情報を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
UNLOAD ($$
SELECT
   T.ROWID                                             AS ROWID_IF
  ,T.APPLICANT_MNG_NO                                  AS APPLICANT_MNG_NO
  ,NVL(T.ZIPCODE,'')                                   AS ZIPCODE
  ,NVL(M.PREFECTURE_NM,'')               ||
      NVL(M.SHIKUTYOUSON_NM,'')          ||
      NVL(M.TSUSHO_NM,'')                ||
      NVL(M.CHOME_NM,'')                 ||
      SUBSTRING(NVL(T.BANTI,''),1,500)   ||
      SUBSTRING(NVL(T.BUILDING,''),1,200)              AS ADDRESS
  ,SUBSTRING(NVL(T.NAME,''),1,242)                     AS NAME
  ,SUBSTRING(NVL(T.TELNO,''),1,20)                     AS TELNO
FROM
    {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_TEMP_CLEANSING T
LEFT JOIN {{ var.value.redshift_ims_schema_name }}.M_HK_ADDRESS M
ON
    T.ADDRESS_CD = M.ADDRESS_CD
WHERE
    NOT EXISTS(
        SELECT 'X'
        FROM
            {{ var.value.redshift_ims_schema_name }}.T_DKP_APPLICANT_MNG_INFO_CL_AC AC
        WHERE
            T.APPLICANT_MNG_NO = AC.APPLICANT_MNG_NO
        AND
            NVL(T.ZIPCODE, '') = NVL(AC.ZIPCODE, '')
        AND
            NVL(T.ADDRESS_CD, '') = NVL(AC.ADDRESS_CD, '')
        AND
            NVL(M.PREFECTURE_NM, '') = NVL(AC.PREFECTURE_NM, '')
        AND
            NVL(M.SHIKUTYOUSON_NM, '') = NVL(AC.SHIKUTYOUSON_NM, '')
        AND
            NVL(M.TSUSHO_NM, '') = NVL(AC.TSUSHO_NM, '')
        AND
            NVL(M.CHOME_NM, '') = NVL(AC.CHOME_NM, '')
        AND
            SUBSTRING(NVL(T.BANTI, ''),1,500) = NVL(AC.BANTI, '')
        AND
            SUBSTRING(NVL(T.BUILDING, ''),1,200) = NVL(AC.BUILDING, '')
        AND
            SUBSTRING(NVL(T.NAME, ''),1,242) = NVL(AC.NAME, '')
        AND
            SUBSTRING(NVL(T.TELNO, ''),1,20) = NVL(AC.TELNO, '')
        AND
            SUBSTRING(NVL(T.EMAIL, ''),1,256) = NVL(AC.EMAIL, '')
        AND
            AC.CL_END_DT = '9999-12-31'
    )
ORDER BY
    T.ADDRESS_CD
$$)
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_DKP_APPLICANT_MNG_INFO/T_DKP_APPLICANT_MNG_INFO_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
