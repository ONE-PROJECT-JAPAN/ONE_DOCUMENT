/*******************************************************************************
  SQL名:
        ＴＲＮスクラップ記事データ蓄積(有料会員)
  処理概要:
        ＴＲＮスクラップ記事データ(有料会員)の蓄積を行う
       蓄積キー:
         NIKKEI_MEMBER_NO, SCRAP_KIND_ID, NEWS_ITEM_ID
       参照テーブル:
         T_DSY_T_DS_SCRAP_KIJI
         T_DSY_T_DS_SCRAP_KIJI_ACCUM
*******************************************************************************/
UPDATE {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI_ACCUM A SET
DELETE_FLG = '0'
, UPD_BATCH_ID = '{{ dag.dag_id }}'
, UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE EXISTS (
    SELECT T.NIKKEI_MEMBER_NO
    , T.SCRAP_KIND_ID
    , T.NEWS_ITEM_ID
    FROM {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI T
    WHERE A.NIKKEI_MEMBER_NO = T.NIKKEI_MEMBER_NO
    AND A.SCRAP_KIND_ID = T.SCRAP_KIND_ID
    AND A.NEWS_ITEM_ID = T.NEWS_ITEM_ID
)
;

UPDATE {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI_ACCUM A SET
DELETE_FLG = '1'
, UPD_BATCH_ID = '{{ dag.dag_id }}'
, UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE NOT EXISTS (
    SELECT T.NIKKEI_MEMBER_NO
    , T.SCRAP_KIND_ID
    , T.NEWS_ITEM_ID
    FROM {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI T
    WHERE A.NIKKEI_MEMBER_NO = T.NIKKEI_MEMBER_NO
    AND A.SCRAP_KIND_ID = T.SCRAP_KIND_ID
    AND A.NEWS_ITEM_ID = T.NEWS_ITEM_ID
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI_ACCUM (
    INSDATE
    , UPDATEDATE
    , NIKKEI_MEMBER_NO
    , SCRAP_KIND_ID
    , NEWS_ITEM_ID
    , CUST_NO
    , DELETE_FLG
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
)
    SELECT
    T.INSDATE
    , T.UPDATEDATE
    , T.NIKKEI_MEMBER_NO
    , T.SCRAP_KIND_ID
    , T.NEWS_ITEM_ID
    , T.CUST_NO
    , '0'
    , '{{ dag.dag_id }}'
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    , '{{ dag.dag_id }}'
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    FROM {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI T
    WHERE NOT EXISTS (
        SELECT A.NIKKEI_MEMBER_NO
        , A.SCRAP_KIND_ID
        , A.NEWS_ITEM_ID
        FROM {{ var.value.redshift_ims_schema_name }}.T_DSY_T_DS_SCRAP_KIJI_ACCUM A
        WHERE T.NIKKEI_MEMBER_NO = A.NIKKEI_MEMBER_NO
        AND T.SCRAP_KIND_ID = A.SCRAP_KIND_ID
        AND T.NEWS_ITEM_ID = A.NEWS_ITEM_ID
    )
;