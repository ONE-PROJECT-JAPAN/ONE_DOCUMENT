/*******************************************************************************
  SQL名:
        ＴＲＮフォローデータ蓄積
  処理概要:
        ＴＲＮフォローデータの蓄積を行う
       蓄積キー:
         NIKKEI_MEMBER_NO
       参照テーブル:
        T_DSU_T_DS_FOLLOW_RENSAI
         T_DSU_T_DS_FOLLOW_RENSAI_ACCUM
*******************************************************************************/
UPDATE {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI_ACCUM A SET
DELETE_FLG = '0'
, UPD_BATCH_ID = '{{ dag.dag_id }}'
, UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE EXISTS (
SELECT T.NIKKEI_MEMBER_NO
,T.UID
FROM {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI T
WHERE A.NIKKEI_MEMBER_NO=T.NIKKEI_MEMBER_NO
AND A.UID=T.UID
)
;

UPDATE {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI_ACCUM A SET
DELETE_FLG = '1'
, UPD_BATCH_ID = '{{ dag.dag_id }}'
, UPD_DT_TM = CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
WHERE NOT EXISTS(
SELECT T.NIKKEI_MEMBER_NO
,T.UID
FROM {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI T
WHERE A.NIKKEI_MEMBER_NO=T.NIKKEI_MEMBER_NO
AND A.UID=T.UID
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI_ACCUM
(
     INSDATE
,    UPDATEDATE
,    NIKKEI_MEMBER_NO
,    UID
,    FOLLOW_DATE
,    DSP_ORD
,    DELETE_FLG
,    INS_BATCH_ID
,    INS_DT_TM
,    UPD_BATCH_ID
,    UPD_DT_TM
)
SELECT
     T.INSDATE
,    T.UPDATEDATE
,    T.NIKKEI_MEMBER_NO
,    T.UID
,    T.FOLLOW_DATE
,    T.DSP_ORD
,    '0'
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI T
WHERE NOT EXISTS(
SELECT A.NIKKEI_MEMBER_NO
,A.UID
FROM {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_FOLLOW_RENSAI_ACCUM A
WHERE T.NIKKEI_MEMBER_NO=A.NIKKEI_MEMBER_NO
AND T.UID=A.UID
)
;
