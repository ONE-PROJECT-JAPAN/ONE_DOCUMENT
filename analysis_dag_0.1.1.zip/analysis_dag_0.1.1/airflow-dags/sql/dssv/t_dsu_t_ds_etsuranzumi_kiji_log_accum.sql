/*******************************************************************************
  SQL名:
        ＴＲＮ鍵付き記事閲覧履歴データ蓄積
  処理概要:
        ＴＲＮ鍵付き記事閲覧履歴データの蓄積を行う
       蓄積キー:
         YEAR_MONTH, NIKKEI_MEMBER_NO, NEWS_ITEM_ID
       参照テーブル:
         T_DSU_T_DS_ETSURANZUMI_KIJI_LOG
*******************************************************************************/
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM
WHERE
    YEAR_MONTH = (SELECT TO_CHAR({{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE(), 'YYYYMM'))
AND
(
    EXISTS
    (
        SELECT 
             NIKKEI_MEMBER_NO
            ,NEWS_ITEM_ID
        FROM
            {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_ETSURANZUMI_KIJI_LOG LOG
        WHERE
            T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM.NIKKEI_MEMBER_NO = LOG.NIKKEI_MEMBER_NO
        AND
            T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM.NEWS_ITEM_ID = LOG.NEWS_ITEM_ID
    )
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM
(
     YEAR_MONTH
    ,INSDATE
    ,UPDATEDATE
    ,NIKKEI_MEMBER_NO
    ,NEWS_ITEM_ID
    ,INS_BATCH_ID
    ,INS_DT_TM
    ,UPD_BATCH_ID
    ,UPD_DT_TM
)
(
    SELECT
         (SELECT TO_CHAR({{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE(), 'YYYYMM'))
        ,INSDATE
        ,UPDATEDATE
        ,NIKKEI_MEMBER_NO
        ,NEWS_ITEM_ID
        ,'{{ dag.dag_id }}'
        ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
        ,'{{ dag.dag_id }}'
        ,CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
    FROM
        {{ var.value.redshift_ims_schema_name }}.T_DSU_T_DS_ETSURANZUMI_KIJI_LOG
)
;