
/*******************************************************************************
  SQL名:
    応募者基本情報（DKP2）データ差分ファイル作成

  処理概要:
       クレンジングのためにIFテーブルのデータをクレンジング用テーブルに追加する
       応募者基本情報（DKP2）を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
*******************************************************************************/
-- テーブル削除
DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO_TEMP_CLEANSING
;

-- テーブル作成及びデータ追加
CREATE TABLE {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO_TEMP_CLEANSING AS 
SELECT 
    ROW_NUMBER () over(order by FORM_ID) AS ROWID
    ,FORM_ID
    ,APPLICANT_ID
    ,NIKKEI_MEMBER_NO
    ,APPLICANT_MNG_NO
    ,EMAIL
    ,NAME
    ,NAME_YOMI
    ,OVERSEAS_FLG
    ,ZIPCODE
    ,ADDRESS_CD
    ,ADDRESS_CD_NAME
    ,BANTI
    ,BUILDING
    ,TELNO
    ,FAXNO
    ,DAYTIME_CONTACT
    ,SEX
    ,BIRTHDAY
    ,OCCUPATION_NM
    ,STORE_CD
    ,SECONDARY_READING
    ,YOBI_1
    ,YOBI_2
    ,REMARK
    ,MAILPROPRIETY_1
    ,MAILPROPRIETY_2
    ,NIKKEI_ENTRY_DATE
    ,NIKKEI_NEW_CREATE_FLG
    ,RECEPTION_DT_TM
    ,ACQUISITION_DT_TM
    ,WIN_LOSE_FLG
    ,WIN_LOSE_MEMO
    ,WIN_LOSE_DATE
    ,PRIZE_NAME
    ,CREATE_UPDATE_DT_TM
    ,UPDATE_USER
FROM {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO
;

-- 応募者基本情報（DKP2）を元に、差分ファイル(MDQクレンジング前)のファイルを作成する
UNLOAD ('
SELECT
   T.ROWID                                        AS ROWID_IF
  ,T.FORM_ID                                      AS FORM_ID
  ,T.APPLICANT_ID                                 AS APPLICANT_ID
  ,SUBSTRING(NVL(T.DAYTIME_CONTACT, \'\'),1,20)   AS DAYTIME_CONTACT
FROM
    {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO_TEMP_CLEANSING T
WHERE
    NOT EXISTS(
        SELECT \'X\'
        FROM
            {{ var.value.redshift_ims_schema_name }}.T_DKPW_APPLICANT_BASIC_INFO_CL_AC AC
        WHERE
            T.FORM_ID = AC.FORM_ID
        AND
            T.APPLICANT_ID = AC.APPLICANT_ID
        AND
            SUBSTRING(NVL(T.DAYTIME_CONTACT, \'\'),1,20) = NVL(AC.DAYTIME_CONTACT, \'\')
        AND
            SUBSTRING(NVL(T.SECONDARY_READING, \'\'),1,255) = NVL(AC.SECONDARY_READING, \'\')
        AND
            AC.CL_END_DT = \'9999-12-31\'
    )
ORDER BY
    T.ADDRESS_CD
')
to 's3://{{ var.value.datastore_s3_bucket_name }}/app/cleansing/T_DKPW_APPLICANT_BASIC_INFO/T_DKPW_APPLICANT_BASIC_INFO_' 
iam_role '{{ var.value.redshift_default_role_arn }}'
CSV DELIMITER AS ','
NULL ''
ALLOWOVERWRITE
PARALLEL OFF
;
