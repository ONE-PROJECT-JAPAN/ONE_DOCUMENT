/*******************************************************************************
  SQL名:
        メンバ値変換データ蓄積
  処理概要:
        メンバ値変換データの蓄積を行う
       蓄積キー:
         MEMBER_VALUE
       参照テーブル:
         M_RT_M_MAPPING_ACCUM
          M_AD_NIKKEI_ID
*******************************************************************************/
DELETE FROM {{ var.value.redshift_ims_schema_name }}."M_RT_M_MAPPING_ACCUM_ACCUM"
WHERE
(
     MEMBER_VALUE
)
IN
(
SELECT
     MEMBER_VALUE
FROM
     {{ var.value.redshift_ims_schema_name }}.M_RT_M_MAPPING_ACCUM
)
;

INSERT INTO {{ var.value.redshift_ims_schema_name }}."M_RT_M_MAPPING_ACCUM_ACCUM"
(
     LAST_UPDATE_DATE
,    MEMBER_VALUE
,    SERIAL_ID
,    USER_NO
,    ENTRY_DATE
,    INS_BATCH_ID
,    INS_DT_TM
,    UPD_BATCH_ID
,    UPD_DT_TM
)
SELECT
     M1.LAST_UPDATE_DATE
,    M1.MEMBER_VALUE
,    M1.SERIAL_ID
,    M_AD."IS_会員番号"
,    M_AD."IS_入会日"
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
,    '{{ dag.dag_id }}'
,    CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
FROM
     {{ var.value.redshift_ims_schema_name }}.M_RT_M_MAPPING_ACCUM M1
LEFT JOIN
    {{ var.value.redshift_ims_schema_name }}.M_AD_NIKKEI_ID M_AD
ON M1.SERIAL_ID =M_AD."IS_シリアルID"
;