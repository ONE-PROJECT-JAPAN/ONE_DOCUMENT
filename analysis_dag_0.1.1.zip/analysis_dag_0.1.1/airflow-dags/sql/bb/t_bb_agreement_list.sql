
/*******************************************************************************
  SQL名:
    T_BB_AGREEMENT_LISTのデータ変換

  処理概要:
       T_BB_AGREEMENT_LISTデータ削除後、
       W_BB_AGREEMENT_LISTテーブルからデータ変換後T_BB_AGREEMENT_LISTへ追加する
*******************************************************************************/
DELETE FROM {{ var.value.redshift_ims_schema_name }}.T_BB_AGREEMENT_LIST
;
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_BB_AGREEMENT_LIST 
    (NIKKEI_MEMBER_NO
    , RP_ID
    , SERVICE_ID
    , TRIAL_FLAG
    , USESTART_DATE
    , REPORT_CATEGORY
    , BBC_FLAG
    , C_ACC_ACCOUNTCODE__C
    , C_CON_FODEPTS_1__C
    , C_CON_FODEPTS_2__C
    , C_CON_FODEPTS_3__C
    , C_CON_FODEPTS_4__C
    , C_CON_FODEPTS_5__C
    , C_CON_FODEPTSCODE_1__C
    , C_CON_FODEPTSCODE_2__C
    , C_CON_FODEPTSCODE_3__C
    , C_CON_FODEPTSCODE_4__C
    , C_CON_FODEPTSCODE_5__C
    , C_CON_FOCOUNTRY__C
    , C_CON_FOSTATE__C
    , C_CON_FOCITY__C
    , C_CON_FOBASE__C)
         (SELECT
            CAST(NULLIF(wk.NIKKEI_MEMBER_NO, 0) AS BIGINT) 
            , wk.RP_ID
            , wk.SERVICE_ID
            , wk.TRIAL_FLAG
            , CAST(wk.USESTART_DATE AS DATE)
            , wk.REPORT_CATEGORY
            , wk.BBC_FLAG 
            , wk.C_ACC_ACCOUNTCODE__C
            , wk.C_CON_FODEPTS_1__C
            , wk.C_CON_FODEPTS_2__C
            , wk.C_CON_FODEPTS_3__C
            , wk.C_CON_FODEPTS_4__C
            , wk.C_CON_FODEPTS_5__C
            , wk.C_CON_FODEPTSCODE_1__C
            , wk.C_CON_FODEPTSCODE_2__C
            , wk.C_CON_FODEPTSCODE_3__C
            , wk.C_CON_FODEPTSCODE_4__C
            , wk.C_CON_FODEPTSCODE_5__C
            , wk.C_CON_FOCOUNTRY__C
            , wk.C_CON_FOSTATE__C
            , wk.C_CON_FOCITY__C
            , wk.C_CON_FOBASE__C
        FROM {{ var.value.redshift_ims_schema_name }}.W_BB_AGREEMENT_LIST wk
    )
;
