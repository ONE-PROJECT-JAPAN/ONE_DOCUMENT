--
-- お試し施策適用VIEW（シリアルID版）連携データアンロード
--
UNLOAD ($$
SELECT
     A.TRIAL_CAMPAIGN_MANAGEMENT_NO
   , A.TRIAL_CAMPAIGN_NAME_INTERNAL
   , A.TRIAL_CAMPAIGN_NAME_EXTERNAL
   , A.SERIAL_ID
   , A.CONTRACT_NO
   , A.TRIAL_ACTIVATE_DETAIL_NO
   , A.RP_ID
   , A.SERVICE_ID
   , A.PLAN_ID
   , A.TRIAL_NO
   , A.ACTIVATE_DATETIME
   , A.TRIAL_END_ESTIMATE_DATETIME
   , A.TRIAL_END_CHARGE_DATETIME
   , A.TRIAL_END_PLAN_ID
   , A.TRIAL_END_REASON
   , A.REMAINING_DAYS
   , A.TRIAL_END_DATETIME
   , A.CURRENT_PLAN_ID
FROM {{var.value.redshift_ims_schema_name}}.T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID AS A
WHERE A.SERIAL_ID IS NOT NULL
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d"), convUTC2JST(next_execution_date, "%Y%m%d%H%M%S")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS '\t'
NULL AS ''
GZIP
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;

-- 後始末：お試し施策適用VIEW（シリアルID版）ワーク削除

DROP TABLE IF EXISTS {{ var.value.redshift_ims_schema_name }}.W_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID;
