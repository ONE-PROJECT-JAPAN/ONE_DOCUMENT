UNLOAD ($$
SELECT
    '''' || REPLACE(REPLACE(REPLACE(A.TRIAL_CAMPAIGN_MANAGEMENT_NO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))          || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_CAMPAIGN_NAME_INTERNAL, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_CAMPAIGN_NAME_EXTERNAL, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '') || ''''
  , '''' || A.NIKKEI_ID_INTERNAL_MEMBER_NO::VARCHAR                                                                                       || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.CONTRACT_NO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                  || ''''
  , '''' || NVL(A.TRIAL_ACTIVATE_DETAIL_NO::VARCHAR, '')                                                                                  || ''''
  , '''' || REPLACE(REPLACE(REPLACE(A.RP_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                                 || ''''
  , '''' || REPLACE(REPLACE(REPLACE(A.SERVICE_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                            || ''''
  , '''' || REPLACE(REPLACE(REPLACE(A.PLAN_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10))                               || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_NO, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')                     || ''''
  , '''' || A.ACTIVATE_DATETIME                                                                                                           || ''''
  , '''' || A.TRIAL_END_ESTIMATE_DATETIME                                                                                                 || ''''
  , '''' || A.TRIAL_END_CHARGE_DATETIME                                                                                                   || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_END_PLAN_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')            || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.TRIAL_END_REASON, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')             || ''''
  , '''' || NVL(A.REMAINING_DAYS::VARCHAR, '')                                                                                            || ''''
  , '''' || A.TRIAL_END_DATETIME                                                                                                          || ''''
  , '''' || NVL(REPLACE(REPLACE(REPLACE(A.CURRENT_PLAN_ID, '''', ''''''), CHR(13)||CHR(10), CHR(10)), CHR(13), CHR(10)), '')              || ''''
FROM {{var.value.redshift_ims_schema_name}}.T_KK_V_TRIAL_CAMPAIGN_APPLY AS A
$$)
TO 's3://{{ params.s3_path.format(var.value.datastore_s3_bucket_name, convUTC2JST(next_execution_date, "%Y%m%d"), convUTC2JST(next_execution_date, "%Y%m%d%H%M%S")) }}'
IAM_ROLE '{{ var.value.redshift_default_role_arn }}'
DELIMITER AS '\t'
NULL AS ''
GZIP
ESCAPE
PARALLEL OFF
MAXFILESIZE AS 3GB
ALLOWOVERWRITE
;
