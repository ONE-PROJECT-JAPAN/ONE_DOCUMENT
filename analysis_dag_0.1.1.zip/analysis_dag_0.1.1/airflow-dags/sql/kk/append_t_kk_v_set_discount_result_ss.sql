/*

   参照テーブル:
      T_KK_V_SET_DISCOUNT_RESULT

*/
INSERT INTO {{ var.value.redshift_ims_schema_name }}.T_KK_V_SET_DISCOUNT_RESULT_SS
(
    SNAPSHOT_DATE
    , NIKKEI_ID_INTERNAL_MEMBER_NO
    , CHILD_SERVICE_ID
    , CHILD_PLAN_ID
    , PARENT_SERVICE_ID
    , PAYMENT_TARGET_YYYYMM_DATE
    , INS_BATCH_ID
    , INS_DT_TM
    , UPD_BATCH_ID
    , UPD_DT_TM
)
SELECT
    {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE() AS SNAPSHOT_DATE
    , NIKKEI_ID_INTERNAL_MEMBER_NO
    , CHILD_SERVICE_ID
    , CHILD_PLAN_ID
    , PARENT_SERVICE_ID
    , PAYMENT_TARGET_YYYYMM_DATE
    , '{{ dag.dag_id }}' AS INS_BATCH_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS INS_DT_TM
    , '{{ dag.dag_id }}' AS UPD_BATCH_ID
    , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE()) AS UPD_DT_TM
FROM
    {{ var.value.redshift_ims_schema_name }}.T_KK_V_SET_DISCOUNT_RESULT
WHERE
    PAYMENT_TARGET_YYYYMM_DATE = {{ var.value.redshift_ims_schema_name }}.GET_BATCH_DATE()
;
