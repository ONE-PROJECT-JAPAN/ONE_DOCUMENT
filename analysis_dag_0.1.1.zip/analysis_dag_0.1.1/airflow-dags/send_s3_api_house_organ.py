import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

import logging
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from botocore.exceptions import ClientError
from common_ims.common_util import convUTC2JST, move_file_one
from common_ims.notification import notify_failure

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2022,8,20,9,00,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_api_house_organ',
    default_args=default_args,
    description='ユーザと契約先コードの連携',
    schedule_interval='0 9 * * *', # 毎日09時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# 環境変数:Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# 環境変数:権限
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')

# ファイル出力先
S3_OUTPUT_PATH = 'outbox/send/house-organ/account_code'

# 一時出力先
S3_TEMP_PATH = f'app/{S3_OUTPUT_PATH}'

# ファイル出力名
FILE_OUTPUT_NAME = 'user_serial_id_list.csv'

# ファイルコピー元
ORG_KEY = os.path.join(S3_TEMP_PATH, f'{FILE_OUTPUT_NAME}000.gz')

# ファイルコピー先
DEST_KEY = os.path.join(S3_OUTPUT_PATH, f'{FILE_OUTPUT_NAME}.gz')

#######################################################################################################
# Python関数
#######################################################################################################
def rename_output_file():
    """
    S3に出力されたファイルの末尾に000.gzが付いているのでリネームする。
    """
    logging.info(f'*** rename_output_file copy_object org_key: {ORG_KEY} To dest_key: {DEST_KEY}')
    
    try:
        # ファイル名の変更（ファイル名の語尾000を削除）
        move_file_one(dest_key=DEST_KEY, org_key=ORG_KEY)
    except ClientError as e:
        logging.error(e)
        raise e

#######################################################################################################
# 前提チェック
#######################################################################################################

# 法人販売システム(BB)のデータ構築

check_impr_bb_to_ims_1 = ExternalTaskSensor(
    task_id='check_impr_bb_to_ims_1',
    external_dag_id='impr_bb_to_ims_1',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=180), # 06時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=1200,      #20分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=140), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=1200,      #20分
    retries=0,
    dag=dag
)
#######################################################################################################
# 処理
#######################################################################################################

# S3配置ファイル作成処理

redshift_to_s3_to_api_house_organ = PostgresOperator(
    task_id='redshift_to_s3_to_api_house_organ',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ims/unload_user_serial_id_list.sql',
    params = {
        's3_path' : f'{S3_BUCKET_NAME}/{S3_TEMP_PATH}/{FILE_OUTPUT_NAME}',
        'redshift_role_arn' : REDSHIFT_DEFAULT_ROLE_ARN
    },
    autocommit=False,
    dag=dag
)

# 出力ファイル名変更処理

rename_output_file = PythonOperator(
    task_id="rename_output_file",
    python_callable=rename_output_file,
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

[ check_impr_bb_to_ims_1, check_s3_to_redshift_m_is_nx_user_serial_id ] >> redshift_to_s3_to_api_house_organ >> rename_output_file >> done_all_task_for_check
