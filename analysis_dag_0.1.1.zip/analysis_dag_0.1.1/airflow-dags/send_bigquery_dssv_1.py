import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,20,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_dssv_1', # DAG名
    default_args=default_args,
    description='配信システム(DSSV)のBigQuery連携',
    schedule_interval='20 7 * * *', # 毎日07時20分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'


#######################################################################################################
# 前提チェック
#######################################################################################################

# 配信システム(DSSV)のデータ構築

check_impr_dssv_to_ims_1 = ExternalTaskSensor(
    task_id='check_impr_dssv_to_ims_1',
    external_dag_id='impr_dssv_to_ims_1',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=200), # 毎日04時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3600,      #60分
    retries=0,
    dag=dag
)

# 配信システム(DSSV)のデータ構築

check_impr_dssv_to_ims_3 = ExternalTaskSensor(
    task_id='check_impr_dssv_to_ims_3',
    external_dag_id='impr_dssv_to_ims_3',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=435), # 毎日00時05分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3600,      #60分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=40), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3600,      #60分
    retries=0,
    dag=dag
)

#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    ＴＲＮメール送信設定情報
    """
    redshift_to_bigquery_t_dsu_t_ds_mail_set_info = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_mail_set_info',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_mail_set_info.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_MAIL_SET_INFO',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＭＳＴ送信メール種別
    """
    redshift_to_bigquery_m_dsu_m_send_mail_kind = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_dsu_m_send_mail_kind',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_dsu_m_send_mail_kind.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_DSU_M_SEND_MAIL_KIND',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ会員情報管理
    """
    redshift_to_bigquery_t_dsu_t_ds_user_meta = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_user_meta',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_user_meta.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_USER_META',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮクリッピングキーワード
    """
    redshift_to_bigquery_t_dsu_t_ds_clipping_keywords = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_clipping_keywords',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_clipping_keywords.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_CLIPPING_KEYWORDS',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    T_DSU_T_DS_ETSURANZUMI_KIJI_LOG
    """
    redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_kiji_log = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_kiji_log',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_etsuranzumi_kiji_log.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_ETSURANZUMI_KIJI_LOG',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ閲覧本数履歴
    """
    redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_honsu_log = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_honsu_log',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_etsuranzumi_honsu_log.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_ETSURANZUMI_HONSU_LOG',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮフォロー
    """
    redshift_to_bigquery_t_dsu_t_ds_follow_rensai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_follow_rensai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_follow_rensai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_RENSAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ人事ウォッチアラート条件
    """
    redshift_to_bigquery_t_dsu_t_ds_jwalert_info = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_jwalert_info',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_jwalert_info.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_JWALERT_INFO',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ企業フォロー
    """
    redshift_to_bigquery_t_dsu_t_ds_follow_company = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_follow_company',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_follow_company.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ企業フォロー個別最終チェック日時
    """
    redshift_to_bigquery_t_dsu_t_ds_follow_company_check = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_follow_company_check',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_follow_company_check.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY_CHECK',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ企業フォロー記事フィルタ
    """
    redshift_to_bigquery_t_dsu_t_ds_follow_company_news_filter = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_follow_company_news_filter',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_follow_company_news_filter.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY_NEWS_FILTER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ＴＲＮ企業フォロー管理
    """
    redshift_to_bigquery_t_dsu_t_ds_follow_company_manage = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsu_t_ds_follow_company_manage',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsu_t_ds_follow_company_manage.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY_MANAGE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    グループ
    """
    redshift_to_bigquery_t_dsg_t_ds_group = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_group',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_group.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_GROUP',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    Rグループ-ユーザ
    """
    redshift_to_bigquery_t_dsg_t_ds_rel_group_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_rel_group_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_rel_group_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_REL_GROUP_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ユーザ
    """
    redshift_to_bigquery_t_dsg_t_ds_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    シェア
    """
    redshift_to_bigquery_t_dsg_t_ds_share = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_share',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_share.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_SHARE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    シェアユーザ
    """
    redshift_to_bigquery_t_dsg_t_ds_share_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_share_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_share_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_SHARE_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    シェア閲覧ログ
    """
    redshift_to_bigquery_t_dsg_t_ds_etsuran_log_share = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_etsuran_log_share',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_etsuran_log_share.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_ETSURAN_LOG_SHARE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    コメント
    """
    redshift_to_bigquery_t_dsg_t_ds_comment = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_comment',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_comment.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_COMMENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    自動収集
    """
    redshift_to_bigquery_t_dsg_t_ds_collection = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_dsg_t_ds_collection',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_dsg_t_ds_collection.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSG_T_DS_COLLECTION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    redshift_to_bigquery_m_dsk_m_canp_hensei = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_dsk_m_canp_hensei',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_dsk_m_canp_hensei.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_DSK_M_CANP_HENSEI'
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_dsu_t_ds_clipping_keywords_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_clipping_keywords_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_CLIPPING_KEYWORDS_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_CLIPPING_KEYWORDS_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_etsuranzumi_honsu_log_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_etsuranzumi_honsu_log_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_ETSURANZUMI_HONSU_LOG_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_ETSURANZUMI_HONSU_LOG_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_etsuranzumi_kiji_log_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_etsuranzumi_kiji_log_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_ETSURANZUMI_KIJI_LOG_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_follow_company_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_follow_company_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_FOLLOW_COMPANY_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_follow_company_manage_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_follow_company_manage_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_COMPANY_MANAGE_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_FOLLOW_COMPANY_MANAGE_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_follow_rensai_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_follow_rensai_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_FOLLOW_RENSAI_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_FOLLOW_RENSAI_ACCUM.sql'
    )

    bq_update_t_dsu_t_ds_jwalert_info_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_dsu_t_ds_jwalert_info_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_DSU_T_DS_JWALERT_INFO_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_DSU_T_DS_JWALERT_INFO_ACCUM.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_mail_set_info >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_m_dsu_m_send_mail_kind >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_user_meta >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_clipping_keywords
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_kiji_log
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_honsu_log
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_follow_rensai
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_jwalert_info
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_follow_company
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_follow_company_manage
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_follow_company_check >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsu_t_ds_follow_company_news_filter >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_group >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_rel_group_user >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_user >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_share >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_share_user >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_etsuran_log_share >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_comment >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_1 ] >> redshift_to_bigquery_t_dsg_t_ds_collection >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_dssv_to_ims_3 ] >> redshift_to_bigquery_m_dsk_m_canp_hensei >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_clipping_keywords >> bq_update_t_dsu_t_ds_clipping_keywords_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_kiji_log >> bq_update_t_dsu_t_ds_etsuranzumi_kiji_log_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_etsuranzumi_honsu_log >> bq_update_t_dsu_t_ds_etsuranzumi_honsu_log_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_follow_rensai >> bq_update_t_dsu_t_ds_follow_rensai_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_jwalert_info >> bq_update_t_dsu_t_ds_jwalert_info_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_follow_company >> bq_update_t_dsu_t_ds_follow_company_accum >> done_all_task_for_check
redshift_to_bigquery_t_dsu_t_ds_follow_company_manage >> bq_update_t_dsu_t_ds_follow_company_manage_accum >> done_all_task_for_check
