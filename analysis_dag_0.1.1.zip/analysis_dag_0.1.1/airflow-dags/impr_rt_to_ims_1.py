import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum
import json


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='impr_rt_to_ims_1', # DAG名
    default_args=default_args,
    description='Rtoaster(RT)データの構築',
    schedule_interval='0 5 * * *', # 毎日05時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# コンバージョンログ（ルールベース・コンテンツ）ワークデータロード

s3_to_redshift_w_rt_conversion_r_log = PythonOperator(
    task_id='s3_to_redshift_w_rt_conversion_r_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_CONVERSION_R_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# コンバージョンログ（ルールベース・コンテンツ）蓄積

s3_to_redshift_t_rt_conversion_r_log_ac = PythonOperator(
    task_id='s3_to_redshift_t_rt_conversion_r_log_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_CONVERSION_R_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER', 'CONVERSION', 'SESSION_ID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_RT_CONVERSION_R_LOG_AC'
    },
    dag=dag
)

# レコメンドログ（ルールベース・コンテンツ）ワークデータロード

s3_to_redshift_w_rt_recommendation_r_log = PythonOperator(
    task_id='s3_to_redshift_w_rt_recommendation_r_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_RECOMMENDATION_R_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# レコメンドログ（ルールベース・コンテンツ）蓄積

s3_to_redshift_t_rt_recommendation_r_log_ac = PythonOperator(
    task_id='s3_to_redshift_t_rt_recommendation_r_log_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_RECOMMENDATION_R_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER', 'SESSION_ID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_RT_RECOMMENDATION_R_LOG_AC'
    },
    dag=dag
)

# モバイルコンバージョンログ（ルールベース・コンテンツ）ワークデータロード

s3_to_redshift_w_rt_conversion_r_log_mob = PythonOperator(
    task_id='s3_to_redshift_w_rt_conversion_r_log_mob',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_CONVERSION_R_LOG_MOB',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# モバイルコンバージョンログ（ルールベース・コンテンツ）蓄積

s3_to_redshift_t_rt_conversion_r_log_mob_ac = PythonOperator(
    task_id='s3_to_redshift_t_rt_conversion_r_log_mob_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_CONVERSION_R_LOG_MOB',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER', 'CONVERSION', 'SESSION_ID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_RT_CONVERSION_R_LOG_MOB_AC'
    },
    dag=dag
)

# モバイルレコメンドログ（ルールベース・コンテンツ）ワークデータロード

s3_to_redshift_w_rt_recommendation_r_log_mob = PythonOperator(
    task_id='s3_to_redshift_w_rt_recommendation_r_log_mob',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_RECOMMENDATION_R_LOG_MOB',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# モバイルレコメンドログ（ルールベース・コンテンツ）蓄積

s3_to_redshift_t_rt_recommendation_r_log_mob_ac = PythonOperator(
    task_id='s3_to_redshift_t_rt_recommendation_r_log_mob_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_RECOMMENDATION_R_LOG_MOB',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER', 'SESSION_ID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_RT_RECOMMENDATION_R_LOG_MOB_AC'
    },
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    レコメンドログ（ルールベース・コンテンツ）ワーク
    """
    redshift_to_bigquery_w_rt_recommendation_r_log = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_rt_recommendation_r_log',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_rt_recommendation_r_log.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_RT_RECOMMENDATION_R_LOG',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    モバイルレコメンドログ（ルールベース・コンテンツ）ワーク
    """
    redshift_to_bigquery_w_rt_recommendation_r_log_mob = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_rt_recommendation_r_log_mob',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_rt_recommendation_r_log_mob.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_RT_RECOMMENDATION_R_LOG_MOB',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_rt_recommendation_r_log_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_rt_recommendation_r_log_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_RT_RECOMMENDATION_R_LOG_AC',
        execute_query='sql/bigquery/execute/UPD__T_RT_RECOMMENDATION_R_LOG_AC.sql'
    )

    bq_update_t_rt_recommendation_r_log_mob_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_rt_recommendation_r_log_mob_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_RT_RECOMMENDATION_R_LOG_MOB_AC',
        execute_query='sql/bigquery/execute/UPD__T_RT_RECOMMENDATION_R_LOG_MOB_AC.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_w_rt_conversion_r_log >> s3_to_redshift_t_rt_conversion_r_log_ac >> done_all_task_for_check
s3_to_redshift_w_rt_recommendation_r_log >> s3_to_redshift_t_rt_recommendation_r_log_ac >> done_all_task_for_check
s3_to_redshift_w_rt_conversion_r_log_mob >> s3_to_redshift_t_rt_conversion_r_log_mob_ac >> done_all_task_for_check
s3_to_redshift_w_rt_recommendation_r_log_mob >> s3_to_redshift_t_rt_recommendation_r_log_mob_ac >> done_all_task_for_check
s3_to_redshift_w_rt_recommendation_r_log >> redshift_to_bigquery_w_rt_recommendation_r_log >> bq_update_t_rt_recommendation_r_log_ac >> done_all_task_for_check
s3_to_redshift_w_rt_recommendation_r_log_mob >> redshift_to_bigquery_w_rt_recommendation_r_log_mob >> bq_update_t_rt_recommendation_r_log_mob_ac >> done_all_task_for_check
