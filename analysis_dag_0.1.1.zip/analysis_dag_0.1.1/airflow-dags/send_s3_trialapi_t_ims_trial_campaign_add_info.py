import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from common_ims.trial_api_util import move_file_s3_to_s3
import logging
import pendulum


####################################################################################################
# 定数宣言
####################################################################################################

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# IMSバケット名
S3_BUCKET_NAME_LEGACY_IMS = Variable.get('legacy_ims_trial_api_s3_bucket_name')

# 転送元
S3_TANSFER_PATH_ORG = """app/{}/T_IMS_TRIAL_CAMPAIGN_ADD_INFO/"""

# 転送先
S3_TANSFER_PATH_DEST = """{}/T_IMS_TRIAL_CAMPAIGN_ADD_INFO/{}"""


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,4,45,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_trialapi_t_ims_trial_campaign_add_info',
    default_args=default_args,
    description='お試し施策追加情報 S3連携',
    schedule_interval='45 4 * * *', # 日次4:45(JST)
    catchup=False,
    user_defined_macros={'convUTC2JST':convUTC2JST},
    max_active_runs=1
)

#######################################################################################################
# データ構築処理
#######################################################################################################

# お試し施策追加情報 S3出力

redshift_to_s3_t_ims_trial_campaign_add_info = PostgresOperator(
    task_id='redshift_to_s3_t_ims_trial_campaign_add_info',
    postgres_conn_id='redshift_default',
    sql='sql/ims/unload_t_ims_trial_campaign_add_info.sql',
    params = {
        's3_path' : """{}/app/{}/T_IMS_TRIAL_CAMPAIGN_ADD_INFO/{}_T_IMS_TRIAL_CAMPAIGN_ADD_INFO"""
    },
    autocommit=False,
    dag=dag
)

# お試し施策追加情報 S3連携

def move_file_s3_to_s3_trialapi(**context):
    next_execution_date = context['next_execution_date']
    move_file_s3_to_s3(S3_BUCKET_NAME, S3_BUCKET_NAME_LEGACY_IMS, S3_TANSFER_PATH_ORG, S3_TANSFER_PATH_DEST, next_execution_date)

s3_to_s3_trialapi = PythonOperator(
    task_id="s3_to_s3_trialapi",
    python_callable=move_file_s3_to_s3_trialapi,
    dag=dag
)

#######################################################################################################
# 依存関係
#######################################################################################################

redshift_to_s3_t_ims_trial_campaign_add_info >> s3_to_s3_trialapi
