import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from datetime import datetime, timedelta
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims import batch
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_ee_to_ims', # DAG名
    default_args=default_args,
    description='日経イベントアンケートシステム(EE)のデータ構築',
    schedule_interval='0 7 * * *', # 毎日07時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'


#######################################################################################################
# 前提チェック
#######################################################################################################

# コードマスタ

check_m_is_mm_code = ExternalTaskSensor(
    task_id='check_m_is_mm_code',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_code',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 職業マスタ

check_m_is_mm_occupation = ExternalTaskSensor(
    task_id='check_m_is_mm_occupation',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_occupation',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 業種マスタ

check_m_is_mm_business = ExternalTaskSensor(
    task_id='check_m_is_mm_business',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_business',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 職種マスタ

check_m_is_mm_job = ExternalTaskSensor(
    task_id='check_m_is_mm_job',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_job',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 役職マスタ

check_m_is_mm_position = ExternalTaskSensor(
    task_id='check_m_is_mm_position',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_position',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 居住国マスタ

check_m_is_mm_country = ExternalTaskSensor(
    task_id='check_m_is_mm_country',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_country',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 住所マスタ

check_m_is_mm_address = ExternalTaskSensor(
    task_id='check_m_is_mm_address',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_address',
    execution_delta=timedelta(minutes=20), # 06:40 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 応募内容_テキスト2データロード

s3_to_redshift_t_ee_v_application_text2 = PythonOperator(
    task_id='s3_to_redshift_t_ee_v_application_text2',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'T_EE_V_応募内容_テキスト2',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 応募内容_メールアドレス2データロード

s3_to_redshift_t_ee_v_application_mailaddress2 = PythonOperator(
    task_id='s3_to_redshift_t_ee_v_application_mailaddress2',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'T_EE_V_応募内容_メールアドレス2',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 応募内容_選択2データロード

s3_to_redshift_t_ee_v_application_choice2 = PythonOperator(
    task_id='s3_to_redshift_t_ee_v_application_choice2',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'T_EE_V_応募内容_選択2',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# マスタ情報データロード

s3_to_redshift_m_ee_v_crm_master_info = PythonOperator(
    task_id='s3_to_redshift_m_ee_v_crm_master_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'M_EE_V_CRM_マスタ情報',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# マスタ情報データ蓄積

s3_to_redshift_m_ee_v_crm_master_info_accum = PythonOperator(
    task_id='s3_to_redshift_m_ee_v_crm_master_info_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'M_EE_V_CRM_マスタ情報',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['フォームID'],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_EE_V_CRM_マスタ情報蓄積'
    },
    dag=dag
)

# 応募者情報データロード

s3_to_redshift_t_ee_v_crm_applicant_info = PythonOperator(
    task_id='s3_to_redshift_t_ee_v_crm_applicant_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'T_EE_T_CRM_応募者情報',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 応募者情報データ蓄積

s3_to_redshift_t_ee_v_crm_applicant_info_accum = PythonOperator(
    task_id='s3_to_redshift_t_ee_v_crm_applicant_info_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ee',
        'redshift_loader_table_name': 'T_EE_T_CRM_応募者情報',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['フォームID', '応募者ID', '登録日時'],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_EE_T_CRM_応募者情報蓄積'
    },
    dag=dag
)

# イベントアンケートデータ汎用項目蓄積

replace_t_ee_v_accum_generalpurpose = PostgresOperator(
    task_id='replace_t_ee_v_accum_generalpurpose',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ee/t_ee_v_ac_general_item.sql',
    autocommit=False,
    dag=dag
)

# イベントアンケートデータ固定項目蓄積・個人情報削除

replace_t_ee_v_accum_fixed = PostgresOperator(
    task_id='replace_t_ee_v_accum_fixed',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ee/t_ee_v_ac_fixed_item.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 蓄積用_固定項目データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_EE_V_AC_FIXED_ITEM_BF = 'app/cleansing/T_EE_V_AC_FIXED_ITEM'
CL_FILE_T_EE_V_AC_FIXED_ITEM_AF = 'app/cleansing/T_EE_V_AC_FIXED_ITEM_CL'
CLEANSIMG_PATH_T_EE_V_AC_FIXED_ITEM_BF = 's3://{{ var.value.datastore_s3_bucket_name }}/' + CL_FILE_T_EE_V_AC_FIXED_ITEM_BF
CLEANSIMG_PATH_T_EE_V_AC_FIXED_ITEM_AF = 's3://{{ var.value.datastore_s3_bucket_name }}/' + CL_FILE_T_EE_V_AC_FIXED_ITEM_AF

# 蓄積用_固定項目データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_ee_v_ac_fixed_item_temp = PostgresOperator(
    task_id='redshift_to_s3_t_ee_v_ac_fixed_item_temp',
    postgres_conn_id='redshift_default',
    sql='sql/ee/t_ee_v_ac_fixed_item_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 蓄積用_固定項目データクレンジング・蓄積クレンジング

cleanse_t_ee_v_ac_fixed_item = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_ee_v_ac_fixed_item",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_EE_V_AC_FIXED_ITEM_BF,
        CLEANSIMG_PATH_T_EE_V_AC_FIXED_ITEM_AF,
        "-colNo", "11",
        "-name", "{3},{4}",
        "-telno", "{7},{10}",
        "-postcode", "{5},{8}",
        "-address", "{6},{9}",
    ]
)

# 蓄積用_固定項目データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_ee_v_ac_fixed_item_cl_ac = PostgresOperator(
    task_id='update_t_ee_v_ac_fixed_item_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/ee/t_ee_v_ac_fixed_item_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(蓄積用_固定項目データクレンジング・蓄積データクレンジング)

delete_from_s3_t_ee_v_ac_fixed_item_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_ee_v_ac_fixed_item_bf',
    aws_conn_id='aws_default',
    bucket = '{{ var.value.datastore_s3_bucket_name }}',
    prefix = CL_FILE_T_EE_V_AC_FIXED_ITEM_BF + '/',
    dag=dag
)

delete_from_s3_t_ee_v_ac_fixed_item_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_ee_v_ac_fixed_item_af',
    aws_conn_id='aws_default',
    bucket = '{{ var.value.datastore_s3_bucket_name }}',
    prefix = CL_FILE_T_EE_V_AC_FIXED_ITEM_AF + '/',
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_m_ee_v_crm_master_info >> s3_to_redshift_m_ee_v_crm_master_info_accum >> done_all_task_for_check
s3_to_redshift_t_ee_v_crm_applicant_info >> s3_to_redshift_t_ee_v_crm_applicant_info_accum >> done_all_task_for_check
s3_to_redshift_t_ee_v_application_choice2 >> done_all_task_for_check
[
  check_m_is_mm_code,
  check_m_is_mm_occupation,
  check_m_is_mm_business,
  check_m_is_mm_job,
  check_m_is_mm_position,
  check_m_is_mm_country,
  check_m_is_mm_address,
  s3_to_redshift_t_ee_v_application_text2,
  s3_to_redshift_t_ee_v_application_mailaddress2,
  s3_to_redshift_t_ee_v_application_choice2
] >> replace_t_ee_v_accum_fixed >> redshift_to_s3_t_ee_v_ac_fixed_item_temp >> cleanse_t_ee_v_ac_fixed_item >> update_t_ee_v_ac_fixed_item_cl_ac >> [delete_from_s3_t_ee_v_ac_fixed_item_bf, delete_from_s3_t_ee_v_ac_fixed_item_af] >> done_all_task_for_check
[
  s3_to_redshift_t_ee_v_application_text2,
  s3_to_redshift_t_ee_v_application_choice2
] >> replace_t_ee_v_accum_generalpurpose >> done_all_task_for_check
