import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.check_operator import CheckOperator
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,6,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_s3_pk_t_cs_incident', # DAG名
    default_args=default_args,
    description='インシデント情報(CS)を紙課金システム(PK)に連携するためのファイル出力',
    schedule_interval='30 6 * * *', # 毎日06時30分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# 環境変数:DBスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# ファイル出力先
S3_OUTPUT_PATH = """{}/outbox/send/pk/T_CS_INCIDENT_{}_"""

#######################################################################################################
# 前提チェック
#######################################################################################################

# 現在時刻から1日前の更新データが1件以上あるかをチェック（UTC同士の比較）

check_t_cs_incident = CheckOperator(
    task_id='check_t_cs_incident',
    conn_id=REDSHIFT_CONN_ID,
    sql=f"""
        SELECT
            count(*) > 0 as result
        FROM
            {DB_SCHEMA}.T_CS_INCIDENT
        WHERE
            UPDATED_UTC > DATEADD(day,-1,GETDATE())""",
    dag=dag
)

#######################################################################################################
# 処理
#######################################################################################################

# インシデント情報のアンロード処理

redshift_to_s3_t_cs_incident = PostgresOperator(
    task_id='redshift_to_s3_t_cs_incident',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/cs/unload_t_cs_incident.sql',
    params = {
        's3_path' : S3_OUTPUT_PATH
    },
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_t_cs_incident >> redshift_to_s3_t_cs_incident
