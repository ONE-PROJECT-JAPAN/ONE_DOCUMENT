import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_cm_to_ims', # DAG名
    default_args=default_args,
    description='ClickMailer(CM)のデータ構築',
    schedule_interval='0 5 * * *', # 毎日05時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

check_extract_from_cm5 = ExternalTaskSensor(
    task_id='check_extract_from_cm5',
    external_dag_id='extr_cm_sftp_to_s3',
    external_task_id='extract_from_cm5',
    execution_delta=timedelta(minutes=15), # 04:45 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

check_extract_from_cm6 = ExternalTaskSensor(
    task_id='check_extract_from_cm6',
    external_dag_id='extr_cm_sftp_to_s3',
    external_task_id='extract_from_cm6',
    execution_delta=timedelta(minutes=15), # 04:45 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# メールサマリ情報ワークデータロード 

s3_to_redshift_w_cm_email_summary = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_summary',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_SUMMARY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# 配信結果（成功）ワークデータロード 

s3_to_redshift_w_cm_email_success = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_success',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_SUCCESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# エラーアドレス情報ワークデータロード 

s3_to_redshift_w_cm_email_blacklist = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_blacklist',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_BLACKLIST',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# トラッキング結果ワークデータロード 

s3_to_redshift_w_cm_email_click = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_click',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_CLICK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# 開封結果ワークデータロード 

s3_to_redshift_w_cm_email_open = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_open',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_OPEN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# 再送設定による除外情報ワークデータロード 

s3_to_redshift_w_cm_email_omit = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_omit',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_OMIT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# 配信結果（エラー）ワークデータロード 

s3_to_redshift_w_cm_email_error = PythonOperator(
    task_id='s3_to_redshift_w_cm_email_error',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'cm',
        'redshift_loader_table_name': 'W_CM_EMAIL_ERROR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# メールサマリ情報蓄積

update_t_cm_email_summary_ac = PostgresOperator(
    task_id='update_t_cm_email_summary_ac',
    postgres_conn_id='redshift_default',
    sql='sql/cm/update_t_cm_email_summary_ac.sql',
    autocommit=False,
    dag=dag
)

# 配信結果（成功）蓄積

update_t_cm_email_success_ac = PostgresOperator(
    task_id='update_t_cm_email_success_ac',
    postgres_conn_id='redshift_default',
    sql='sql/cm/update_t_cm_email_success_ac.sql',
    autocommit=False,
    dag=dag
)

# エラーアドレス情報蓄積

update_t_cm_email_blacklist_ac = PostgresOperator(
    task_id='update_t_cm_email_blacklist_ac',
    postgres_conn_id='redshift_default',
    sql='sql/cm/update_t_cm_email_blacklist_ac.sql',
    autocommit=False,
    dag=dag
)

# 再送設定による除外情報蓄積

update_t_cm_email_omit_ac = PostgresOperator(
    task_id='update_t_cm_email_omit_ac',
    postgres_conn_id='redshift_default',
    sql='sql/cm/update_t_cm_email_omit_ac.sql',
    autocommit=False,
    dag=dag
)

# 配信結果（エラー）蓄積

update_t_cm_email_error_ac = PostgresOperator(
    task_id='update_t_cm_email_error_ac',
    postgres_conn_id='redshift_default',
    sql='sql/cm/update_t_cm_email_error_ac.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    redshift_to_bigquery_w_cm_email_summary = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_cm_email_summary',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_cm_email_summary.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_CM_EMAIL_SUMMARY'
    )

    redshift_to_bigquery_w_cm_email_success = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_cm_email_success',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_cm_email_success.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_CM_EMAIL_SUCCESS'
    )

    redshift_to_bigquery_w_cm_email_click = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_cm_email_click',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_cm_email_click.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_CM_EMAIL_CLICK'
    )

    redshift_to_bigquery_w_cm_email_open = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_cm_email_open',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_cm_email_open.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_CM_EMAIL_OPEN'
    )

    redshift_to_bigquery_w_cm_email_error = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_w_cm_email_error',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/w_cm_email_error.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='W_CM_EMAIL_ERROR'
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_cm_email_click_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_cm_email_click_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_CM_EMAIL_CLICK_AC',
        execute_query='sql/bigquery/execute/UPD__T_CM_EMAIL_CLICK_AC.sql'
    )

    bq_update_t_cm_email_error_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_cm_email_error_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_CM_EMAIL_ERROR_AC',
        execute_query='sql/bigquery/execute/UPD__T_CM_EMAIL_ERROR_AC.sql'
    )

    bq_update_t_cm_email_open_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_cm_email_open_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_CM_EMAIL_OPEN_AC',
        execute_query='sql/bigquery/execute/UPD__T_CM_EMAIL_OPEN_AC.sql'
    )

    bq_update_t_cm_email_success_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_cm_email_success_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_CM_EMAIL_SUCCESS_AC',
        execute_query='sql/bigquery/execute/UPD__T_CM_EMAIL_SUCCESS_AC.sql'
    )

    bq_update_t_cm_email_summary_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_cm_email_summary_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_CM_EMAIL_SUMMARY_AC',
        execute_query='sql/bigquery/execute/UPD__T_CM_EMAIL_SUMMARY_AC.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_summary >> update_t_cm_email_summary_ac >> done_all_task_for_check
s3_to_redshift_w_cm_email_summary >> redshift_to_bigquery_w_cm_email_summary
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_success >> update_t_cm_email_success_ac >> done_all_task_for_check
s3_to_redshift_w_cm_email_success >> redshift_to_bigquery_w_cm_email_success
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_blacklist >> update_t_cm_email_blacklist_ac >> done_all_task_for_check
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_click >> redshift_to_bigquery_w_cm_email_click >> bq_update_t_cm_email_click_ac >> done_all_task_for_check
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_open >> redshift_to_bigquery_w_cm_email_open >> bq_update_t_cm_email_open_ac >> done_all_task_for_check
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_omit >> update_t_cm_email_omit_ac >> done_all_task_for_check
[check_extract_from_cm5, check_extract_from_cm6] >> s3_to_redshift_w_cm_email_error >> update_t_cm_email_error_ac >> done_all_task_for_check
s3_to_redshift_w_cm_email_error >> redshift_to_bigquery_w_cm_email_error
redshift_to_bigquery_w_cm_email_summary >> bq_update_t_cm_email_summary_ac >> done_all_task_for_check
redshift_to_bigquery_w_cm_email_success >> bq_update_t_cm_email_success_ac >> done_all_task_for_check
redshift_to_bigquery_w_cm_email_error >> bq_update_t_cm_email_error_ac >> done_all_task_for_check
