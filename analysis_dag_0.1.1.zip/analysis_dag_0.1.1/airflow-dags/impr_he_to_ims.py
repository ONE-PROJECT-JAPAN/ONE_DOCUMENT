import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,23,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_he_to_ims', # DAG名
    default_args=default_args,
    description='販売店評価システム(HE)のデータ構築',
    schedule_interval='0 23 * * *', # 毎日23時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# 事業所別統計データロード

s3_to_redshift_t_he_branch_statistics = PythonOperator(
    task_id='s3_to_redshift_t_he_branch_statistics',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_BRANCH_STATISTICS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 人口統計データロード

s3_to_redshift_t_he_population_statistics = PythonOperator(
    task_id='s3_to_redshift_t_he_population_statistics',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_POPULATION_STATISTICS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 人口統計要覧データロード

s3_to_redshift_t_he_population_statistics_outline = PythonOperator(
    task_id='s3_to_redshift_t_he_population_statistics_outline',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_POPULATION_STATISTICS_OUTLINE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 人口要覧データロード

s3_to_redshift_t_he_population_outline = PythonOperator(
    task_id='s3_to_redshift_t_he_population_outline',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_POPULATION_OUTLINE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# クレームデータロード

s3_to_redshift_t_he_claim = PythonOperator(
    task_id='s3_to_redshift_t_he_claim',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_CLAIM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# クレーム小分類データロード

s3_to_redshift_m_he_claim_category_s = PythonOperator(
    task_id='s3_to_redshift_m_he_claim_category_s',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_CLAIM_CATEGORY_S',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# クレーム新旧変換データロード

s3_to_redshift_m_he_claim_old_and_new_convert = PythonOperator(
    task_id='s3_to_redshift_m_he_claim_old_and_new_convert',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_CLAIM_OLD_AND_NEW_CONVERT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# クレーム大分類データロード

s3_to_redshift_m_he_claim_category_l = PythonOperator(
    task_id='s3_to_redshift_m_he_claim_category_l',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_CLAIM_CATEGORY_L',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 算出式パターンデータロード

s3_to_redshift_m_he_formula_pattern = PythonOperator(
    task_id='s3_to_redshift_m_he_formula_pattern',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_FORMULA_PATTERN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 算出式情報管理データロード

s3_to_redshift_m_he_formula_info_mng = PythonOperator(
    task_id='s3_to_redshift_m_he_formula_info_mng',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_FORMULA_INFO_MNG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 実数入力カラムマスタデータロード

s3_to_redshift_m_he_real_num_input_column = PythonOperator(
    task_id='s3_to_redshift_m_he_real_num_input_column',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_REAL_NUM_INPUT_COLUMN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 実数入力パターンデータロード

s3_to_redshift_m_he_real_num_input_pattern = PythonOperator(
    task_id='s3_to_redshift_m_he_real_num_input_pattern',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_REAL_NUM_INPUT_PATTERN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 社員データロード

s3_to_redshift_m_he_employee = PythonOperator(
    task_id='s3_to_redshift_m_he_employee',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_EMPLOYEE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 所属部データロード

s3_to_redshift_m_he_department = PythonOperator(
    task_id='s3_to_redshift_m_he_department',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_DEPARTMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 請求項目選択パターンデータロード

s3_to_redshift_m_he_request_item_pattern = PythonOperator(
    task_id='s3_to_redshift_m_he_request_item_pattern',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_REQUEST_ITEM_PATTERN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 担当区域データロード

s3_to_redshift_m_he_charge_area = PythonOperator(
    task_id='s3_to_redshift_m_he_charge_area',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_CHARGE_AREA',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 入り止めヘッダデータロード

s3_to_redshift_t_he_enter_stop_hdr = PythonOperator(
    task_id='s3_to_redshift_t_he_enter_stop_hdr',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_ENTER_STOP_HDR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 入り止め情報データロード

s3_to_redshift_t_he_enter_stop_info = PythonOperator(
    task_id='s3_to_redshift_t_he_enter_stop_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_ENTER_STOP_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 入力共通情報データロード

s3_to_redshift_t_he_input_common = PythonOperator(
    task_id='s3_to_redshift_t_he_input_common',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'T_HE_INPUT_COMMON',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 入力情報マスタデータロード

s3_to_redshift_m_he_input = PythonOperator(
    task_id='s3_to_redshift_m_he_input',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_INPUT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 媒体_販売店評価システムデータロード

s3_to_redshift_m_he_baitai = PythonOperator(
    task_id='s3_to_redshift_m_he_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 本支社データロード

s3_to_redshift_m_he_hon_shisha = PythonOperator(
    task_id='s3_to_redshift_m_he_hon_shisha',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_HON_SHISHA',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 役職権限データロード

s3_to_redshift_m_he_post_authority = PythonOperator(
    task_id='s3_to_redshift_m_he_post_authority',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'he',
        'redshift_loader_table_name': 'M_HE_POST_AUTHORITY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    事業所別統計
    """
    redshift_to_bigquery_t_he_branch_statistics = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_branch_statistics',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_branch_statistics.sql',
        bigquery_dataset='domo',
        bigquery_table='T_HE_BRANCH_STATISTICS',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    人口統計
    """
    redshift_to_bigquery_t_he_population_statistics = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_population_statistics',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_population_statistics.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HE_POPULATION_STATISTICS',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    人口統計要覧
    """
    redshift_to_bigquery_t_he_population_statistics_outline = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_population_statistics_outline',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_population_statistics_outline.sql',
        bigquery_dataset='domo',
        bigquery_table='T_HE_POPULATION_STATISTICS_OUTLINE',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    人口要覧
    """
    redshift_to_bigquery_t_he_population_outline = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_population_outline',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_population_outline.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HE_POPULATION_OUTLINE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    クレーム小分類
    """
    redshift_to_bigquery_m_he_claim_category_s = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_claim_category_s',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_claim_category_s.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_CLAIM_CATEGORY_S',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    クレーム新旧変換
    """
    redshift_to_bigquery_m_he_claim_old_and_new_convert = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_claim_old_and_new_convert',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_claim_old_and_new_convert.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_CLAIM_OLD_AND_NEW_CONVERT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    クレーム大分類
    """
    redshift_to_bigquery_m_he_claim_category_l = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_claim_category_l',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_claim_category_l.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_CLAIM_CATEGORY_L',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    算出式パターン
    """
    redshift_to_bigquery_m_he_formula_pattern = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_formula_pattern',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_formula_pattern.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_FORMULA_PATTERN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    算出式情報管理
    """
    redshift_to_bigquery_m_he_formula_info_mng = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_formula_info_mng',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_formula_info_mng.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_FORMULA_INFO_MNG',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    実数入力カラムマスタ
    """
    redshift_to_bigquery_m_he_real_num_input_column = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_real_num_input_column',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_real_num_input_column.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_REAL_NUM_INPUT_COLUMN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    実数入力パターン
    """
    redshift_to_bigquery_m_he_real_num_input_pattern = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_real_num_input_pattern',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_real_num_input_pattern.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_REAL_NUM_INPUT_PATTERN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    所属部
    """
    redshift_to_bigquery_m_he_department = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_department',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_department.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_DEPARTMENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    入り止めヘッダ
    """
    redshift_to_bigquery_t_he_enter_stop_hdr = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_enter_stop_hdr',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_enter_stop_hdr.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HE_ENTER_STOP_HDR',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    入り止め情報
    """
    redshift_to_bigquery_t_he_enter_stop_info = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_enter_stop_info',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_enter_stop_info.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HE_ENTER_STOP_INFO',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    入力共通情報
    """
    redshift_to_bigquery_t_he_input_common = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_he_input_common',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_he_input_common.sql',
        bigquery_dataset='domo',
        bigquery_table='T_HE_INPUT_COMMON',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    入力情報マスタ
    """
    redshift_to_bigquery_m_he_input = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_input',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_input.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_INPUT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    媒体_販売店評価システム
    """
    redshift_to_bigquery_m_he_baitai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_baitai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_baitai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_BAITAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    役職権限
    """
    redshift_to_bigquery_m_he_post_authority = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_he_post_authority',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_he_post_authority.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HE_POST_AUTHORITY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_he_branch_statistics >> redshift_to_bigquery_t_he_branch_statistics >> done_all_task_for_check
s3_to_redshift_t_he_population_statistics >> redshift_to_bigquery_t_he_population_statistics >> done_all_task_for_check
s3_to_redshift_t_he_population_statistics_outline >> redshift_to_bigquery_t_he_population_statistics_outline >> done_all_task_for_check
s3_to_redshift_t_he_population_outline >> redshift_to_bigquery_t_he_population_outline >> done_all_task_for_check
s3_to_redshift_t_he_claim >> done_all_task_for_check
s3_to_redshift_m_he_claim_category_s >> redshift_to_bigquery_m_he_claim_category_s >> done_all_task_for_check
s3_to_redshift_m_he_claim_old_and_new_convert >> redshift_to_bigquery_m_he_claim_old_and_new_convert >> done_all_task_for_check
s3_to_redshift_m_he_claim_category_l >> redshift_to_bigquery_m_he_claim_category_l >> done_all_task_for_check
s3_to_redshift_m_he_formula_pattern >> redshift_to_bigquery_m_he_formula_pattern >> done_all_task_for_check
s3_to_redshift_m_he_formula_info_mng >> redshift_to_bigquery_m_he_formula_info_mng >> done_all_task_for_check
s3_to_redshift_m_he_real_num_input_column >> redshift_to_bigquery_m_he_real_num_input_column >> done_all_task_for_check
s3_to_redshift_m_he_real_num_input_pattern >> redshift_to_bigquery_m_he_real_num_input_pattern >> done_all_task_for_check
s3_to_redshift_m_he_employee >> done_all_task_for_check
s3_to_redshift_m_he_department >> redshift_to_bigquery_m_he_department >> done_all_task_for_check
s3_to_redshift_m_he_request_item_pattern >> done_all_task_for_check
s3_to_redshift_m_he_charge_area >> done_all_task_for_check
s3_to_redshift_t_he_enter_stop_hdr >> redshift_to_bigquery_t_he_enter_stop_hdr >> done_all_task_for_check
s3_to_redshift_t_he_enter_stop_info >> redshift_to_bigquery_t_he_enter_stop_info >> done_all_task_for_check
s3_to_redshift_t_he_input_common >> redshift_to_bigquery_t_he_input_common >> done_all_task_for_check
s3_to_redshift_m_he_input >> redshift_to_bigquery_m_he_input >> done_all_task_for_check
s3_to_redshift_m_he_baitai >> redshift_to_bigquery_m_he_baitai >> done_all_task_for_check
s3_to_redshift_m_he_hon_shisha >> done_all_task_for_check
s3_to_redshift_m_he_post_authority >> redshift_to_bigquery_m_he_post_authority >> done_all_task_for_check
