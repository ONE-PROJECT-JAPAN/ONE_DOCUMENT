import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.redshift_loader import invoke_redshift_loader

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,2,15,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_mm_to_ims_1', # DAG名
    default_args=default_args,
    description='マーケットシステム(MM)データの構築',
    schedule_interval='15 2 * * *', # 毎日02時15分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 登録銘柄情報データロード

s3_to_redshift_t_mm_port_stock = PythonOperator(
    task_id='s3_to_redshift_t_mm_port_stock',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'T_MM_PORT_STOCK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 企業マスタ（NKD）データロード

s3_to_redshift_m_mm_comp_profile_nkd = PythonOperator(
    task_id='s3_to_redshift_m_mm_comp_profile_nkd',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'M_MM_COMP_PROFILE_NKD',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 登録銘柄情報（投資信託）データロード

s3_to_redshift_t_mm_port_fund = PythonOperator(
    task_id='s3_to_redshift_t_mm_port_fund',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'T_MM_PORT_FUND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 登録銘柄情報（預貯金など自由枠）データロード

s3_to_redshift_t_mm_port_free = PythonOperator(
    task_id='s3_to_redshift_t_mm_port_free',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'T_MM_PORT_FREE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 登録銘柄情報（カスタマイズ）データロード

s3_to_redshift_t_mm_port_custom_info = PythonOperator(
    task_id='s3_to_redshift_t_mm_port_custom_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'T_MM_PORT_CUSTOM_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 米国企業銘柄マスタデータロード

s3_to_redshift_m_mm_quick_apis_usastocks_service = PythonOperator(
    task_id='s3_to_redshift_m_mm_quick_apis_usastocks_service',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'M_MM_QUICK_APIS_USASTOCKS_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 業界マスタデータロード

s3_to_redshift_m_mm_needs_gyoshu_master_m = PythonOperator(
    task_id='s3_to_redshift_m_mm_needs_gyoshu_master_m',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'M_MM_NEEDS_GYOSHU_MASTER_M',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 投信ファンド情報マスタ（NKD）データロード

s3_to_redshift_m_mm_fund_profile_nkd = PythonOperator(
    task_id='s3_to_redshift_m_mm_fund_profile_nkd',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'mm',
        'redshift_loader_table_name': 'M_MM_FUND_PROFILE_NKD',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_mm_port_stock >> done_all_task_for_check
s3_to_redshift_m_mm_comp_profile_nkd >> done_all_task_for_check
s3_to_redshift_t_mm_port_fund >> done_all_task_for_check
s3_to_redshift_t_mm_port_free >> done_all_task_for_check
s3_to_redshift_t_mm_port_custom_info >> done_all_task_for_check
s3_to_redshift_m_mm_quick_apis_usastocks_service >> done_all_task_for_check
s3_to_redshift_m_mm_needs_gyoshu_master_m >> done_all_task_for_check
s3_to_redshift_m_mm_fund_profile_nkd >> done_all_task_for_check
