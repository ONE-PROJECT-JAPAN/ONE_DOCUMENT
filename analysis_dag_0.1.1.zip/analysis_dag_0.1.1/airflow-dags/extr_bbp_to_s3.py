import sys, os

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from common_ims import batch
from common_ims.notification import notify_failure
import pendulum


default_args = {
    'start_date': datetime(2021,1,1,0,30,0, tzinfo=pendulum.timezone("Asia/Tokyo")),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=1), # 他システムの処理タイミングには依存しないため短めにする
    'on_failure_callback': notify_failure
}

dag = DAG(
    'extr_bpp_to_s3', # DAG名
    default_args=default_args,
    description='BP GWDB (Oracle) からデータを抽出する',
    schedule_interval='5 0 * * *', # 毎日00時05分(JST)
    catchup=False,
    concurrency=1, # タスクの同時実行数を制限する
)

table_names = [
    "T_BPP_V_USER_ALL",
    "T_BPP_T_USER",
    "T_BPP_T_USER_MOBILE",
    "T_BPP_T_USER_SERVICE",
    "T_BPP_T_USER_SEMINAR",
    "T_BPP_T_USER_PERMISSION",
    "T_BPP_T_USER_ATTRIBUTE",
    "T_BPP_T_IKOU_USER_TRACE",
    "M_BPP_M_ATTR_TRANSFORM",
    "M_BPP_M_ATTR_INVERSE_TRANSFORM",
    "M_BPP_M_ATTRIBUTE_VALUE",
    "M_BPP_M_ATTRIBUTE",
    "M_BPP_M_SERVICE",
    "M_BPP_M_PERMISSION",
    "M_BPP_M_SET_MANAGE",
    "M_BPP_M_GROUP",
]

extract_tasks = []
for tbl in table_names:
    task = batch.create_operator(
        dag=dag,
        task_id=f'extract_{tbl.lower()}_to_s3',
        job_name='embulk-gp',
        queue=batch.QUEUE_DEFAULT,
        command=[
            "run",
            f"config/extract-bpp/{tbl}.yml.liquid",
        ]
    )
    extract_tasks.append(task)

extract_tasks
