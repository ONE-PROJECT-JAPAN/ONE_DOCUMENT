import sys
import os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS'
local_tz = pendulum.timezone("Asia/Tokyo")

default_args = {
    'start_date': datetime(2021,1,1,7,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id=f'exec_bigquery_{BIGQUERY_TABLE_NAME.lower()}',
    default_args=default_args,
    description=f'{BIGQUERY_TABLE_NAME}構築',
    schedule_interval='30 7 1 * *',
    catchup=False
)


#
# BigQueryテーブル操作
#
with dag:
    append_t_bi_user_id_daily_service_priority_pln_lastday_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_id_daily_service_priority_pln_lastday_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS',
        execute_query=f'sql/bigquery/execute/UPD__T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS.sql'
    )

    append_t_bi_user_num_daily_service_priority_pln_lastday_ss = bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_num_daily_service_priority_pln_lastday_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_NUM_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS',
        execute_query='sql/bigquery/execute/UPD__T_BI_USER_NUM_DAILY_SERVICE_PRIORITY_PLN_LASTDAY_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#
# 依存関係
#
append_t_bi_user_id_daily_service_priority_pln_lastday_ss >> append_t_bi_user_num_daily_service_priority_pln_lastday_ss >> done_all_task_for_check
