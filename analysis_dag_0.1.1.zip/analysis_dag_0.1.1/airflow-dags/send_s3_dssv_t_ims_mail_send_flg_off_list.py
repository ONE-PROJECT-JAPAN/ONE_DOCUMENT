import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

import gzip
import logging
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import Variable
from airflow.operators.check_operator import CheckOperator
from airflow.operators.python import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from boto3 import Session
from common_ims import batch
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2022, 6, 1, 0, 0, 0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_dssv_t_ims_mail_send_flg_off_list',
    default_args=default_args,
    description='電子版ニュースメール配信停止告知対象の連携処理',
    schedule_interval='0 17 * * *',  # 毎日17時00分(JST)
    user_defined_macros={'convUTC2JST': convUTC2JST},
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

# Redshiftのスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# S3のバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

#  抽出済みかを確認

check_done_export = CheckOperator(
    task_id='check_done_export',
    conn_id=REDSHIFT_CONN_ID,
    sql=f"""
        SELECT
            count(*) > 0 as result
        FROM
            {DB_SCHEMA}.T_MA_EXPORT_INFO
        WHERE
            CAMPAIGN_ID = '100004' and export_date = '{{{{convUTC2JST(next_execution_date, "%Y-%m-%d")}}}}'""",
    dag=dag
)

# 配信データの有無確認

def get_export_result(**context):

    hook = PostgresHook(postgres_conn_id='redshift_default')
    next_execution_date = context['next_execution_date']
    # 処理対象件数確認
    for record in hook.get_records(f"""
        SELECT
            count(SERIAL_ID)
        FROM
            {DB_SCHEMA}.T_MA_EXPORT_INFO
        WHERE
            CAMPAIGN_ID = '100004' and export_date = '{convUTC2JST(next_execution_date, "%Y-%m-%d")}' and SERIAL_ID is not null
    """):
        logging.info('get_export_result :' + str(record[0]))
        if record[0] >= 1:
            return 'call_batch_check_delivered'
        else:
            return 'make_t_ims_mail_send_flg_off_list_zero'
    return

# 電子版ニュースメール配信停止告知対象の連携処理ファイル作成処理

def make_mail_send_flg_off_list(**context):
    hook = PostgresHook(postgres_conn_id='redshift_default')
    next_execution_date = context['next_execution_date']
    exec_date = convUTC2JST(next_execution_date, "%Y%m%d")

    json = '{"update_destination_id" : 1,"users":['

    for record in hook.get_records(f"""
        SELECT
            '{{"user_serial_id":"' + lpad(ma.serial_id, 10, '0') + '",' + '"nikkei_member_no":"' +
                lpad(id.user_no, 10, '0') + '","permissions":[{{"id":"00020NST0","is_enabled":false}}]}},'
        FROM
            {DB_SCHEMA}.M_IS_NX_USER_SERIAL_ID id, {DB_SCHEMA}.T_MA_EXPORT_INFO ma
        WHERE
            ma.serial_id = id.serial_id
            and campaign_id = '100004'
            and export_date = '{convUTC2JST(next_execution_date, "%Y-%m-%d")}';
    """):
        json += record[0]

    # 末尾がカンマである場合削除して最後の括弧を付ける
    json = json.rstrip(',') + ']}'

    key = f'outbox/send/dssv/T_IMS_MAIL_SEND_FLG_OFF_LIST_{exec_date}_000.gz'

    b = bytes(json, 'utf-8')
    body = gzip.compress(b)  # gzipにして圧縮する

    s3client = Session().client('s3')
    s3client.put_object(Bucket=S3_BUCKET_NAME, Key=key, Body=body, ACL='bucket-owner-full-control', ContentType='application/x-gzip')


#######################################################################################################
# 処理
#######################################################################################################

# 抽出結果によって分岐するブランチ

branch_task_export_result = BranchPythonOperator(
    task_id='branch_task_export_result',
    dag=dag,
    python_callable=get_export_result,
)

# バッチ_本番配信済チェック

call_batch_check_delivered = batch.create_operator(
    dag=dag,
    task_id="call_batch_check_delivered",
    job_name="delivery-clickmailer",
    queue=batch.QUEUE_DEFAULT,
    command=[
        "check_delivered_stop_mail.py"  # スクリプト名
    ],
    environment={
        "REDSHIFT_SCHEMA": DB_SCHEMA
    }
)

# 電子版ニュースメール配信停止告知対象の連携処理ファイル作成処理

make_t_ims_mail_send_flg_off_list = PythonOperator(
    task_id="make_t_ims_mail_send_flg_off_list",
    python_callable=make_mail_send_flg_off_list,
    dag=dag
)

# 電子版ニュースメール配信停止告知対象の連携処理ファイル作成処理(0件)

make_t_ims_mail_send_flg_off_list_zero = PythonOperator(
    task_id="make_t_ims_mail_send_flg_off_list_zero",
    python_callable=make_mail_send_flg_off_list,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_done_export >> branch_task_export_result
branch_task_export_result >> call_batch_check_delivered >> make_t_ims_mail_send_flg_off_list
branch_task_export_result >> make_t_ims_mail_send_flg_off_list_zero
