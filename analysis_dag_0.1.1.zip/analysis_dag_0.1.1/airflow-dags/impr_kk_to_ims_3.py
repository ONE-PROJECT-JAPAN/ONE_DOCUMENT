import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.trial_api_util import move_file_s3_to_s3
from common_ims.replace_t_kk_v_trial_campaign_apply_serial_id import main_trial_campaign
from boto3 import Session
import boto3
import logging
import pendulum
import json


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,0,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_kk_to_ims_3', # DAG名
    default_args=default_args,
    description='日経ID課金・決済システム(KK)のデータ構築(お試しAPI)',
    schedule_interval='*/10 * * * *', # 随時10分(JST)
    catchup=False,
    user_defined_macros={'convUTC2JST':convUTC2JST},
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

# RedshiftのIAM ロール
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# ロード対象ファイルパス
S3_INPUT_PATH = 'inbox/recv/kk/'

# ロード対象ファイルPrefix
S3_INPUT_PREFIX = 'T_KK_V_TRIAL_CAMPAIGN_APPLY_UPDATE_'

# ロード対象ファイルの一時パス
S3_INPUT_PATH_TEMP_LOAD = 'inbox/recv/kk/datastore_load_data/T_KK_V_TRIAL_CAMPAIGN_APPLY_UPDATE/'

# 退避パス
S3_CMP_PATH = 'inbox/cmp/kk/'

# IMSバケット名
S3_BUCKET_NAME_LEGACY_IMS = Variable.get('legacy_ims_trial_api_s3_bucket_name')

# 転送元
S3_TANSFER_PATH_ORG = """app/{}/T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID/"""

# 転送先
S3_TANSFER_PATH_DEST = """{}/T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID/{}"""

# 転送元拡張子
FILE_EXTENTION_ORG = """000.gz"""

# 転送先拡張子
FILE_EXTENTION_DEST = """.tsv.gz"""

#######################################################################################################
# Python定義
#######################################################################################################

# ロード処理

def load_table(s3_input_prefix):
    conn = None
    cursor = None
    try:
        logging.info(f'*** load_table s3_input_prefix: {s3_input_prefix}')
        file_pair = os.path.split(s3_input_prefix)
        
        # 一時パスへのパスを作成
        file_path = os.path.join(S3_INPUT_PATH_TEMP_LOAD, file_pair[1])
        logging.info(f'*** load_table file_path: {file_path}')

        # DB 接続
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        cursor = conn.cursor()
        
        # データ削除
        query_delete = f"""DELETE FROM {REDSHIFT_SCHEMA}.T_KK_V_TRIAL_CAMPAIGN_APPLY_UPDATE where true"""
        cursor.execute(query_delete)
        
        # ロード
        query_copy = f"""COPY {REDSHIFT_SCHEMA}.T_KK_V_TRIAL_CAMPAIGN_APPLY_UPDATE FROM 's3://{S3_BUCKET_NAME}/{file_path}' CREDENTIALS 'aws_iam_role={REDSHIFT_DEFAULT_ROLE_ARN}' CSV GZIP ;"""
        cursor.execute(query_copy)

        # コミット
        conn.commit()
    except Exception as e:
        logging.error(f'*** load_table Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()


# 指定のパスから指定のパスにファイルを移す

def move_files(file_list, org_path, dest_path, add_flag):
    logging.info(f'*** move_files org_path: {org_path} dest_path: {dest_path} add_flag: {add_flag}')
    
    # 空のファイルは処理しない
    if file_list == None:
        logging.error(f'*** move_files file_list: {str(file_list)}')
        return
        
    s3client = Session().client('s3')
    # 対象ファイル
    for key_path in file_list:
        file_pair = os.path.split(key_path)
        # コピー元
        org_key = os.path.join(org_path, file_pair[1])
        
        prefix_dttm = ''
        # ファイル移動時に日時を付ける場合
        if add_flag:
            exe_date = datetime.now(local_tz)
            prefix_dttm = exe_date.strftime("%Y%m%d%H%M%S_")
        
        archive_file_prefix = f'{prefix_dttm}{file_pair[1]}'
        
        # コピー先
        dest_key = os.path.join(dest_path, archive_file_prefix)
        
        try:
            # ファイルコピー
            s3client.copy_object(Bucket=S3_BUCKET_NAME, Key=dest_key, CopySource={'Bucket': S3_BUCKET_NAME, 'Key': org_key})
            
            # ファイル削除
            s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=org_key)
        except Exception as e:
            logging.warning(f'*** move_files Exception: {str(e)}')
            # 失敗しても例外は無視する
            continue


# 主処理

def main(**context):
    # S3のファイル確認
    s3 = boto3.resource('s3')
    s3BucketObj = s3.Bucket(S3_BUCKET_NAME)
    logging.info(f'*** load_table S3_BUCKET_NAME: {S3_BUCKET_NAME}')
    
    # ロード対象ファイル
    keys = None
    
    try:
        file_path = f'{S3_INPUT_PATH}{S3_INPUT_PREFIX}'
        response = s3BucketObj.meta.client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=file_path)
        
        # 処理対象ファイル有無チェック
        if not('Contents' in response):
            logging.error(f'*** main ファイルなし: {file_path}')
            # ファイルが存在しない場合
            raise Exception(f'{S3_INPUT_PATH}に対象のファイル{S3_INPUT_PREFIX}が存在しない')

        if 'Contents' in response:
            keys = [i['Key'] for i in response['Contents']]
            
            # 最新のファイル名の順にソート
            keys.sort(reverse=True)
            logging.info(f'*** main sorted keys: {keys}')
            
            # ロードするのは最新ファイルのみ
            arr_load = []
            arr_load.append(keys[0])
            
            # Prefix一致するファイルはロード用のパスへ移動
            move_files(keys, S3_INPUT_PATH, S3_INPUT_PATH_TEMP_LOAD, False)

            # ロード処理
            load_table(arr_load[0])
            
            # ファイル退避（正常終了時）
            move_files(keys, S3_INPUT_PATH_TEMP_LOAD, S3_CMP_PATH, True)
            
    except Exception as e:
        # エラー
        logging.error(f'*** main Exception: {str(e)}')

        # ファイル退避（異常終了時もcmpに移動）移動するのはエラーファイルのみならず受領分すべてを対象とする
        move_files(keys, S3_INPUT_PATH_TEMP_LOAD, S3_CMP_PATH, True)
        raise e

#######################################################################################################
# データ構築処理
#######################################################################################################

# お試し施策適用VIEW(更新版)データロード

s3_to_redshift_t_kk_v_trial_campaign_apply_update = PythonOperator(
    task_id="s3_to_redshift_t_kk_v_trial_campaign_apply_update",
    python_callable=main,
    dag=dag
)

# お試し施策適用VIEW（シリアルID版）ワーク洗替

replace_w_kk_v_trial_campaign_apply_serial_id = PostgresOperator(
    task_id='replace_w_kk_v_trial_campaign_apply_serial_id',
    postgres_conn_id='redshift_default',
    sql='sql/kk/replace_w_kk_v_trial_campaign_apply_serial_id.sql',
    autocommit=False,
    dag=dag
)

# お試し施策適用VIEW（シリアルID版）構築

replace_t_kk_v_trial_campaign_apply_serial_id = PythonOperator(
    task_id="replace_t_kk_v_trial_campaign_apply_serial_id",
    python_callable=main_trial_campaign,
    dag=dag
)

# S3出力

redshift_to_s3_t_kk_v_trial_campaign_apply_serial_id = PostgresOperator(
    task_id='redshift_to_s3_t_kk_v_trial_campaign_apply_serial_id',
    postgres_conn_id='redshift_default',
    sql='sql/kk/unload_t_kk_v_trial_campaign_apply_serial_id.sql',
    params = {
        's3_path' : """{}/app/{}/T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID/{}_T_KK_V_TRIAL_CAMPAIGN_APPLY_SERIAL_ID"""
    },
    autocommit=False,
    dag=dag
)

# S3連携

def move_file_s3_to_s3_trialapi(**context):
    next_execution_date = context['next_execution_date']
    move_file_s3_to_s3(S3_BUCKET_NAME, S3_BUCKET_NAME_LEGACY_IMS, S3_TANSFER_PATH_ORG, S3_TANSFER_PATH_DEST, next_execution_date)

s3_to_s3_trialapi = PythonOperator(
    task_id="s3_to_s3_trialapi",
    python_callable=move_file_s3_to_s3_trialapi,
    dag=dag
)

#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_kk_v_trial_campaign_apply_update >> replace_w_kk_v_trial_campaign_apply_serial_id >> replace_t_kk_v_trial_campaign_apply_serial_id >> redshift_to_s3_t_kk_v_trial_campaign_apply_serial_id >> s3_to_s3_trialapi
