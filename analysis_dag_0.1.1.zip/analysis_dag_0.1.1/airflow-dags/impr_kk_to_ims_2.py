import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,6,15,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_kk_to_ims_2', # DAG名
    default_args=default_args,
    description='日経ID課金・決済システム(KK)のデータ構築 月次(1日)',
    schedule_interval='15 6 1 * *', # 月次(1日) 06時15分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# 契約情報分析(月末日用)データロード 

s3_to_redshift_t_kk_contract_analyze_lastday = PythonOperator(
    task_id='s3_to_redshift_t_kk_contract_analyze_lastday',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_CONTRACT_ANALYZE_LASTDAY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    契約情報分析(月末日用)
    """
    redshift_to_bigquery_t_kk_contract_analyze_lastday = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_kk_contract_analyze_lastday',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_kk_contract_analyze_lastday.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_KK_CONTRACT_ANALYZE_LASTDAY',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_kk_contract_analyze_lastday >> redshift_to_bigquery_t_kk_contract_analyze_lastday >> done_all_task_for_check
