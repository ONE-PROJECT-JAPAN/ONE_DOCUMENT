import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))


####################################################################################################
# 外部リストデータクレンジング・取込
####################################################################################################

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims import batch
from chardet.universaldetector import UniversalDetector
from boto3 import Session
import boto3
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,9,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 0,
    'on_failure_callback': notify_failure
}

dag = DAG(
    'frnt_append_m_ims_external_load_list', # DAG名
    default_args=default_args,
    description=' 外部リストデータクレンジング・取込',
    schedule_interval='*/5 9-22  * * *', # 毎日 9:00-22:00(JST) 5分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DB_SCHEMA = Variable.get('redshift_ims_schema_name')        # DBスキーマ名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')   # S3のバケット名
S3_ROLE_ARN = Variable.get('redshift_default_role_arn')     # S3のrole

# Xcom key名称
XCOM_DB_LIST_ID = 'db_list_id'
XCOM_EXTERNAL_LIST_PATH = 'external_list_path'
XCOM_DB_CATEGORY_ID = 'db_category_id'
XCOM_LOAD_STATUS_CD = 'load_status_cd'

# Fileパス
CL_FILE_GENERAL = 'app/external/M_IMS_EXTERNAL_LOAD_LIST/GENERAL_ATTRIBUTE_DISP'   # 汎用属性項目ファイル（リスト属性表示管理一時外部テーブル用）
CL_FILE_EDIT = 'app/external/M_IMS_EXTERNAL_LOAD_LIST/EDIT_EXTERNAL_LIST'          # 編集済みファイル
CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_BF = 'app/cleansing/W_IMS_EXTERNAL_LOAD_LIST'     # クレンジング前
CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_AF = 'app/cleansing/W_IMS_EXTERNAL_LOAD_LIST_CL'  # クレンジング後
CLEANSIMG_PATH_W_IMS_EXTERNAL_LOAD_LIST_BF = f"""s3://{S3_BUCKET_NAME}/{CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_BF}"""
CLEANSIMG_PATH_W_IMS_EXTERNAL_LOAD_LIST_AF = f"""s3://{S3_BUCKET_NAME}/{CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_AF}"""

# DB copy 業務エラー
ERR_STL_LOAD_ERRORS = 'stl_load_errors'

# ファイル 存在なし 業務エラー
ERR_STL_NOFILE_ERRORS = 'NoSuchKey'

# 固定属性項目
ARR_FIX_ATTRIBUTES = [
    'ID'
    ,'氏名'
    ,'メールアドレス'
    ,'住所'
    ,'電話番号'
]

# 汎用属性項目の最大数
MAX_GENERAL_ATTR_COUNT = 5

# 取込リストファイル最大項目数
MAX_ALL_ATTR_COUNT = len(ARR_FIX_ATTRIBUTES) + MAX_GENERAL_ATTR_COUNT

# 終了ステータス
RS_CODE_NORMAL = 1                        # 正常終了
RS_CODE_ERROR_ETC = -1                    # 異常終了：その他
RS_CODE_ERROR_ENCODE = -2                 # 異常終了：文字コードNG

# 編集処理の識別用
INDEX_ID_NOT_FOUND = 'ID_NOT_FOUND'
INDEX_BLANK = 'BLANK'


# 終了ステータス
RS_CODE_NORMAL = 1                        # 正常終了
RS_CODE_ERROR_ETC = -1                    # 異常終了：その他
RS_CODE_ERROR_ENCODE = -2                 # 異常終了：文字コードNG

# 取込対象件数取得用のSQL
SQL_GET_CNT_LIST_EDL = f"""
    select
        count(E.list_id)
    from
        {DB_SCHEMA}.t_edl_load_mng E
    join {DB_SCHEMA}.m_ims_list_mng M on
        E.list_id = M.list_id
    where
        E.load_status_cd = 0
    limit 1
    """

# 取込対象取得用のSQL（一度に1レコードのみ取得）※複数データを動的にタスク生成不可のため
SQL_GET_LIST_EDL = f"""
    select
        E.list_id,
        E.external_list_filepath,
        E.external_list_filename,
        M.list_category_id
    from
        {DB_SCHEMA}.t_edl_load_mng E
    join {DB_SCHEMA}.m_ims_list_mng M on
        E.list_id = M.list_id
    where
        E.load_status_cd = 0
    order by
        E.load_queue_timestamp
    limit 1
    """

# 一時テーブル作成
SQL_CREATE = f"""
    create temp table external_load_list (
        list_internal_id varchar(120),
        name varchar(200),
        email varchar(1020),
        address varchar(400),
        telno varchar(120),
        general_attribute_1 varchar(1020),
        general_attribute_2 varchar(1020),
        general_attribute_3 varchar(1020),
        general_attribute_4 varchar(1020),
        general_attribute_5 varchar(1020));
    """

# 編集済みのTSVファイルをロード
SQL_COPY = f"""
    copy external_load_list
    from 's3://{S3_BUCKET_NAME}/{CL_FILE_EDIT}' 
    iam_role '{S3_ROLE_ARN}'
    format as csv 
    delimiter '\t' 
    quote '\"';
    """

# クレンジング用にUnload
SQL_UNLOAD = f"""
    unload ('
    select
        list_internal_id,
        name,
        email,
        address,
        telno,
        general_attribute_1,
        general_attribute_2,
        general_attribute_3,
        general_attribute_4,
        general_attribute_5
    from
        external_load_list
    ') 
    to 's3://{S3_BUCKET_NAME}/app/cleansing/W_IMS_EXTERNAL_LOAD_LIST/W_IMS_EXTERNAL_LOAD_LIST_' 
    iam_role '{S3_ROLE_ARN}'
    csv delimiter as ', ' 
    null '' 
    allowoverwrite 
    parallel off;
    """


#######################################################################################################
# データ構築処理
#######################################################################################################

# 取込対象データ確認

def get_list_count(**context):

    hook = PostgresHook(postgres_conn_id='redshift_default')

    # 処理対象件数確認
    for record in hook.get_records(SQL_GET_CNT_LIST_EDL):
        logging.info('get_list_count :' + str(record[0]))
        if record[0] >= 1:
            return True
    return False

# 取込対象データ確認結果（分岐）

check_exist_task_list_data = ShortCircuitOperator(
     task_id='check_exist_task_list_data',
     python_callable=get_list_count,
     provide_context=True,
     dag=dag
)

# 外部リストデータファイルの編集

def edit_s3_file (**context):

    # context 内より task_id を key に取得
    paramForList = context['task_instance'].xcom_pull(task_ids='get_edl_list_task')
    logging.info('edit_s3_file  paramForList :' + str(paramForList))

    try:
        # 引数取得
        db_list_id = paramForList[0]
        external_list_path = paramForList[1]
        db_category_id = paramForList[3]
        
        # xcomに値格納
        context['ti'].xcom_push(key=XCOM_DB_LIST_ID, value=str(db_list_id))
        context['ti'].xcom_push(key=XCOM_EXTERNAL_LIST_PATH, value=str(external_list_path))
        context['ti'].xcom_push(key=XCOM_DB_CATEGORY_ID, value=str(db_category_id))

        # sql実行結果リストなし判定
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(S3_BUCKET_NAME)
        
        obj = bucket.Object(external_list_path)

        response = obj.get()
        body = response['Body'].read()

        # ファイルサイズチェック
        if len(body) == 0:
            logging.warning('edit_s3_file  : 処理対象ファイルが0バイトです')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        # 文字コードチェック
        detector = UniversalDetector()
        for line in body.splitlines():
            detector.feed(line)
            # 推定結果が定まるとdetector.doneがTrueになる
            if detector.done:
                break
        detector.close()
        
        enc = detector.result['encoding']
        if enc not in ['utf-8', 'ascii']:
            logging.warning('edit_s3_file : 処理対象ファイルの文字コードがASCIIまたはUTF-8ではありません   文字コード : ' + str(enc))
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ENCODE))
            return RS_CODE_ERROR_ENCODE

        # ヘッダ部とデータ部の抽出
        load_data = body.decode('utf-8')
        all_line = load_data.splitlines()
        
        line_all_cnt = len(all_line)
        headers = None
        if line_all_cnt > 0:
            headers = all_line[0].split('\t')
            
        # ヘッダ部：空文字の存在チェック
        if headers is None or '' in headers or None in headers:
            logging.warning('edit_s3_file  : 処理対象ファイルにヘッダ行が正しく設定されていません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        # ヘッダ部：重複チェック
        if len(headers) != len(set(headers)):
            logging.warning('edit_s3_file  : ヘッダ名が重複しています')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC
            
        # データ部：存在チェック
        if line_all_cnt <= 1:
            logging.warning('edit_s3_file  : 処理対象ファイルにレコード行が存在しません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC
            
        #
        # 固定属性ヘッダ解析
        #
        
        # 全項目を出力順に並び変えたインデックス（必ずMAX_ALL_ATTR_COUNTの数分）
        sorted_indexes = []
        
        # 固定項目が存在していたインデックス
        fix_exist_indexes = []
        
        for i, fix_attr in enumerate(ARR_FIX_ATTRIBUTES):
            
            if fix_attr in headers:
                header_index = headers.index(fix_attr)
                
                sorted_indexes.append(header_index)
                fix_exist_indexes.append(header_index)
                
            else:
                if(i == 0):
                    sorted_indexes.append('ID_NOT_FOUND')
                    
                else:
                    sorted_indexes.append('BLANK')

        #
        # 汎用属性ヘッダ解析
        #
        
        general_header_attrs = []
        general_number = 1
        
        for header_index, header_name in enumerate(headers):
        
            if header_index not in fix_exist_indexes:
                sorted_indexes.append(header_index)
                
                general_header_attrs.append([header_name, 'GENERAL_ATTRIBUTE_' + str(general_number)])
                general_number = general_number + 1
                
                if(len(sorted_indexes) >= MAX_ALL_ATTR_COUNT):
                    break
        del fix_exist_indexes
        
        #
        # 汎用属性ファイル生成
        #
        
        general_attr_dump = ''
        for general_header_attr in general_header_attrs:
        
            general_attr_dump += '\t'.join(general_header_attr)
            general_attr_dump += '\n'

        # ファイル出力
        obj_general_attr = bucket.Object(CL_FILE_GENERAL)
        obj_general_attr.put(Body = general_attr_dump)
        
        del general_header_attrs
        
        # 汎用属性の不足分を追加
        lack_size = MAX_ALL_ATTR_COUNT - len(sorted_indexes)
        for i in range(lack_size):
            sorted_indexes.append(INDEX_BLANK)

        #
        # 編集済みファイル生成
        #
        
        id_value = 1
        output_dump = ''
        for line_cnt in range(line_all_cnt - 1):
            record = all_line[line_cnt + 1].split('\t')
            output_record = []
            
            for sorted_index in sorted_indexes:
            
                if sorted_index == 'ID_NOT_FOUND':
                    output_record.append(str(id_value))
                    id_value = id_value + 1
                
                elif sorted_index == 'BLANK':
                    output_record.append('')
                    
                else:
                    output_record.append(record[sorted_index])
                    
            output_dump += '\t'.join(output_record)
            output_dump += '\n'
            
        # ファイル出力
        obj_output = bucket.Object(CL_FILE_EDIT)
        obj_output.put(Body = output_dump)

    except Exception as e:

        # ファイルが存在しない場合のみを業務エラーとして処理する
        if (ERR_STL_NOFILE_ERRORS in str(e)) :
            logging.warning('edit_s3_file  : 処理対象ファイルが存在しません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC
        
        logging.error('edit_s3_file Exception e :' + str(e))
        context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
        return RS_CODE_ERROR_ETC

    # 正常終了
    context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_NORMAL))
    return RS_CODE_NORMAL

edit_w_ims_external_load_list = PythonOperator (
    task_id='edit_w_ims_external_load_list',
    provide_context=True,
    python_callable=edit_s3_file,
    dag=dag
)

# 外部リストデータファイルの編集（結果による分岐）

def check_edit_result(**context):

    # context 内より task_id を key に取得
    result = context['task_instance'].xcom_pull(task_ids='edit_w_ims_external_load_list')
    if result == RS_CODE_NORMAL:
        return 'convert_tsv2csv_m_ims_external_load_list'
    else:
        logging.warning('check_edit_result : 外部リスト取込のファイルNG ' + str(result))
        return 'update_t_edl_load_mng_edit_error'
    return

branch_task_file_edit_result = BranchPythonOperator(
    task_id='branch_task_file_edit_result',
    dag=dag,
    python_callable=check_edit_result,
)

# 取込対象外部リストデータ取得

def get_list_from_sql(**context):

    hook = PostgresHook(postgres_conn_id='redshift_default')
    for record in hook.get_records(SQL_GET_LIST_EDL):
        logging.info('get_list_from_sql record:' + str(record))
        return record

get_edl_list_task = PythonOperator(
     task_id='get_edl_list_task',
     python_callable=get_list_from_sql,
     provide_context=True,
     dag=dag
)

# 名寄せ項目クレンジング・ファイル出力（tsv→csv）

def load_w_ims_external_load_list4tsv(**context):

    conn = None
    cursor = None
    try:
        conn = PostgresHook(postgres_conn_id='redshift_default').get_conn()
        cursor = conn.cursor()
        # SQL実行：一時テーブル作成
        cursor.execute(SQL_CREATE)
        try:
            # SQL実行：ロード処理
            cursor.execute(SQL_COPY)
        except Exception as copy_exe:
            logging.error('load_w_ims_external_load_list4tsv Exception copy_exe :' + str(copy_exe))

            # ロードエラーのみを業務エラーとして処理する
            if (ERR_STL_LOAD_ERRORS in str(copy_exe)) :
                # 異常終了時のタスク名
                return 'update_t_edl_load_mng_load_error'
            raise copy_exe

        # SQL実行：クレンジング用のUnload処理
        cursor.execute(SQL_UNLOAD)
    except Exception as e:
        logging.error('load_w_ims_external_load_list4tsv Exception e :' + str(e))
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

    # 正常終了時のタスク名
    return 'cleanse_m_ims_external_load_list'

convert_tsv2csv_m_ims_external_load_list = PythonOperator(
     task_id='convert_tsv2csv_m_ims_external_load_list',
     python_callable=load_w_ims_external_load_list4tsv,
     provide_context=True,
     dag=dag
)

# 名寄せ項目クレンジング用ファイル出力（結果による分岐）

def check_load_result(**context):

    # context 内より task_id を key に取得
    return context['task_instance'].xcom_pull(task_ids='convert_tsv2csv_m_ims_external_load_list')

branch_task_load_result = BranchPythonOperator(
    task_id='branch_task_load_result',
    dag=dag,
    python_callable=check_load_result,
)

# データクレンジング処理

cleanse_m_ims_external_load_list = batch.create_operator(
    dag=dag,
    task_id='cleanse_m_ims_external_load_list',
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_W_IMS_EXTERNAL_LOAD_LIST_BF,
        CLEANSIMG_PATH_W_IMS_EXTERNAL_LOAD_LIST_AF,
        "-colNo", "10",
        "-name", "{1}",
        "-address", "{3}",
        "-telno", "{4}",
    ]
)

# リスト取込処理

append_m_ims_external_load_list_normal = PostgresOperator(
    task_id='append_m_ims_external_load_list_normal',
    postgres_conn_id='redshift_default',
    sql='sql/ims/insert_m_ims_external_load_list.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル退避（共通：正常、ロード処理異常）

def exe_copy_delete_s3_file(bucketName, orgFileKey, destFileKey):

    logging.info('exe_copy_delete_s3_file orgFileKey:' + str(orgFileKey))
    logging.info('exe_copy_delete_s3_file destFileKey:' + str(destFileKey))
    copy_source={'Bucket': bucketName, 'Key': orgFileKey}
    s3client=Session().client('s3')
    try:
        # ファイルコピー
        s3client.copy_object(CopySource=copy_source, Bucket=bucketName, Key=destFileKey)
        # ファイル削除
        s3client.delete_object(Bucket=bucketName, Key=orgFileKey)
    except Exception as e:
        # ファイル退避でエラーになってもそのままとする
        logging.error('exe_copy_delete_s3_file error :' + str(e))

def copy_delete_s3_file(external_list_path, rs_flag):

    logging.info('s3FileCopy external_list_path :' + str(external_list_path))
    # フルパス
    src_object_name = external_list_path
    path_file_arr = os.path.split(src_object_name)
    # パス
    s3_path_without_filename = path_file_arr[0]
    # ファイル名
    db_s3_file_name_external_list = path_file_arr[1]
    
    # 退避ファイル（正常の場合COMP_Y_）
    dest_object_name = s3_path_without_filename + '/COMP_Y_' + db_s3_file_name_external_list

    # 異常の場合COMP_X
    if rs_flag == False:
        dest_object_name = s3_path_without_filename + '/COMP_X_' + db_s3_file_name_external_list

    # S3のコピー、削除実行
    exe_copy_delete_s3_file(S3_BUCKET_NAME, src_object_name, dest_object_name)


#######################################################################################################
# 正常終了処理時の後始末
#######################################################################################################

# 外部リスト取込ファイル退避
def s3_file_copy_nomal(**context):

    external_list_path = context['ti'].xcom_pull(task_ids='edit_w_ims_external_load_list', key=XCOM_EXTERNAL_LIST_PATH)
    copy_delete_s3_file(external_list_path, True)

delete_from_s3_file_m_ims_external_load_list = PythonOperator (
    task_id='delete_from_s3_file_m_ims_external_load_list',
    provide_context=True,
    python_callable=s3_file_copy_nomal,
    dag=dag
)

# 編集済みファイルの削除

delete_from_s3_m_ims_external_load_list_edit = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_ims_external_load_list_edit',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_EDIT,
    dag=dag
)

# 汎用属性項目ファイルの削除

delete_from_s3_m_ims_external_load_list_general = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_ims_external_load_list_general',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_GENERAL,
    dag=dag
)

# S3ファイル削除(クレンジング前)

delete_from_s3_w_ims_external_load_list_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_bf',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    prefix=CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_BF + '/',
    dag=dag
)

# S3ファイル削除(クレンジング後)

delete_from_s3_w_ims_external_load_list_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_af',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    prefix=CL_FILE_W_IMS_EXTERNAL_LOAD_LIST_AF + '/',
    dag=dag
)


#######################################################################################################
# ファイルの編集処理にて異常終了した場合
#######################################################################################################

# DBステータス更新（取込失敗）

update_t_edl_load_mng_edit_error = PostgresOperator(
    task_id='update_t_edl_load_mng_edit_error',
    postgres_conn_id='redshift_default',
    sql='sql/ims/update_t_edl_load_mng_edit_error.sql',
    autocommit=False,
    dag=dag
)

# 削除対象ファイルパスの取得

def s3_file_copy_error(**context):

    external_list_path = context['ti'].xcom_pull(task_ids='edit_w_ims_external_load_list', key=XCOM_EXTERNAL_LIST_PATH)
    copy_delete_s3_file(external_list_path, False)

move_from_s3_m_ims_external_load_list_edit_error = PythonOperator (
    task_id='move_from_s3_m_ims_external_load_list_edit_error',
    provide_context=True,
    python_callable=s3_file_copy_error,
    dag=dag
)

# 編集済みファイルの削除

delete_from_s3_w_ims_external_load_list_edit_error = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_edit_error',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_EDIT,
    dag=dag
)

# 汎用属性項目ファイルの削除

delete_from_s3_w_ims_external_load_list_general_error = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_general_error',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_GENERAL,
    dag=dag
)


#######################################################################################################
# 外部リストデータロード処理にて異常終了した場合
#######################################################################################################

# DBステータス更新

update_t_edl_load_mng_load_error = PostgresOperator(
    task_id='update_t_edl_load_mng_load_error',
    postgres_conn_id='redshift_default',
    sql='sql/ims/update_t_edl_load_mng_load_error.sql',
    autocommit=False,
    dag=dag
)

# 削除対象ファイルパスの取得

move_from_s3_m_ims_external_load_list_load_error = PythonOperator (
    task_id='move_from_s3_m_ims_external_load_list_load_error',
    provide_context=True,
    python_callable=s3_file_copy_error,
    dag=dag
)

# 編集済みファイルの削除

delete_from_s3_w_ims_external_load_list_edit_load_error = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_edit_load_error',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_EDIT,
    dag=dag
)

# 汎用属性項目ファイルの削除

delete_from_s3_w_ims_external_load_list_general_load_error = S3DeleteObjectsOperator(
    task_id='delete_from_s3_w_ims_external_load_list_general_load_error',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    keys=CL_FILE_GENERAL,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_exist_task_list_data >> get_edl_list_task >> edit_w_ims_external_load_list >> branch_task_file_edit_result
branch_task_file_edit_result >> convert_tsv2csv_m_ims_external_load_list >> branch_task_load_result
branch_task_file_edit_result >> update_t_edl_load_mng_edit_error
branch_task_load_result >> cleanse_m_ims_external_load_list >> append_m_ims_external_load_list_normal
branch_task_load_result >> update_t_edl_load_mng_load_error
append_m_ims_external_load_list_normal >> delete_from_s3_file_m_ims_external_load_list
delete_from_s3_file_m_ims_external_load_list >> [delete_from_s3_m_ims_external_load_list_edit, delete_from_s3_m_ims_external_load_list_general, delete_from_s3_w_ims_external_load_list_bf, delete_from_s3_w_ims_external_load_list_af]
update_t_edl_load_mng_edit_error >> move_from_s3_m_ims_external_load_list_edit_error >> [delete_from_s3_w_ims_external_load_list_edit_error, delete_from_s3_w_ims_external_load_list_general_error]
update_t_edl_load_mng_load_error >> move_from_s3_m_ims_external_load_list_load_error >> [delete_from_s3_w_ims_external_load_list_edit_load_error, delete_from_s3_w_ims_external_load_list_general_load_error]
