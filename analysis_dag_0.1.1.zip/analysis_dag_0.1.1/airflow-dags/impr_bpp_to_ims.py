import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum

REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
ATLAS_BIGQUERY_IMS_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_bpp_to_ims', # DAG名
    default_args=default_args,
    description='GWDBシステム(BPP)のデータ構築',
    schedule_interval='0 5 * * *', # 毎日05時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# ユーザー情報ビューデータ蓄積

s3_to_redshift_t_bpp_v_user_all_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_v_user_all_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_V_USER_ALL',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SERIALID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_V_USER_ALL_AC'
    },
    dag=dag
)

# ユーザー基本データロード

s3_to_redshift_t_bpp_t_user = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ユーザー基本蓄積

s3_to_redshift_t_bpp_t_user_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SERIALID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_USER_AC'
    },
    dag=dag
)

# サービス関連属性データロード

s3_to_redshift_t_bpp_t_user_service = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_service',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# サービス関連属性蓄積

s3_to_redshift_t_bpp_t_user_service_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_service_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SERIALID', 'SERVICE_ID'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_USER_SERVICE_AC'
    },
    dag=dag
)

# セミナー属性データロード

s3_to_redshift_t_bpp_t_user_seminar = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_seminar',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_SEMINAR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# セミナー属性蓄積

s3_to_redshift_t_bpp_t_user_seminar_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_seminar_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_SEMINAR',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['T_SEMINAR_SEQ'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_USER_SEMINAR_AC'
    },
    dag=dag
)

# 各種パーミッション属性データロード

s3_to_redshift_t_bpp_t_user_permission = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_permission',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_PERMISSION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 各種パーミッション属性蓄積

s3_to_redshift_t_bpp_t_user_permission_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_permission_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_PERMISSION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SERIALID', 'PERMISSION_CD'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_USER_PERMISSION_AC'
    },
    dag=dag
)

# 協力者属性データロード

s3_to_redshift_t_bpp_t_user_attribute = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_attribute',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_ATTRIBUTE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 協力者属性蓄積

s3_to_redshift_t_bpp_t_user_attribute_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_attribute_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_ATTRIBUTE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SERIALID', 'ATTRIBUTE_CD'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_USER_ATTRIBUTE_AC'
    },
    dag=dag
)

# 移行ユーザートレースデータロード

s3_to_redshift_t_bpp_t_ikou_user_trace = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_ikou_user_trace',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_IKOU_USER_TRACE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 移行ユーザートレースデータ蓄積

s3_to_redshift_t_bpp_t_ikou_user_trace_ac = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_ikou_user_trace_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_IKOU_USER_TRACE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'SERIALID' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BPP_T_IKOU_USER_TRACE_AC',
    },
    dag=dag
)

# 協力者属性マッピングマスタ（GWDB -> 日経ID)データロード

s3_to_redshift_m_bpp_m_attr_transform = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_attr_transform',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_ATTR_TRANSFORM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 協力者属性マッピングマスタ（日経ID -> GWDB)データロード

s3_to_redshift_m_bpp_m_attr_inverse_transform = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_attr_inverse_transform',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_ATTR_INVERSE_TRANSFORM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 協力者属性値マスタデータロード

s3_to_redshift_m_bpp_m_attribute_value = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_attribute_value',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_ATTRIBUTE_VALUE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# 協力者属性項目マスタデータロード

s3_to_redshift_m_bpp_m_attribute = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_attribute',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_ATTRIBUTE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# サービスマスタデータロード

s3_to_redshift_m_bpp_m_service = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_service',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# パーミッションマスタデータロード

s3_to_redshift_m_bpp_m_permission = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_permission',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_PERMISSION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# セット商品管理マスタデータロード

s3_to_redshift_m_bpp_m_set_manage = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_set_manage',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_SET_MANAGE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# グループマスタデータロード

s3_to_redshift_m_bpp_m_group = PythonOperator(
    task_id='s3_to_redshift_m_bpp_m_group',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'M_BPP_M_GROUP',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

#携帯関連属性データロード

s3_to_redshift_t_bpp_t_user_mobile = PythonOperator(
    task_id='s3_to_redshift_t_bpp_t_user_mobile',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'bpp',
        'redshift_loader_table_name': 'T_BPP_T_USER_MOBILE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ユーザーサービス情報ビューデータマート作成

replace_t_bpp_v_user_service_all = PostgresOperator(
    task_id='replace_t_bpp_v_user_service_all',
    postgres_conn_id='redshift_default',
    sql='sql/bpp/replace_t_bpp_v_user_service_all.sql',
    autocommit=False,
    dag=dag
)

# ユーザー情報ビューデータの更新

update_t_bpp_v_user_all_ac = PostgresOperator(
    task_id='update_t_bpp_v_user_all_ac',
    postgres_conn_id='redshift_default',
    sql='sql/bpp/update_t_bpp_v_user_all_ac.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    協力者属性マッピングマスタ（GWDB -> 日経ID)
    """
    redshift_to_bigquery_m_bpp_m_attr_transform = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_bpp_m_attr_transform',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_bpp_m_attr_transform.sql',
        bigquery_dataset=ATLAS_BIGQUERY_IMS_DATASET_NAME,
        bigquery_table='M_BPP_M_ATTR_TRANSFORM',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    協力者属性マッピングマスタ（日経ID -> GWDB)
    """
    redshift_to_bigquery_m_bpp_m_attr_inverse_transform = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_bpp_m_attr_inverse_transform',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_bpp_m_attr_inverse_transform.sql',
        bigquery_dataset=ATLAS_BIGQUERY_IMS_DATASET_NAME,
        bigquery_table='M_BPP_M_ATTR_INVERSE_TRANSFORM',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    パーミッションマスタ
    """
    redshift_to_bigquery_m_bpp_m_permission = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_bpp_m_permission',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_bpp_m_permission.sql',
        bigquery_dataset=ATLAS_BIGQUERY_IMS_DATASET_NAME,
        bigquery_table='M_BPP_M_PERMISSION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    セット商品管理マスタ
    """
    redshift_to_bigquery_m_bpp_m_set_manage = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_bpp_m_set_manage',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_bpp_m_set_manage.sql',
        bigquery_dataset=ATLAS_BIGQUERY_IMS_DATASET_NAME,
        bigquery_table='M_BPP_M_SET_MANAGE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    ユーザーサービス情報ビュー
    """
    redshift_to_bigquery_t_bpp_v_user_service_all = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_bpp_v_user_service_all',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_bpp_v_user_service_all.sql',
        bigquery_dataset=ATLAS_BIGQUERY_IMS_DATASET_NAME,
        bigquery_table='T_BPP_V_USER_SERVICE_ALL',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################
# ユーザー情報ビューデータ蓄積

s3_to_redshift_t_bpp_t_user >> s3_to_redshift_t_bpp_t_user_ac >> done_all_task_for_check
[s3_to_redshift_t_bpp_t_user, s3_to_redshift_t_bpp_v_user_all_ac] >> update_t_bpp_v_user_all_ac >> done_all_task_for_check
s3_to_redshift_t_bpp_t_user_service >> s3_to_redshift_t_bpp_t_user_service_ac >> done_all_task_for_check
s3_to_redshift_t_bpp_t_user_seminar >> s3_to_redshift_t_bpp_t_user_seminar_ac >> done_all_task_for_check
s3_to_redshift_t_bpp_t_user_permission >> s3_to_redshift_t_bpp_t_user_permission_ac >> done_all_task_for_check
s3_to_redshift_t_bpp_t_user_attribute >> s3_to_redshift_t_bpp_t_user_attribute_ac >> done_all_task_for_check
s3_to_redshift_t_bpp_t_ikou_user_trace >> s3_to_redshift_t_bpp_t_ikou_user_trace_ac >> done_all_task_for_check
s3_to_redshift_m_bpp_m_attr_transform >> redshift_to_bigquery_m_bpp_m_attr_transform >> done_all_task_for_check
s3_to_redshift_m_bpp_m_attr_inverse_transform >> redshift_to_bigquery_m_bpp_m_attr_inverse_transform >> done_all_task_for_check
s3_to_redshift_m_bpp_m_attribute_value >> done_all_task_for_check
s3_to_redshift_m_bpp_m_attribute >> done_all_task_for_check
s3_to_redshift_m_bpp_m_service
s3_to_redshift_m_bpp_m_permission >> redshift_to_bigquery_m_bpp_m_permission >> done_all_task_for_check
s3_to_redshift_m_bpp_m_set_manage >> redshift_to_bigquery_m_bpp_m_set_manage >> done_all_task_for_check
s3_to_redshift_m_bpp_m_group >> done_all_task_for_check
s3_to_redshift_t_bpp_t_user_mobile
[
s3_to_redshift_t_bpp_t_user_mobile
, s3_to_redshift_t_bpp_t_user
, s3_to_redshift_t_bpp_t_user_permission
, s3_to_redshift_t_bpp_t_user_service
, s3_to_redshift_t_bpp_t_user_attribute
, s3_to_redshift_m_bpp_m_service
] >> replace_t_bpp_v_user_service_all >> done_all_task_for_check
