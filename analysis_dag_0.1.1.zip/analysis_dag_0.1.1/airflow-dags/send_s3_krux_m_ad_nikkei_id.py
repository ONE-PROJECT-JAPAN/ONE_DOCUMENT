import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.transfers.s3_to_sftp import S3ToSFTPOperator
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum
import logging

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,0,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_krux_m_ad_nikkei_id',
    default_args=default_args,
    description='Kruxへの連携データ作成',
    schedule_interval='40 0 * * *', # 毎日00時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# 環境変数:DBスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# 環境変数:S3バケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# ファイル出力先
S3_OUTPUT_PATH = """{}/outbox/send/krux/{}_wk_"""

#######################################################################################################
# 前提チェック
#######################################################################################################

# M_AD_NIKKEI_ID

check_replace_m_ad_nikkei_id = ExternalTaskSensor(
    task_id='check_replace_m_ad_nikkei_id',
    external_dag_id='trns_replace_m_ad_nikkei_id',
    external_task_id='replace_m_ad_nikkei_id',
    execution_delta=timedelta(minutes=1045), # 毎日7時15分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# スコア

check_replace_m_ims_score = ExternalTaskSensor(
    task_id='check_replace_m_ims_score',
    external_dag_id='trns_replace_m_ims_score',
    external_task_id='replace_m_ims_score',
    execution_delta=timedelta(minutes=905), # 毎日9時35分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 共通属性

check_replace_m_is_nx_attribute = ExternalTaskSensor(
    task_id='check_replace_m_is_nx_attribute',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='replace_m_is_nx_attribute',
    execution_delta=timedelta(minutes=1080), # 毎日6時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 都道府県マスタ

check_s3_to_redshift_m_is_mm_prefecture = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_mm_prefecture',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_mm_prefecture',
    execution_delta=timedelta(minutes=1080), # 毎日6時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# RP利用状態

check_s3_to_redshift_m_is_nx_rp_registration = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_rp_registration',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_rp_registration',
    execution_delta=timedelta(minutes=1080), # 毎日6時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

#######################################################################################################
# 処理
#######################################################################################################

# 送信ファイル作成処理

redshift_to_s3_to_krux = PostgresOperator(
    task_id='redshift_to_s3_to_krux',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ims/unload_krux.sql',
    params = {
        's3_path' : S3_OUTPUT_PATH
    },
    autocommit=False,
    dag=dag
)

# 送信処理

put_file = S3ToSFTPOperator(
    task_id='put_file',
    sftp_conn_id='ssh_krux',
    s3_bucket=S3_BUCKET_NAME,
    s3_key=f"""outbox/send/krux/{{{{ convUTC2JST(next_execution_date, "%Y%m%d") }}}}_wk_000.gz""",
    sftp_path=f"""nikkeidata/{{{{ convUTC2JST(next_execution_date, "%Y%m%d") }}}}.tsv.gz""",
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

[
  check_replace_m_ad_nikkei_id,
  check_replace_m_ims_score,
  check_replace_m_is_nx_attribute,
  check_s3_to_redshift_m_is_mm_prefecture,
  check_s3_to_redshift_m_is_nx_rp_registration
] >> redshift_to_s3_to_krux >> put_file >> done_all_task_for_check
