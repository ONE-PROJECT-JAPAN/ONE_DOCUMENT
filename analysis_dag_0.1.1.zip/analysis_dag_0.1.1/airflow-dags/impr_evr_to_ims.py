import sys, os

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims import batch
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,23,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_evr_to_ims', # DAG名
    default_args=default_args,
    description='イベントレジスト(EVR)のデータ構築',
    schedule_interval='30 23 * * *', # 毎日23時30分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# イベント属性情報データロード

s3_to_redshift_t_evr_event = PythonOperator(
    task_id='s3_to_redshift_t_evr_event',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_EVENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# イベント属性情報データ蓄積

s3_to_redshift_t_evr_event_ac = PythonOperator(
    task_id='s3_to_redshift_t_evr_event_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_EVENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'EVENT_UID' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_EVR_EVENT_AC',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# セッション属性情報データロード

s3_to_redshift_t_evr_checkin_object = PythonOperator(
    task_id='s3_to_redshift_t_evr_checkin_object',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_CHECKIN_OBJECT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# セッション属性情報データ蓄積

s3_to_redshift_t_evr_checkin_object_ac = PythonOperator(
    task_id='s3_to_redshift_t_evr_checkin_object_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_CHECKIN_OBJECT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'UID' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_EVR_CHECKIN_OBJECT_AC',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# チェックイン属性情報データロード

s3_to_redshift_t_evr_checkin_manager = PythonOperator(
    task_id='s3_to_redshift_t_evr_checkin_manager',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_CHECKIN_MANAGER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# チェックイン属性情報データ蓄積

s3_to_redshift_t_evr_checkin_manager_ac = PythonOperator(
    task_id='s3_to_redshift_t_evr_checkin_manager_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_CHECKIN_MANAGER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'UID' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_EVR_CHECKIN_MANAGER_AC',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)

# 参加者属性情報データロード

s3_to_redshift_t_evr_attendee = PythonOperator(
    task_id='s3_to_redshift_t_evr_attendee',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'evr',
        'redshift_loader_table_name': 'T_EVR_ATTENDEE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-noescape',
        'redshift_loader_skip_rows': 1,
    },
    dag=dag
)


#######################################################################################################
# 参加者属性情報 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_EVR_ATTENDEE_BF = 'app/cleansing/T_EVR_ATTENDEE'
CL_FILE_T_EVR_ATTENDEE_AF = 'app/cleansing/T_EVR_ATTENDEE_CL'
CLEANSIMG_PATH_T_EVR_ATTENDEE_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_EVR_ATTENDEE_BF}'
CLEANSIMG_PATH_T_EVR_ATTENDEE_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_EVR_ATTENDEE_AF}'

# 参加者属性情報（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_evr_attendee_temp = PostgresOperator(
    task_id='redshift_to_s3_t_evr_attendee_temp',
    postgres_conn_id='redshift_default',
    sql='sql/evr/t_evr_attendee_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 参加者属性情報クレンジング

cleanse_t_evr_attendee = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_evr_attendee",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_EVR_ATTENDEE_BF,
        CLEANSIMG_PATH_T_EVR_ATTENDEE_AF,
        "-colNo", "6",
        "-name", "{2}",
        "-telno", "{3}",
        "-postcode", "{4}",
        "-address", "{5}",
    ]
)

# 参加者属性情報クレンジング蓄積(一時テーブルの削除含む)

update_t_evr_attendee_cl_ac = PostgresOperator(
    task_id='update_t_evr_attendee_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/evr/t_evr_attendee_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(参加者属性情報データクレンジング)

delete_from_s3_t_evr_attendee_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_evr_attendee_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_EVR_ATTENDEE_BF + '/',
    dag=dag
)

delete_from_s3_t_evr_attendee_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_evr_attendee_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_EVR_ATTENDEE_AF + '/',
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    参加者属性情報
    """
    redshift_to_bigquery_t_evr_attendee = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_evr_attendee',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_evr_attendee.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_EVR_ATTENDEE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    イベント属性情報
    """
    redshift_to_bigquery_t_evr_event = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_evr_event',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_evr_event.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_EVR_EVENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    チェックイン属性情報
    """
    redshift_to_bigquery_t_evr_checkin_manager = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_evr_checkin_manager',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_evr_checkin_manager.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_EVR_CHECKIN_MANAGER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_evr_attendee >> redshift_to_s3_t_evr_attendee_temp >> cleanse_t_evr_attendee >> update_t_evr_attendee_cl_ac >> [delete_from_s3_t_evr_attendee_bf, delete_from_s3_t_evr_attendee_af] >> done_all_task_for_check
s3_to_redshift_t_evr_event >> [s3_to_redshift_t_evr_event_ac, redshift_to_bigquery_t_evr_event] >> done_all_task_for_check
s3_to_redshift_t_evr_checkin_object >> s3_to_redshift_t_evr_checkin_object_ac >> done_all_task_for_check
s3_to_redshift_t_evr_checkin_manager >> [s3_to_redshift_t_evr_checkin_manager_ac, redshift_to_bigquery_t_evr_checkin_manager] >> done_all_task_for_check
s3_to_redshift_t_evr_attendee >> redshift_to_bigquery_t_evr_attendee >> done_all_task_for_check
