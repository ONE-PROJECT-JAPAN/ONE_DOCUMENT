import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from airflow.models import Variable
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from common_ims.notification import notify_failure
import re
import logging

####################################################################################################
# Trigger DAGの引数 (Configuration JSON (Optional))
####################################################################################################

# フォーマット
# { "BASIC_SET_ID"        : "",
#   "CONTENT_TEMPLATE_ID" : "",
#   "TEST_DELIVERY_EMAIL" : ""
# }

# サンプル(メールアドレス単数)
# { "BASIC_SET_ID"        : "01",
#   "CONTENT_TEMPLATE_ID" : "29240010",
#   "TEST_DELIVERY_EMAIL" : "aaa@example.com"
# }

# サンプル(メールアドレス複数)
# { "BASIC_SET_ID"        : "01",
#   "CONTENT_TEMPLATE_ID" : "29240010",
#   "TEST_DELIVERY_EMAIL" : "aaa@example.com,bbb@example.com"
# }

####################################################################################################
# DAG
####################################################################################################

default_args = {
    'start_date': days_ago(2),
    'depends_on_past': False,
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_append_test_delivery_data', # DAG名
    default_args=default_args,
    description='テストメール配信データ作成',
    schedule_interval=None, # 手動実行
    max_active_runs=1 # DAG の最大同時実行数1
)

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

# シーケンスID
SEQUENCE_ID = 'SEQ_PLAN_ID02'


#######################################################################################################
# データ構築処理
#######################################################################################################

# 入力項目必須チェック
def check_input_param(**context):

    # BASIC_SET_ID(基本設定ID)
    basic_set_id = context['dag_run'].conf['BASIC_SET_ID']
    logging.info(f'BASIC_SET_ID = {basic_set_id}')

    # CONTENT_TEMPLATE_ID(コンテンツテンプレートID)
    content_template_id = context['dag_run'].conf['CONTENT_TEMPLATE_ID']
    logging.info(f'CONTENT_TEMPLATE_ID = {content_template_id}')

    # TEST_DELIVERY_EMAIL(テスト配信メールアドレス(カンマ区切りで複数指定可))
    test_delivery_email = context['dag_run'].conf['TEST_DELIVERY_EMAIL']

    # 数字判定(基本設定ID)
    if re.fullmatch('[0-9]+', basic_set_id) == None:
        raise Exception("BASIC_SET_ID(基本設定ID)に半角数字以外が含まれています。")

    # 数字判定(コンテンツテンプレートID)
    if re.fullmatch('[0-9]+', content_template_id) == None:
        raise Exception("CONTENT_TEMPLATE_ID(コンテンツテンプレートID)に半角数字以外が含まれています。")

    # 未設定判定(テスト配信メールアドレス)
    if not test_delivery_email:
        raise Exception("TEST_DELIVERY_EMAIL(テスト配信メールアドレス(カンマ区切りで複数指定可))が空です。")

check_trigger_dag_param = PythonOperator(
     task_id='check_trigger_dag_param',
     python_callable=check_input_param,
     provide_context=True,
     dag=dag
)

# 施策管理登録
# 施策別テスト配信メールアドレス登録
def append_test_delivery_data(**context):
    conn = None
    cursor = None
    try:
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        cursor = conn.cursor()

        #######################################################################
        # SQL実行：シーケンス番号取得
        #######################################################################
        query = f"""
                    SELECT SEQ_NO FROM {REDSHIFT_SCHEMA}.M_IMS_SEQUENCE WHERE SEQ_NAME = '{SEQUENCE_ID}';
                """
        logging.info(cursor.query)
        cursor.execute(query)

        # fetchoneでデータを取得
        result = cursor.fetchone()
        sequence_no = result[0]

        #######################################################################
        # SQL実行：施策管理登録
        #######################################################################

        # Trigger DAGのJSON設定値
        basic_set_id = context['dag_run'].conf['BASIC_SET_ID']       # 基本設定ID
        content_template_id = context['dag_run'].conf['CONTENT_TEMPLATE_ID'] # コンテンツテンプレートID
        test_delivery_email = context['dag_run'].conf['TEST_DELIVERY_EMAIL'] # テスト配信メールアドレス(カンマ区切りで複数指定可)

        query = f"""
                    INSERT INTO {REDSHIFT_SCHEMA}.T_IMS_PLAN_MNG
                    (
                      PLAN_ID
                      , PLAN_CLASS_CD
                      , TEST_DELIVERY_STATUS_CD
                      , TEST_DELIVERY_TM
                      , BASIC_SET_ID
                      , MAILFROM
                      , REPLYTO
                      , TEST_DELIVERY_ADD_EMAIL
                      , CONTENT_TEMPLATE_ID
                      , SUBJECT
                      , BODY_FORMAT
                      , BODY
                      , DELETE_FLG
                      , INS_PGM_ID
                      , INS_DT_TM
                      , UPD_PGM_ID
                      , UPD_DT_TM
                    )
                    SELECT
                      %s
                      , '3'    --メール固定配信
                      , '020'  -- テスト配信中
                      , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
                      , %s
                      , T1.MAILFROM
                      , T1.REPLYTO
                      , %s
                      , %s
                      , T2.SUBJECT
                      , T2.BODY_FORMAT
                      , T2.BODY
                      , '0'
                      , %s
                      , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
                      , %s
                      , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
                    FROM
                      {REDSHIFT_SCHEMA}.M_IMS_CM_BASIC_SET_MNG T1,
                      {REDSHIFT_SCHEMA}.M_IMS_CONTENT_TEMPLATE_MNG T2
                    WHERE
                      T1.BASIC_SET_ID = %s
                      AND T2.CONTENT_TEMPLATE_ID = %s;
                """
        cursor.execute(query, (sequence_no, basic_set_id, test_delivery_email, content_template_id, dag.dag_id, dag.dag_id, basic_set_id, content_template_id))

        #######################################################################
        # SQL実行：施策別テスト配信メールアドレス登録
        #######################################################################
        query = f"""
                    INSERT INTO {REDSHIFT_SCHEMA}.T_IMS_PLAN_TEST_DELIVERY_EMAIL
                    (
                      PLAN_ID
                      , PLAN_CLASS_CD
                      , EMAIL
                      , INS_PGM_ID
                      , INS_DT_TM
                      , UPD_PGM_ID
                      , UPD_DT_TM
                    )
                    SELECT
                      %s
                      , '3'
                      , T1.EMAIL
                      , %s
                      , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
                      , %s
                      , CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())
                    FROM
                      (
                        SELECT
                          SPLIT_PART(%s, ',', (ROW_NUMBER() OVER ())::INTEGER) AS EMAIL
                        FROM
                          SVV_TABLE_INFO
                      ) T1
                    WHERE
                      T1.EMAIL != '';
                """
        cursor.execute(query, (sequence_no, dag.dag_id, dag.dag_id, test_delivery_email))

        #######################################################################
        # SQL実行：シーケンス番号更新
        #######################################################################
        query = f"""
                    UPDATE {REDSHIFT_SCHEMA}.M_IMS_SEQUENCE SET SEQ_NO = SEQ_NO + 1 WHERE SEQ_NAME = '{SEQUENCE_ID}';
                """
        logging.info(cursor.query)
        cursor.execute(query)
        conn.commit()
    except Exception as e:
        logging.error(f'*** append_test_delivery_data_main Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

append_test_delivery_data_main = PythonOperator(
     task_id='append_test_delivery_data_main',
     python_callable=append_test_delivery_data,
     provide_context=True,
     dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_trigger_dag_param >> append_test_delivery_data_main
