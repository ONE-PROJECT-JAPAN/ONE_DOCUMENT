import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,20,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_bb', # DAG名
    default_args=default_args,
    description='法人販売システム(BB)のBigQuery連携',
    schedule_interval='20 7 * * *', # 毎日07時20分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn') 
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# 法人販売システム(BB)のデータ構築

check_impr_bb_to_ims_1 = ExternalTaskSensor(
    task_id='check_impr_bb_to_ims_1',
    external_dag_id='impr_bb_to_ims_1',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=80), # 06時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=1200,      #20分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=40), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=1200,      #20分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    法人契約者リスト情報
    """
    redshift_to_bigquery_t_bb_agreement_list = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_bb_agreement_list',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_bb_agreement_list.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BB_AGREEMENT_LIST',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    法人契約者リスト情報(For Office用)
    """
    redshift_to_bigquery_t_bb_agreement_list_for_office = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_bb_agreement_list_for_office',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_bb_agreement_list_for_office.sql',
        bigquery_dataset='ims_for_office',
        bigquery_table='T_BB_AGREEMENT_LIST',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_bb_agreement_list_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_bb_agreement_list_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BB_AGREEMENT_LIST_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_BB_AGREEMENT_LIST_ACCUM.sql'
    )

    bq_update_t_bb_agreement_list_accum_for_office = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_bb_agreement_list_accum_for_office',
        bigquery_dataset='ims_for_office',
        bigquery_table='T_BB_AGREEMENT_LIST_ACCUM',
        is_table_update_mng=False,
        execute_query='sql/bigquery/execute/UPD__T_BB_AGREEMENT_LIST_ACCUM_FOR_OFFICE.sql'
    )

    bq_append_t_bb_user_id_daily_rp_service_rpt_agreement_list_ss = bigquery_executor(
        dag=dag,
        group_id='bq_append_t_bb_user_id_daily_rp_service_rpt_agreement_list_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS',
        execute_query='sql/bigquery/execute/UPD__T_BB_USER_ID_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS.sql'
    )

    bq_append_t_bb_user_num_daily_rp_service_rpt_agreement_list_ss = bigquery_executor(
        dag=dag,
        group_id='bq_append_t_bb_user_num_daily_rp_service_rpt_agreement_list_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BB_USER_NUM_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS',
        execute_query='sql/bigquery/execute/UPD__T_BB_USER_NUM_DAILY_RP_SERVICE_RPT_AGREEMENT_LIST_SS.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_bb_to_ims_1 ] >> redshift_to_bigquery_t_bb_agreement_list
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_bb_to_ims_1 ] >> redshift_to_bigquery_t_bb_agreement_list_for_office
redshift_to_bigquery_t_bb_agreement_list >> bq_update_t_bb_agreement_list_accum >> done_all_task_for_check
redshift_to_bigquery_t_bb_agreement_list >> bq_append_t_bb_user_id_daily_rp_service_rpt_agreement_list_ss >> bq_append_t_bb_user_num_daily_rp_service_rpt_agreement_list_ss >> done_all_task_for_check
redshift_to_bigquery_t_bb_agreement_list_for_office >> bq_update_t_bb_agreement_list_accum_for_office >> done_all_task_for_check
