import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,45,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='exec_bigquery_t_ims_user_num_daily_service_kbn_ss', # DAG名
    default_args=default_args,
    description='会員数日別サービス別区分別スナップショット',
    schedule_interval='45 8 * * *', # 毎日 8:45(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS'

#######################################################################################################
# データ構築処理
#######################################################################################################

check_redshift_to_bigquery_d_ims_nikkei_member_no_list = ExternalTaskSensor(
    task_id='check_redshift_to_bigquery_d_ims_nikkei_member_no_list',
    external_dag_id='trns_replace_d_ims_nikkei_member_no_list',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=65),
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_redshift_to_bigquery_m_ad_nikkei_id = ExternalTaskSensor(
    task_id='check_redshift_to_bigquery_m_ad_nikkei_id',
    external_dag_id='trns_replace_m_ad_nikkei_id',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=90),
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_redshift_to_bigquery_m_is_nx_migration = ExternalTaskSensor(
    task_id='check_redshift_to_bigquery_m_is_nx_migration',
    external_dag_id='send_bigquery_is',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=105),
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_redshift_to_bigquery_t_bpp_v_user_service_all = ExternalTaskSensor(
    task_id='check_redshift_to_bigquery_t_bpp_v_user_service_all',
    external_dag_id='impr_bpp_to_ims',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=225),
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

#
# BigQueryテーブル操作
#
with dag:
    append_t_ims_user_num_daily_service_kbn_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_ims_user_num_daily_service_kbn_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS',
        execute_query='sql/bigquery/execute/UPD__T_IMS_USER_NUM_DAILY_SERVICE_KBN_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

[ check_redshift_to_bigquery_d_ims_nikkei_member_no_list, 
  check_redshift_to_bigquery_m_ad_nikkei_id,
  check_redshift_to_bigquery_m_is_nx_migration,
  check_redshift_to_bigquery_t_bpp_v_user_service_all
] >> append_t_ims_user_num_daily_service_kbn_ss >> done_all_task_for_check
