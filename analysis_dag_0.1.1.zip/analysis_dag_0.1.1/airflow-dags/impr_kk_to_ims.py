import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_kk_to_ims', # DAG名
    default_args=default_args,
    description='日経ID課金・決済システム(KK)のデータ構築',
    schedule_interval='30 5 * * *', # 毎日05時30分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 契約情報分析VIEWデータロード 

s3_to_redshift_t_kk_v_contract_analyze = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_contract_analyze',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_CONTRACT_ANALYZE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 契約情報分析VIEWデータ蓄積

s3_to_redshift_t_kk_v_contract_analyze_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_contract_analyze_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_CONTRACT_ANALYZE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_ID_INTERNAL_MEMBER_NO', 'RP_ID', 'SERVICE_ID', 'CONTRACT_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_V_CONTRACT_ANALYZE_ACCUM',
    },
    dag=dag
)

# 外部サービス認可マッピングVIEWデータロード 

s3_to_redshift_t_kk_v_external_service_permit_mapping = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_external_service_permit_mapping',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_EXTERNAL_SERVICE_PERMIT_MAPPING',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# お試し施策データロード 

s3_to_redshift_m_kk_m_trial_campaign = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_trial_campaign',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_TRIAL_CAMPAIGN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# お試し施策適用VIEWデータロード

s3_to_redshift_t_kk_v_trial_campaign_apply = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_trial_campaign_apply',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_TRIAL_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# お試し施策適用VIEWデータ蓄積

s3_to_redshift_t_kk_v_trial_campaign_apply_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_trial_campaign_apply_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_TRIAL_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'TRIAL_CAMPAIGN_MANAGEMENT_NO', 'NIKKEI_ID_INTERNAL_MEMBER_NO', 'RP_ID', 'SERVICE_ID', 'PLAN_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_V_TRIAL_CAMPAIGN_APPLY_ACCUM',
    },
    dag=dag
)

# サービスマスタデータロード

s3_to_redshift_m_kk_m_service = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_service',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# プランマスタデータロード

s3_to_redshift_m_kk_m_plan = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_plan',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_PLAN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# ユーザマスタデータロード

s3_to_redshift_m_kk_m_customer = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_customer',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_CUSTOMER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# ユーザマスタ蓄積

s3_to_redshift_m_kk_m_customer_accum = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_customer_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_CUSTOMER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_ID_INTERNAL_MEMBER_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_KK_M_CUSTOMER_ACCUM',
    },
    dag=dag
)

# 解約アンケートデータロード

s3_to_redshift_t_kk_t_close_enquete = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_close_enquete',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CLOSE_ENQUETE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 解約アンケートデータ蓄積

s3_to_redshift_t_kk_t_close_enquete_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_close_enquete_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CLOSE_ENQUETE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'ENQUETE_ID', 'ENQUETE_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_CLOSE_ENQUETE_ACCUM',
    },
    dag=dag
)

# 契約データロード

s3_to_redshift_t_kk_t_contract = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_contract',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CONTRACT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 契約データ蓄積

s3_to_redshift_t_kk_t_contract_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_contract_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CONTRACT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_CONTRACT_ACCUM',
    },
    dag=dag
)

# キー商品セット割引結果VIEWデータロード

s3_to_redshift_t_kk_v_set_discount_result = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_set_discount_result',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_SET_DISCOUNT_RESULT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 割引クーポン施策データロード

s3_to_redshift_m_kk_m_coupon_campaign = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_coupon_campaign',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_COUPON_CAMPAIGN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 当月カードＮＧ一覧情報VIEWデータロード

s3_to_redshift_t_kk_v_present_month_card_ng_list = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_present_month_card_ng_list',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_PRESENT_MONTH_CARD_NG_LIST',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 契約履歴情報分析VIEWデータロード

s3_to_redshift_t_kk_v_contract_history_analyze = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_contract_history_analyze',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_CONTRACT_HISTORY_ANALYZE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 契約履歴情報分析VIEW蓄積

s3_to_redshift_t_kk_v_contract_history_analyze_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_contract_history_analyze_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_CONTRACT_HISTORY_ANALYZE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_ID_INTERNAL_MEMBER_NO', 'RP_ID', 'SERVICE_ID', 'PLAN_ID', 'CONTRACT_NO', 'REQUEST_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_V_CONTRACT_HISTORY_ANALYZE_ACCUM',
    },
    dag=dag
)

# 割引クーポン施策適用VIEWデータロード

s3_to_redshift_t_kk_v_coupon_campaign_apply = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_coupon_campaign_apply',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_COUPON_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 割引クーポン施策適用VIEW蓄積

s3_to_redshift_t_kk_v_coupon_campaign_apply_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_coupon_campaign_apply_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_COUPON_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'COUPON_CAMPAIGN_MANAGEMENT_NO', 'NIKKEI_ID_INTERNAL_MEMBER_NO', 'RP_ID', 'SERVICE_ID', 'PLAN_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_V_COUPON_CAMPAIGN_APPLY_ACCUM',
    },
    dag=dag
)

# お試し対象サービスデータロード

s3_to_redshift_m_kk_m_trial_service = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_trial_service',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_TRIAL_SERVICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# RPマスタデータロード

s3_to_redshift_m_kk_m_rp = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_rp',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_RP',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 割引クーポン価格データ抽出・ロードデータロード

s3_to_redshift_m_kk_m_coupon_price = PythonOperator(
    task_id='s3_to_redshift_m_kk_m_coupon_price',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'M_KK_M_COUPON_PRICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 無料体験クーポン施策適用VIEWデータ抽出・ロードデータロード

s3_to_redshift_t_kk_v_free_coupon_campaign_apply = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_free_coupon_campaign_apply',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_FREE_COUPON_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 無料体験クーポン施策適用データ蓄積

s3_to_redshift_t_kk_v_free_coupon_campaign_apply_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_v_free_coupon_campaign_apply_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_V_FREE_COUPON_CAMPAIGN_APPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'FREE_COUPON_CAMPAIGN_MANAGEMENT_NO', 'NIKKEI_ID_INTERNAL_MEMBER_NO', 'RP_ID', 'SERVICE_ID', 'PLAN_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_V_FREE_COUPON_CAMPAIGN_APPLY_ACCUM',
    },
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_kk_v_contract_analyze >> s3_to_redshift_t_kk_v_contract_analyze_accum >> done_all_task_for_check
s3_to_redshift_t_kk_v_external_service_permit_mapping >> done_all_task_for_check
s3_to_redshift_m_kk_m_trial_campaign >> done_all_task_for_check
s3_to_redshift_t_kk_v_trial_campaign_apply >> s3_to_redshift_t_kk_v_trial_campaign_apply_accum >> done_all_task_for_check
s3_to_redshift_m_kk_m_service >> done_all_task_for_check
s3_to_redshift_m_kk_m_plan >> done_all_task_for_check
s3_to_redshift_m_kk_m_customer >> s3_to_redshift_m_kk_m_customer_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_close_enquete >> s3_to_redshift_t_kk_t_close_enquete_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_contract >> s3_to_redshift_t_kk_t_contract_accum >> done_all_task_for_check
s3_to_redshift_t_kk_v_set_discount_result >> done_all_task_for_check
s3_to_redshift_m_kk_m_coupon_campaign >> done_all_task_for_check
s3_to_redshift_t_kk_v_present_month_card_ng_list >> done_all_task_for_check
s3_to_redshift_t_kk_v_contract_history_analyze >> s3_to_redshift_t_kk_v_contract_history_analyze_accum >> done_all_task_for_check
s3_to_redshift_t_kk_v_coupon_campaign_apply >> s3_to_redshift_t_kk_v_coupon_campaign_apply_accum >> done_all_task_for_check
s3_to_redshift_m_kk_m_trial_service >> done_all_task_for_check
s3_to_redshift_m_kk_m_rp >> done_all_task_for_check
s3_to_redshift_m_kk_m_coupon_price >> done_all_task_for_check
s3_to_redshift_t_kk_v_free_coupon_campaign_apply >> s3_to_redshift_t_kk_v_free_coupon_campaign_apply_accum >> done_all_task_for_check
