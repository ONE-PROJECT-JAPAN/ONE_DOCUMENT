import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_hk', # DAG名
    default_args=default_args,
    description='購読センターシステム(HK)のBigQuery連携',
    schedule_interval='0 7 * * *', # 毎日7時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# 購読センターシステム(HK)のデータ構築

check_impr_hk_to_ims = ExternalTaskSensor(
    task_id='check_impr_hk_to_ims',
    external_dag_id='impr_hk_to_ims',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=480), # 23時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=20), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3000,      #50分
    retries=0,
    dag=dag
)

#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    区域
    """
    redshift_to_bigquery_m_hk_area = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_area',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_area.sql',
        bigquery_dataset='domo',
        bigquery_table='M_HK_AREA',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    販売店
    """
    redshift_to_bigquery_m_hk_store = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_store',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_store.sql',
        bigquery_dataset='domo',
        bigquery_table='M_HK_STORE',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    住所マスタ
    """
    redshift_to_bigquery_m_hk_address = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_address',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_address.sql',
        bigquery_dataset='domo',
        bigquery_table='M_HK_ADDRESS',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    読者基本情報（紙課金システム連携用）
    """
    redshift_to_bigquery_t_hk_basic_info_pk_user = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_basic_info_pk_user',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_basic_info_pk_user.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_BASIC_INFO_PK_USER',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    購読申込基本情報（紙課金システム連携用）
    """
    redshift_to_bigquery_t_hk_basic_info_pk_subscription = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_basic_info_pk_subscription',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_basic_info_pk_subscription.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_BASIC_INFO_PK_SUBSCRIPTION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    申込媒体（紙課金システム連携用）
    """
    redshift_to_bigquery_m_hk_pk_subscription_baitai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_pk_subscription_baitai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_pk_subscription_baitai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_PK_SUBSCRIPTION_BAITAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    都道府県
    """
    redshift_to_bigquery_m_hk_prefecture = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_prefecture',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_prefecture.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_PREFECTURE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    市区町村
    """
    redshift_to_bigquery_m_hk_shikutyouson = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_shikutyouson',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_shikutyouson.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_SHIKUTYOUSON',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    住所テリトリ
    """
    redshift_to_bigquery_m_hk_address_territory = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_address_territory',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_address_territory.sql',
        bigquery_dataset='domo',
        bigquery_table='M_HK_ADDRESS_TERRITORY',
        is_table_update_mng=False,
        bigquery_additional_sql=None
    )

    """
    販売店取扱媒体
    """
    redshift_to_bigquery_m_hk_store_treatment_baitai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_store_treatment_baitai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_store_treatment_baitai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_STORE_TREATMENT_BAITAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    店主販売店
    """
    redshift_to_bigquery_m_hk_owner_store = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_owner_store',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_owner_store.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_OWNER_STORE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    系統
    """
    redshift_to_bigquery_m_hk_keito = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_keito',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_keito.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_KEITO',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    販売方法
    """
    redshift_to_bigquery_m_hk_sales_method = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_sales_method',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_sales_method.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_SALES_METHOD',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    販売店備考
    """
    redshift_to_bigquery_m_hk_store_remark = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_store_remark',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_store_remark.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_STORE_REMARK',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    謝礼品
    """
    redshift_to_bigquery_m_hk_sharei = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_sharei',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_sharei.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_SHAREI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    崩れ理由（リファレンス）
    """
    redshift_to_bigquery_m_hk_break_ryu_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_break_ryu_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_break_ryu_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_BREAK_RYU_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    アプローチ方法（リファレンス）
    """
    redshift_to_bigquery_m_hk_approach_method_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_approach_method_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_approach_method_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_APPROACH_METHOD_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    販売店拡張結果（リファレンス）
    """
    redshift_to_bigquery_m_hk_store_extend_result_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_store_extend_result_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_store_extend_result_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_STORE_EXTEND_RESULT_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    テレマ拡張結果（リファレンス）
    """
    redshift_to_bigquery_m_hk_telema_extend_result_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_telema_extend_result_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_telema_extend_result_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_TELEMA_EXTEND_RESULT_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    コメント（リファレンス）
    """
    redshift_to_bigquery_m_hk_comment_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_comment_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_comment_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_COMMENT_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    購読崩れ情報
    """
    redshift_to_bigquery_t_hk_subscription_break = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_subscription_break',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_subscription_break.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_SUBSCRIPTION_BREAK',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    前回割り当て
    """
    redshift_to_bigquery_t_hk_last_allocation = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_last_allocation',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_last_allocation.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_LAST_ALLOCATION',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    住所テリトリ削除情報
    """
    redshift_to_bigquery_t_hk_address_territory_delete = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_address_territory_delete',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_address_territory_delete.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_ADDRESS_TERRITORY_DELETE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    移転取消
    """
    redshift_to_bigquery_t_hk_move_cn = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_move_cn',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_move_cn.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_MOVE_CN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    連動サイト
    """
    redshift_to_bigquery_m_hk_linkage_site = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_linkage_site',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_linkage_site.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_LINKAGE_SITE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    キャンペーン変換
    """
    redshift_to_bigquery_m_hk_camp_convert = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_camp_convert',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_camp_convert.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_CAMP_CONVERT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    アンケート
    """
    redshift_to_bigquery_m_hk_enq = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_enq',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_enq.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_ENQ',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    アンケート項目
    """
    redshift_to_bigquery_m_hk_enq_item = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_enq_item',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_enq_item.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_ENQ_ITEM',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    申込IDリンク
    """
    redshift_to_bigquery_m_hk_subscription_id_link = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_subscription_id_link',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_subscription_id_link.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_SUBSCRIPTION_ID_LINK',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    WEB系統
    """
    redshift_to_bigquery_m_hk_web_keito = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_web_keito',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_web_keito.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_WEB_KEITO',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    系統変換
    """
    redshift_to_bigquery_m_hk_keito_convert = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_keito_convert',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_keito_convert.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_KEITO_CONVERT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    担当部署
    """
    redshift_to_bigquery_m_hk_charge_department = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_charge_department',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_charge_department.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_CHARGE_DEPARTMENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    キャンペーンアンケート
    """
    redshift_to_bigquery_m_hk_camp_enq = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_camp_enq',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_camp_enq.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_CAMP_ENQ',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    キャンペーンアンケート項目
    """
    redshift_to_bigquery_m_hk_camp_enq_item = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_camp_enq_item',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_camp_enq_item.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_CAMP_ENQ_ITEM',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    チラシ配布区分
    """
    redshift_to_bigquery_m_hk_flyer_distribution_kbn = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_flyer_distribution_kbn',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_flyer_distribution_kbn.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_FLYER_DISTRIBUTION_KBN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    苦情大分類（リファレンス）
    """
    redshift_to_bigquery_m_hk_complaint_category_l_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_complaint_category_l_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_complaint_category_l_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_COMPLAINT_CATEGORY_L_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    苦情小分類（リファレンス）
    """
    redshift_to_bigquery_m_hk_complaint_category_s_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_complaint_category_s_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_complaint_category_s_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_COMPLAINT_CATEGORY_S_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    苦情申込口（リファレンス）
    """
    redshift_to_bigquery_m_hk_complaint_subscript_method_ref = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_complaint_subscript_method_ref',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_complaint_subscript_method_ref.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_COMPLAINT_SUBSCRIPT_METHOD_REF',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    苦情内容
    """
    redshift_to_bigquery_t_hk_complaint_content = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_complaint_content',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_complaint_content.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_COMPLAINT_CONTENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    苦情内容媒体
    """
    redshift_to_bigquery_t_hk_complaint_content_baitai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_hk_complaint_content_baitai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_hk_complaint_content_baitai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_HK_COMPLAINT_CONTENT_BAITAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    謝礼品対象媒体
    """
    redshift_to_bigquery_m_hk_sharei_target_baitai = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_sharei_target_baitai',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_sharei_target_baitai.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_SHAREI_TARGET_BAITAI',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    大口事業所マスタ
    """
    redshift_to_bigquery_m_hk_prime_office = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_hk_prime_office',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_hk_prime_office.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_HK_PRIME_OFFICE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_area >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_store >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_basic_info_pk_user >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_basic_info_pk_subscription >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_pk_subscription_baitai >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_prefecture >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_shikutyouson >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_address_territory >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_store_treatment_baitai >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_owner_store >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_keito >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_sales_method >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_store_remark >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_sharei >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_break_ryu_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_approach_method_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_store_extend_result_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_telema_extend_result_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_comment_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_subscription_break >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_last_allocation >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_address_territory_delete >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_move_cn >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_linkage_site >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_camp_convert >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_enq >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_enq_item >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_subscription_id_link >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_web_keito >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_keito_convert >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_charge_department >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_camp_enq >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_camp_enq_item >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_flyer_distribution_kbn >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_complaint_category_l_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_complaint_category_s_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_complaint_subscript_method_ref >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_complaint_content >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_t_hk_complaint_content_baitai >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_sharei_target_baitai >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_prime_office >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_hk_to_ims] >> redshift_to_bigquery_m_hk_address >> done_all_task_for_check
