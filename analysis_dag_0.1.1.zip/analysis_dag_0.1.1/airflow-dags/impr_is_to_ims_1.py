import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import \
    S3DeleteObjectsOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from common_ims import batch
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims.redshift_loader import invoke_redshift_loader

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,6,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_is_to_ims_1', # DAG名
    default_args=default_args,
    description='新日経ID会員システム(IS)のデータ構築',
    schedule_interval='40 6 * * *', # 毎日06時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')


#######################################################################################################
# データ構築処理
#######################################################################################################

# 共通属性テーブルデータロード 

s3_to_redshift_m_is_nx_attribute_if = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_attribute_if',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_ATTRIBUTE_IF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 移行テーブルデータロード 

s3_to_redshift_m_is_nx_migration = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_migration',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_MIGRATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# RP利用状態テーブルデータロード 

s3_to_redshift_m_is_nx_rp_registration = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_rp_registration',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_RP_REGISTRATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# シリアルIDテーブルデータロード 

s3_to_redshift_m_is_nx_user_serial_id = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_serial_id',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_SERIAL_ID',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ユーザ付属情報管理テーブルデータロード

s3_to_redshift_m_is_nx_user_attachment = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_attachment',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_ATTACHMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# ユーザ付属情報管理テーブル蓄積

s3_to_redshift_m_is_nx_user_attachment_accum = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_attachment_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_ATTACHMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'C_LOCAL_USER_ID', 'CATEGORY', 'KEY' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_IS_NX_USER_ATTACHMENT_ACCUM',
    },
    dag=dag
)

# コードマスタテーブルデータロード 

s3_to_redshift_m_is_mm_code = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_code',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_CODE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 居住国マスタテーブルデータロード 

s3_to_redshift_m_is_mm_country = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_country',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_COUNTRY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 住所マスタテーブルデータロード 

s3_to_redshift_m_is_mm_address = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_address',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_ADDRESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 職業マスタテーブルデータロード 

s3_to_redshift_m_is_mm_occupation = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_occupation',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_OCCUPATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 業種マスタテーブルデータロード 

s3_to_redshift_m_is_mm_business = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_business',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_BUSINESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 職種マスタテーブルデータロード 

s3_to_redshift_m_is_mm_job = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_job',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_JOB',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 役職マスタテーブルデータロード 

s3_to_redshift_m_is_mm_position = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_position',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_POSITION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# オープン化ユーザID管理テーブルデータロード 

s3_to_redshift_m_is_ox_user = PythonOperator(
    task_id='s3_to_redshift_m_is_ox_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_OX_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 都道府県マスタテーブルデータロード

s3_to_redshift_m_is_mm_prefecture = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_prefecture',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_PREFECTURE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 新聞購読状況マスタテーブルデータロード

s3_to_redshift_m_is_mm_subscription = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 興味関心項目マスタテーブルデータロード

s3_to_redshift_m_is_mm_interest = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_interest',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_INTEREST',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 法人形態マスタテーブルデータロード

s3_to_redshift_m_is_mm_corporation_type = PythonOperator(
    task_id='s3_to_redshift_m_is_mm_corporation_type',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_MM_CORPORATION_TYPE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# RPマスタテーブルデータロード

s3_to_redshift_m_is_t_rp_master = PythonOperator(
    task_id='s3_to_redshift_m_is_t_rp_master',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_T_RP_MASTER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 追加属性（文字列）テーブルデータロード

s3_to_redshift_m_is_nx_additional_attr_text = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_additional_attr_text',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_ADDITIONAL_ATTR_TEXT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 法人属性テーブルデータロード

s3_to_redshift_m_is_nx_user_company = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_company',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_COMPANY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 法人属性テーブルデータ蓄積

s3_to_redshift_m_is_nx_user_company_accum = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_company_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_COMPANY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'USER_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_IS_NX_USER_COMPANY_ACCUM',
    },
    dag=dag
)

# ストアトークンテーブルデータロード

s3_to_redshift_m_is_nx_user_store_token = PythonOperator(
    task_id='s3_to_redshift_m_is_nx_user_store_token',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'M_IS_NX_USER_STORE_TOKEN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 共通属性テーブル母数データスナップショット 

replace_m_is_nx_attribute = PostgresOperator(
    task_id='replace_m_is_nx_attribute',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_nx_attribute.sql',
    autocommit=False,
    dag=dag
)

#  共通属性テーブル母数データ蓄積

update_m_is_nx_attribute_accum = PostgresOperator(
    task_id='update_m_is_nx_attribute_accum',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_nx_attribute_accum.sql',
    autocommit=False,
    dag=dag
)

#  オープン化ユーザーID管理テーブルデータ蓄積

update_m_is_ox_user_accum = PostgresOperator(
    task_id='update_m_is_ox_user_accum',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_ox_user_accum.sql',
    autocommit=False,
    dag=dag
)

# バックエンド認証テーブルデータロード 

s3_to_redshift_t_is_t_backend_user = PythonOperator(
    task_id='s3_to_redshift_t_is_t_backend_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'is',
        'redshift_loader_table_name': 'T_IS_T_BACKEND_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

#######################################################################################################
# 共通属性テーブル母数データ蓄積からクレンジング対象データをS3へ出力
#######################################################################################################

CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_BF = 'app/cleansing/M_IS_NX_ATTRIBUTE_ACCUM'
CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_AF = 'app/cleansing/M_IS_NX_ATTRIBUTE_ACCUM_CL'
CLEANSIMG_PATH_M_IS_NX_ATTRIBUTE_ACCUM_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_BF}'
CLEANSIMG_PATH_M_IS_NX_ATTRIBUTE_ACCUM_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_AF}'

redshift_to_s3_m_is_nx_attribute_accum = PostgresOperator(
    task_id='redshift_to_s3_m_is_nx_attribute_accum',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_nx_attribute_accum4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 共通属性テーブルデータクレンジング

cleanse_m_is_nx_attribute_accum = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_is_nx_attribute_accum",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_IS_NX_ATTRIBUTE_ACCUM_BF,
        CLEANSIMG_PATH_M_IS_NX_ATTRIBUTE_ACCUM_AF,
        "-colNo", "15",
        "-address", "{6}",
        "-postcode", "{4},{12}",
        "-name", "{2,3},{11}",
        "-telno", "{10},{14}",
    ]
)

# 共通属性テーブルデータクレンジング・蓄積

update_m_is_nx_attribute_accum_cl_ac = PostgresOperator(
    task_id='update_m_is_nx_attribute_accum_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_nx_attribute_accum_cl_ac.sql',
    autocommit=False,
    dag=dag
)


# S3ファイル削除(共通属性テーブルデータクレンジング)

delete_from_s3_m_is_nx_attribute_accum_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_is_nx_attribute_accum_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_BF + '/',
    dag=dag
)

delete_from_s3_m_is_nx_attribute_accum_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_is_nx_attribute_accum_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_IS_NX_ATTRIBUTE_ACCUM_AF + '/',
    dag=dag
)

#######################################################################################################
# 住所マスタ クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_M_IS_MM_ADDRESS_BF = 'app/cleansing/M_IS_MM_ADDRESS'
CL_FILE_M_IS_MM_ADDRESS_AF = 'app/cleansing/M_IS_MM_ADDRESS_CL'
CLEANSIMG_PATH_M_IS_MM_ADDRESS_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_IS_MM_ADDRESS_BF}'
CLEANSIMG_PATH_M_IS_MM_ADDRESS_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_IS_MM_ADDRESS_AF}'

# 住所マスタ（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_m_is_mm_address_temp = PostgresOperator(
    task_id='redshift_to_s3_m_is_mm_address_temp',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_mm_address_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 住所マスタクレンジング

cleanse_m_is_mm_address = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_is_mm_address",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_IS_MM_ADDRESS_BF,
        CLEANSIMG_PATH_M_IS_MM_ADDRESS_AF,
        "-colNo", "4",
        "-address", "{3}",
        "-postcode", "{2}",
    ]
)

# 住所マスタクレンジング蓄積(一時テーブルの削除含む)

update_m_is_mm_address_cl_ac = PostgresOperator(
    task_id='update_m_is_mm_address_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/is/m_is_mm_address_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(住所マスタデータクレンジング)

delete_from_s3_m_is_mm_address_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_is_mm_address_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_IS_MM_ADDRESS_BF + '/',
    dag=dag
)

delete_from_s3_m_is_mm_address_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_is_mm_address_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_IS_MM_ADDRESS_AF + '/',
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_m_is_nx_user_serial_id >> done_all_task_for_check
s3_to_redshift_m_is_nx_attribute_if >> replace_m_is_nx_attribute >> update_m_is_nx_attribute_accum >> redshift_to_s3_m_is_nx_attribute_accum >> cleanse_m_is_nx_attribute_accum 
s3_to_redshift_m_is_nx_migration >> done_all_task_for_check
s3_to_redshift_m_is_nx_rp_registration >> done_all_task_for_check
s3_to_redshift_m_is_nx_user_attachment >> s3_to_redshift_m_is_nx_user_attachment_accum >> done_all_task_for_check
s3_to_redshift_m_is_mm_code >> done_all_task_for_check
s3_to_redshift_m_is_mm_country >> done_all_task_for_check
s3_to_redshift_m_is_mm_occupation >> done_all_task_for_check
s3_to_redshift_m_is_mm_business >> done_all_task_for_check
s3_to_redshift_m_is_mm_job >> done_all_task_for_check
s3_to_redshift_m_is_mm_position >> done_all_task_for_check
s3_to_redshift_m_is_ox_user >> update_m_is_ox_user_accum >> done_all_task_for_check
[s3_to_redshift_m_is_mm_address, cleanse_m_is_nx_attribute_accum] >> update_m_is_nx_attribute_accum_cl_ac >> [delete_from_s3_m_is_nx_attribute_accum_bf, delete_from_s3_m_is_nx_attribute_accum_af] >> done_all_task_for_check
s3_to_redshift_m_is_mm_prefecture >> done_all_task_for_check
s3_to_redshift_m_is_mm_subscription >> done_all_task_for_check
s3_to_redshift_m_is_mm_interest >> done_all_task_for_check
s3_to_redshift_m_is_mm_corporation_type >> done_all_task_for_check
s3_to_redshift_m_is_t_rp_master >> done_all_task_for_check
s3_to_redshift_m_is_nx_additional_attr_text >> done_all_task_for_check
s3_to_redshift_m_is_nx_user_company >> s3_to_redshift_m_is_nx_user_company_accum >> done_all_task_for_check
s3_to_redshift_m_is_nx_user_store_token >> done_all_task_for_check
s3_to_redshift_m_is_mm_address >> redshift_to_s3_m_is_mm_address_temp >> cleanse_m_is_mm_address >> update_m_is_mm_address_cl_ac >> [delete_from_s3_m_is_mm_address_bf, delete_from_s3_m_is_mm_address_af] >> done_all_task_for_check
s3_to_redshift_t_is_t_backend_user >> done_all_task_for_check
