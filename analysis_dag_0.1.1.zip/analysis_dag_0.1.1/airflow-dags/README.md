# crm-airflow-dags

## 開発の流れ
1. (必要な場合) `s3://nikkei-crm-airflow2-dev/dags/sandbox/` 下に DAG を配置し、dev 環境で動作を確認する。一定期間の経過後に自動的に削除されるので注意。
2. `main` ブランチに向けて pull request を出す。
3. マージされたら dev 環境へデプロイされるので、動作を確認する。

## 本番反映
`main` ブランチのデプロイしたいコミットに対してタグを打った後、そのタグを指定して GitHub Actions の [airflow-dags-prod workflow](https://github.com/Nikkei/nkcrm/actions/workflows/airflow-dags-prod.yml) を実行する。

## Variables
開発環境と本番環境の DAG を共通化するため、いくつかの Variable を定義している。
Variable の使用方法については [Airflow の公式ドキュメント](https://airflow.apache.org/docs/apache-airflow/stable/concepts.html#variables) を参照。
使用できる Variable は [Airflow の Terraform ソース](https://github.com/Nikkei/crm-terraform/blob/main/modules/airflow/main.tf) 内の `airflow_variables` ローカル変数を参照。
