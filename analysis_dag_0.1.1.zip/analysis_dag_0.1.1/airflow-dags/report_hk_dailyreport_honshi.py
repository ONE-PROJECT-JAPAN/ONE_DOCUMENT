import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
import unicodedata
import boto3
import logging
import pendulum

from boto3 import Session
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from common_ims.common_util import move_file_s3_to_s3_by_full_control

####################################################################################################
# DAG
####################################################################################################
local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2020,1,1,8,30,0,tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='report_hk_dailyreport_honshi', # DAG名
    default_args=default_args,
    description='販売局日報',
    schedule_interval='30 8 * * *', # 毎日8時30分(JST)
    catchup=False
)

####################################################################################################
# Python関数
####################################################################################################

REDSHIFT_CONN_ID = 'redshift_default'
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
S3_BUCKET_NAME_TRANSFER = Variable.get('transfer_s3_bucket_name')
S3_PREFIX = 'hanbai/Hanbai/DailyReport'

NEWLINE = '\r\n'
LINE1 = '----------------------------------------------------' + NEWLINE
LINE2 = '====================================================' + NEWLINE
ROW_LABEL_LENGTH = 22
ZENKAKU_SPACE = '　'
HANKAKU_SPACE = ' '

def len_count(p_text: str) -> int:
    """
    文字列長取得
    Shift JISのため、全角文字は2バイトで計算する

    Parameters
    ----------
    p_value : T
        変換対象

    Returns
    -------
    str: 変換後文字列 (SHIFT JIS)
    """
    count = 0
    for c in p_text:
        if unicodedata.east_asian_width(c) in 'FWA':
            count += 2
        else:
            count += 1
    return count

def adjustment_zenkaku(p_text: str, p_size: int = ROW_LABEL_LENGTH) -> str:
    """
    全角スペース埋め
    * 対象文字列が指定されたサイズより小さい場合、不足分を全角スペースで埋める
    * 全角スペースで埋められない場合は半角スペースで埋める

    Parameters
    ----------
    p_text : str
        対象文字列

    Returns
    -------
    str: 全角スペース追加後文字列
    """
    result = p_text
    count = len_count(p_text=p_text)
    if count < p_size:
        diff = p_size - count
        result += ZENKAKU_SPACE * (diff // 2)
        result += HANKAKU_SPACE * (diff % 2)

    return result

def add_comma(p_text: str) -> str:
    """
    数値の文字列にカンマ追加を追加する

    Parameters
    ----------
    p_text : str
        対象文字列

    Returns
    -------
    str: カンマ追加後文字列
    """
    if p_text is None or p_text == '':
        return p_text

    return "{:,}".format(int(p_text))

def get_report_date(
    p_conn,
    p_schema: str) -> str:
    """
    レポート日付

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名

    Returns
    -------
    str: レポート日付
    """
    query = f"""SELECT REPORT_DATE FROM {p_schema}.V_XLT_HANBAI_DAILY_REPORT_DATE"""
    with p_conn.cursor() as cursor:
        cursor.execute(query)
        rec = cursor.fetchone()

    return rec[0]

def get_hon_shisha_dict(
    p_conn,
    p_schema: str) -> dict:
    """
    本支社内訳

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名

    Returns
    -------
    list: 本支社内訳データ
    """
    query = f"""SELECT
                      KBN
                    , HON_SHISHA_CD
                    , HON_SHISHA_NM
                    , SUBSCRIPTION_NUM
                    , SUBSCRIPTION_NUM_YEAR_AGO
                    , SUBSCRIPTION_NUM_DIFF_YEAR_AGO
                    , SUBSCRIPTION_NUM_MONTH_YEAR_AGO
                FROM
                    {p_schema}.V_XLT_HANBAI_DAILY_REPORT_HON_SHISHA
                ORDER BY
                      KBN
                    , HON_SHISHA_CD"""

    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchall()

        hon_shisha_dict = {}

        for rec in recs:
            kbn = rec[0]
            if kbn not in hon_shisha_dict:
                hon_shisha_dict[kbn] = []

            hon_shisha_cd = rec[1]
            hon_shisha_nm = rec[2].encode('cp932').decode('cp932')
            subscription_num = add_comma(rec[3]).rjust(6)
            subscription_num_year_ago = add_comma(rec[4]).rjust(6)
            subscription_num_diff_year_ago = add_comma(rec[5]).rjust(6)
            subscription_num_month_year_ago = add_comma(rec[6]).rjust(6)

            hon_shisha_dict[kbn].append([
                hon_shisha_cd,
                hon_shisha_nm,
                subscription_num,
                subscription_num_year_ago,
                subscription_num_diff_year_ago,
                subscription_num_month_year_ago
            ])

    return hon_shisha_dict

def get_reception_class_dict(
    p_conn,
    p_schema: str) -> dict:
    """
    受付種別内訳

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名

    Returns
    -------
    dict: 受付種別内訳データ
    """
    query = f"""SELECT
                      KBN
                    , BAITAI_CD
                    , RECEPTION_CLASS_NM
                    , SUBSCRIPTION_NUM
                    , SUBSCRIPTION_NUM_YEAR_AGO
                    , SUBSCRIPTION_NUM_DIFF_YEAR_AGO
                    , SUBSCRIPTION_NUM_MONTH_YEAR_AGO
                    , RECEPTION_CLASS_KBN
                    , SORT_ORDER
                FROM
                    {p_schema}.V_XLT_HANBAI_DAILY_REPORT_RECEPTION_CLASS
                ORDER BY
                      KBN
                    , BAITAI_CD
                    , SORT_ORDER"""

    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchall()

        reception_class_dict = {}

        for rec in recs:
            kbn = rec[0]
            baitai_cd = rec[1]
            key = f'{kbn}-{baitai_cd}'
            if key not in reception_class_dict:
                reception_class_dict[key] = []

            reception_class_nm = rec[2].encode('cp932').decode('cp932')
            subscription_num = add_comma(rec[3]).rjust(6)
            subscription_num_year_ago = add_comma(rec[4]).rjust(6)
            subscription_num_diff_year_ago = add_comma(rec[5]).rjust(6)
            subscription_num_month_year_ago = add_comma(rec[6]).rjust(6)
            reception_class_kbn = rec[7]
            sort_order = rec[8]

            reception_class_dict[key].append([
                reception_class_nm,
                subscription_num,
                subscription_num_year_ago,
                subscription_num_diff_year_ago,
                subscription_num_month_year_ago,
                reception_class_kbn,
                sort_order
            ])

    return reception_class_dict

def create_report(
    p_report_date: str,
    p_hon_shisha_dict: dict,
    p_reception_class_dict: dict) -> str:
    """
    レポート作成

    Parameters
    ----------
    p_report_date: str
        レポート日付
    p_hon_shisha_dict : dict
        本支社内訳
    p_reception_class_dict : dict
        受付種別内訳

    Returns
    -------
    str: レポート
    """
    value = f'◇申込状況（{p_report_date}合計）{NEWLINE}'
    value += LINE2
    value += f'■購読（本紙）{NEWLINE}'
    value += f'　　　　　　　　　　　申込数　前年　　前年比　前年{NEWLINE}'
    value += f'販売店集金　　　　　　　　　　申込数　　　　　同月合計{NEWLINE}'

    # KBN=1, BAITAI_CD=10
    kbn1_10_list = p_reception_class_dict['1-10']
    for item in kbn1_10_list:
        if item[5] == 'A' or item[5] == 'B' or item[5] == 'SUMA' or item[5] == 'SUMB':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += f'Ｗプラン{NEWLINE}'
    for item in kbn1_10_list:
        if item[5] == 'C' or item[5] == 'SUMC':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += f'紙課金{NEWLINE}'
    for item in kbn1_10_list:
        if item[5] == 'D' or item[5] == 'SUMD':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    for item in kbn1_10_list:
        if item[5] == 'SUMACD' or item[5] == 'SUMABCD':
            value += f'{adjustment_zenkaku(item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += LINE1
    # 本支社内訳
    value += f'本支社内訳（Ｗプラン、紙課金は未確定分を除く）{NEWLINE}'
    kbn1_list = p_hon_shisha_dict[1]
    for item in kbn1_list:
        if item[0] != 99:
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[1])}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{ZENKAKU_SPACE}{item[5]}{NEWLINE}'
        else:
            value += LINE1
            value += f'{adjustment_zenkaku(item[1])}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{ZENKAKU_SPACE}{item[5]}{NEWLINE}'

    value += LINE2
    value += f'■購読（SS）{NEWLINE}'
    value += f'　　　　　　　　　　　申込数　前年　　前年比　前年{NEWLINE}'
    value += f'販売店集金　　　　　　　　　　申込数　　　　　同月合計{NEWLINE}'

    # KBN=1, BAITAI_CD=30
    kbn1_30_list = p_reception_class_dict['1-30']
    for item in kbn1_30_list:
        if item[5] == 'A' or item[5] == 'B' or item[5] == 'SUMA' or item[5] == 'SUMB':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'
    
    value += f'紙課金{NEWLINE}'
    for item in kbn1_30_list:
        if item[5] == 'SUMD':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'
    for item in kbn1_30_list:
        if item[5] == 'SUMAD' or item[5] == 'SUMABD':
            value += f'{adjustment_zenkaku(item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += LINE1
    value += f'■購読（MJ）{NEWLINE}'
    value += f'　　　　　　　　　　　申込数　前年　　前年比　前年{NEWLINE}'
    value += f'販売店集金　　　　　　　　　　申込数　　　　　同月合計{NEWLINE}'

    # KBN=1, BAITAI_CD=40
    kbn1_40_list = p_reception_class_dict['1-40']
    for item in kbn1_40_list:
        if item[5] == 'A' or item[5] == 'B' or item[5] == 'SUMA' or item[5] == 'SUMB':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += f'紙課金{NEWLINE}'
    for item in kbn1_40_list:
        if item[5] == 'SUMD':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    for item in kbn1_40_list:
        if item[5] == 'SUMAD' or item[5] == 'SUMABD':
            value += f'{adjustment_zenkaku(item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += LINE1
    value += f'■購読（VS）{NEWLINE}'
    value += f'　　　　　　　　　　　申込数　前年　　前年比　前年{NEWLINE}'
    value += f'　　　　　　　　　　　　　　　申込数　　　　　同月合計{NEWLINE}'

    # KBN=1, BAITAI_CD=50
    kbn1_50_list = p_reception_class_dict['1-50']
    for item in kbn1_50_list:
        if item[5] == 'Z':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += LINE2
    value += f'■試読（本紙）{NEWLINE}'
    value += f'　　　　　　　　　　　申込数　前年　　前年比　前年{NEWLINE}'
    value += f'　　　　　　　　　　　　　　　申込数　　　　　同月合計{NEWLINE}'

    # KBN=2, BAITAI_CD=10
    kbn2_10_list = p_reception_class_dict['2-10']
    for item in kbn2_10_list:
        if item[5] == 'A' or item[5] == 'B' or item[5] == 'SUMA' or item[5] == 'SUMB' or item[5] == 'SUMAB':
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[0])}{item[1]}{ZENKAKU_SPACE}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{NEWLINE}'

    value += LINE1
    # 本支社内訳 試読（本紙）
    value += f'本支社内訳{NEWLINE}'
    kbn2_list = p_hon_shisha_dict[2]
    for item in kbn2_list:
        if item[0] != 99:
            value += f'{adjustment_zenkaku(ZENKAKU_SPACE+item[1])}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{ZENKAKU_SPACE}{item[5]}{NEWLINE}'
        else:
            value += LINE1
            value += f'{adjustment_zenkaku(item[1])}{item[2]}{ZENKAKU_SPACE}{item[3]}{ZENKAKU_SPACE}{item[4]}{ZENKAKU_SPACE}{item[5]}{NEWLINE}'
    value += LINE2

    value += f'{NEWLINE}※前年申込数は、前年同月の同期間の申込数合計{NEWLINE}{NEWLINE}'

    return value

def save_report_to_s3(p_report: str, p_execdate: str):
    """
    販売局日報 S3出力

    Parameters
    ----------
    p_report : str
        レポート
    p_execdate : str
        実行日

    Returns
    -------
    なし
    """
    
    s3client = Session().client('s3')

    filepath = f'app/{S3_PREFIX}/DailyReport_Honshi_{p_execdate}.txt'
    resource = boto3.resource('s3')
    obj = resource.Object(S3_BUCKET_NAME, filepath)
    obj.put(Body=f'{p_report}'.encode('cp932'))

    move_file_s3_to_s3_by_full_control(s3client, S3_BUCKET_NAME, S3_BUCKET_NAME_TRANSFER, filepath, f'{S3_PREFIX}/DailyReport_Honshi_{p_execdate}.txt')

def main(**context) -> None:
    """
    販売局日報 主処理

    Parameters
    ----------
    context: dict
        コンテキスト

    Returns
    -------
    なし
    """
    try:
        conn =  PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        exec_date = convUTC2JST(context['next_execution_date'], "%Y%m%d")
        report_date = get_report_date(p_conn=conn, p_schema=REDSHIFT_SCHEMA)
        hon_shisha_dict = get_hon_shisha_dict(p_conn=conn, p_schema=REDSHIFT_SCHEMA)
        reception_class_dict = get_reception_class_dict(p_conn=conn, p_schema=REDSHIFT_SCHEMA)

        if report_date is None:
            logging.error(f'*** main レポート日付が取得できません。')
            raise Exception("レポート日付が取得できません。")
        if hon_shisha_dict is None or len(hon_shisha_dict)==0:
            logging.error(f'*** main 本支社内訳データが取得できません。')
            raise Exception("本支社内訳データが取得できません。")
        if reception_class_dict is None or len(reception_class_dict)==0:
            logging.error(f'*** main 受付種別内訳データが取得できません。')
            raise Exception("受付種別内訳データが取得できません。")

        report = create_report(
            p_report_date=report_date,
            p_hon_shisha_dict=hon_shisha_dict,
            p_reception_class_dict=reception_class_dict
        )

        save_report_to_s3(
            p_report=report,
            p_execdate=exec_date
        )
    except Exception as e:
        logging.error(f'*** main Exception: {str(e)}')
        conn.rollback()
        raise e

    finally:
        if conn:
            conn.close()

####################################################################################################
# 前提チェック処理
####################################################################################################

check_tables = (
    ('M_HE_HON_SHISHA',                    'impr_he_to_ims', 's3_to_redshift_m_he_hon_shisha',                    570), # 毎日23時00分(JST)
    ('M_HK_HON_SHISHA_CONTROL',            'impr_hk_to_ims', 's3_to_redshift_m_hk_hon_shisha_control',            570), # 毎日23時00分(JST)
    ('M_HK_PK_SUBSCRIPTION_BAITAI',        'impr_hk_to_ims', 's3_to_redshift_m_hk_pk_subscription_baitai',        570), # 毎日23時00分(JST)
    ('M_HK_RECEPTION_CLASS_REF',           'impr_hk_to_ims', 's3_to_redshift_m_hk_reception_class_ref',           570), # 毎日23時00分(JST)
    ('M_HK_SUBSCRIPTION_BAITAI',           'impr_hk_to_ims', 's3_to_redshift_m_hk_subscription_baitai',           570), # 毎日23時00分(JST)
    ('T_HK_BASIC_INFO_PK_SUBSCRIPTION',    'impr_hk_to_ims', 's3_to_redshift_t_hk_basic_info_pk_subscription',    570), # 毎日23時00分(JST)
    ('T_HK_BASIC_INFO_PK_USER',            'impr_hk_to_ims', 's3_to_redshift_t_hk_basic_info_pk_user',            570), # 毎日23時00分(JST)
    ('T_HK_BASIC_INFO_SUBSCRIPTION',       'impr_hk_to_ims', 's3_to_redshift_t_hk_basic_info_subscription',       570), # 毎日23時00分(JST)
    ('T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION', 'impr_hk_to_ims', 's3_to_redshift_t_hk_basic_info_trial_subscription', 570), # 毎日23時00分(JST)
    ('T_HK_BASIC_INFO_USER',               'impr_hk_to_ims', 's3_to_redshift_t_hk_basic_info_user',               570), # 毎日23時00分(JST)
    ('T_PK_V_SUBSCRIPTION_NUM',            'impr_pk_to_ims', 's3_to_redshift_t_pk_v_subscription_num',            180)  # 毎日05時30分(JST)
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=7200,      #120分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

####################################################################################################
# 帳票作成処理
####################################################################################################

output_dailyreport_honshi = PythonOperator(
    task_id='output_dailyreport_honshi',
    python_callable=main,
    provide_context=True,
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

####################################################################################################
# 依存関係
####################################################################################################
check_tasks >> output_dailyreport_honshi >> done_all_task_for_check
