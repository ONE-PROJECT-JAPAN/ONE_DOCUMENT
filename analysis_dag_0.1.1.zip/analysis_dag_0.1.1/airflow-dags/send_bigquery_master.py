import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_bigquery_master',
    default_args=default_args,
    description='ClickMailer(CM)のデータ構築',
    schedule_interval='0 7 * * *', # 毎日07時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

# BigQuery連携対象テーブル
# テーブル名、転送先データセット名のタプルのタプル
tables = (
    ('M_IMS_DEPARTMENT', BIGQUERY_DATASET_NAME),
    ('M_IMS_EMAIL_ERROR', BIGQUERY_DATASET_NAME),
    ('M_IMS_GENRE', BIGQUERY_DATASET_NAME),
    ('M_IMS_MAIL_KNOCKDOWN_TYPE', BIGQUERY_DATASET_NAME),
    ('M_IMS_PURPOSE', BIGQUERY_DATASET_NAME),
    ('M_IMS_RP', BIGQUERY_DATASET_NAME),
    ('M_IMS_SITE_SERVICE', BIGQUERY_DATASET_NAME),
    ('M_BJ_EVENT', BIGQUERY_DATASET_NAME),
    ('M_BJ_EVENT_CATEGORY', BIGQUERY_DATASET_NAME),
    ('M_BJ_EVENT_CATEGORY_MNG', BIGQUERY_DATASET_NAME),
    ('M_BI_AGE', BIGQUERY_DATASET_NAME),
    ('M_BB_CORPORATE_PLN', BIGQUERY_DATASET_NAME),
    ('M_CRM_CODE', BIGQUERY_DATASET_NAME),
    ('M_CRM_OPTION', BIGQUERY_DATASET_NAME),
    ('M_CRM_RKN_PLN', BIGQUERY_DATASET_NAME),
    ('M_EVR_CATEGORY', BIGQUERY_DATASET_NAME),
    ('T_IMS_PLAN_GENRE', BIGQUERY_DATASET_NAME),
    ('T_IMS_PLAN_MNG', BIGQUERY_DATASET_NAME),
    ('T_HE_STORE_ADDRESS_DELIVERY_NUM', 'domo')
)

#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    bigquery_tasks = []
    for t in tables:
        task = redshift_to_bigquery(
            dag=dag,
            group_id=f'redshift_to_bigquery_{t[0].lower()}',
            aws_conn_id='aws_default',
            gcp_conn_id='google_cloud_default',
            s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
            redshift_conn_id='redshift_default',
            redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
            redshift_select_sql=f'sql/unload/{t[0].lower()}.sql',
            bigquery_dataset=t[1].lower(),
            bigquery_table=t[0].upper(),
            is_table_update_mng=True if t[1].lower() != 'domo' else False
        )
        bigquery_tasks.append(task)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################
bigquery_tasks >> done_all_task_for_check
