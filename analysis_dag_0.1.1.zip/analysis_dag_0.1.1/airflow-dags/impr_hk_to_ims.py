import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims import batch
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,23,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_hk_to_ims', # DAG名
    default_args=default_args,
    description='購読センターシステム(HK)のデータ構築',
    schedule_interval='0 23 * * *', # 毎日23時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')


#######################################################################################################
# データ構築処理
#######################################################################################################

# 本支社管轄データロード

s3_to_redshift_m_hk_hon_shisha_control = PythonOperator(
    task_id='s3_to_redshift_m_hk_hon_shisha_control',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_HON_SHISHA_CONTROL',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 区域データロード

s3_to_redshift_m_hk_area = PythonOperator(
    task_id='s3_to_redshift_m_hk_area',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_AREA',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売店データロード

s3_to_redshift_m_hk_store = PythonOperator(
    task_id='s3_to_redshift_m_hk_store',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_STORE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 住所マスタデータロード

s3_to_redshift_m_hk_address = PythonOperator(
    task_id='s3_to_redshift_m_hk_address',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ADDRESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 読者基本情報データロード

s3_to_redshift_t_hk_basic_info_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 読者追加情報データロード

s3_to_redshift_t_hk_additional_info_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_additional_info_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDITIONAL_INFO_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 購読申込基本情報データロード

s3_to_redshift_t_hk_basic_info_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 申込媒体データロード

s3_to_redshift_m_hk_subscription_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_subscription_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SUBSCRIPTION_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 試読申込基本情報データロード

s3_to_redshift_t_hk_basic_info_trial_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_trial_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_TRIAL_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 試読申込追加情報データロード

s3_to_redshift_t_hk_additional_info_trial_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_additional_info_trial_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDITIONAL_INFO_TRIAL_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 移転申込基本情報データロード

s3_to_redshift_t_hk_basic_info_move_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_move_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_MOVE_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 継続申込基本情報データロード

s3_to_redshift_t_hk_basic_info_continue_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_continue_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_CONTINUE_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_読者基本情報データロード

s3_to_redshift_t_hk_basic_info_pk_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_pk_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_PK_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_読者追加情報データロード

s3_to_redshift_t_hk_additional_info_pk_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_additional_info_pk_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDITIONAL_INFO_PK_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_購読申込基本情報データロード

s3_to_redshift_t_hk_basic_info_pk_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_pk_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_PK_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_移転申込基本情報データロード

s3_to_redshift_t_hk_basic_info_pk_move_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_pk_move_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_PK_MOVE_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_申込媒体データロード

s3_to_redshift_m_hk_pk_subscription_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_pk_subscription_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_PK_SUBSCRIPTION_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 購読申込基本情報蓄積

update_t_hk_basic_info_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 申込媒体蓄積

update_m_hk_subscription_baitai_ac = PostgresOperator(
    task_id='update_m_hk_subscription_baitai_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_subscription_baitai_ac.sql',
    autocommit=False,
    dag=dag
)

# 試読申込基本情報データ蓄積

update_t_hk_basic_info_trial_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_trial_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_trial_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 試読申込追加情報データ蓄積

update_t_hk_additional_info_trial_subscription_ac = PostgresOperator(
    task_id='update_t_hk_additional_info_trial_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_trial_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 移転申込基本情報データ蓄積

update_t_hk_basic_info_move_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_move_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_move_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 継続申込基本情報データ蓄積

update_t_hk_basic_info_continue_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_continue_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_continue_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 購読申込基本情報（紙課金システム連携用）データ蓄積

update_t_hk_basic_info_pk_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_pk_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_pk_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 移転申込基本情報（紙課金システム連携用）データ蓄積

update_t_hk_basic_info_pk_move_subscription_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_pk_move_subscription_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_pk_move_subscription_ac.sql',
    autocommit=False,
    dag=dag
)

# 申込媒体（紙課金システム連携用）データ蓄積

update_m_hk_pk_subscription_baitai_ac = PostgresOperator(
    task_id='update_m_hk_pk_subscription_baitai_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_pk_subscription_baitai_ac.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 読者基本情報クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_BASIC_INFO_USER_BF = 'app/cleansing/T_HK_BASIC_INFO_USER'
CL_FILE_T_HK_BASIC_INFO_USER_AF = 'app/cleansing/T_HK_BASIC_INFO_USER_CL'
CLEANSIMG_PATH_T_HK_BASIC_INFO_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_USER_BF}'
CLEANSIMG_PATH_T_HK_BASIC_INFO_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_USER_AF}'

# 読者基本情報（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_basic_info_user = PostgresOperator(
    task_id='redshift_to_s3_t_hk_basic_info_user',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_user4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 読者基本情報データクレンジング

cleanse_t_hk_basic_info_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_basic_info_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_BASIC_INFO_USER_BF,
        CLEANSIMG_PATH_T_HK_BASIC_INFO_USER_AF,
        "-colNo", "7",
        "-postcode", "{2}",
        "-address", "{3}",
        "-name", "{4}",
        "-telno", "{5}{6}",
    ]
)

# 読者基本情報データクレンジング・蓄積(一時テーブルの削除含む)

update_t_hk_basic_info_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_user_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(読者基本情報データクレンジング)

delete_from_s3_t_hk_basic_info_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_basic_info_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_USER_AF + '/',
    dag=dag
)


#######################################################################################################
# 読者追加情報クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_ADDITIONAL_INFO_USER_BF = 'app/cleansing/T_HK_ADDITIONAL_INFO_USER'
CL_FILE_T_HK_ADDITIONAL_INFO_USER_AF = 'app/cleansing/T_HK_ADDITIONAL_INFO_USER_CL'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_USER_BF}'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_USER_AF}'

# 読者追加情報（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_additional_info_user = PostgresOperator(
    task_id='redshift_to_s3_t_hk_additional_info_user',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_user4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 読者追加情報データクレンジング

cleanse_t_hk_additional_info_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_additional_info_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_USER_BF,
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_USER_AF,
        "-colNo", "3",
        "-name", "{2}",
    ]
)

# 読者追加情報データクレンジング・蓄積(一時テーブルの削除含む)

update_t_hk_additional_info_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_additional_info_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_user_cl_ac.sql',
    params = {
        'dic_id_occ' : '1',
        'dic_id_sec' : '2'
    },
    autocommit=False,
    dag=dag
)

# S3ファイル削除(読者追加情報データクレンジング)

delete_from_s3_t_hk_additional_info_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_additional_info_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_USER_AF + '/',
    dag=dag
)


#######################################################################################################
# 紙課金_読者基本情報クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_BASIC_INFO_PK_USER_BF = 'app/cleansing/T_HK_BASIC_INFO_PK_USER'
CL_FILE_T_HK_BASIC_INFO_PK_USER_AF = 'app/cleansing/T_HK_BASIC_INFO_PK_USER_CL'
CLEANSIMG_PATH_T_HK_BASIC_INFO_PK_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_PK_USER_BF}'
CLEANSIMG_PATH_T_HK_BASIC_INFO_PK_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_PK_USER_AF}'

# 紙課金_読者基本情報（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_basic_info_pk_user = PostgresOperator(
    task_id='redshift_to_s3_t_hk_basic_info_pk_user',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_pk_user4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 紙課金_読者基本情報データクレンジング

cleanse_t_hk_basic_info_pk_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_basic_info_pk_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_BASIC_INFO_PK_USER_BF,
        CLEANSIMG_PATH_T_HK_BASIC_INFO_PK_USER_AF,
        "-colNo", "7",
        "-postcode", "{2}",
        "-address", "{3}",
        "-name", "{4}",
        "-telno", "{5}{6}",
    ]
)

# 紙課金_読者基本情報データクレンジング・蓄積(一時テーブルの削除含む)

update_t_hk_basic_info_pk_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_pk_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_pk_user_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(紙課金_読者基本情報データクレンジング)

delete_from_s3_t_hk_basic_info_pk_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_pk_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_PK_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_basic_info_pk_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_pk_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_PK_USER_AF + '/',
    dag=dag
)


#######################################################################################################
# 紙課金_読者追加情報クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_BF = 'app/cleansing/T_HK_ADDITIONAL_INFO_PK_USER'
CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_AF = 'app/cleansing/T_HK_ADDITIONAL_INFO_PK_USER_CL'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_PK_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_BF}'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_PK_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_AF}'

# 紙課金_読者追加情報（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_additional_info_pk_user = PostgresOperator(
    task_id='redshift_to_s3_t_hk_additional_info_pk_user',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_pk_user4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 紙課金_読者追加情報データクレンジング

cleanse_t_hk_additional_info_pk_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_additional_info_pk_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_PK_USER_BF,
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_PK_USER_AF,
        "-colNo", "3",
        "-name", "{2}",
    ]
)

# 紙課金_読者追加情報データクレンジング・蓄積(一時テーブルの削除含む)

update_t_hk_additional_info_pk_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_additional_info_pk_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_pk_user_cl_ac.sql',
    params = {
        'dic_id_occ' : '1',
        'dic_id_sec' : '2'
    },
    autocommit=False,
    dag=dag
)

# S3ファイル削除(紙課金_読者追加情報データクレンジング)

delete_from_s3_t_hk_additional_info_pk_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_pk_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_additional_info_pk_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_pk_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_PK_USER_AF + '/',
    dag=dag
)

# 都道府県データロード

s3_to_redshift_m_hk_prefecture = PythonOperator(
    task_id='s3_to_redshift_m_hk_prefecture',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_PREFECTURE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 市区町村データロード

s3_to_redshift_m_hk_shikutyouson = PythonOperator(
    task_id='s3_to_redshift_m_hk_shikutyouson',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SHIKUTYOUSON',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 町名番地データロード

s3_to_redshift_m_hk_banti = PythonOperator(
    task_id='s3_to_redshift_m_hk_banti',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_BANTI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 住所テリトリデータロード

s3_to_redshift_m_hk_address_territory = PythonOperator(
    task_id='s3_to_redshift_m_hk_address_territory',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ADDRESS_TERRITORY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 住所備考データロード

s3_to_redshift_m_hk_address_remark = PythonOperator(
    task_id='s3_to_redshift_m_hk_address_remark',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ADDRESS_REMARK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 所属データロード

s3_to_redshift_m_hk_attribute = PythonOperator(
    task_id='s3_to_redshift_m_hk_attribute',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ATTRIBUTE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売店住所データロード

s3_to_redshift_m_hk_store_address = PythonOperator(
    task_id='s3_to_redshift_m_hk_store_address',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_STORE_ADDRESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売店取扱媒体データロード

s3_to_redshift_m_hk_store_treatment_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_store_treatment_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_STORE_TREATMENT_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 店主データロード

s3_to_redshift_m_hk_owner = PythonOperator(
    task_id='s3_to_redshift_m_hk_owner',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_OWNER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 店主販売店データロード

s3_to_redshift_m_hk_owner_store = PythonOperator(
    task_id='s3_to_redshift_m_hk_owner_store',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_OWNER_STORE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 系統データロード

s3_to_redshift_m_hk_keito = PythonOperator(
    task_id='s3_to_redshift_m_hk_keito',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_KEITO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売方法データロード

s3_to_redshift_m_hk_sales_method = PythonOperator(
    task_id='s3_to_redshift_m_hk_sales_method',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SALES_METHOD',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売店備考データロード

s3_to_redshift_m_hk_store_remark = PythonOperator(
    task_id='s3_to_redshift_m_hk_store_remark',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_STORE_REMARK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 媒体データロード

s3_to_redshift_m_hk_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# キャンペーンデータロード

s3_to_redshift_m_hk_camp = PythonOperator(
    task_id='s3_to_redshift_m_hk_camp',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CAMP',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# キャンペーン媒体データロード

s3_to_redshift_m_hk_camp_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_camp_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CAMP_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 受付ユーザデータロード

s3_to_redshift_m_hk_reception_user = PythonOperator(
    task_id='s3_to_redshift_m_hk_reception_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_RECEPTION_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 謝礼品データロード

s3_to_redshift_m_hk_sharei = PythonOperator(
    task_id='s3_to_redshift_m_hk_sharei',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SHAREI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 申込区分データロード

s3_to_redshift_m_hk_subscription_kbn = PythonOperator(
    task_id='s3_to_redshift_m_hk_subscription_kbn',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SUBSCRIPTION_KBN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 受付種別データロード

s3_to_redshift_m_hk_reception_class_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_reception_class_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_RECEPTION_CLASS_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 宣伝媒体データロード

s3_to_redshift_m_hk_advertise_baitai_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_advertise_baitai_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ADVERTISE_BAITAI_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 崩れ理由データロード

s3_to_redshift_m_hk_break_ryu_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_break_ryu_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_BREAK_RYU_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# アプローチ方法データロード

s3_to_redshift_m_hk_approach_method_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_approach_method_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_APPROACH_METHOD_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 販売店拡張結果データロード

s3_to_redshift_m_hk_store_extend_result_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_store_extend_result_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_STORE_EXTEND_RESULT_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# テレマ拡張結果データロード

s3_to_redshift_m_hk_telema_extend_result_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_telema_extend_result_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_TELEMA_EXTEND_RESULT_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 受付場所データロード

s3_to_redshift_m_hk_reception_place_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_reception_place_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_RECEPTION_PLACE_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# コメントデータロード

s3_to_redshift_m_hk_comment_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_comment_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_COMMENT_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 購読崩れ情報データロード

s3_to_redshift_t_hk_subscription_break = PythonOperator(
    task_id='s3_to_redshift_t_hk_subscription_break',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_SUBSCRIPTION_BREAK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 購読崩れ情報蓄積

s3_to_redshift_t_hk_subscription_break_ac = PythonOperator(
    task_id='s3_to_redshift_t_hk_subscription_break_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_SUBSCRIPTION_BREAK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['SUBSCRIPTION_NO'],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_HK_SUBSCRIPTION_BREAK_AC'
    },
    dag=dag
)

# 前回割り当てデータロード

s3_to_redshift_t_hk_last_allocation = PythonOperator(
    task_id='s3_to_redshift_t_hk_last_allocation',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_LAST_ALLOCATION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# マスタ配布・取込ログデータロード

s3_to_redshift_t_hk_mst_distribution_load_log = PythonOperator(
    task_id='s3_to_redshift_t_hk_mst_distribution_load_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_MST_DISTRIBUTION_LOAD_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 住所配布データデータロード

s3_to_redshift_t_hk_address_distribution_data = PythonOperator(
    task_id='s3_to_redshift_t_hk_address_distribution_data',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDRESS_DISTRIBUTION_DATA',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 住所テリトリ削除情報データロード

s3_to_redshift_t_hk_address_territory_delete = PythonOperator(
    task_id='s3_to_redshift_t_hk_address_territory_delete',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDRESS_TERRITORY_DELETE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 試読お知らせ情報データロード

s3_to_redshift_t_hk_trial_notice_ref = PythonOperator(
    task_id='s3_to_redshift_t_hk_trial_notice_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_TRIAL_NOTICE_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 移転取消データロード

s3_to_redshift_t_hk_move_cn = PythonOperator(
    task_id='s3_to_redshift_t_hk_move_cn',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_MOVE_CN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 連動サイトデータロード

s3_to_redshift_m_hk_linkage_site = PythonOperator(
    task_id='s3_to_redshift_m_hk_linkage_site',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_LINKAGE_SITE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# キャンペーン変換データロード

s3_to_redshift_m_hk_camp_convert = PythonOperator(
    task_id='s3_to_redshift_m_hk_camp_convert',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CAMP_CONVERT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# アンケートデータロード

s3_to_redshift_m_hk_enq = PythonOperator(
    task_id='s3_to_redshift_m_hk_enq',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ENQ',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# アンケート項目データロード

s3_to_redshift_m_hk_enq_item = PythonOperator(
    task_id='s3_to_redshift_m_hk_enq_item',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_ENQ_ITEM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 本支社メールアドレスデータロード

s3_to_redshift_m_hk_hon_shisha_email = PythonOperator(
    task_id='s3_to_redshift_m_hk_hon_shisha_email',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_HON_SHISHA_EMAIL',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 申込IDリンクデータロード

s3_to_redshift_m_hk_subscription_id_link = PythonOperator(
    task_id='s3_to_redshift_m_hk_subscription_id_link',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SUBSCRIPTION_ID_LINK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# WEB系統データロード

s3_to_redshift_m_hk_web_keito = PythonOperator(
    task_id='s3_to_redshift_m_hk_web_keito',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_WEB_KEITO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 系統変換データロード

s3_to_redshift_m_hk_keito_convert = PythonOperator(
    task_id='s3_to_redshift_m_hk_keito_convert',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_KEITO_CONVERT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 担当部署データロード

s3_to_redshift_m_hk_charge_department = PythonOperator(
    task_id='s3_to_redshift_m_hk_charge_department',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CHARGE_DEPARTMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# キャンペーンアンケートデータロード

s3_to_redshift_m_hk_camp_enq = PythonOperator(
    task_id='s3_to_redshift_m_hk_camp_enq',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CAMP_ENQ',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# キャンペーンアンケート項目データロード

s3_to_redshift_m_hk_camp_enq_item = PythonOperator(
    task_id='s3_to_redshift_m_hk_camp_enq_item',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CAMP_ENQ_ITEM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# アンケート回答データロード

s3_to_redshift_w_hk_enq_reply = PythonOperator(
    task_id='s3_to_redshift_w_hk_enq_reply',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'W_HK_ENQ_REPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# アンケート回答ヘッダ明細作成

replace_t_hk_enq_reply_hdr_dtl = PostgresOperator(
    task_id='replace_t_hk_enq_reply_hdr_dtl',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_enq_reply_hdr_dtl.sql',
    autocommit=False,
    dag=dag
)

# アンケート回答ヘッダ明細蓄積作成

append_t_hk_enq_reply_hdr_dtl_ac = PostgresOperator(
    task_id='append_t_hk_enq_reply_hdr_dtl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_enq_reply_hdr_dtl_ac.sql',
    autocommit=False,
    dag=dag
)

# チラシ配布区分データロード

s3_to_redshift_m_hk_flyer_distribution_kbn = PythonOperator(
    task_id='s3_to_redshift_m_hk_flyer_distribution_kbn',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_FLYER_DISTRIBUTION_KBN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# カード種類データロード

s3_to_redshift_m_hk_card_kind = PythonOperator(
    task_id='s3_to_redshift_m_hk_card_kind',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_CARD_KIND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情大分類データロード

s3_to_redshift_m_hk_complaint_category_l_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_complaint_category_l_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_COMPLAINT_CATEGORY_L_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情小分類データロード

s3_to_redshift_m_hk_complaint_category_s_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_complaint_category_s_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_COMPLAINT_CATEGORY_S_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情申込口データロード

s3_to_redshift_m_hk_complaint_subscript_method_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_complaint_subscript_method_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_COMPLAINT_SUBSCRIPT_METHOD_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情ステータスデータロード

s3_to_redshift_m_hk_complaint_status_ref = PythonOperator(
    task_id='s3_to_redshift_m_hk_complaint_status_ref',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_COMPLAINT_STATUS_REF',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情申込基本情報データロード

s3_to_redshift_t_hk_basic_info_complaint_subscription = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_complaint_subscription',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_COMPLAINT_SUBSCRIPTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情内容データロード

s3_to_redshift_t_hk_complaint_content = PythonOperator(
    task_id='s3_to_redshift_t_hk_complaint_content',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_COMPLAINT_CONTENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情内容媒体データロード

s3_to_redshift_t_hk_complaint_content_baitai = PythonOperator(
    task_id='s3_to_redshift_t_hk_complaint_content_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_COMPLAINT_CONTENT_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情過去事例データロード

s3_to_redshift_t_hk_complaint_past_case = PythonOperator(
    task_id='s3_to_redshift_t_hk_complaint_past_case',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_COMPLAINT_PAST_CASE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情読者基本情報データロード

s3_to_redshift_t_hk_basic_info_complaint_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_basic_info_complaint_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_BASIC_INFO_COMPLAINT_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 苦情読者追加情報データロード

s3_to_redshift_t_hk_additional_info_complaint_user = PythonOperator(
    task_id='s3_to_redshift_t_hk_additional_info_complaint_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_ADDITIONAL_INFO_COMPLAINT_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# THANKYOUMAIL送信ログデータロード

s3_to_redshift_t_hk_thankyoumail_send_log = PythonOperator(
    task_id='s3_to_redshift_t_hk_thankyoumail_send_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_THANKYOUMAIL_SEND_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 謝礼品対象媒体データロード

s3_to_redshift_m_hk_sharei_target_baitai = PythonOperator(
    task_id='s3_to_redshift_m_hk_sharei_target_baitai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_SHAREI_TARGET_BAITAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 大口事業所マスタデータロード

s3_to_redshift_m_hk_prime_office = PythonOperator(
    task_id='s3_to_redshift_m_hk_prime_office',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'M_HK_PRIME_OFFICE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_アンケート回答データロード

s3_to_redshift_w_hk_pk_enq_reply = PythonOperator(
    task_id='s3_to_redshift_w_hk_pk_enq_reply',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'W_HK_PK_ENQ_REPLY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 紙課金_アンケート回答ヘッダ明細作成

replace_t_hk_pk_enq_reply_hdr_dtl = PostgresOperator(
    task_id='replace_t_hk_pk_enq_reply_hdr_dtl',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_pk_enq_reply_hdr_dtl.sql',
    autocommit=False,
    dag=dag
)

# 紙課金_アンケート回答ヘッダ明細蓄積作成

append_t_hk_pk_enq_reply_hdr_dtl_ac = PostgresOperator(
    task_id='append_t_hk_pk_enq_reply_hdr_dtl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_pk_enq_reply_hdr_dtl_ac.sql',
    autocommit=False,
    dag=dag
)

# 受付中止住所データロード

s3_to_redshift_t_hk_receipt_stop_address = PythonOperator(
    task_id='s3_to_redshift_t_hk_receipt_stop_address',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_RECEIPT_STOP_ADDRESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 受付中止住所データ蓄積

s3_to_redshift_t_hk_receipt_stop_address_ac = PythonOperator(
    task_id='s3_to_redshift_t_hk_receipt_stop_address_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'hk',
        'redshift_loader_table_name': 'T_HK_RECEIPT_STOP_ADDRESS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'ADDRESS_CD', 'BAITAI_CD', 'STORE_CD' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_HK_RECEIPT_STOP_ADDRESS_AC',
    },
    dag=dag
)


#######################################################################################################
# 住所マスタデータクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_M_HK_ADDRESS_BF = 'app/cleansing/M_HK_ADDRESS'
CL_FILE_M_HK_ADDRESS_AF = 'app/cleansing/M_HK_ADDRESS_CL'
CLEANSIMG_PATH_M_HK_ADDRESS_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_ADDRESS_BF}'
CLEANSIMG_PATH_M_HK_ADDRESS_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_ADDRESS_AF}'

# 住所マスタデータクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_m_hk_address_temp = PostgresOperator(
    task_id='redshift_to_s3_m_hk_address_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_address_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 住所マスタデータクレンジング・蓄積クレンジング

cleanse_m_hk_address = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_hk_address",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_HK_ADDRESS_BF,
        CLEANSIMG_PATH_M_HK_ADDRESS_AF,
        "-colNo", "6",
        "-postcode", "{4}",
        "-address", "{5}",
    ]
)

# 住所マスタデータクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_m_hk_address_cl_ac = PostgresOperator(
    task_id='update_m_hk_address_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_address_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(住所マスタデータクレンジング・蓄積データクレンジング)

delete_from_s3_m_hk_address_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_address_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_ADDRESS_BF + '/',
    dag=dag
)

delete_from_s3_m_hk_address_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_address_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_ADDRESS_AF + '/',
    dag=dag
)


#######################################################################################################
# 町名番地データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_M_HK_BANTI_BF = 'app/cleansing/M_HK_BANTI'
CL_FILE_M_HK_BANTI_AF = 'app/cleansing/M_HK_BANTI_CL'
CLEANSIMG_PATH_M_HK_BANTI_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_BANTI_BF}'
CLEANSIMG_PATH_M_HK_BANTI_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_BANTI_AF}'

# 町名番地データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_m_hk_banti_temp = PostgresOperator(
    task_id='redshift_to_s3_m_hk_banti_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_banti_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 町名番地データクレンジング・蓄積クレンジング

cleanse_m_hk_banti = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_hk_banti",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_HK_BANTI_BF,
        CLEANSIMG_PATH_M_HK_BANTI_AF,
        "-colNo", "7",
        "-postcode", "{5}",
    ]
)

# 町名番地データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_m_hk_banti_cl_ac = PostgresOperator(
    task_id='update_m_hk_banti_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_banti_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(町名番地データクレンジング・蓄積データクレンジング)

delete_from_s3_m_hk_banti_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_banti_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_BANTI_BF + '/',
    dag=dag
)

delete_from_s3_m_hk_banti_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_banti_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_BANTI_AF + '/',
    dag=dag
)


#######################################################################################################
# 本支社メールアドレスデータクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_M_HK_HON_SHISHA_EMAIL_BF = 'app/cleansing/M_HK_HON_SHISHA_EMAIL'
CL_FILE_M_HK_HON_SHISHA_EMAIL_AF = 'app/cleansing/M_HK_HON_SHISHA_EMAIL_CL'
CLEANSIMG_PATH_M_HK_HON_SHISHA_EMAIL_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_HON_SHISHA_EMAIL_BF}'
CLEANSIMG_PATH_M_HK_HON_SHISHA_EMAIL_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_HON_SHISHA_EMAIL_AF}'

# 本支社メールアドレスデータクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_m_hk_hon_shisha_email_temp = PostgresOperator(
    task_id='redshift_to_s3_m_hk_hon_shisha_email_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_hon_shisha_email_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 本支社メールアドレスデータクレンジング・蓄積クレンジング

cleanse_m_hk_hon_shisha_email = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_hk_hon_shisha_email",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_HK_HON_SHISHA_EMAIL_BF,
        CLEANSIMG_PATH_M_HK_HON_SHISHA_EMAIL_AF,
        "-colNo", "2",
    ]
)

# 本支社メールアドレスデータクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_m_hk_hon_shisha_email_cl_ac = PostgresOperator(
    task_id='update_m_hk_hon_shisha_email_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_hon_shisha_email_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(本支社メールアドレスデータクレンジング・蓄積データクレンジング)

delete_from_s3_m_hk_hon_shisha_email_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_hon_shisha_email_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_HON_SHISHA_EMAIL_BF + '/',
    dag=dag
)

delete_from_s3_m_hk_hon_shisha_email_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_hon_shisha_email_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_HON_SHISHA_EMAIL_AF + '/',
    dag=dag
)


#######################################################################################################
# 販売店住所データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_M_HK_STORE_ADDRESS_BF = 'app/cleansing/M_HK_STORE_ADDRESS'
CL_FILE_M_HK_STORE_ADDRESS_AF = 'app/cleansing/M_HK_STORE_ADDRESS_CL'
CLEANSIMG_PATH_M_HK_STORE_ADDRESS_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_STORE_ADDRESS_BF}'
CLEANSIMG_PATH_M_HK_STORE_ADDRESS_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_M_HK_STORE_ADDRESS_AF}'

# 販売店住所データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_m_hk_store_address_temp = PostgresOperator(
    task_id='redshift_to_s3_m_hk_store_address_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_store_address_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 販売店住所データクレンジング・蓄積クレンジング

cleanse_m_hk_store_address = batch.create_operator(
    dag=dag,
    task_id="cleanse_m_hk_store_address",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_M_HK_STORE_ADDRESS_BF,
        CLEANSIMG_PATH_M_HK_STORE_ADDRESS_AF,
        "-colNo", "6",
        "-telno", "{5}",
        "-postcode", "{3}",
        "-address", "{4}",
    ]
)

# 販売店住所データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_m_hk_store_address_cl_ac = PostgresOperator(
    task_id='update_m_hk_store_address_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/m_hk_store_address_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(販売店住所データクレンジング・蓄積データクレンジング)

delete_from_s3_m_hk_store_address_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_store_address_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_STORE_ADDRESS_BF + '/',
    dag=dag
)

delete_from_s3_m_hk_store_address_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_m_hk_store_address_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_M_HK_STORE_ADDRESS_AF + '/',
    dag=dag
)


#######################################################################################################
# 苦情読者追加情報データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_BF = 'app/cleansing/T_HK_ADDITIONAL_INFO_COMPLAINT_USER'
CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_AF = 'app/cleansing/T_HK_ADDITIONAL_INFO_COMPLAINT_USER_CL'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_BF}'
CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_AF}'

# 苦情読者追加情報データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_additional_info_complaint_user_temp = PostgresOperator(
    task_id='redshift_to_s3_t_hk_additional_info_complaint_user_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_complaint_user_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 苦情読者追加情報データクレンジング・蓄積クレンジング

cleanse_t_hk_additional_info_complaint_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_additional_info_complaint_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_BF,
        CLEANSIMG_PATH_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_AF,
        "-colNo", "3",
        "-name", "{2}",
    ]
)

# 苦情読者追加情報データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_hk_additional_info_complaint_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_additional_info_complaint_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_additional_info_complaint_user_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(苦情読者追加情報データクレンジング・蓄積データクレンジング)

delete_from_s3_t_hk_additional_info_complaint_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_complaint_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_additional_info_complaint_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_additional_info_complaint_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDITIONAL_INFO_COMPLAINT_USER_AF + '/',
    dag=dag
)


#######################################################################################################
# 住所配布データデータクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_BF = 'app/cleansing/T_HK_ADDRESS_DISTRIBUTION_DATA'
CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_AF = 'app/cleansing/T_HK_ADDRESS_DISTRIBUTION_DATA_CL'
CLEANSIMG_PATH_T_HK_ADDRESS_DISTRIBUTION_DATA_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_BF}'
CLEANSIMG_PATH_T_HK_ADDRESS_DISTRIBUTION_DATA_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_AF}'

# 住所配布データデータクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_address_distribution_data_temp = PostgresOperator(
    task_id='redshift_to_s3_t_hk_address_distribution_data_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_address_distribution_data_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 住所配布データデータクレンジング・蓄積クレンジング

cleanse_t_hk_address_distribution_data = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_address_distribution_data",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_ADDRESS_DISTRIBUTION_DATA_BF,
        CLEANSIMG_PATH_T_HK_ADDRESS_DISTRIBUTION_DATA_AF,
        "-colNo", "6",
        "-postcode", "{4}",
        "-address", "{5}",
    ]
)

# 住所配布データデータクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_hk_address_distribution_data_cl_ac = PostgresOperator(
    task_id='update_t_hk_address_distribution_data_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_address_distribution_data_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(住所配布データデータクレンジング・蓄積データクレンジング)

delete_from_s3_t_hk_address_distribution_data_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_address_distribution_data_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_address_distribution_data_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_address_distribution_data_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_ADDRESS_DISTRIBUTION_DATA_AF + '/',
    dag=dag
)


#######################################################################################################
# 苦情読者基本情報データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_BF = 'app/cleansing/T_HK_BASIC_INFO_COMPLAINT_USER'
CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_AF = 'app/cleansing/T_HK_BASIC_INFO_COMPLAINT_USER_CL'
CLEANSIMG_PATH_T_HK_BASIC_INFO_COMPLAINT_USER_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_BF}'
CLEANSIMG_PATH_T_HK_BASIC_INFO_COMPLAINT_USER_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_AF}'

# 苦情読者基本情報データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_basic_info_complaint_user_temp = PostgresOperator(
    task_id='redshift_to_s3_t_hk_basic_info_complaint_user_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_complaint_user_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 苦情読者基本情報データクレンジング・蓄積クレンジング

cleanse_t_hk_basic_info_complaint_user = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_basic_info_complaint_user",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_BASIC_INFO_COMPLAINT_USER_BF,
        CLEANSIMG_PATH_T_HK_BASIC_INFO_COMPLAINT_USER_AF,
        "-colNo", "7",
        "-name", "{4}",
        "-telno", "{5}{6}",
        "-postcode", "{2}",
        "-address", "{3}",
    ]
)

# 苦情読者基本情報データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_hk_basic_info_complaint_user_cl_ac = PostgresOperator(
    task_id='update_t_hk_basic_info_complaint_user_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_basic_info_complaint_user_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(苦情読者基本情報データクレンジング・蓄積データクレンジング)

delete_from_s3_t_hk_basic_info_complaint_user_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_complaint_user_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_basic_info_complaint_user_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_basic_info_complaint_user_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_BASIC_INFO_COMPLAINT_USER_AF + '/',
    dag=dag
)


#######################################################################################################
# THANKYOUMAIL送信ログデータクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_BF = 'app/cleansing/T_HK_THANKYOUMAIL_SEND_LOG'
CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_AF = 'app/cleansing/T_HK_THANKYOUMAIL_SEND_LOG_CL'
CLEANSIMG_PATH_T_HK_THANKYOUMAIL_SEND_LOG_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_BF}'
CLEANSIMG_PATH_T_HK_THANKYOUMAIL_SEND_LOG_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_AF}'

# THANKYOUMAIL送信ログデータクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_thankyoumail_send_log_temp = PostgresOperator(
    task_id='redshift_to_s3_t_hk_thankyoumail_send_log_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_thankyoumail_send_log_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# THANKYOUMAIL送信ログデータクレンジング・蓄積クレンジング

cleanse_t_hk_thankyoumail_send_log = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_thankyoumail_send_log",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_THANKYOUMAIL_SEND_LOG_BF,
        CLEANSIMG_PATH_T_HK_THANKYOUMAIL_SEND_LOG_AF,
        "-colNo", "3",
    ]
)

# THANKYOUMAIL送信ログデータクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_hk_thankyoumail_send_log_cl_ac = PostgresOperator(
    task_id='update_t_hk_thankyoumail_send_log_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_thankyoumail_send_log_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(THANKYOUMAIL送信ログデータクレンジング・蓄積データクレンジング)

delete_from_s3_t_hk_thankyoumail_send_log_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_thankyoumail_send_log_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_thankyoumail_send_log_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_thankyoumail_send_log_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_THANKYOUMAIL_SEND_LOG_AF + '/',
    dag=dag
)


#######################################################################################################
# 試読お知らせ情報（リファレンス）データクレンジング・蓄積 クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_HK_TRIAL_NOTICE_REF_BF = 'app/cleansing/T_HK_TRIAL_NOTICE_REF'
CL_FILE_T_HK_TRIAL_NOTICE_REF_AF = 'app/cleansing/T_HK_TRIAL_NOTICE_REF_CL'
CLEANSIMG_PATH_T_HK_TRIAL_NOTICE_REF_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_TRIAL_NOTICE_REF_BF}'
CLEANSIMG_PATH_T_HK_TRIAL_NOTICE_REF_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_HK_TRIAL_NOTICE_REF_AF}'

# 試読お知らせ情報（リファレンス）データクレンジング・蓄積（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_hk_trial_notice_ref_temp = PostgresOperator(
    task_id='redshift_to_s3_t_hk_trial_notice_ref_temp',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_trial_notice_ref_temp4cleansing.sql',
    autocommit=False,
    dag=dag
)

# 試読お知らせ情報（リファレンス）データクレンジング・蓄積クレンジング

cleanse_t_hk_trial_notice_ref = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_hk_trial_notice_ref",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_HK_TRIAL_NOTICE_REF_BF,
        CLEANSIMG_PATH_T_HK_TRIAL_NOTICE_REF_AF,
        "-colNo", "3",
        "-telno", "{2}",
    ]
)

# 試読お知らせ情報（リファレンス）データクレンジング・蓄積クレンジング蓄積(一時テーブルの削除含む)

update_t_hk_trial_notice_ref_cl_ac = PostgresOperator(
    task_id='update_t_hk_trial_notice_ref_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/hk/t_hk_trial_notice_ref_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(試読お知らせ情報（リファレンス）データクレンジング・蓄積データクレンジング)

delete_from_s3_t_hk_trial_notice_ref_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_trial_notice_ref_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_TRIAL_NOTICE_REF_BF + '/',
    dag=dag
)

delete_from_s3_t_hk_trial_notice_ref_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_hk_trial_notice_ref_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_HK_TRIAL_NOTICE_REF_AF + '/',
    dag=dag
)

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_m_hk_hon_shisha_control >> done_all_task_for_check
s3_to_redshift_m_hk_area >> done_all_task_for_check
s3_to_redshift_m_hk_store >> done_all_task_for_check
[s3_to_redshift_m_hk_address, s3_to_redshift_t_hk_basic_info_user] >> redshift_to_s3_t_hk_basic_info_user >> cleanse_t_hk_basic_info_user >> update_t_hk_basic_info_user_cl_ac
s3_to_redshift_t_hk_additional_info_user >> redshift_to_s3_t_hk_additional_info_user >> cleanse_t_hk_additional_info_user >> update_t_hk_additional_info_user_cl_ac
s3_to_redshift_t_hk_basic_info_subscription >> update_t_hk_basic_info_subscription_ac >> done_all_task_for_check
s3_to_redshift_m_hk_subscription_baitai >> update_m_hk_subscription_baitai_ac >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_trial_subscription >> update_t_hk_basic_info_trial_subscription_ac
s3_to_redshift_t_hk_additional_info_trial_subscription >> update_t_hk_additional_info_trial_subscription_ac >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_move_subscription >> update_t_hk_basic_info_move_subscription_ac >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_continue_subscription >> update_t_hk_basic_info_continue_subscription_ac >> done_all_task_for_check
[s3_to_redshift_m_hk_address, s3_to_redshift_t_hk_basic_info_pk_user] >> redshift_to_s3_t_hk_basic_info_pk_user >> cleanse_t_hk_basic_info_pk_user >> update_t_hk_basic_info_pk_user_cl_ac
s3_to_redshift_t_hk_additional_info_pk_user >> redshift_to_s3_t_hk_additional_info_pk_user >> cleanse_t_hk_additional_info_pk_user >> update_t_hk_additional_info_pk_user_cl_ac
s3_to_redshift_t_hk_basic_info_pk_subscription >> update_t_hk_basic_info_pk_subscription_ac >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_pk_move_subscription >> update_t_hk_basic_info_pk_move_subscription_ac >> done_all_task_for_check
s3_to_redshift_m_hk_pk_subscription_baitai >> update_m_hk_pk_subscription_baitai_ac >> done_all_task_for_check
update_t_hk_basic_info_user_cl_ac >> [delete_from_s3_t_hk_basic_info_user_bf, delete_from_s3_t_hk_basic_info_user_af] >> done_all_task_for_check
update_t_hk_additional_info_user_cl_ac >> [delete_from_s3_t_hk_additional_info_user_bf, delete_from_s3_t_hk_additional_info_user_af] >> done_all_task_for_check
update_t_hk_basic_info_pk_user_cl_ac >> [delete_from_s3_t_hk_basic_info_pk_user_bf, delete_from_s3_t_hk_basic_info_pk_user_af] >> done_all_task_for_check
update_t_hk_additional_info_pk_user_cl_ac >> [delete_from_s3_t_hk_additional_info_pk_user_bf, delete_from_s3_t_hk_additional_info_pk_user_af] >> done_all_task_for_check
s3_to_redshift_m_hk_prefecture >> done_all_task_for_check
s3_to_redshift_m_hk_shikutyouson >> done_all_task_for_check
s3_to_redshift_m_hk_address_territory >> done_all_task_for_check
s3_to_redshift_m_hk_address_remark >> done_all_task_for_check
s3_to_redshift_m_hk_attribute >> done_all_task_for_check
s3_to_redshift_m_hk_store_treatment_baitai >> done_all_task_for_check
s3_to_redshift_m_hk_owner >> done_all_task_for_check
s3_to_redshift_m_hk_owner_store >> done_all_task_for_check
s3_to_redshift_m_hk_keito >> done_all_task_for_check
s3_to_redshift_m_hk_sales_method >> done_all_task_for_check
s3_to_redshift_m_hk_store_remark >> done_all_task_for_check
s3_to_redshift_m_hk_baitai >> done_all_task_for_check
s3_to_redshift_m_hk_camp >> done_all_task_for_check
s3_to_redshift_m_hk_camp_baitai >> done_all_task_for_check
s3_to_redshift_m_hk_reception_user >> done_all_task_for_check
s3_to_redshift_m_hk_sharei >> done_all_task_for_check
s3_to_redshift_m_hk_subscription_kbn >> done_all_task_for_check
s3_to_redshift_m_hk_reception_class_ref >> done_all_task_for_check
s3_to_redshift_m_hk_advertise_baitai_ref >> done_all_task_for_check
s3_to_redshift_m_hk_break_ryu_ref >> done_all_task_for_check
s3_to_redshift_m_hk_approach_method_ref >> done_all_task_for_check
s3_to_redshift_m_hk_store_extend_result_ref >> done_all_task_for_check
s3_to_redshift_m_hk_telema_extend_result_ref >> done_all_task_for_check
s3_to_redshift_m_hk_reception_place_ref >> done_all_task_for_check
s3_to_redshift_m_hk_comment_ref >> done_all_task_for_check
s3_to_redshift_t_hk_subscription_break >> s3_to_redshift_t_hk_subscription_break_ac >> done_all_task_for_check
s3_to_redshift_t_hk_last_allocation >> done_all_task_for_check
s3_to_redshift_t_hk_mst_distribution_load_log >> done_all_task_for_check
s3_to_redshift_t_hk_address_territory_delete >> done_all_task_for_check
s3_to_redshift_t_hk_move_cn >> done_all_task_for_check
s3_to_redshift_m_hk_linkage_site >> done_all_task_for_check
s3_to_redshift_m_hk_camp_convert >> done_all_task_for_check
s3_to_redshift_m_hk_enq >> done_all_task_for_check
s3_to_redshift_m_hk_enq_item >> done_all_task_for_check
s3_to_redshift_m_hk_subscription_id_link >> done_all_task_for_check
s3_to_redshift_m_hk_web_keito >> done_all_task_for_check
s3_to_redshift_m_hk_keito_convert >> done_all_task_for_check
s3_to_redshift_m_hk_charge_department >> done_all_task_for_check
s3_to_redshift_m_hk_camp_enq >> done_all_task_for_check
s3_to_redshift_m_hk_camp_enq_item >> done_all_task_for_check
s3_to_redshift_w_hk_enq_reply >> replace_t_hk_enq_reply_hdr_dtl >> append_t_hk_enq_reply_hdr_dtl_ac >> done_all_task_for_check
s3_to_redshift_m_hk_flyer_distribution_kbn >> done_all_task_for_check
s3_to_redshift_m_hk_card_kind >> done_all_task_for_check
s3_to_redshift_m_hk_complaint_category_l_ref >> done_all_task_for_check
s3_to_redshift_m_hk_complaint_category_s_ref >> done_all_task_for_check
s3_to_redshift_m_hk_complaint_subscript_method_ref >> done_all_task_for_check
s3_to_redshift_m_hk_complaint_status_ref >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_complaint_subscription >> done_all_task_for_check
s3_to_redshift_t_hk_complaint_content >> done_all_task_for_check
s3_to_redshift_t_hk_complaint_content_baitai >> done_all_task_for_check
s3_to_redshift_t_hk_complaint_past_case >> done_all_task_for_check
s3_to_redshift_m_hk_sharei_target_baitai >> done_all_task_for_check
s3_to_redshift_m_hk_prime_office >> done_all_task_for_check
s3_to_redshift_w_hk_pk_enq_reply >> replace_t_hk_pk_enq_reply_hdr_dtl >> append_t_hk_pk_enq_reply_hdr_dtl_ac >> done_all_task_for_check
s3_to_redshift_t_hk_receipt_stop_address >> s3_to_redshift_t_hk_receipt_stop_address_ac >> done_all_task_for_check
s3_to_redshift_m_hk_address >> redshift_to_s3_m_hk_address_temp >> cleanse_m_hk_address >> update_m_hk_address_cl_ac >> [delete_from_s3_m_hk_address_bf, delete_from_s3_m_hk_address_af] >> done_all_task_for_check
s3_to_redshift_m_hk_banti >> redshift_to_s3_m_hk_banti_temp >> cleanse_m_hk_banti >> update_m_hk_banti_cl_ac >> [delete_from_s3_m_hk_banti_bf, delete_from_s3_m_hk_banti_af] >> done_all_task_for_check
s3_to_redshift_m_hk_hon_shisha_email >> redshift_to_s3_m_hk_hon_shisha_email_temp >> cleanse_m_hk_hon_shisha_email >> update_m_hk_hon_shisha_email_cl_ac >> [delete_from_s3_m_hk_hon_shisha_email_bf, delete_from_s3_m_hk_hon_shisha_email_af] >> done_all_task_for_check
s3_to_redshift_m_hk_store_address >> redshift_to_s3_m_hk_store_address_temp >> cleanse_m_hk_store_address >> update_m_hk_store_address_cl_ac >> [delete_from_s3_m_hk_store_address_bf, delete_from_s3_m_hk_store_address_af] >> done_all_task_for_check
s3_to_redshift_t_hk_additional_info_complaint_user >> redshift_to_s3_t_hk_additional_info_complaint_user_temp >> cleanse_t_hk_additional_info_complaint_user >> update_t_hk_additional_info_complaint_user_cl_ac >> [delete_from_s3_t_hk_additional_info_complaint_user_bf, delete_from_s3_t_hk_additional_info_complaint_user_af] >> done_all_task_for_check
s3_to_redshift_t_hk_address_distribution_data >> redshift_to_s3_t_hk_address_distribution_data_temp >> cleanse_t_hk_address_distribution_data >> update_t_hk_address_distribution_data_cl_ac >> [delete_from_s3_t_hk_address_distribution_data_bf, delete_from_s3_t_hk_address_distribution_data_af] >> done_all_task_for_check
s3_to_redshift_t_hk_basic_info_complaint_user >> redshift_to_s3_t_hk_basic_info_complaint_user_temp >> cleanse_t_hk_basic_info_complaint_user >> update_t_hk_basic_info_complaint_user_cl_ac >> [delete_from_s3_t_hk_basic_info_complaint_user_bf, delete_from_s3_t_hk_basic_info_complaint_user_af] >> done_all_task_for_check
s3_to_redshift_t_hk_thankyoumail_send_log >> redshift_to_s3_t_hk_thankyoumail_send_log_temp >> cleanse_t_hk_thankyoumail_send_log >> update_t_hk_thankyoumail_send_log_cl_ac >> [delete_from_s3_t_hk_thankyoumail_send_log_bf, delete_from_s3_t_hk_thankyoumail_send_log_af] >> done_all_task_for_check
s3_to_redshift_t_hk_trial_notice_ref >> redshift_to_s3_t_hk_trial_notice_ref_temp >> cleanse_t_hk_trial_notice_ref >> update_t_hk_trial_notice_ref_cl_ac >> [delete_from_s3_t_hk_trial_notice_ref_bf, delete_from_s3_t_hk_trial_notice_ref_af] >> done_all_task_for_check
