"""
エリア別契約数リスト（月次）
随時は販売局側で利用していないとのことで廃止
"""
import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from typing import TypeVar
from boto3 import Session
import unicodedata
import boto3
import logging
import pendulum

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.operators.check_operator import CheckOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from common_ims.common_util import move_file_s3_to_s3_by_full_control

####################################################################################################
# DAG
####################################################################################################
local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2020,1,1,23,30,0,tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='report_hk_contract_by_area_list', # DAG名
    default_args=default_args,
    description='エリア別契約数リスト',
    schedule_interval='30 23 * * *', # 23時30分(JST)
    catchup=False
)

####################################################################################################
# Python関数
####################################################################################################

REDSHIFT_CONN_ID = 'redshift_default'
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
S3_BUCKET_NAME_TRANSFER = Variable.get('transfer_s3_bucket_name')
S3_PREFIX = 'hanbai/Hanbai/StoreAddress/Monthly'

QUERY_CONDITION_BY_AREA = {
    '0': "HON_SHISHA_CD = 1 AND M_HK_AREA.PREFECTURE_CD IN('08','09','10','11','12','13','14')",
    '1': "HON_SHISHA_CD = 1 AND M_HK_AREA.PREFECTURE_CD NOT IN('08','09','10','11','12','13','14')",
    '2': "HON_SHISHA_CD = 2",
    '3': "HON_SHISHA_CD = 3",
    '4': "HON_SHISHA_CD = 4",
    '5': "HON_SHISHA_CD = 5"
}

FILE_NAME_BY_AREA = {
    '0': '東京（一都六県）',
    '1': '東京（一都六県以外）',
    '2': '大阪',
    '3': '名古屋',
    '4': '西部',
    '5': '札幌',
}

LIST_HEADER = '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17\r\n'

T = TypeVar('T')

def to_str(p_value: T) -> str:
    """
    任意の型を文字列型に変換

    Parameters
    ----------
    p_value : T
        変換対象

    Returns
    -------
    str: 変換後文字列 (SHIFT JIS)
    """
    result = p_value
    if p_value is None:
        result = ''
    elif not isinstance(p_value, str):
        result = str(p_value)
    return result.encode('cp932').decode('cp932')

def hankaku_to_zenkaku(p_text: str) -> str:
    """
    半角 - 全角変換

    Parameters
    ----------
    p_text : str
        変換対象文字列

    Returns
    -------
    str: 全角変換後文字列
    """
    return p_text.translate(str.maketrans({chr(0x0021 + i): chr(0xFF01 + i) for i in range(94)}))

def get_takuhai_shimeymd(
    p_conn,
    p_schema: str,
    p_exec_date: str) -> dict:
    """
    締め日取得

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名
    Returns
    -------
    dict: 締め日と年月の辞書
    """
    query = f"""SELECT TAKUHAI_SHIME_YMD,YEAR_MONTH
    FROM {p_schema}.T_IMS_TAKUHAI_SHIME
    WHERE YEAR_MONTH = TO_CHAR(TO_DATE('{p_exec_date}', 'YYYYMMDD') - 1, 'YYYYMM')
    ORDER BY TAKUHAI_SHIME_YMD DESC"""
    logging.info(query)

    with p_conn.cursor() as cursor:
        cursor.execute(query)
        rec = cursor.fetchall()

    dic = { 'TakuhaiShimeYmd': rec[0][0], 'YearMonth': rec[0][1] }

    return dic

def get_branch_year(p_conn, p_schema: str) -> str:
    """
    事業所年度取得

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名

    Returns
    -------
    str: 事業所年度
    """
    query = f"""SELECT MAX(NENDO) FROM {p_schema}.T_HE_BRANCH_STATISTICS"""
    logging.info(query)
    with p_conn.cursor() as cursor:
        cursor.execute(query)
        rec = cursor.fetchall()

        result = rec[0][0]

    return result

def get_population_year(p_conn, p_schema: str) -> str:
    """
    世代数年度取得

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名

    Returns
    -------
    str: 世代数年度
    """
    query = f"""SELECT MAX(NENDO) FROM {p_schema}.T_HE_POPULATION_STATISTICS_OUTLINE"""
    logging.info(query)
    with p_conn.cursor() as cursor:
        cursor.execute(query)
        rec = cursor.fetchall()

        result = rec[0][0]

    return result

def get_query_contract_by_area(p_schema: str, p_area: str, p_exec_date: str) -> str:
    """
    エリア別契約数リスト_東京（一都六県）_帳票取得～エリア別契約数リスト_札幌_帳票取得クエリ作成

    Parameters
    ----------
    p_schema : str
        Redshiftスキーマ名
    p_area: str
        エリア

    Returns
    -------
    str: エリア別契約数リスト取得クエリ
    """
    condition = QUERY_CONDITION_BY_AREA[p_area]

    query = f"""SELECT
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_CD,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.KEITO_CD,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_NM,
                 THE.TOGETU_TAKUHAISU,
                 CASE 
                     WHEN T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_PERSONAL IS NOT NULL OR T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_CORPORATION IS NOT NULL 
                     THEN NVL(T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_PERSONAL,0) + NVL(T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_CORPORATION,0)
                     ELSE NULL
                 END,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.JGDC,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.PREFECTURE_NM,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.SHIKUTYOUSON_NM,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.TSUSHO_NM,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.CHOME_NM,
                 DECODE(V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.W_CNT_STORE_ADDRESS,0,NULL,V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.W_CNT_STORE_ADDRESS),
                 DECODE(V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.D_CNT_STORE_ADDRESS,0,NULL,V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.D_CNT_STORE_ADDRESS),
                 DECODE(V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.TUKI_CNT_ADDRESS,0,NULL,V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.TUKI_CNT_ADDRESS),
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.SETAISU,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.JIGYOSHOSU,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.MOSAIC_TYPE,
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.MOSAIC_TYPE_NM
             FROM
                 (
                     SELECT
                         SNAPSHOT_DATE,
                         STORE_CD,
                         KEITO_CD,
                         STORE_NM,
                         JGDC,
                         PREFECTURE_CD,
                         SHIKUTYOUSON_CD,
                         TSUSHO_CD,
                         CHOME_CD,
                         PREFECTURE_NM,
                         SHIKUTYOUSON_NM,
                         TSUSHO_NM,
                         CHOME_NM,
                         W_CNT_STORE_ADDRESS,
                         D_CNT_STORE_ADDRESS,
                         TUKI_CNT_ADDRESS,
                         SETAISU,
                         JIGYOSHOSU,
                         MOSAIC_TYPE,
                         MOSAIC_TYPE_NM,
                         MOSAIC_VERSION,
                         NK_CNT,
                         NK_DSR2_CNT,
                         NK_W_CNT,
                         NK_PERSONAL_TUKI_CNT,
                         NK_CORP_TUKI_CNT,
                         NK_OVERSEA_CNT,
                         HK_NK_CNT,
                         HK_NK_DSR2_CNT,
                         HK_HK_CNT,
                         HK_TRIAL_NK_CNT,
                         HK_TRIAL_NK_DSR2_CNT,
                         HK_TRIAL_HK_CNT,
                         HK_SUBSCRIPTION_NK_CNT,
                         HK_SUBSCRIPTION_NK_DSR2_CNT,
                         HK_SUBSCRIPTION_HK_CNT
                     FROM {p_schema}.T_IMS_HANBAI_NUM_STORE_ADDRESS_SS
                 ) V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS
                 LEFT OUTER JOIN
                 (
                     SELECT
                         TOGETU_TAKUHAISU
                         ,STORE_CD
                     FROM
                         {p_schema}.T_HE_INPUT_COMMON
                     WHERE
                         T_HE_INPUT_COMMON.PROCESS_YM = TO_CHAR(TO_DATE('{p_exec_date}', 'YYYYMMDD') - 1,'YYYYMM')
                     AND T_HE_INPUT_COMMON.BAITAI_CD = '10'
                 ) THE
                 ON
                     V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_CD = THE.STORE_CD
                 LEFT OUTER JOIN
                     {p_schema}.T_HE_STORE_ADDRESS_DELIVERY_NUM
                 ON
                     V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_CD = T_HE_STORE_ADDRESS_DELIVERY_NUM.STORE_CD
                 AND V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.JGDC = (
                                                                 T_HE_STORE_ADDRESS_DELIVERY_NUM.PREFECTURE_CD ||
                                                                 T_HE_STORE_ADDRESS_DELIVERY_NUM.SHIKUTYOUSON_CD ||
                                                                 T_HE_STORE_ADDRESS_DELIVERY_NUM.TSUSHO_CD ||
                                                                 T_HE_STORE_ADDRESS_DELIVERY_NUM.CHOME_CD
                                                                )
             WHERE   
                 TO_CHAR(SNAPSHOT_DATE,'YYYYMM') = TO_CHAR(TO_DATE('{p_exec_date}', 'YYYYMMDD') - 1,'YYYYMM')
             AND V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_CD IN
                     (
                         SELECT
                             STORE_CD
                         FROM
                             {p_schema}.M_HK_STORE
                             INNER JOIN 
                                 {p_schema}.M_HK_AREA
                             ON M_HK_STORE.AREA_CD = M_HK_AREA.AREA_CD
                         WHERE {condition}
                     ) 
             AND (
                  V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.W_CNT_STORE_ADDRESS <> 0
                  OR V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.D_CNT_STORE_ADDRESS <> 0
                  OR V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.TUKI_CNT_ADDRESS <> 0
                  OR T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_PERSONAL IS NOT NULL
                  OR T_HE_STORE_ADDRESS_DELIVERY_NUM.NK_CORPORATION IS NOT NULL
                 ) 
             ORDER BY
                 V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.STORE_CD
               , V_T_IMS_HANBAI_NUM_STORE_ADDRESS_SS.JGDC"""

    return query

def get_contract_by_area(
    p_conn,
    p_schema: str,
    p_area: str,
    p_exec_date: str) -> list:
    """
    エリア別契約数リスト_東京（一都六県）_帳票取得～エリア別契約数リスト_札幌_帳票取得

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        Redshiftスキーマ名
    p_area: str
        エリア

    Returns
    -------
    list: エリア別契約数リスト_東京（一都六県）_帳票取得～エリア別契約数リスト_札幌_帳票データ
    """
    query = get_query_contract_by_area(p_schema=p_schema, p_area=p_area, p_exec_date=p_exec_date)
    logging.info(query)

    with p_conn.cursor() as cursor:
        cursor.execute(query)
        recs = cursor.fetchall()

        contract_by_area = []
        for rec in recs:
            dic = {}
            dic['StoreCd'] = rec[0]
            dic['KeitoCd'] = rec[1]
            dic['StoreNm'] = rec[2]
            dic['TogetsuTakuhaisu'] = rec[3]
            dic['HonshiTakuhaisu'] = rec[4]
            dic['Jgdc'] = rec[5]
            dic['PrefectureNm'] = rec[6]
            dic['ShikutyousonNm'] = rec[7]
            dic['TsushoNm'] = rec[8]
            dic['ChomeNm'] = rec[9]
            dic['WCntStoreAddress'] = rec[10]
            dic['DCntStoreAddress'] = rec[11]
            dic['TukiCntAddress'] = rec[12]
            dic['Setaisu'] = rec[13]
            dic['Jigyoshosu'] = rec[14]
            dic['MosaicType'] = rec[15]
            dic['MosaicTypeNm'] = rec[16]

            contract_by_area.append(dic)

    return contract_by_area

def create_header(p_yyyy: str, p_mm: str, p_dd: str) -> str:
    """
    ヘッダ部作成

    Parameters
    ----------
    p_yyyy : str
        年
    p_mm : str
        月
    p_dd : str
        日

    Returns
    -------
    str: ヘッダ部
    """
    zen_yyyy = hankaku_to_zenkaku(p_text=p_yyyy)
    zen_mm = hankaku_to_zenkaku(p_text=p_mm)
    zen_dd = hankaku_to_zenkaku(p_text=p_dd)

    value = "補足\r\n"
    value += f'・　当リストのデータは、{zen_yyyy}年{zen_mm}月{zen_dd}日に統合マーケから取得しました。\r\n'
    value += f'・　列No.4は、販売店別の宅配数です。また、{zen_yyyy}年{zen_mm}月の数値です。\r\n'
    value += '・　列No.13、14、15は、住所コード別の数値です。（販売店の担当比率を考慮していません） \r\n'
    value += '・　列No.11、12は、紙契約情報(読者管理)の販売店および住所コード別に集計した件数です。 \r\n'
    value += '注意事項（*）\r\n'
    value += '「月ぎめプラン」のユーザーの所在地は住所コードで特定していますので、複数店制の地域は、それぞれに同じ数が記載されています。ご注意ください。\r\n'

    return value

def create_list(
    p_contract_by_area: list,
    p_yyyy: str,
    p_mm: str,
    p_poulation_year: str,
    p_branch_year: str) -> str:
    """
    リスト部作成

    Parameters
    ----------
    p_contract_by_area : list
        リスト
    p_yyyy : str
        年
    p_mm : str
        月
    p_poulation_year : str
        世帯数年度
    p_branch_year : str
        事業所数年度

    Returns
    -------
    str: リスト部
    """
    header = LIST_HEADER
    header = header + '販売店コード,'
    header = header + '系統コード,'
    header = header + '販売店名,'
    header = header + f'宅配数（販売店別）{p_yyyy}年{p_mm}月,'
    header = header + '本紙宅配数（町丁名別）,'
    header = header + '住所コード,'
    header = header + '都道府県名,'
    header = header + '市区町村名,'
    header = header + '大字通称名,'
    header = header + '字丁目名,'
    header = header + 'Wプラン契約数（販売店・住所ｺｰﾄﾞ別）,'
    header = header + '日経ID決済宅配数（販売店・住所ｺｰﾄﾞ別）,'
    header = header + '月ぎめ契約数（住所ｺｰﾄﾞ別）,'
    header = header + f'世帯数{p_poulation_year}年度,'
    header = header + f'事業所数{p_branch_year}年度,'
    header = header + 'Mosaicタイプ,'
    header = header + 'Mosaicタイプ名\r\n'

    value = ''
    for elem in p_contract_by_area:
        rec = []
        rec.append(to_str(elem['StoreCd']))
        rec.append(to_str(elem['KeitoCd']))
        rec.append(to_str(elem['StoreNm']))
        rec.append(to_str(elem['TogetsuTakuhaisu']))
        rec.append(to_str(elem['HonshiTakuhaisu']))
        rec.append(to_str(elem['Jgdc']))
        rec.append(to_str(elem['PrefectureNm']))
        rec.append(to_str(elem['ShikutyousonNm']))
        rec.append(to_str(elem['TsushoNm']))
        rec.append(to_str(elem['ChomeNm']))
        rec.append(to_str(elem['WCntStoreAddress']))
        rec.append(to_str(elem['DCntStoreAddress']))
        rec.append(to_str(elem['TukiCntAddress']))
        rec.append(to_str(elem['Setaisu']))
        rec.append(to_str(elem['Jigyoshosu']))
        rec.append(to_str(elem['MosaicType']))
        rec.append(to_str(elem['MosaicTypeNm']))

        value = value + ','.join(rec)
        value = value + '\r\n'

    return header + value


def save_report_to_s3(
    p_header: str,
    p_list: str,
    p_area: str,
    p_yyyy: str,
    p_mm: str) -> None:
    """
    エリア別契約数リスト_東京（一都六県）_帳票取得～エリア別契約数リスト_札幌_帳票 S3出力

    Parameters
    ----------
    p_header : str
        ヘッダ部
    p_list : str
        リスト部
    p_area : str
        エリア
    p_yyyy : str
        年
    p_mm : str
        月

    Returns
    -------
    なし
    """

    s3client = Session().client('s3')
    object_key = f'app/{S3_PREFIX}/エリア別契約数リスト_{FILE_NAME_BY_AREA[p_area]}_{p_yyyy}{p_mm}.csv'

    s3resource = boto3.resource('s3')
    obj = s3resource.Object(S3_BUCKET_NAME, object_key)
    obj.put(Body=f'{p_header}{p_list}'.encode('cp932'))

    move_file_s3_to_s3_by_full_control(s3client, S3_BUCKET_NAME, S3_BUCKET_NAME_TRANSFER, object_key, f'{S3_PREFIX}/エリア別契約数リスト_{FILE_NAME_BY_AREA[p_area]}_{p_yyyy}{p_mm}.csv')

def main(**context) -> None:
    """
    エリア別契約数リスト_東京（一都六県）_帳票取得～エリア別契約数リスト_札幌_帳票 主処理

    Parameters
    ----------
    p_conn: psycopg2.extensions.connection
        Redshift接続
    p_schema : str
        スキーマ名
    p_area : str
        エリア
    p_mode : str
        モード
    Returns
    -------
    なし
    """
    try:
        conn =  PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        exec_date = convUTC2JST(context['next_execution_date'], "%Y%m%d")

        schema = REDSHIFT_SCHEMA
        params = context['params']
        area = params['area']

        takuhai_shimeymd = get_takuhai_shimeymd(p_conn=conn, p_schema=schema, p_exec_date=exec_date)

        shimeymd = takuhai_shimeymd['TakuhaiShimeYmd']

        shime_yyyy = shimeymd[0:4]
        shime_mm = shimeymd[4:6]
        shime_dd = shimeymd[6:8]

        branch_year = get_branch_year(p_conn=conn, p_schema=schema)
        population_year = get_population_year(p_conn=conn, p_schema=schema)
        contract_by_area = get_contract_by_area(
            p_conn=conn,
            p_schema=schema,
            p_area=area,
            p_exec_date=exec_date
        )

        save_report_to_s3(
            p_header=create_header(p_yyyy=shime_yyyy, p_mm=shime_mm, p_dd=shime_dd),
            p_list=create_list(
                p_contract_by_area=contract_by_area,
                p_yyyy=shime_yyyy,
                p_mm=shime_mm,
                p_poulation_year=population_year,
                p_branch_year=branch_year
            ),
            p_area=area,
            p_yyyy=shime_yyyy,
            p_mm=shime_mm
        )
    except Exception as e:
        logging.error(f'*** main Exception: {str(e)}')
        conn.rollback()
        raise e

    finally:
        if conn:
            conn.close()

####################################################################################################
# 帳票作成処理
####################################################################################################

output_contract_by_area_list_tokyo = PythonOperator(
    task_id='output_contract_by_area_list_tokyo',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '0'
    },
    dag=dag
)

output_contract_by_area_list_besides_tokyo = PythonOperator(
    task_id='output_contract_by_area_list_besides_tokyo',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '1'
    },
    dag=dag
)

output_contract_by_area_list_osaka = PythonOperator(
    task_id='output_contract_by_area_list_osaka',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '2'
    },
    dag=dag
)

output_contract_by_area_list_nagoya = PythonOperator(
    task_id='output_contract_by_area_list_nagoya',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '3'
    },
    dag=dag
)

output_contract_by_area_list_seibu = PythonOperator(
    task_id='output_contract_by_area_list_seibu',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '4'
    },
    dag=dag
)

output_contract_by_area_list_sapporo = PythonOperator(
    task_id='output_contract_by_area_list_sapporo',
    python_callable=main,
    provide_context=True,
    params= {
        'area': '5'
    },
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

####################################################################################################
# 締め日チェック処理
####################################################################################################

def is_shime_date(**context):
    exec_date = convUTC2JST(context['next_execution_date'], "%Y%m%d")
    query = f"""SELECT
                 TAKUHAI_SHIME_YMD
                FROM
                 {REDSHIFT_SCHEMA}.T_IMS_TAKUHAI_SHIME
                 WHERE
                  YEAR_MONTH = TO_CHAR(TO_DATE('{exec_date}', 'YYYYMMDD') - 1, 'YYYYMM')
                  AND TAKUHAI_SHIME_YMD = '{exec_date}'"""
    hook = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID)
    # 締め日チェック処理
    for record in hook.get_records(query):
        logging.info(f'*** is_shime_date: {str(record[0])}')
        if len(record) >= 1:
            return True
    return False

check_shime_date = ShortCircuitOperator(
    task_id='check_shime_date',
    python_callable=is_shime_date,
    provide_context=True,
    dag=dag
)


#######################################################################################################
# 前提チェック
#######################################################################################################

check_tables = (
    ('M_HK_AREA',                          'impr_hk_to_ims', 's3_to_redshift_m_hk_area',                          30), # 毎日23時00分(JST)
    ('M_HK_STORE',                         'impr_hk_to_ims', 's3_to_redshift_m_hk_store',                         30), # 毎日23時00分(JST)
    ('T_HE_BRANCH_STATISTICS',             'impr_he_to_ims', 's3_to_redshift_t_he_branch_statistics',             30), # 毎日23時00分(JST)
    ('T_HE_INPUT_COMMON',                  'impr_he_to_ims', 's3_to_redshift_t_he_input_common',                  30), # 毎日23時00分(JST)
    ('T_HE_POPULATION_STATISTICS_OUTLINE', 'impr_he_to_ims', 's3_to_redshift_t_he_population_statistics_outline', 30), # 毎日23時00分(JST)
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=7200,      #120分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

check_t_ims_hanbai_num_store_address_ss = CheckOperator(
    task_id='check_t_ims_hanbai_num_store_address_ss',
    conn_id=REDSHIFT_CONN_ID,
    sql=f"""
        SELECT
            count(*) > 0 as result
        FROM
            {REDSHIFT_SCHEMA}.T_IMS_HANBAI_NUM_STORE_ADDRESS_SS""",
    retries=3,
    retry_delay=timedelta(minutes=3),
    dag=dag
)


####################################################################################################
# 依存関係
####################################################################################################
check_shime_date >> check_tasks >> output_contract_by_area_list_tokyo
check_shime_date >> check_t_ims_hanbai_num_store_address_ss >> output_contract_by_area_list_tokyo
output_contract_by_area_list_tokyo >> output_contract_by_area_list_besides_tokyo
output_contract_by_area_list_besides_tokyo >> output_contract_by_area_list_osaka
output_contract_by_area_list_osaka >> output_contract_by_area_list_nagoya
output_contract_by_area_list_nagoya >> output_contract_by_area_list_seibu
output_contract_by_area_list_seibu >> output_contract_by_area_list_sapporo >> done_all_task_for_check
