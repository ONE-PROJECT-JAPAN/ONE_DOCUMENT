import sys, os

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from common_ims import batch
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


default_args = {
    'start_date': datetime(2021,1,1,0,30,0, tzinfo=pendulum.timezone("Asia/Tokyo")),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=1), # 他システムの処理タイミングには依存しないため短めにする
    'on_failure_callback': notify_failure
}

dag = DAG(
    'extr_cm_sftp_to_s3',
    default_args=default_args,
    description='ClickM@iler の SFTP サーバーからデータを抽出する',
    schedule_interval='45 4 * * *', # 毎日04時45分(JST)
    catchup=False,
    user_defined_macros={'convUTC2JST':convUTC2JST},
)

extract_from_cm5 = batch.create_operator(
    dag=dag,
    task_id=f'extract_from_cm5',
    job_name='extract-sftp-clickmailer-cm5',
    queue=batch.QUEUE_DEFAULT,
    command=[
        '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        '{{ var.value.datastore_s3_bucket_name }}',
        'inbox/recv/cm',
        'CM5',
    ]
)

extract_from_cm6 = batch.create_operator(
    dag=dag,
    task_id=f'extract_from_cm6',
    job_name='extract-sftp-clickmailer-cm6',
    queue=batch.QUEUE_DEFAULT,
    command=[
        '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        '{{ var.value.datastore_s3_bucket_name }}',
        'inbox/recv/cm',
        'CM6',
    ]
)

extract_from_cm5
extract_from_cm6
