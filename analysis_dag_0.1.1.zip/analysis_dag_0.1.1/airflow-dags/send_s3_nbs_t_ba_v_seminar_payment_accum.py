import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum
import boto3

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,12,35,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_nbs_t_ba_v_seminar_payment_accum',
    default_args=default_args,
    description='NBSへの連携データ作成',
    schedule_interval='35 12 * * *', # 毎日12時35分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# 環境変数:DBスキーマ名
DB_SCHEMA = Variable.get('redshift_ims_schema_name')

# 環境変数:S3バケット名
S3_BUCKET_NAME = Variable.get('sharedfs_s3_bucket_name')

# ファイル出力先
S3_OUTPUT_PATH = """{}/Asteria/IMS/NBS/NBS申し込みリスト/{}_wk_"""

HEADER = '"VF_日経ビジネススクール講座申込","IS_日経ID会員番号_表示用","IS_性別","VF_年齢","IS_都道府県(郵便番号)","IS_職業名","IS_職種名","IS_業種名","IS_役職名","IS_従業員規模","IS_勤務先・学校","所属される部署名","講座内部ID","申し込み日時","申し込みID","受講料（税込）","開催日","定員数（表示用）"\r\n'

#######################################################################################################
# 前提チェック
#######################################################################################################

# M_AD_NIKKEI_ID

check_replace_m_ad_nikkei_id = ExternalTaskSensor(
    task_id='check_replace_m_ad_nikkei_id',
    external_dag_id='trns_replace_m_ad_nikkei_id',
    external_task_id='replace_m_ad_nikkei_id',
    execution_delta=timedelta(minutes=320), # 毎日7時15分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 共通属性

check_replace_m_is_nx_attribute = ExternalTaskSensor(
    task_id='check_replace_m_is_nx_attribute',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='replace_m_is_nx_attribute',
    execution_delta=timedelta(minutes=355), # 毎日6時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 講座本番

check_s3_to_redshift_t_ba_v_seminar_honban = ExternalTaskSensor(
    task_id='check_s3_to_redshift_t_ba_v_seminar_honban',
    external_dag_id='impr_ba_to_ims',
    external_task_id='s3_to_redshift_t_ba_v_seminar_honban',
    execution_delta=timedelta(minutes=415), # 毎日5時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 申し込みデータ蓄積

check_s3_to_redshift_t_ba_v_seminar_payment_accum = ExternalTaskSensor(
    task_id='check_s3_to_redshift_t_ba_v_seminar_payment_accum',
    external_dag_id='impr_ba_to_ims',
    external_task_id='s3_to_redshift_t_ba_v_seminar_payment_accum',
    execution_delta=timedelta(minutes=415), # 毎日5時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)

# 汎用属性マートデータ蓄積（RPサイト）

check_finish_t_gp_attr_ac = ExternalTaskSensor(
    task_id='check_finish_t_gp_attr_ac',
    external_dag_id='trns_update_t_gp_attr_ac',
    external_task_id='finish_t_gp_attr_ac',
    execution_delta=timedelta(minutes=395), # 毎日6時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)


#######################################################################################################
# 処理
#######################################################################################################

# 送信ファイル作成処理

redshift_to_s3_to_nbs = PostgresOperator(
    task_id='redshift_to_s3_to_nbs',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/ims/unload_nbs_subscription_list.sql',
    params = {
        's3_path' : S3_OUTPUT_PATH
    },
    autocommit=False,
    dag=dag
)

# 送信ファイルリネーム、改行コード変更処理

def main(**context):
    exec_date = convUTC2JST(context['next_execution_date'], "%Y%m%d")
    src_path =f'Asteria/IMS/NBS/NBS申し込みリスト/{exec_date}_wk_000'
    dst_path= f'Asteria/IMS/NBS/NBS申し込みリスト/{exec_date}_NBS申し込みリスト.csv'

    s3client = boto3.client('s3')
    s3resource = boto3.resource('s3')
    
    response = s3client.get_object(Bucket=S3_BUCKET_NAME, Key=src_path)
    src_data = response['Body'].read().decode('utf-8')
    dst_data = HEADER + src_data.replace('\n', '\r\n')
    
    dst_obj = s3resource.Object(bucket_name=S3_BUCKET_NAME, key=dst_path)
    dst_obj.put(Body=dst_data.encode('utf-8'))
    
    s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=src_path)

rename_send_s3_file = PythonOperator(
    task_id='rename_send_s3_file',
    python_callable=main,
    provide_context=True,
    dag=dag
)

#######################################################################################################
# 依存関係
#######################################################################################################

[
  check_replace_m_ad_nikkei_id,
  check_replace_m_is_nx_attribute,
  check_s3_to_redshift_t_ba_v_seminar_honban,
  check_s3_to_redshift_t_ba_v_seminar_payment_accum,
  check_finish_t_gp_attr_ac
] >> redshift_to_s3_to_nbs >> rename_send_s3_file
