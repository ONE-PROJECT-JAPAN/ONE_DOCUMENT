import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from common_ims.bqexec import bigquery_executor
from common_ims.bqsync import redshift_to_bigquery
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,15,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_mm', # DAG名
    default_args=default_args,
    description='マーケットシステム(MM)データのBigQuery連携',
    schedule_interval='15 7 * * *', # 毎日07時15分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# マーケットシステム(MM)データの構築

check_impr_mm_to_ims_1 = ExternalTaskSensor(
    task_id='check_impr_mm_to_ims_1',
    external_dag_id='impr_mm_to_ims_1',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=300), # 02時15分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=2700,      #45分
    retries=0,
    dag=dag
)

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=35), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=2700,      #45分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    redshift_to_bigquery_t_mm_port_stock = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_mm_port_stock',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_mm_port_stock.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_STOCK'
    )

    redshift_to_bigquery_m_mm_comp_profile_nkd = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_mm_comp_profile_nkd',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_mm_comp_profile_nkd.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_COMP_PROFILE_NKD'
    )

    redshift_to_bigquery_t_mm_port_fund = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_mm_port_fund',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_mm_port_fund.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_FUND'
    )

    redshift_to_bigquery_t_mm_port_free = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_mm_port_free',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_mm_port_free.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_FREE'
    )

    redshift_to_bigquery_t_mm_port_custom_info = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_mm_port_custom_info',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_mm_port_custom_info.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_CUSTOM_INFO'
    )

    redshift_to_bigquery_m_mm_quick_apis_usastocks_service = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_mm_quick_apis_usastocks_service',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_mm_quick_apis_usastocks_service.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_QUICK_APIS_USASTOCKS_SERVICE'
    )

    redshift_to_bigquery_m_mm_needs_gyoshu_master_m = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_mm_needs_gyoshu_master_m',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_mm_needs_gyoshu_master_m.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_NEEDS_GYOSHU_MASTER_M'
    )

    redshift_to_bigquery_m_mm_fund_profile_nkd = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_m_mm_fund_profile_nkd',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/m_mm_fund_profile_nkd.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_FUND_PROFILE_NKD'
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_mm_port_stock_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_mm_port_stock_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_STOCK_AC',
        execute_query='sql/bigquery/execute/UPD__T_MM_PORT_STOCK_AC.sql'
    )

    bq_update_m_mm_comp_profile_nkd_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_mm_comp_profile_nkd_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_COMP_PROFILE_NKD_AC',
        execute_query='sql/bigquery/execute/UPD__M_MM_COMP_PROFILE_NKD_AC.sql'
    )

    bq_update_t_mm_port_fund_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_mm_port_fund_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_FUND_AC',
        execute_query='sql/bigquery/execute/UPD__T_MM_PORT_FUND_AC.sql'
    )

    bq_update_t_mm_port_free_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_mm_port_free_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_FREE_AC',
        execute_query='sql/bigquery/execute/UPD__T_MM_PORT_FREE_AC.sql'
    )

    bq_update_t_mm_port_custom_info_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_mm_port_custom_info_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_MM_PORT_CUSTOM_INFO_AC',
        execute_query='sql/bigquery/execute/UPD__T_MM_PORT_CUSTOM_INFO_AC.sql'
    )

    bq_update_m_mm_quick_apis_usastocks_service_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_mm_quick_apis_usastocks_service_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_QUICK_APIS_USASTOCKS_SERVICE_AC',
        execute_query='sql/bigquery/execute/UPD__M_MM_QUICK_APIS_USASTOCKS_SERVICE_AC.sql'
    )

    bq_update_m_mm_needs_gyoshu_master_m_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_mm_needs_gyoshu_master_m_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_NEEDS_GYOSHU_MASTER_M_AC',
        execute_query='sql/bigquery/execute/UPD__M_MM_NEEDS_GYOSHU_MASTER_M_AC.sql'
    )

    bq_update_m_mm_fund_profile_nkd_ac = bigquery_executor(
        dag=dag,
        group_id='bq_update_m_mm_fund_profile_nkd_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='M_MM_FUND_PROFILE_NKD_AC',
        execute_query='sql/bigquery/execute/UPD__M_MM_FUND_PROFILE_NKD_AC.sql'
    )


"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_mm_to_ims_1 ] >> redshift_to_bigquery_t_mm_port_stock >> bq_update_t_mm_port_stock_ac >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_mm_to_ims_1 ] >> redshift_to_bigquery_t_mm_port_fund >> bq_update_t_mm_port_fund_ac >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_mm_to_ims_1 ] >> redshift_to_bigquery_t_mm_port_free >> bq_update_t_mm_port_free_ac >> done_all_task_for_check
[ check_s3_to_redshift_m_is_nx_user_serial_id, check_impr_mm_to_ims_1 ] >> redshift_to_bigquery_t_mm_port_custom_info >> bq_update_t_mm_port_custom_info_ac >> done_all_task_for_check
check_impr_mm_to_ims_1 >> redshift_to_bigquery_m_mm_comp_profile_nkd >> bq_update_m_mm_comp_profile_nkd_ac >> done_all_task_for_check
check_impr_mm_to_ims_1 >> redshift_to_bigquery_m_mm_quick_apis_usastocks_service >> bq_update_m_mm_quick_apis_usastocks_service_ac >> done_all_task_for_check
check_impr_mm_to_ims_1 >> redshift_to_bigquery_m_mm_needs_gyoshu_master_m >> bq_update_m_mm_needs_gyoshu_master_m_ac >> done_all_task_for_check
check_impr_mm_to_ims_1 >> redshift_to_bigquery_m_mm_fund_profile_nkd >> bq_update_m_mm_fund_profile_nkd_ac >> done_all_task_for_check
