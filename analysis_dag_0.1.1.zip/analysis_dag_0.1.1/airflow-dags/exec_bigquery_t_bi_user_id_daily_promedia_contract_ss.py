import os
import sys

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from common_ims.bqexec import bigquery_executor
from common_ims.notification import notify_failure

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS'
local_tz = pendulum.timezone("Asia/Tokyo")

default_args = {
    'start_date': datetime(2022, 8, 16, 8, 0, 0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

#
# exec_bigquery_t_bi_user_id_daily_promedia_contract_ss
# T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS構築
# 毎日08時00分(JST)
#
dag = DAG(
    dag_id=f'exec_bigquery_{BIGQUERY_TABLE_NAME.lower()}',
    default_args=default_args,
    description=f'{BIGQUERY_TABLE_NAME}構築',
    schedule_interval='0 8 * * *',
    catchup=False
)

#
# 前提テーブル構築チェック
# M_CRM_CODE, M_BB_CORPORATE_PLN             毎日07時00分(JST)
# T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS      毎日07時30分(JST)
# T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS 毎日07時30分(JST)
#
check_tables = (
    ('M_CRM_CODE',                                 'send_bigquery_master',                                     'done_all_task_for_check', 60),
    ('T_BI_USER_ID_DAILY_DS_PRIORITY_PLN_SS',      'exec_bigquery_t_bi_user_id_daily_ds_priority_pln_ss',      'done_all_task_for_check', 30),
    ('T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS', 'exec_bigquery_t_bi_user_id_daily_service_priority_pln_ss', 'done_all_task_for_check', 30),
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=7200,      #120分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

#
# BigQueryテーブル操作
#
with dag:
    append_t_bi_user_id_daily_promedia_contract_ss = bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_id_daily_promedia_contract_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS',
        execute_query='sql/bigquery/execute/UPD__T_BI_USER_ID_DAILY_PROMEDIA_CONTRACT_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#
# 依存関係
#
check_tasks >> append_t_bi_user_id_daily_promedia_contract_ss >> done_all_task_for_check
