import os
import sys
from typing import Type

sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

import logging
from datetime import datetime, timedelta

import pendulum
from airflow import DAG
from airflow.models import Variable
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from boto3 import Session
from common_ims.common_util import (convUTC2JST,
                                    move_file_s3_to_s3_by_full_control)
from common_ims.notification import notify_failure

#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,6,0,0, tzinfo=local_tz),
    'retries': 0,
    'depends_on_past': False,
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_cs_to_ims', # DAG名
    default_args=default_args,
    description='CSシステム(CS)データ構築',
    schedule_interval='*/10 * * * *', # 毎10分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)

####################################################################################################
# 定数宣言
####################################################################################################

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# ロード対象ファイルパス
S3_INPUT_PATH = 'inbox/recv/cs/'

# 1度のロード対象ファイルパス
S3_INPUT_PATH_TEMP_LOAD = 'inbox/cmp/cs/datastore_load_data/'

# ファイル退避パス
S3_ARCHIVE_PATH = 'inbox/cmp/cs/'

# ロードエラーファイル退避パス
S3_ERROR_PATH = 'inbox/error/cs/'

# RedshiftのIAM ロール
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

# テーブル名
LOAD_TABLE_LIST = ['T_CS_INCIDENT', 'T_CS_INCIDENT_THREAD']

# ファイルPrefix
LOAD_FILE_PRE_DICT = {"T_CS_INCIDENT":"T_CS_INCIDENT_20", "T_CS_INCIDENT_THREAD":"T_CS_INCIDENT_THREAD_20"}

# テーブルキー
LOAD_TABLE_KEY_DICT = {"T_CS_INCIDENT":"REF_NO, UPDATED_UTC", "T_CS_INCIDENT_THREAD":"REF_NO, ENTERED_UTC, SEQ"}

# テーブルカラム
TABLE_COL_DICT = {"T_CS_INCIDENT":"CREATED_UTC\
, UPDATED_UTC\
, REF_NO\
, SUBJECT\
, STATUS_NAME\
, QUEUE_NAME\
, ASSGN_ACCT_NAME\
, PROD_NAME\
, CAT_NAME\
, DISP_NAME\
, LABEL_01_NAME\
, LABEL_02_NAME\
, APPLICATION_SOURCE_NAME\
, SEVERITY_NAME\
, ACCEPT_CASE_CAT_NAME\
, ACCEPT_DATE_UTC\
, MEMO\
, STORE_AREA\
, STORE_NAME\
, STORE_CODE\
, DELIVERY_START_DATE\
, APPLICATION_NUMBER\
, CUSTOMER_ID\
, STORE_PHONE\
, PHONE_CATEGORY_NAME\
, DEVICE_CATEGORY_NAME\
, DEVICE_NAME\
, OS_VERSION\
, BROWSER_NAME\
, CONNECTION_CATEGORY_NAME\
, AGREEMENT_ELECTRONIC_EDITION_NAME\
, READING_PAPER_NAME\
, SHOP_NEWSPAPER\
, CORPORATE_NAME\
, DIVISION\
, RESPONSIBLE_AGENCY\
, INQUIRY_CONTENT_NAME\
, CURRENT_READING_NAME\
, FOREIGN_ADDRESS\
, DM_ADDRESSEE\
, DM_TITLE\
, DM_CAMPAIGN_CODE\
, INDIVIDUAL_AREA1\
, INDIVIDUAL_AREA2\
, INDIVIDUAL_AREA3\
, INDIVIDUAL_AREA4\
, NAME\
, FURIGANA\
, BIRTH_DATE\
, GENDER\
, PHONE\
, COUNTRY_OF_RESIDENCE\
, POSTAL_CODE\
, ADDRESS\
, IDENTIFICATION_ITEM1_NAME\
, IDENTIFICATION_ITEM2_NAME\
, IDENTIFICATION_ITEM3_NAME\
, CURRENT_PLAN_NAME\
, EMAIL\
, CUSTOMER_ID_PAPER_CHARGES\
, NIKKEI_MEMBER_NO\
, SERIAL_ID\
, REJECT_DM\
, REJECT_PHONE\
, ALERT_FLG\
, MAILBOX_NAME\
, INTERFACE_NAME\
, SOURCE_NAME"\
\
, "T_CS_INCIDENT_THREAD":"REF_NO, ENTERED_UTC, ENTRY_TYPE_NAME, CHAN_NAME, SEQ, NOTE "}


#######################################################################################################
# Python定義
#######################################################################################################

# ロード処理（一時テーブルを作成し、蓄積処理を行う）

def load_table(table_name, s3_input_prefix):
    conn = None
    cursor = None
    try:
        logging.info(f'*** load_table s3_input_prefix: {s3_input_prefix}')

        # DB 接続
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        cursor = conn.cursor()
        
        # ロード用の一時テーブルを作成
        query_temp_create = f"""CREATE TEMPORARY TABLE TEMP_{table_name} AS SELECT * from {REDSHIFT_SCHEMA}.{table_name} limit 0"""
        
        # ロード
        query_copy = f"""COPY TEMP_{table_name} FROM 's3://{S3_BUCKET_NAME}/{s3_input_prefix}' CREDENTIALS 'aws_iam_role={REDSHIFT_DEFAULT_ROLE_ARN}' DELIMITER '\t' IGNOREHEADER 1 CSV QUOTE AS '"' EMPTYASNULL ACCEPTINVCHARS TRUNCATECOLUMNS TIMEFORMAT 'auto';"""
        
        # 同一キーのデータを削除
        query_original_delete = f"""DELETE FROM {REDSHIFT_SCHEMA}.{table_name} WHERE ({LOAD_TABLE_KEY_DICT[table_name]}) IN (SELECT DISTINCT {LOAD_TABLE_KEY_DICT[table_name]} FROM TEMP_{table_name})"""
        
        # 一時テーブルから本テーブルにデータ追加（万が一同一蓄積キーのデータが届いた場合は一つのみ登録）
        query_original_insert = f"""INSERT INTO {REDSHIFT_SCHEMA}.{table_name} SELECT {TABLE_COL_DICT[table_name]} FROM (SELECT ROW_NUMBER() over(partition by {LOAD_TABLE_KEY_DICT[table_name]}) as rownum, * from TEMP_{table_name}) WHERE rownum = 1"""
        
        # 一時テーブル作成
        logging.info(f'*** load_table query_temp_create: {query_temp_create}')
        cursor.execute(query_temp_create)
        
        # ロード
        logging.info(f'*** load_table query_copy: {query_copy}')
        cursor.execute(query_copy)
        
        # 蓄積キーにてデータ削除
        logging.info(f'*** load_table query_original_delete: {query_original_delete}')
        cursor.execute(query_original_delete)
        
        # 一時テーブルからデータ追加
        logging.info(f'*** load_table query_original_insert: {query_original_insert}')
        cursor.execute(query_original_insert)
        
        # テーブル毎コミット
        conn.commit()
    except Exception as e:
        logging.error(f'*** load_table Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()


# 指定のパスから指定のパスにファイルを移す

def move_files(s3client, file_list, org_path, dest_path):
    logging.info(f'*** move_files org_path: {org_path} dest_path: {dest_path}')
    
    # 空のファイルは処理しない
    if file_list == None:
        logging.warning(f'*** move_files file_list: {str(file_list)}')
        return
        
    # 対象ファイル
    for key_path in file_list:
        file_pair = os.path.split(key_path)
        # コピー元
        org_key = os.path.join(org_path, file_pair[1])
        # コピー先
        dest_key = os.path.join(dest_path, file_pair[1])
        
        try:
            # ファイルコピー
            move_file_s3_to_s3_by_full_control(s3client, S3_BUCKET_NAME, S3_BUCKET_NAME, org_key, dest_key)
            
        except Exception as e:
            logging.warning(f'*** move_files Exception: {str(e)}')
            # 失敗しても例外は無視する
            continue

# 主処理

def main(**context):
    s3client = Session().client('s3')
    logging.info(f'*** load_table S3_BUCKET_NAME: {S3_BUCKET_NAME}')
    
    # ロード結果（空：正常、空でない：異常）
    load_result = ''
    
    # 処理対象テーブル
    for table_name in LOAD_TABLE_LIST:
        logging.info(f'*** main table_name: {table_name}')
        s3_input_prefix_table = """{}{}""".format(S3_INPUT_PATH, LOAD_FILE_PRE_DICT[table_name])
        s3_input_prefix_temp_load = """{}{}/""".format(S3_INPUT_PATH_TEMP_LOAD, LOAD_FILE_PRE_DICT[table_name])
        
        #
        # ロード対象ファイル確認
        #
        response = None
        keys = None
        try:
            response = s3client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_input_prefix_table)

            # 処理対象ファイル有無チェック
            if not('Contents' in response):
                logging.info(f'*** main s3_input_prefix_tableにファイルなし: {s3_input_prefix_table}')
                # ファイルが存在しない場合は何もしない
                continue

        except Exception as e_list:
            logging.error(f'*** main ファイル取得エラー : {str(e_list)}')
            # ロード結果にテーブル名を格納し、処理継続する
            load_result += f'{table_name}  '
            continue
        #
        # ファイル取得しロード処理
        #
        try:
            if 'Contents' in response:
                keys = [i['Key'] for i in response['Contents']]
                logging.info(f'*** main keys: {keys}')

                # ロード対象ファイルをロード用のパスへ移動（移動中）
                move_files(s3client, keys, S3_INPUT_PATH, s3_input_prefix_temp_load)

                # 一時フォルダのファイル一覧を再取得（前スケジュールの取り残された分を含めて取得））
                prefix_response = s3client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_input_prefix_temp_load)
                if 'Contents' in prefix_response:
                    prefix_keys = [i['Key'] for i in prefix_response['Contents']]
                    logging.info(f'*** main ロード処理 prefix_keys: {prefix_keys}')
                    # 退避ファイル対象を再設定
                    keys = prefix_keys

                # ロード処理
                load_table(table_name, s3_input_prefix_temp_load)

                # ファイル退避（正常終了時）
                move_files(s3client, keys, s3_input_prefix_temp_load, S3_ARCHIVE_PATH)
        except Exception as e_load:
            # ロードエラー発生時にはタスクをエラーとし、エラー通知する）
            logging.warning(f'*** main table_name:{table_name} ==>  Exception: {str(e_load)}')
            
            # ロード結果（空：正常、空でない：異常）初期化
            load_result = ''

            # 1回 リトライ (DB接続エラーのため)
            try:
                # ロード処理
                logging.warning(f'*** main LOAD リトライ : {str(keys)}')
                
                load_table(table_name, s3_input_prefix_temp_load)
                
                # ファイル退避（正常終了時）
                move_files(s3client, keys, s3_input_prefix_temp_load, S3_ARCHIVE_PATH)
            except Exception as e_retry:
            
                # 対象ファイルをログに出力
                logging.warning(f'*** main LOAD リトライ NG files: {str(keys)}')
                
                # ファイル退避（異常終了時）
                move_files(s3client, keys, s3_input_prefix_temp_load, S3_ERROR_PATH)

                # ロード結果にテーブル名を格納し、処理継続する
                load_result += f'{table_name}  '

    # ロード結果が空白でない場合はロード中エラーと判断し例外発生させる
    if len(load_result) != 0:
        raise Exception(f'ロード中にエラーが発生したため、タスクが異常終了しました。ロードエラーテーブル: {load_result}')

#######################################################################################################
# データ構築処理
#######################################################################################################

# インシデント情報及びインシデントスレッドデータロード

s3_to_redshift_t_cs_incident_and_thread = PythonOperator(
    task_id="s3_to_redshift_t_cs_incident_and_thread",
    python_callable=main,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_cs_incident_and_thread
