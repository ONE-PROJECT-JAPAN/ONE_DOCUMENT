import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,10,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'ma_replace_master', # DAG名
    default_args=default_args,
    description='MAマスタデータ取込処理',
    schedule_interval='10 7 * * *', # 毎日 7:10(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DB_SCHEMA = Variable.get('redshift_ims_schema_name')        # DBスキーマ名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')   # S3のバケット名
S3_PATH = f"""app/ma/master/"""                             # マスタデータパス
S3_PATH_MASTER_1 = f"""s3://{S3_BUCKET_NAME}/{S3_PATH}M_MA_MAIL_SEND_INFO"""
S3_PATH_MASTER_2 = f"""s3://{S3_BUCKET_NAME}/{S3_PATH}M_MA_DELIVERY_LIST_INFO"""


#######################################################################################################
# データ構築処理
#######################################################################################################

# MAメール配信情報マスタデータロード

replace_m_ma_mail_send_info = PostgresOperator(
    task_id='replace_m_ma_mail_send_info',
    postgres_conn_id='redshift_default',
    sql='sql/ma/replace_m_ma_master.sql',
    params = {
        's3_path' : S3_PATH_MASTER_1,
        'table_name' : 'M_MA_MAIL_SEND_INFO'
    },
    autocommit=False,
    dag=dag
)

# MA配信リスト情報マスタデータロード

replace_m_ma_delivery_list_info = PostgresOperator(
    task_id='replace_m_ma_delivery_list_info',
    postgres_conn_id='redshift_default',
    sql='sql/ma/replace_m_ma_master.sql',
    params = {
        's3_path' : S3_PATH_MASTER_2,
        'table_name' : 'M_MA_DELIVERY_LIST_INFO'
    },
    autocommit=False,
    dag=dag
)

# S3のマスタファイル削除

delete_from_s3_master = S3DeleteObjectsOperator(
    task_id='delete_from_s3_master',
    aws_conn_id='aws_default',
    bucket = '{{ var.value.datastore_s3_bucket_name }}',
    prefix = S3_PATH,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

[replace_m_ma_mail_send_info, replace_m_ma_delivery_list_info] >> delete_from_s3_master
