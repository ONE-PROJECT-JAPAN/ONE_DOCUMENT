import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
from common_ims.trial_api_util import move_file_s3_to_s3
import logging
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,0,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_ims_t_kk_v_trial_campaign_apply',
    default_args=default_args,
    description='お試し施策適用VIEW作成処理',
    schedule_interval='*/30 * * * *', # 随時30分(JST)
    catchup=False,
    user_defined_macros={'convUTC2JST':convUTC2JST},
    max_active_runs=1
)

####################################################################################################
# 定数宣言
####################################################################################################

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# IMSバケット名
S3_BUCKET_NAME_LEGACY_IMS = Variable.get('legacy_ims_s3_bucket_name')

# 転送元
S3_TANSFER_PATH_ORG = """app/{}/T_KK_V_TRIAL_CAMPAIGN_APPLY/"""

# 転送先
S3_TANSFER_PATH_DEST = """{}/T_KK_V_TRIAL_CAMPAIGN_APPLY/{}"""


#######################################################################################################
# データ構築処理
#######################################################################################################

# お試し施策適用VIEW洗替

replace_w_kk_v_trial_campaign_apply = PostgresOperator(
    task_id='replace_w_kk_v_trial_campaign_apply',
    postgres_conn_id='redshift_default',
    sql='sql/kk/replace_t_kk_v_trial_campaign_apply.sql',
    autocommit=False,
    dag=dag
)

# お試し施策適用VIEW S3出力

redshift_to_s3_t_kk_v_trial_campaign_apply = PostgresOperator(
    task_id='redshift_to_s3_t_kk_v_trial_campaign_apply',
    postgres_conn_id='redshift_default',
    sql='sql/kk/unload_t_kk_v_trial_campaign_apply.sql',
    params = {
        's3_path' : """{}/app/{}/T_KK_V_TRIAL_CAMPAIGN_APPLY/{}_T_KK_V_TRIAL_CAMPAIGN_APPLY"""
    },
    autocommit=False,
    dag=dag
)

# お試し施策適用VIEW S3連携

def move_file_s3_to_s3_ims(**context):
    next_execution_date = context['next_execution_date']
    move_file_s3_to_s3(S3_BUCKET_NAME, S3_BUCKET_NAME_LEGACY_IMS, S3_TANSFER_PATH_ORG, S3_TANSFER_PATH_DEST, next_execution_date)

s3_to_s3_ims = PythonOperator(
    task_id="s3_to_s3_ims",
    python_callable=move_file_s3_to_s3_ims,
    dag=dag
)

#######################################################################################################
# 依存関係
#######################################################################################################

replace_w_kk_v_trial_campaign_apply >> redshift_to_s3_t_kk_v_trial_campaign_apply >> s3_to_s3_ims
