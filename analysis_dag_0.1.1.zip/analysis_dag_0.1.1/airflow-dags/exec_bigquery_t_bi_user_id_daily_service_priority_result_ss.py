import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,7,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='exec_bigquery_t_bi_user_id_daily_service_priority_result_ss', # DAG名
    default_args=default_args,
    description='会員ID日別サービス別優先判定結果スナップショット',
    schedule_interval='30 7 * * *', # 毎日 7:30(JST)
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS'

#######################################################################################################
# データ構築処理
#######################################################################################################

check_send_bigquery_bb = ExternalTaskSensor(
    task_id='check_send_bigquery_bb',
    external_dag_id='send_bigquery_bb',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=10), # 毎日07時20分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_send_bigquery_kk = ExternalTaskSensor(
    task_id='check_send_bigquery_kk',
    external_dag_id='send_bigquery_kk',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=30), # 毎日07時00分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)

check_update_m_is_nx_attribute = ExternalTaskSensor(
    task_id='check_update_m_is_nx_attribute',
    external_dag_id='exec_bigquery_m_is_nx_attribute',
    external_task_id='done_all_task_for_check',
    execution_delta=timedelta(minutes=20), # 毎日07時10分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300,
    timeout=7200,
    retries=0,
    dag=dag
)


#
# BigQueryテーブル操作
#
with dag:
    append_t_bi_user_id_daily_service_priority_result_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_id_daily_service_priority_result_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS',
        execute_query=f'sql/bigquery/execute/UPD__T_BI_USER_ID_DAILY_SERVICE_PRIORITY_RESULT_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

[ check_send_bigquery_bb, 
  check_send_bigquery_kk,
  check_update_m_is_nx_attribute
] >> append_t_bi_user_id_daily_service_priority_result_ss >> done_all_task_for_check
