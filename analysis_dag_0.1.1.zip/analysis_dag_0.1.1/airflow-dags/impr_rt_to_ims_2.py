import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,11,45,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='impr_rt_to_ims_2', # DAG名
    default_args=default_args,
    description='Rtoaster(RT)データの構築',
    schedule_interval='45 11 * * *', # 毎日11時45分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


#######################################################################################################
# 前提チェック
#######################################################################################################

# 広告配信新日経統合IDマスタ

check_m_ad_nikkei_id = ExternalTaskSensor(
    task_id='check_m_ad_nikkei_id',
    external_dag_id='trns_replace_m_ad_nikkei_id',
    external_task_id='replace_m_ad_nikkei_id',
    execution_delta=timedelta(minutes=270), # 07:15 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# RT_M_メンバ値変換）ワークデータロード

s3_to_redshift_w_rt_m_mapping = PythonOperator(
    task_id='s3_to_redshift_w_rt_m_mapping',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_M_MAPPING',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# RT_M_メンバ値変換_蓄積用

s3_to_redshift_m_rt_m_mapping_accum = PythonOperator(
    task_id='s3_to_redshift_m_rt_m_mapping_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_M_MAPPING',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['LAST_UPDATE_DATE', 'MEMBER_VALUE'],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_RT_M_MAPPING_ACCUM'
    },
    dag=dag
)

# メンバ値変換データ蓄積

replace_m_rt_m_mapping_accum_accum = PostgresOperator(
    task_id='replace_m_rt_m_mapping_accum_accum',
    postgres_conn_id='redshift_default',
    sql='sql/rt/m_rt_m_mapping_accum_accum.sql',
    autocommit=False,
    dag=dag
)

# RT_T_顧客スコア履歴ワークデータロード

s3_to_redshift_w_rt_t_score = PythonOperator(
    task_id='s3_to_redshift_w_rt_t_score',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_T_SCORE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# RT_T_顧客スコア履歴_蓄積用

s3_to_redshift_t_rt_t_score_accum = PythonOperator(
    task_id='s3_to_redshift_t_rt_t_score_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_T_SCORE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER_VALUE', 'VISIT_NUM', 'SCORE_GROUP', 'SCORE_ITEM'],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_RT_T_SCORE_ACCUM'
    },
    dag=dag
)

# RT_M_固定スコア履歴ワークデータロード

s3_to_redshift_w_rt_m_user = PythonOperator(
    task_id='s3_to_redshift_w_rt_m_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_M_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1
    },
    dag=dag
)

# RT_M_固定スコア履歴_蓄積用

s3_to_redshift_m_rt_m_user_accum = PythonOperator(
    task_id='s3_to_redshift_m_rt_m_user_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'rt',
        'redshift_loader_table_name': 'W_RT_M_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'tsv-gzip',
        'redshift_loader_skip_rows': 1,
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': ['MEMBER_VALUE', 'VISIT_NUM'],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_RT_M_USER_ACCUM'
    },
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_w_rt_m_mapping >> [s3_to_redshift_m_rt_m_mapping_accum, check_m_ad_nikkei_id] >> replace_m_rt_m_mapping_accum_accum
s3_to_redshift_w_rt_t_score >> s3_to_redshift_t_rt_t_score_accum
s3_to_redshift_w_rt_m_user >> s3_to_redshift_m_rt_m_user_accum
