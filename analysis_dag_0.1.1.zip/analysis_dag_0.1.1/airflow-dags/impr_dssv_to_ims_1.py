import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,4,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_dssv_to_ims_1', # DAG名
    default_args=default_args,
    description='配信システム(DSSV)のデータ構築',
    schedule_interval='0 4 * * *', # 毎日04時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)


####################################################################################################
# 定数宣言
####################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

#######################################################################################################
# データ構築処理
#######################################################################################################

# ＴＲＮメール送信設定情報データロード 

s3_to_redshift_t_dsu_t_ds_mail_set_info = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_mail_set_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_MAIL_SET_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮメール送信設定情報蓄積

s3_to_redshift_t_dsu_t_ds_mail_set_info_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_mail_set_info_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_MAIL_SET_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'SEND_MAIL_KIND' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_MAIL_SET_INFO_ACCUM',
    },
    dag=dag
)

# ＭＳＴ送信メール種別データロード 

s3_to_redshift_m_dsu_m_send_mail_kind = PythonOperator(
    task_id='s3_to_redshift_m_dsu_m_send_mail_kind',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'M_DSU_M_SEND_MAIL_KIND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＭＳＴ送信メール種別データ蓄積

s3_to_redshift_m_dsu_m_send_mail_kind_accum = PythonOperator(
    task_id='s3_to_redshift_m_dsu_m_send_mail_kind_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'M_DSU_M_SEND_MAIL_KIND',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'SEND_MAIL_KIND' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'M_DSU_M_SEND_MAIL_KIND_ACCUM',

    },
    dag=dag
)

# ＴＲＮ会員情報管理データロード 

s3_to_redshift_t_dsu_t_ds_user_meta = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_user_meta',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_USER_META',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ会員情報管理蓄積

s3_to_redshift_t_dsu_t_ds_user_meta_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_user_meta_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_USER_META',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_USER_META_ACCUM',
    },
    dag=dag
)

# ＴＲＮクリッピングキーワードデータロード 

s3_to_redshift_t_dsu_t_ds_clipping_keywords = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_clipping_keywords',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_CLIPPING_KEYWORDS',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ鍵付き記事閲覧履歴データロード 

s3_to_redshift_t_dsu_t_ds_etsuranzumi_kiji_log = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_etsuranzumi_kiji_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_ETSURANZUMI_KIJI_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ鍵付き記事閲覧履歴データ蓄積

replace_t_dsu_t_ds_etsuranzumi_kiji_log_accum = PostgresOperator(
    task_id='replace_t_dsu_t_ds_etsuranzumi_kiji_log_accum',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/dssv/t_dsu_t_ds_etsuranzumi_kiji_log_accum.sql',
    autocommit=False,
    dag=dag
)

# ＴＲＮ閲覧本数履歴データロード 

s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_ETSURANZUMI_HONSU_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ閲覧本数履歴蓄積

s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_ETSURANZUMI_HONSU_LOG',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'BATCH_JIKKO_START_DATE' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_ETSURANZUMI_HONSU_LOG_ACCUM',
    },
    dag=dag
)

# ＴＲＮフォローデータロード 

s3_to_redshift_t_dsu_t_ds_follow_rensai = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_rensai',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_RENSAI',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮフォローデータ蓄積

replace_t_dsu_t_ds_follow_rensai_accum = PostgresOperator(
    task_id='replace_t_dsu_t_ds_follow_rensai_accum',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql='sql/dssv/t_dsu_t_ds_follow_rensai_accum.sql',
    autocommit=False,
    dag=dag
)

# ＴＲＮ人事ウォッチアラート条件データロード 

s3_to_redshift_t_dsu_t_ds_jwalert_info = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_jwalert_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_JWALERT_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ人事ウオッチアラート条件蓄積

s3_to_redshift_t_dsu_t_ds_jwalert_info_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_jwalert_info_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_JWALERT_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'TONYU_NUM' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_JWALERT_INFO_ACCUM',
    },
    dag=dag
)

# ＴＲＮ企業フォローデータロード 

s3_to_redshift_t_dsu_t_ds_follow_company = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ企業フォロー蓄積

s3_to_redshift_t_dsu_t_ds_follow_company_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'FOLLOW_TYPE', 'FOLLOW_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_ACCUM',
    },
    dag=dag
)

# ＴＲＮ企業フォロー個別最終チェック日時データロード 

s3_to_redshift_t_dsu_t_ds_follow_company_check = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_check',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_CHECK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ企業フォロー個別最終チェック日時蓄積

s3_to_redshift_t_dsu_t_ds_follow_company_check_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_check_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_CHECK',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'FOLLOW_TYPE', 'FOLLOW_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_CHECK_ACCUM',
    },
    dag=dag
)

# ＴＲＮ企業フォロー記事フィルタデータロード 

s3_to_redshift_t_dsu_t_ds_follow_company_news_filter = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_news_filter',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_NEWS_FILTER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ企業フォロー記事フィルタ蓄積

s3_to_redshift_t_dsu_t_ds_follow_company_news_filter_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_news_filter_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_NEWS_FILTER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_MEMBER_NO', 'FILTER_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_NEWS_FILTER_ACCUM',
    },
    dag=dag
)

# ＴＲＮ企業フォロー管理データロード 

s3_to_redshift_t_dsu_t_ds_follow_company_manage = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_manage',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_MANAGE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip'
    },
    dag=dag
)

# ＴＲＮ企業フォロー管理蓄積

s3_to_redshift_t_dsu_t_ds_follow_company_manage_accum = PythonOperator(
    task_id='s3_to_redshift_t_dsu_t_ds_follow_company_manage_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_MANAGE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'json-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'FOLLOW_TYPE', 'FOLLOW_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_DSU_T_DS_FOLLOW_COMPANY_MANAGE_ACCUM',
    },
    dag=dag
)

# グループデータロード

s3_to_redshift_t_dsg_t_ds_group = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_group',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_GROUP',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# Rグループ-ユーザデータロード

s3_to_redshift_t_dsg_t_ds_rel_group_user = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_rel_group_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_REL_GROUP_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# ユーザ情報データロード

s3_to_redshift_t_dsg_t_ds_user = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# シェアデータロード

s3_to_redshift_t_dsg_t_ds_share = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_share',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_SHARE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# シェアユーザデータロード

s3_to_redshift_t_dsg_t_ds_share_user = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_share_user',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_SHARE_USER',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# シェア閲覧ログデータロード

s3_to_redshift_t_dsg_t_ds_etsuran_log_share = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_etsuran_log_share',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_ETSURAN_LOG_SHARE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# コメントデータロード

s3_to_redshift_t_dsg_t_ds_comment = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_comment',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_COMMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 自動収集データロード

s3_to_redshift_t_dsg_t_ds_collection = PythonOperator(
    task_id='s3_to_redshift_t_dsg_t_ds_collection',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dssv',
        'redshift_loader_table_name': 'T_DSG_T_DS_COLLECTION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_dsu_t_ds_mail_set_info >> s3_to_redshift_t_dsu_t_ds_mail_set_info_accum >> done_all_task_for_check
s3_to_redshift_m_dsu_m_send_mail_kind >> s3_to_redshift_m_dsu_m_send_mail_kind_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_user_meta >> s3_to_redshift_t_dsu_t_ds_user_meta_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_clipping_keywords >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_etsuranzumi_kiji_log >> replace_t_dsu_t_ds_etsuranzumi_kiji_log_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log >> s3_to_redshift_t_dsu_t_ds_etsuranzumi_honsu_log_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_follow_rensai >> replace_t_dsu_t_ds_follow_rensai_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_jwalert_info >> s3_to_redshift_t_dsu_t_ds_jwalert_info_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_follow_company >> s3_to_redshift_t_dsu_t_ds_follow_company_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_follow_company_check >> s3_to_redshift_t_dsu_t_ds_follow_company_check_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_follow_company_news_filter >> s3_to_redshift_t_dsu_t_ds_follow_company_news_filter_accum >> done_all_task_for_check
s3_to_redshift_t_dsu_t_ds_follow_company_manage >> s3_to_redshift_t_dsu_t_ds_follow_company_manage_accum >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_group >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_rel_group_user >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_user >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_share >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_share_user >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_etsuran_log_share >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_comment >> done_all_task_for_check
s3_to_redshift_t_dsg_t_ds_collection >> done_all_task_for_check
