import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.operators.python_operator import PythonOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
from common_ims import batch
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,4,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_dkpw_to_ims', # DAG名
    default_args=default_args,
    description='日経W倶楽部(DKP2)のデータ構築',
    schedule_interval='40 4 * * *', # 毎日04時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')


#######################################################################################################
# 前提チェック
#######################################################################################################

# 住所マスタ

check_m_hk_address = ExternalTaskSensor(
    task_id='check_m_hk_address',
    external_dag_id='impr_hk_to_ims',
    external_task_id='s3_to_redshift_m_hk_address',
    execution_delta=timedelta(minutes=340), # 23:00 JST
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=300, #5分
    timeout=7200,      #120分
    retries=0,
    dag=dag
)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 応募者基本情報(DKP2)データロード

s3_to_redshift_t_dkpw_applicant_basic_info = PythonOperator(
    task_id='s3_to_redshift_t_dkpw_applicant_basic_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dkpw',
        'redshift_loader_table_name': 'T_DKPW_APPLICANT_BASIC_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 応募者管理情報(DKP2)データロード

s3_to_redshift_t_dkpw_applicant_mng_info = PythonOperator(
    task_id='s3_to_redshift_t_dkpw_applicant_mng_info',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dkpw',
        'redshift_loader_table_name': 'T_DKPW_APPLICANT_MNG_INFO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)


#######################################################################################################
# 応募者基本情報(DKP2)クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_BF = 'app/cleansing/T_DKPW_APPLICANT_BASIC_INFO'
CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_AF = 'app/cleansing/T_DKPW_APPLICANT_BASIC_INFO_CL'
CLEANSIMG_PATH_T_DKPW_APPLICANT_BASIC_INFO_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_BF}'
CLEANSIMG_PATH_T_DKPW_APPLICANT_BASIC_INFO_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_AF}'

# 応募者基本情報(DKP2)（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_dkpw_applicant_basic_info = PostgresOperator(
    task_id='redshift_to_s3_t_dkpw_applicant_basic_info',
    postgres_conn_id='redshift_default',
    sql='sql/dkpw/t_dkpw_applicant_basic_info4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 応募者基本情報(DKP2)データクレンジング

cleanse_t_dkpw_applicant_basic_info = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_dkpw_applicant_basic_info",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_DKPW_APPLICANT_BASIC_INFO_BF,
        CLEANSIMG_PATH_T_DKPW_APPLICANT_BASIC_INFO_AF,
        "-colNo", "4",
        "-telno", "{3}",
    ]
)

# 応募者基本情報(DKP2)データクレンジング・蓄積(一時テーブルの削除含む)

update_t_dkpw_applicant_basic_info_cl_ac = PostgresOperator(
    task_id='update_t_dkpw_applicant_basic_info_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/dkpw/t_dkpw_applicant_basic_info_cl_ac.sql',
    params = {
        'dic_id_sec' : '4'
    },
    autocommit=False,
    dag=dag
)

# S3ファイル削除(応募者基本情報(DKP2)データクレンジング)

delete_from_s3_t_dkpw_applicant_basic_info_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_dkpw_applicant_basic_info_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_BF + '/',
    dag=dag
)

delete_from_s3_t_dkpw_applicant_basic_info_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_dkpw_applicant_basic_info_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_DKPW_APPLICANT_BASIC_INFO_AF + '/',
    dag=dag
)


#######################################################################################################
# 応募者管理情報(DKP2)クレンジング処理のために一時テーブル作成、IFテーブルからデータ投入
#######################################################################################################

CL_FILE_T_DKPW_APPLICANT_MNG_INFO_BF = 'app/cleansing/T_DKPW_APPLICANT_MNG_INFO'
CL_FILE_T_DKPW_APPLICANT_MNG_INFO_AF = 'app/cleansing/T_DKPW_APPLICANT_MNG_INFO_CL'
CLEANSIMG_PATH_T_DKPW_APPLICANT_MNG_INFO_BF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_DKPW_APPLICANT_MNG_INFO_BF}'
CLEANSIMG_PATH_T_DKPW_APPLICANT_MNG_INFO_AF = f's3://{DATASTORE_S3_BUCKET_NAME}/{CL_FILE_T_DKPW_APPLICANT_MNG_INFO_AF}'

# 応募者管理情報(DKP2)（クレンジング用一時テーブル）からクレンジング対象データをS3へ出力

redshift_to_s3_t_dkpw_applicant_mng_info = PostgresOperator(
    task_id='redshift_to_s3_t_dkpw_applicant_mng_info',
    postgres_conn_id='redshift_default',
    sql='sql/dkpw/t_dkpw_applicant_mng_info4cleaning.sql',
    autocommit=False,
    dag=dag
)

# 応募者管理情報(DKP2)データクレンジング

cleanse_t_dkpw_applicant_mng_info = batch.create_operator(
    dag=dag,
    task_id="cleanse_t_dkpw_applicant_mng_info",
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CLEANSIMG_PATH_T_DKPW_APPLICANT_MNG_INFO_BF,
        CLEANSIMG_PATH_T_DKPW_APPLICANT_MNG_INFO_AF,
        "-colNo", "6",
        "-postcode", "{2}",
        "-address", "{3}",
        "-name", "{4}",
        "-telno", "{5}",
    ]
)

# 応募者管理情報(DKP2)データクレンジング・蓄積(一時テーブルの削除含む)

update_t_dkpw_applicant_mng_info_cl_ac = PostgresOperator(
    task_id='update_t_dkpw_applicant_mng_info_cl_ac',
    postgres_conn_id='redshift_default',
    sql='sql/dkpw/t_dkpw_applicant_mng_info_cl_ac.sql',
    autocommit=False,
    dag=dag
)

# S3ファイル削除(応募者管理情報(DKP2)データクレンジング)

delete_from_s3_t_dkpw_applicant_mng_info_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_dkpw_applicant_mng_info_bf',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_DKPW_APPLICANT_MNG_INFO_BF + '/',
    dag=dag
)

delete_from_s3_t_dkpw_applicant_mng_info_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_dkpw_applicant_mng_info_af',
    aws_conn_id='aws_default',
    bucket = DATASTORE_S3_BUCKET_NAME,
    prefix = CL_FILE_T_DKPW_APPLICANT_MNG_INFO_AF + '/',
    dag=dag
)

# 応募者購読状況(DKP2)データロード

s3_to_redshift_t_dkpw_applicant_subscription_condition = PythonOperator(
    task_id='s3_to_redshift_t_dkpw_applicant_subscription_condition',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dkpw',
        'redshift_loader_table_name': 'T_DKPW_APPLICANT_SUBSCRIPTION_CONDITION',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 対象フォーム(DKP2)データロード

s3_to_redshift_m_dkpw_target_form = PythonOperator(
    task_id='s3_to_redshift_m_dkpw_target_form',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dkpw',
        'redshift_loader_table_name': 'M_DKPW_TARGET_FORM',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# フォーム分類マスタ(DKP2)データロード

s3_to_redshift_m_dkpw_form_category_mst = PythonOperator(
    task_id='s3_to_redshift_m_dkpw_form_category_mst',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'dkpw',
        'redshift_loader_table_name': 'M_DKPW_FORM_CATEGORY_MST',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 最終タスク

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_dkpw_applicant_basic_info >> redshift_to_s3_t_dkpw_applicant_basic_info >> cleanse_t_dkpw_applicant_basic_info >> update_t_dkpw_applicant_basic_info_cl_ac
update_t_dkpw_applicant_basic_info_cl_ac >> [delete_from_s3_t_dkpw_applicant_basic_info_bf, delete_from_s3_t_dkpw_applicant_basic_info_af] >> done_all_task_for_check
[check_m_hk_address, s3_to_redshift_t_dkpw_applicant_mng_info] >> redshift_to_s3_t_dkpw_applicant_mng_info >> cleanse_t_dkpw_applicant_mng_info >> update_t_dkpw_applicant_mng_info_cl_ac
update_t_dkpw_applicant_mng_info_cl_ac >> [delete_from_s3_t_dkpw_applicant_mng_info_bf, delete_from_s3_t_dkpw_applicant_mng_info_af] >> done_all_task_for_check
s3_to_redshift_t_dkpw_applicant_subscription_condition >> done_all_task_for_check
s3_to_redshift_m_dkpw_target_form >> done_all_task_for_check
s3_to_redshift_m_dkpw_form_category_mst >> done_all_task_for_check
