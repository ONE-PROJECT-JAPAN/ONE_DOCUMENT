import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.common_util import convUTC2JST
from common_ims.common_util import s3_to_redshift_accum_duplicate_key
from common_ims.notification import notify_failure
import logging
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,6,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_kk_to_ims_4', # DAG名
    default_args=default_args,
    description='日経ID課金・決済システム(KK)のデータ構築',
    schedule_interval='40 6 * * *', # 毎日06時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# ロード対象ファイルパス(現行)
S3_INPUT_PATH = 'inbox/recv/kk/'

# ファイル退避パス(現行)
S3_ARCHIVE_PATH = 'inbox/cmp/kk/'

# CPOYのオプション
COPY_OPTION = "CSV GZIP EMPTYASNULL DATEFORMAT 'auto' TIMEFORMAT 'auto'"

#######################################################################################################
# Python定義
#######################################################################################################

def load_t_kk_t_payment_amount_change_results(**context):
    """
    請求額変更実績(差分蓄積処理)

    Parameters:
    ----------
    context:
        Dict
    """

    # 対象テーブル
    table_name = "T_KK_T_PAYMENT_AMOUNT_CHANGE_RESULTS"
    # 取込対象の日付
    next_execution_date = context['next_execution_date']
    file_prefix_date = convUTC2JST(next_execution_date, "%Y%m%d")
    # 蓄積キー
    accum_key = "ID"
    # 蓄積キーが重複時のソートキー
    sort_key = "UPDATE_DATETIME desc"
    # テーブルのカラム（Insert時使用）
    table_cols = "\
ID\
, NIKKEI_ID_INTERNAL_MEMBER_NO\
, SERVICE_ID\
, PAYMENT_TARGET_YYYYMM_DATE\
, PAYMENT_NO\
, PAYMENT_COMMIT_DATE\
, PAYMENT_AMOUNT_CHANGE_TYPE\
, DISCOUNT_PRICE_CODE\
, COUPON_APPLY_NO\
, PARENT_SERVICE_ID_ARRAY\
, DIFFERENCE_AMOUNT\
, PAYMENT_COMMIT_NO\
, CREATE_ID\
, CREATE_DATETIME\
, UPDATE_ID\
, UPDATE_DATETIME\
, DELETE_ID\
, DELETE_DATETIME"
    
    # ファイル退避時にエラー発生した場合の挙動（エラーにしない））
    file_move_error_stop = False
    
    s3_to_redshift_accum_duplicate_key(
        S3_INPUT_PATH, S3_ARCHIVE_PATH, table_name, file_prefix_date, accum_key, sort_key, table_cols, COPY_OPTION, file_move_error_stop)


def load_t_kk_t_coupon_apply(**context):
    """
    割引クーポン適用(差分蓄積処理)

    Parameters:
    ----------
    context:
        Dict
    """
    # 対象テーブル
    table_name = "T_KK_T_COUPON_APPLY"
    # 取込対象の日付
    next_execution_date = context['next_execution_date']
    file_prefix_date = convUTC2JST(next_execution_date, "%Y%m%d")
    # 蓄積キー
    accum_key = "COUPON_APPLY_NO"
    # 蓄積キーが重複時のソートキー
    sort_key = "UPDATE_DATETIME desc"
    # テーブルのカラム（Insert時使用）
    table_cols = "\
COUPON_APPLY_NO\
, NIKKEI_ID_INTERNAL_MEMBER_NO\
, COUPON_CAMPAIGN_MANAGEMENT_NO\
, COUPON_CODE\
, SERVICE_ID\
, CONTRACT_NO\
, COUPON_DISCOUNT_START_YYYYMM_DATE\
, COUPON_DISCOUNT_END_YYYYMM_DATE\
, COUPON_DISCOUNT_PENALTY_END_DATE\
, APPLY_DATE\
, APPLY_END_DATE\
, APPLY_END_TYPE\
, CREATE_ID\
, CREATE_DATETIME\
, UPDATE_ID\
, UPDATE_DATETIME\
, DELETE_ID\
, DELETE_DATETIME"

    # ファイル退避時にエラー発生した場合の挙動（エラーにしない））
    file_move_error_stop = False
    
    s3_to_redshift_accum_duplicate_key(
        S3_INPUT_PATH, S3_ARCHIVE_PATH, table_name, file_prefix_date, accum_key, sort_key, table_cols, COPY_OPTION, file_move_error_stop)


#######################################################################################################
# データ構築処理
#######################################################################################################

# 請求額変更実績データロード

s3_to_redshift_t_kk_t_payment_amount_change_results = PythonOperator(
    task_id="s3_to_redshift_t_kk_t_payment_amount_change_results",
    python_callable=load_t_kk_t_payment_amount_change_results,
    dag=dag
)

# 割引クーポン適用データロード

s3_to_redshift_t_kk_t_coupon_apply = PythonOperator(
    task_id="s3_to_redshift_t_kk_t_coupon_apply",
    python_callable=load_t_kk_t_coupon_apply,
    dag=dag
)

# 申請履歴データロード

s3_to_redshift_t_kk_t_request_history = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_request_history',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_REQUEST_HISTORY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 請求データロード

s3_to_redshift_t_kk_t_payment = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_payment',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PAYMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 請求データ蓄積

s3_to_redshift_t_kk_t_payment_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_payment_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PAYMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'PAYMENT_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_PAYMENT_ACCUM',
    },
    dag=dag
)

# 認可データロード

s3_to_redshift_t_kk_t_permit = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_permit',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PERMIT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 認可データ蓄積

s3_to_redshift_t_kk_t_permit_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_permit_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PERMIT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'PERMIT_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_PERMIT_ACCUM',
    },
    dag=dag
)

# プラン価格改定履歴データロード

s3_to_redshift_t_kk_t_plan_price_change_history = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_plan_price_change_history',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PLAN_PRICE_CHANGE_HISTORY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# プラン価格改定履歴データ蓄積

s3_to_redshift_t_kk_t_plan_price_change_history_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_plan_price_change_history_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_PLAN_PRICE_CHANGE_HISTORY',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'PRICE_CHANGE_HISTORY_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_PLAN_PRICE_CHANGE_HISTORY_ACCUM',
    },
    dag=dag
)

# 顧客対応メモデータロード

s3_to_redshift_t_kk_t_customer_memo = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_customer_memo',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CUSTOMER_MEMO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 顧客対応メモデータ蓄積

s3_to_redshift_t_kk_t_customer_memo_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_customer_memo_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CUSTOMER_MEMO',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'NIKKEI_ID_INTERNAL_MEMBER_NO' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_CUSTOMER_MEMO_ACCUM',
    },
    dag=dag
)

# 契約明細データロード

s3_to_redshift_t_kk_t_contract_detail = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_contract_detail',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CONTRACT_DETAIL',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip'
    },
    dag=dag
)

# 契約明細データ蓄積

s3_to_redshift_t_kk_t_contract_detail_accum = PythonOperator(
    task_id='s3_to_redshift_t_kk_t_contract_detail_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'kk',
        'redshift_loader_table_name': 'T_KK_T_CONTRACT_DETAIL',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_KK_T_CONTRACT_DETAIL_ACCUM',
    },
    dag=dag
)

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_kk_t_payment_amount_change_results >> done_all_task_for_check
s3_to_redshift_t_kk_t_coupon_apply >> done_all_task_for_check
s3_to_redshift_t_kk_t_request_history >> done_all_task_for_check
s3_to_redshift_t_kk_t_payment >> s3_to_redshift_t_kk_t_payment_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_permit >> s3_to_redshift_t_kk_t_permit_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_plan_price_change_history >> s3_to_redshift_t_kk_t_plan_price_change_history_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_customer_memo >> s3_to_redshift_t_kk_t_customer_memo_accum >> done_all_task_for_check
s3_to_redshift_t_kk_t_contract_detail >> s3_to_redshift_t_kk_t_contract_detail_accum >> done_all_task_for_check
