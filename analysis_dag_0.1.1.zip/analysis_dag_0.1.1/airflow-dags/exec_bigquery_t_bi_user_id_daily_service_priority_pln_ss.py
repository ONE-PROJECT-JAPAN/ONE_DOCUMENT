import sys
import os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from airflow import DAG
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims.bqexec import bigquery_executor
import pendulum

BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')
BIGQUERY_TABLE_NAME = 'T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS'
local_tz = pendulum.timezone("Asia/Tokyo")

default_args = {
    'start_date': datetime(2021,1,1,7,30,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id=f'exec_bigquery_{BIGQUERY_TABLE_NAME.lower()}',
    default_args=default_args,
    description=f'{BIGQUERY_TABLE_NAME}構築',
    schedule_interval='30 7 * * *',
    catchup=False
)

#
# 前提テーブル構築チェック
#
check_tables = (
    ('M_IS_NX_ATTRIBUTE',    'exec_bigquery_m_is_nx_attribute', 'done_all_task_for_check', 20), # 毎日07時10分(JST)
    ('send_bigquery_kk',     'send_bigquery_kk',                'done_all_task_for_check', 30), # 毎日07時00分(JST)
    ('send_bigquery_bb',     'send_bigquery_bb',                'done_all_task_for_check', 10), # 毎日07時20分(JST)
)

check_tasks = []
for table in check_tables:
    check_task = ExternalTaskSensor(
        task_id=f'check_{table[0].lower()}',
        external_dag_id=table[1],
        external_task_id=table[2],
        execution_delta=timedelta(minutes=table[3]),
        allowed_states=['success'],
        mode='reschedule',
        poke_interval=300, #5分
        timeout=3600,      #60分
        retries=0,
        dag=dag
    )

    check_tasks.append(check_task)

#
# BigQueryテーブル操作
#
with dag:
    append_t_bi_user_id_daily_service_priority_pln_ss =  bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_id_daily_service_priority_pln_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS',
        execute_query=f'sql/bigquery/execute/UPD__T_BI_USER_ID_DAILY_SERVICE_PRIORITY_PLN_SS.sql'
    )

    append_t_bi_user_num_daily_service_priority_pln_ss = bigquery_executor(
        dag=dag,
        group_id='append_t_bi_user_num_daily_service_priority_pln_ss',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BI_USER_NUM_DAILY_SERVICE_PRIORITY_PLN_SS',
        execute_query='sql/bigquery/execute/UPD__T_BI_USER_NUM_DAILY_SERVICE_PRIORITY_PLN_SS.sql'
    )

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#
# 依存関係
#
check_tasks >> append_t_bi_user_id_daily_service_priority_pln_ss >> append_t_bi_user_num_daily_service_priority_pln_ss >> done_all_task_for_check
