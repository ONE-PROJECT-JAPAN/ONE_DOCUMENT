import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_etix_to_ims', # DAG名
    default_args=default_args,
    description='ETIXシステム(ETIX)のデータ構築',
    schedule_interval='0 8 * * *', # 毎日08時00分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# イーティックス・オンラインチケット購入情報データロード

s3_to_redshift_t_etix_ticket_purchase = PythonOperator(
    task_id='s3_to_redshift_t_etix_ticket_purchase',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'etix',
        'redshift_loader_table_name': 'T_ETIX_TICKET_PURCHASE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
    },
    dag=dag
)

# イーティックス・オンラインチケット購入情報データ蓄積

s3_to_redshift_t_etix_ticket_purchase_ac = PythonOperator(
    task_id='s3_to_redshift_t_etix_ticket_purchase_ac',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'etix',
        'redshift_loader_table_name': 'T_ETIX_TICKET_PURCHASE',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv',
        'redshift_loader_target_table_name': 'T_ETIX_TICKET_PURCHASE_AC',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'EVENT_NAME', 'EVENT_GENRE', 'EVENT_START_DATE', 'EVENT_END_DATE', 'OPEN_USER_ID', 'TICKET_PRICE_NAME', 'TICKET_PRICE', 'PURCHASE_DT_TM' ],
            'extra_columns': [
                 {'name': 'INS_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'INS_DT_TM',  'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_PGM_ID', 'value': "'{{ dag.dag_id }}'"},
                 {'name': 'UPD_DT_TM',  'value': "CONVERT_TIMEZONE ('Asia/Tokyo', GETDATE())"}
            ]
        }
    },
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    イーティックス・オンラインチケット購入情報
    """
    redshift_to_bigquery_t_etix_ticket_purchase = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_etix_ticket_purchase',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_etix_ticket_purchase.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_ETIX_TICKET_PURCHASE',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    update_t_etix_ticket_purchase_ac = bigquery_executor(
        dag=dag,
        group_id='update_t_etix_ticket_purchase_ac',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_ETIX_TICKET_PURCHASE_AC',
        execute_query='sql/bigquery/execute/UPD__T_ETIX_TICKET_PURCHASE_AC.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_etix_ticket_purchase >> s3_to_redshift_t_etix_ticket_purchase_ac >> done_all_task_for_check
s3_to_redshift_t_etix_ticket_purchase >> redshift_to_bigquery_t_etix_ticket_purchase >> update_t_etix_ticket_purchase_ac >> done_all_task_for_check

