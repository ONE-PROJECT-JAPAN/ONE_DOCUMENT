import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.amazon.aws.operators.s3_delete_objects import S3DeleteObjectsOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.python_operator import ShortCircuitOperator
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims import batch
from boto3 import Session
from chardet.universaldetector import UniversalDetector
import boto3
import logging
import pendulum


####################################################################################################
# DAG
####################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,0,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 0,
    'on_failure_callback': notify_failure
}

dag = DAG(
    'frnt_append_t_bj_event_participant_cl', # DAG名
    default_args=default_args,
    description='イベント参加者データクレンジング・取込',
    schedule_interval='*/5 10-22  * * *', # 毎日 10:00-22:00(JST) 5分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DB_SCHEMA      = Variable.get('redshift_ims_schema_name')   # DBスキーマ名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')   # S3のバケット名
S3_ROLE_ARN    = Variable.get('redshift_default_role_arn')  # S3のrole

# Xcom key名称
XCOM_EVENT_ID       = 'event_id'
XCOM_FILE_PATH      = 'file_path'
XCOM_M_EVENT_ID     = 'm_event_id'
XCOM_LOAD_STATUS_CD = 'load_status_cd'

# Fileパス
CL_FILE_EDIT      = 'app/event/W_BJ_EVENT_PARTICIPANT_CL/EDIT_EVENT_PARTICIPANT_LIST'      # ヘッダーなしファイル
CL_FILE_CLEANS_BF = 'app/cleansing/W_BJ_EVENT_PARTICIPANT_CL'     # クレンジング前
CL_FILE_CLEANS_AF = 'app/cleansing/W_BJ_EVENT_PARTICIPANT_CL_CL'  # クレンジング後
CL_FILE_CLEANS_BF_FULL_PATH = f"""s3://{S3_BUCKET_NAME}/{CL_FILE_CLEANS_BF}"""
CL_FILE_CLEANS_AF_FULL_PATH = f"""s3://{S3_BUCKET_NAME}/{CL_FILE_CLEANS_AF}"""

# DB copy 業務エラー
ERR_STL_LOAD_ERRORS = 'stl_load_errors'

# ファイル 存在なし　業務エラー
ERR_STL_NOFILE_ERRORS = 'NoSuchKey'

# 終了ステータス
RS_CODE_NORMAL = 1          # 正常終了
RS_CODE_ERROR_ETC = -1      # 異常終了：その他
RS_CODE_ERROR_ENCODE = -2   # 異常終了：文字コードNG

# 取込対象件数取得用のSQL
SQL_GET_CNT_LIST_BJ = f"""
    select
         count(epm.event_id)
    from
        {DB_SCHEMA}.T_BJ_EVENT_PARTICIPANT_LOAD_MNG epm
    left join 
        (select 
             event_id 
          from 
            {DB_SCHEMA}.M_BJ_EVENT 
          where 
              delete_flg = false) as em
    on
        epm.event_id = em.event_id
    where
        epm.load_status_cd = 0
    """

# 取込対象取得用のSQL（一度に1レコードのみ取得）※複数データを動的にタスク生成不可のため
SQL_GET_LIST_BJ = f"""
    select
         epm.event_id
        ,epm.event_participant_filepath
        ,epm.event_participant_filename
        ,em.event_id as m_event_id
    from
        {DB_SCHEMA}.T_BJ_EVENT_PARTICIPANT_LOAD_MNG epm
    left join 
        (select 
             event_id 
          from 
            {DB_SCHEMA}.M_BJ_EVENT 
          where 
              delete_flg = false) as em
    on
        epm.event_id = em.event_id
    where
        epm.load_status_cd = 0
    order by 
        epm.load_queue_timestamp
        asc
    limit 1
    """

# イベント参加者ワークを削除
SQL_DELETE = f"""
    delete from {DB_SCHEMA}.W_BJ_EVENT_PARTICIPANT;
    """

# イベント参加者ワークにロード
SQL_COPY = f"""
    copy {DB_SCHEMA}.W_BJ_EVENT_PARTICIPANT
    from 's3://{S3_BUCKET_NAME}/{CL_FILE_EDIT}' 
    iam_role '{S3_ROLE_ARN}'
    delimiter '\t' 
    null '';
    """

# イベント参加者ワークの項目を編集し、unload
SQL_UNLOAD = f"""
    unload ('
        select
        w.rowid as rowid_if,
        nvl(w.last_name,'''') || nvl(w.first_name,'''') as name,
        case when w.work_addr1 is null then nvl(w.home_zipcode,'''') else nvl(w.work_zipcode,'''') end as zipcode,
        case when w.work_addr1 is null then nvl(w.home_addr1,'''') || nvl(w.home_addr2,'''') else nvl(w.work_addr1,'''') || nvl(w.work_addr2,'''') end as address,
        case when w.work_addr1 is null then nvl(w.home_phone,'''') else nvl(w.work_phone,'''') end as phone
        from {DB_SCHEMA}.W_BJ_EVENT_PARTICIPANT w 
        order by zipcode
    ') 
    to '{CL_FILE_CLEANS_BF_FULL_PATH}/W_BJ_EVENT_PARTICIPANT_CL_'
    iam_role '{S3_ROLE_ARN}'
    csv delimiter as ',' 
    null '' 
    allowoverwrite 
    parallel off;
    """

#######################################################################################################
# データ構築処理
#######################################################################################################

# 取込対象イベント参加者ファイル検索　※対象レコードの有無のみ確認

def get_list_count(**context):

    hook = PostgresHook(postgres_conn_id='redshift_default')

    # 処理対象件数確認
    for record in hook.get_records(SQL_GET_CNT_LIST_BJ):
        logging.info('get_list_count :' + str(record[0]))
        if record[0] >= 1:
            return True
    return False

# 取込対象イベント参加者ファイル検索　結果（分岐）　1件以上の場合、後続処理へ遷移（0件の場合、後続処理スキップで終了）

check_exist_task_list_data = ShortCircuitOperator(
     task_id='check_exist_task_list_data',
     python_callable=get_list_count,
     provide_context=True,
     dag=dag
)

# 取込対象イベント参加者ファイル検索　※対象レコードの取得（１レコードのみ）

def get_list_from_sql(**context):

    hook = PostgresHook(postgres_conn_id='redshift_default')
    for record in hook.get_records(SQL_GET_LIST_BJ):
        logging.info('get_list_from_sql record:' + str(record))
        return record

get_bj_list_task = PythonOperator(
     task_id='get_bj_list_task',
     python_callable=get_list_from_sql,
     provide_context=True,
     dag=dag
)

# イベント参加者ファイルのチェック処理

def edit_s3_file (**context):

    # context 内より task_id を key に取得
    paramForList = context['task_instance'].xcom_pull(task_ids='get_bj_list_task')
    logging.info('edit_s3_file  paramForList :' + str(paramForList))

    try:
        # 引数取得
        event_id = paramForList[0]
        file_path = paramForList[1]
        m_event_id = paramForList[3]
        
        if len(m_event_id) == 0:
            logging.warning('edit_s3_file  : 取込対象のイベントがイベントマスタに登録されていません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        # xcomに値格納
        context['ti'].xcom_push(key=XCOM_EVENT_ID, value=str(event_id))
        context['ti'].xcom_push(key=XCOM_FILE_PATH, value=str(file_path))
        context['ti'].xcom_push(key=XCOM_M_EVENT_ID, value=str(m_event_id))

        # sql実行結果リストなし判定
        s3 = boto3.resource('s3')
        bucket = s3.Bucket(S3_BUCKET_NAME)
        
        obj = bucket.Object(file_path)

        response = obj.get()
        body = response['Body'].read()

        if len(body) == 0:
            logging.warning('edit_s3_file  : 処理対象ファイルが0バイトです')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        # 文字コードチェック
        detector = UniversalDetector()
        for line in body.splitlines():
            # 1行ずつfeed
            detector.feed(line)
            # 推定結果が定まるとdetector.doneがTrueになる
            if detector.done:
                break
        detector.close()

        enc = detector.result['encoding']
        del line # 不要メモリ解消
        del detector # 不要メモリ解消

        if(( enc != 'utf-8') and (enc != 'ascii')):
            logging.warning('edit_s3_file : 処理対象ファイルの文字コードがASCIIまたはUTF-8ではありません' + str(enc))
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ENCODE))
            return RS_CODE_ERROR_ENCODE

        load_data = body.decode('utf-8')
        del body # 不要メモリ解消

        all_line = load_data.splitlines()
        del load_data # 不要メモリ解消

        records = []
        for line in all_line:
            records.append(line.split('\t'))
        del all_line # 不要メモリ解消

        # ヘッダー（先頭１行）を移動　（配列から削除）
        headers = records.pop(0)
        
        if not headers[0]:
            logging.warning('edit_s3_file  : 処理対象ファイルにヘッダ行が設定されていません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        if len(records) == 0:
            logging.warning('edit_s3_file  : 処理対象ファイルにレコード行が存在しません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC

        # ヘッダーなしファイルを作成
        dumpData = ''
        for record in records:
            output_record = []
            for n in record:
                output_record.append(n)
            # レコードセット
            dumpData += '\t'.join(output_record)
            dumpData += '\n'

        # ファイル出力
        obj_output = bucket.Object(CL_FILE_EDIT)
        obj_output.put(Body = dumpData)

        del records # 不要メモリ解消

    except Exception as e:

        if (ERR_STL_NOFILE_ERRORS in str(e)) :
            logging.warning('edit_s3_file  : 処理対象ファイルが存在しません')
            context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
            return RS_CODE_ERROR_ETC
        
        logging.error('edit_s3_file Exception e :' + str(e))
        context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_ERROR_ETC))
        return RS_CODE_ERROR_ETC

    # 正常終了
    context['ti'].xcom_push(key=XCOM_LOAD_STATUS_CD, value=str(RS_CODE_NORMAL))
    return RS_CODE_NORMAL

edit_t_bj_event_participant_cl = PythonOperator (
    task_id='edit_t_bj_event_participant_cl',
    provide_context=True,
    python_callable=edit_s3_file,
    dag=dag
)

# イベント参加者ファイルのチェック処理　結果（分岐）　ファイルが正常の場合、後続処理へ遷移（ファイルが異常の場合、エラー処理へ遷移）

def check_edit_result(**context):

    # context 内より task_id を key に取得
    result = context['task_instance'].xcom_pull(task_ids='edit_t_bj_event_participant_cl')
    if result == RS_CODE_NORMAL:
        return 'convert_tsv2csv_t_bj_event_participantl_cl'
    else:
        logging.warning('check_edit_result : イベント参加者ファイル：NG ' + str(result))
        return 'update_t_bj_event_participant_edit_error'

branch_task_file_edit_result = BranchPythonOperator(
    task_id='branch_task_file_edit_result',
    dag=dag,
    python_callable=check_edit_result,
)

# イベント参加者ワークロード及び、レコード取得・ファイル書き出し

def load_t_bj_event_participant_cl4tsv(**context):

    conn = None
    cursor = None
    try:
        conn = PostgresHook(postgres_conn_id='redshift_default').get_conn()
        cursor = conn.cursor()
        
        # SQL実行：一時テーブル作成
        cursor.execute(SQL_DELETE)
        try:
            # SQL実行：ロード処理
            cursor.execute(SQL_COPY)
        except Exception as copy_exe:
            logging.error('load_t_bj_event_participant_cl4tsv Exception copy_exe :' + str(copy_exe))

            # ロードエラーのみを業務エラーとして処理する
            if (ERR_STL_LOAD_ERRORS in str(copy_exe)) :
                # 異常終了時のタスク名
                return 'update_t_bj_event_participant_load_error'
            raise copy_exe

        # SQL実行：クレンジング用のUnload処理
        cursor.execute(SQL_UNLOAD)
        conn.commit()
    except Exception as e:
        logging.error('load_t_bj_event_participant_cl4tsv Exception e :' + str(e))
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

    # 正常終了時のタスク名
    return 'cleanse_t_bj_event_participant_cl'

convert_tsv2csv_t_bj_event_participantl_cl = PythonOperator(
     task_id='convert_tsv2csv_t_bj_event_participantl_cl',
     python_callable=load_t_bj_event_participant_cl4tsv,
     provide_context=True,
     dag=dag
)

# イベント参加者ワークロード及び、レコード取得・ファイル書き出し　結果（分岐）　正常の場合、後続処理へ遷移（異常の場合、エラー処理へ遷移）

def check_load_result(**context):

    # context 内より task_id を key に取得
    return context['task_instance'].xcom_pull(task_ids='convert_tsv2csv_t_bj_event_participantl_cl')

branch_task_load_result = BranchPythonOperator(
    task_id='branch_task_load_result',
    dag=dag,
    python_callable=check_load_result,
)

# 名寄せ項目クレンジング・ファイル出力

cleanse_t_bj_event_participant_cl = batch.create_operator(
    dag=dag,
    task_id='cleanse_t_bj_event_participant_cl',
    job_name="datacleansing",
    queue=batch.QUEUE_DATACLEANSING,
    command=[
        CL_FILE_CLEANS_BF_FULL_PATH,
        CL_FILE_CLEANS_AF_FULL_PATH,
        "-colNo", "5",
        "-name", "{1}",
        "-postcode", "{2}",
        "-address", "{3}",
        "-telno", "{4}",
    ]
)

# リスト取込処理

append_t_bj_event_participant_cl_normal = PostgresOperator(
    task_id='append_t_bj_event_participant_cl_normal',
    postgres_conn_id='redshift_default',
    sql='sql/ims/insert_t_bj_event_participant_cl.sql',
    autocommit=False,
    dag=dag
)

#######################################################################################################
# 異常終了処理：イベント参加者ファイルのチェック処理
#######################################################################################################

# DBステータス更新

update_t_bj_event_participant_edit_error = PostgresOperator(
    task_id='update_t_bj_event_participant_edit_error',
    postgres_conn_id='redshift_default',
    sql='sql/ims/update_t_bj_event_participant_edit_error.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 異常終了処理：イベント参加者ワークロード及び、レコード取得・ファイル書き出し
#######################################################################################################

# DBステータス更新

update_t_bj_event_participant_load_error = PostgresOperator(
    task_id='update_t_bj_event_participant_load_error',
    postgres_conn_id='redshift_default',
    sql='sql/ims/update_t_bj_event_participant_load_error.sql',
    autocommit=False,
    dag=dag
)


#######################################################################################################
# 正常終了処理時の後始末
#######################################################################################################

# S3ファイル削除(クレンジング前)

delete_from_s3_t_bj_event_participant_cl_bf = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_bj_event_participant_cl_bf',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    prefix=CL_FILE_CLEANS_BF + '/',
    dag=dag
)

# S3ファイル削除(クレンジング後)

delete_from_s3_t_bj_event_participant_cl_af = S3DeleteObjectsOperator(
    task_id='delete_from_s3_t_bj_event_participant_cl_af',
    aws_conn_id='aws_default',
    bucket=S3_BUCKET_NAME,
    prefix=CL_FILE_CLEANS_AF + '/',
    dag=dag
)

# DAGの全タスク完了

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)

#######################################################################################################
# 依存関係
#######################################################################################################

check_exist_task_list_data >> get_bj_list_task >> edit_t_bj_event_participant_cl >> branch_task_file_edit_result
branch_task_file_edit_result >> convert_tsv2csv_t_bj_event_participantl_cl >> branch_task_load_result
branch_task_file_edit_result >> update_t_bj_event_participant_edit_error >> done_all_task_for_check
branch_task_load_result >> cleanse_t_bj_event_participant_cl >> append_t_bj_event_participant_cl_normal
branch_task_load_result >> update_t_bj_event_participant_load_error >> done_all_task_for_check
append_t_bj_event_participant_cl_normal >> [ delete_from_s3_t_bj_event_participant_cl_bf
                                           , delete_from_s3_t_bj_event_participant_cl_af] >> done_all_task_for_check
