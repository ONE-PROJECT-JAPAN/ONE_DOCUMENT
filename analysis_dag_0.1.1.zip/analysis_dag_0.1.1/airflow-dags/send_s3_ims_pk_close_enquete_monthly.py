import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum
import boto3


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,5,10,3,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='send_s3_ims_pk_close_enquete_monthly',
    default_args=default_args,
    description='解約アンケートレポート（月次）作成',
    schedule_interval='3 10 5 * *', # 毎月5日10時03分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

REDSHIFT_CONN_ID = 'redshift_default'

DB_SCHEMA = Variable.get('redshift_ims_schema_name')

S3_BUCKET_NAME = Variable.get('sharedfs_s3_bucket_name')

# ファイル出力先
S3_FOLDER = 'Asteria/IMS/PK/解約アンケート'
S3_FILENAME_WK = '_pk_close_enquete_monthly_wk_'
S3_FILENAME = '_pk_close_enquete_monthly.csv'
S3_OUTPUT_PATH = """{}/""" + S3_FOLDER + """/{}""" + S3_FILENAME_WK

#######################################################################################################
# 処理
#######################################################################################################

# 送信ファイル作成処理

redshift_to_s3_to_ims = PostgresOperator(
    task_id='redshift_to_s3_to_ims',
    postgres_conn_id=REDSHIFT_CONN_ID,
    sql=f'sql/ims/unload_pk_close_enquete_monthly.sql',
    params = {
        's3_path' : S3_OUTPUT_PATH
    },
    autocommit=False,
    dag=dag
)

# 送信ファイルリネーム処理

def main(**context):
    exec_date = convUTC2JST(context['next_execution_date'], "%Y%m%d")
    src_path = f'{S3_FOLDER}/{exec_date}{S3_FILENAME_WK}000'
    dst_path = f'{S3_FOLDER}/{exec_date}{S3_FILENAME}'

    s3client = boto3.client('s3')
    s3resource = boto3.resource('s3')

    response = s3client.get_object(Bucket=S3_BUCKET_NAME, Key=src_path)
    src_data = response['Body'].read().decode('utf-8')
    dst_data = src_data.replace('\n', '\r\n')

    dst_obj = s3resource.Object(bucket_name=S3_BUCKET_NAME, key=dst_path)
    dst_obj.put(Body=dst_data.encode('cp932'))

    s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=src_path)

rename_send_s3_file = PythonOperator(
    task_id='rename_send_s3_file',
    python_callable=main,
    provide_context=True,
    dag=dag
)

#######################################################################################################
# 依存関係
#######################################################################################################

redshift_to_s3_to_ims >> rename_send_s3_file
