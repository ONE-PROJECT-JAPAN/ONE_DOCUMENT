import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.redshift_loader import invoke_redshift_loader
from common_ims.bqsync import redshift_to_bigquery
from common_ims.bqexec import bigquery_executor
from common_ims.common_util import convUTC2JST
from common_ims.notification import notify_failure
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,5,40,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 6,
    'retry_delay': timedelta(minutes=10),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'impr_ba_to_ims', # DAG名
    default_args=default_args,
    description='日経ビジネススクール(BA)のデータ構築',
    schedule_interval='40 5 * * *', # 毎日05時40分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST}, # ユーザ関数定義
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# データ構築処理
#######################################################################################################

# 講座本番データロード

s3_to_redshift_t_ba_v_seminar_honban = PythonOperator(
    task_id='s3_to_redshift_t_ba_v_seminar_honban',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ba',
        'redshift_loader_table_name': 'T_BA_V_SEMINAR_HONBAN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 講座本番データ蓄積

s3_to_redshift_t_ba_v_seminar_honban_accum = PythonOperator(
    task_id='s3_to_redshift_t_ba_v_seminar_honban_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ba',
        'redshift_loader_table_name': 'T_BA_V_SEMINAR_HONBAN',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'SYSTEM_SEMINAR_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BA_V_SEMINAR_HONBAN_ACCUM',
    },
    dag=dag
)

# 申し込みデータロード

s3_to_redshift_t_ba_v_seminar_payment = PythonOperator(
    task_id='s3_to_redshift_t_ba_v_seminar_payment',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ba',
        'redshift_loader_table_name': 'T_BA_V_SEMINAR_PAYMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
    },
    dag=dag
)

# 申し込みデータ蓄積

s3_to_redshift_t_ba_v_seminar_payment_accum = PythonOperator(
    task_id='s3_to_redshift_t_ba_v_seminar_payment_accum',
    provide_context=True,
    python_callable=invoke_redshift_loader,
    op_kwargs={
        'redshift_loader_system_id': 'ba',
        'redshift_loader_table_name': 'T_BA_V_SEMINAR_PAYMENT',
        'redshift_loader_date': '{{ convUTC2JST(next_execution_date, "%Y%m%d") }}',
        'redshift_loader_format': 'csv-gzip',
        'redshift_loader_accumulation': {
            'mode': 'update',
            'key_columns': [ 'PAYMENT_ID' ],
            'extra_columns': [
                 {'name': 'INS_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'INS_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"},
                 {'name': 'UPD_BATCH_ID', 'value': "'{{dag.dag_id}}'"},
                 {'name': 'UPD_DT_TM',    'value': "CONVERT_TIMEZONE('Asia/Tokyo', GETDATE())"}
            ]
        },
        'redshift_loader_target_table_name': 'T_BA_V_SEMINAR_PAYMENT_ACCUM',
    },
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################

with dag:
    """
    講座本番データ
    """
    redshift_to_bigquery_t_ba_v_seminar_honban = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_ba_v_seminar_honban',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_ba_v_seminar_honban.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BA_V_SEMINAR_HONBAN',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )

    """
    申し込みデータ
    """
    redshift_to_bigquery_t_ba_v_seminar_payment = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_ba_v_seminar_payment',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_ba_v_seminar_payment.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BA_V_SEMINAR_PAYMENT',
        is_table_update_mng=True,
        bigquery_additional_sql=None
    )


#######################################################################################################
# BigQueryテーブル操作
#######################################################################################################

with dag:
    bq_update_t_ba_v_seminar_payment_accum = bigquery_executor(
        dag=dag,
        group_id='bq_update_t_ba_v_seminar_payment_accum',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BA_V_SEMINAR_PAYMENT_ACCUM',
        execute_query='sql/bigquery/execute/UPD__T_BA_V_SEMINAR_PAYMENT_ACCUM.sql'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

s3_to_redshift_t_ba_v_seminar_honban >> [s3_to_redshift_t_ba_v_seminar_honban_accum, redshift_to_bigquery_t_ba_v_seminar_honban] >> done_all_task_for_check
s3_to_redshift_t_ba_v_seminar_payment >> s3_to_redshift_t_ba_v_seminar_payment_accum >> done_all_task_for_check
s3_to_redshift_t_ba_v_seminar_payment >> redshift_to_bigquery_t_ba_v_seminar_payment >> bq_update_t_ba_v_seminar_payment_accum >> done_all_task_for_check
