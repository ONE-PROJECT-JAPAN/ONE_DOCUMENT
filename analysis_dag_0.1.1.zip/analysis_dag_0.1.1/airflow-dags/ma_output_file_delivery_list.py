import sys, os
from typing import Type
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.models import Variable
from common_ims.notification import notify_failure
from common_ims import constant
from boto3 import Session
from botocore.exceptions import ClientError
import logging
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,0,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'on_failure_callback': notify_failure
}

dag = DAG(
    dag_id='ma_output_file_delivery_list',
    default_args=default_args,
    description='配信リスト出力',
    schedule_interval='*/10 8-15 * * *', # 毎日 8:00～15:50(JST) 10分毎
    catchup=False,
    max_active_runs=1 # DAG の最大同時実行数1
)


#######################################################################################################
# 定数
#######################################################################################################

# RedshiftのコネクションID
REDSHIFT_CONN_ID = 'redshift_default'

# Redshiftのスキーマ名
REDSHIFT_SCHEMA = Variable.get('redshift_ims_schema_name')

# RedshiftのIAM ロール
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')

# Datastoreのバケット名
S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')

# ワークステーションの共有バケット名
S3_BUCKET_NAME_SHAREDFS = Variable.get('sharedfs_s3_bucket_name')

# 一時出力先
S3_WORK_PATH = 'app/mss/配信リスト'
S3_BUCKET_NAME_WORK = S3_BUCKET_NAME + '/' + S3_WORK_PATH

#######################################################################################################
# Python関数
#######################################################################################################

def get_export_id_list(cursor):
    """
    ファイル出力対象の情報を取得

    Parameters
    ----------
    cursor : 
        カーソル

    Returns
    -------
    export_id_list : list
        タプル（抽出ID/施策ID/抽出日/ファイル出力パス）のリスト
    """
    export_id_list = []

    # {DATE}, {COUNT}はM_MA_DELIVERY_LIST_INFO.FILE_OUTPUT_PATH_FORMATに登録されている置換文字列
    query = f"""WITH MAIN AS
               (
                   SELECT
                       T1.FILE_OUTPUT_PATH_FORMAT
                     , T2.EXPORT_ID
                     , T2.CAMPAIGN_ID
                     , T2.EXPORT_DATE
                   FROM
                       {REDSHIFT_SCHEMA}.M_MA_DELIVERY_LIST_INFO T1
                       INNER JOIN {REDSHIFT_SCHEMA}.T_MA_EXPORT_INFO T2
                           ON T1.CAMPAIGN_ID = T2.CAMPAIGN_ID 
                   WHERE
                       NOT EXISTS (
                           SELECT
                               1
                           FROM
                              {REDSHIFT_SCHEMA}.T_MA_DELIVERY_LIST_OUTPUT_HISTORY SUB
                           WHERE T2.EXPORT_ID = SUB.EXPORT_ID
                       )
                   GROUP BY T1.FILE_OUTPUT_PATH_FORMAT
                          , T2.EXPORT_ID
                          , T2.CAMPAIGN_ID
                          , T2.EXPORT_DATE
               ),
               TARGET_COUNT AS
               (
                   SELECT
                       T1.EXPORT_ID
                     , COUNT(DISTINCT T2.SERIAL_ID) CNT
                   FROM
                       MAIN T1
                       INNER JOIN {REDSHIFT_SCHEMA}.T_MA_EXPORT_INFO T2
                           ON T1.EXPORT_ID = T2.EXPORT_ID
                       INNER JOIN {REDSHIFT_SCHEMA}.M_IS_NX_USER_SERIAL_ID T3
                           ON T2.SERIAL_ID = T3.SERIAL_ID
                       INNER JOIN {REDSHIFT_SCHEMA}.M_IS_NX_ATTRIBUTE T4
                           ON T3.USER_NO = T4.USER_NO
                   GROUP BY T1.EXPORT_ID
               )
               SELECT
                   T1.EXPORT_ID
                 , T1.CAMPAIGN_ID
                 , T1.EXPORT_DATE
                 , REPLACE(REPLACE(T1.FILE_OUTPUT_PATH_FORMAT, '{{DATE}}', TO_CHAR(T1.EXPORT_DATE, 'YYYYMMDD')), '{{COUNT}}', CAST(NVL(T2.CNT, 0) AS VARCHAR))
               FROM 
                   MAIN T1
                   LEFT OUTER JOIN TARGET_COUNT T2
                       ON T1.EXPORT_ID = T2.EXPORT_ID
               ORDER BY T1.EXPORT_ID"""

    logging.info(f'*** get_export_id_list QUERY: {query}')
    cursor.execute(query)

    for rec in cursor:
        export_id = rec[0]
        campaign_id = rec[1]
        export_date = rec[2]
        file_output_path = rec[3]
        t = (export_id, campaign_id, export_date, file_output_path)
        export_id_list.append(t)

    return export_id_list

def output_ma_delivery_list(cursor, export_id, file_output_path):
    """
    配信リスト出力

    Parameters
    ----------
    cursor : 
        カーソル
    export_id : str
        抽出ID
    file_output_path : str
        ファイル出力パス
    """
    logging.info(f'*** output_delivery_list file_output_path: {file_output_path}')

    # 配信リスト出力
    query = f"""UNLOAD
                ($$
                     SELECT DISTINCT
                         T3.EMAIL AS email
                       , T1.SERIAL_ID As serial_id
                     FROM
                         {REDSHIFT_SCHEMA}.T_MA_EXPORT_INFO T1
                         INNER JOIN {REDSHIFT_SCHEMA}.M_IS_NX_USER_SERIAL_ID T2
                             ON T1.SERIAL_ID = T2.SERIAL_ID
                         INNER JOIN {REDSHIFT_SCHEMA}.M_IS_NX_ATTRIBUTE T3
                             ON T2.USER_NO = T3.USER_NO
                     WHERE
                         T1.EXPORT_ID = '{export_id}'
                     ORDER BY EMAIL
                $$)
                TO 's3://{S3_BUCKET_NAME_WORK}/{file_output_path}'
                iam_role '{REDSHIFT_DEFAULT_ROLE_ARN}'
                DELIMITER AS ','
                HEADER
                NULL AS ''
                ESCAPE
                PARALLEL OFF
                MAXFILESIZE AS 5GB
                ALLOWOVERWRITE"""
    logging.info(f'*** output_delivery_list QUERY: {query}')
    cursor.execute(query)

    # ファイル名の変更（ファイル名の語尾000を削除）
    s3client = Session().client('s3')
    try:
        # コピー先
        dest_key = os.path.join(constant.S3_DELIVERY_LIST_PATH, file_output_path)
        # コピー元
        org_key = os.path.join(S3_WORK_PATH, file_output_path + "000")

        logging.info(f'*** output_delivery_list org_key: {org_key} dest_key: {dest_key}')
        
        # S3の配信リスト出力先へファイルコピー（_000を除去するため実施）
        s3client.copy_object(Bucket=S3_BUCKET_NAME_SHAREDFS, Key=dest_key, CopySource={'Bucket': S3_BUCKET_NAME, 'Key': org_key})
        # S3の一時出力ファイル削除
        s3client.delete_object(Bucket=S3_BUCKET_NAME, Key=org_key)
    except ClientError as e:
        logging.error(e)
        raise e

def main(**context):
    """
    主処理

    Parameters
    ----------
    context : dict
        コンテキスト変数
    """
    conn = None
    cursor = None
    try:
        conn = PostgresHook(postgres_conn_id=REDSHIFT_CONN_ID).get_conn()
        cursor = conn.cursor()

        # 配信リスト出力対象取得
        export_id_list = get_export_id_list(cursor)
        logging.info(f' main 配信リスト出力対象件数：{len(export_id_list)}')

        # 施策毎に出力処理
        for export_id, campaign_id, export_date, file_output_path in export_id_list:
            logging.debug(f'抽出ID：{export_id}, 施策ID：{campaign_id}, 抽出日：{export_date}, ファイル出力パス：{file_output_path}')
            # 配信リスト出力
            output_ma_delivery_list(cursor, export_id, file_output_path)
            
            # MA配信リスト出力履歴へ書き込み
            query = f"""INSERT INTO {REDSHIFT_SCHEMA}.T_MA_DELIVERY_LIST_OUTPUT_HISTORY 
                        VALUES(%s, %s, %s, %s, CONVERT_TIMEZONE('Asia/Tokyo', GETDATE()))
                    """
            cursor.execute(query, (export_id, campaign_id, export_date, file_output_path))

            # 施策毎にコミット
            conn.commit()
    except Exception as e:
        logging.error(f'*** main Exception: {str(e)}')
        if conn is not None:
            conn.rollback()
        raise e
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

#######################################################################################################
# タスク
#######################################################################################################

output_delivery_list = PythonOperator(
    task_id="output_delivery_list",
    python_callable=main,
    dag=dag
)


#######################################################################################################
# 依存関係
#######################################################################################################

output_delivery_list
