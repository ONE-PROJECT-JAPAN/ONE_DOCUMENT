import sys, os
sys.path.insert(0, os.path.realpath(
    os.path.join(os.path.dirname(__file__), '.')))

from airflow import DAG
from datetime import datetime, timedelta
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
from common_ims.bqsync import redshift_to_bigquery
from common_ims.notification import notify_failure
from common_ims.common_util import convUTC2JST
import pendulum


#######################################################################################################
# DAG
#######################################################################################################

local_tz = pendulum.timezone("Asia/Tokyo")
default_args = {
    'start_date': datetime(2021,1,1,8,50,0, tzinfo=local_tz),
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=3),
    'on_failure_callback': notify_failure
}

dag = DAG(
    'send_bigquery_t_bj_event_participant', # DAG名
    default_args=default_args,
    description='イベント参加者データのBigQuery連携',
    schedule_interval='50 8 * * *', # 毎日08時50分(JST)
    user_defined_macros={'convUTC2JST':convUTC2JST},
    catchup=False
)

####################################################################################################
# 定数宣言
####################################################################################################

# 環境変数
DATASTORE_S3_BUCKET_NAME = Variable.get('datastore_s3_bucket_name')
REDSHIFT_DEFAULT_ROLE_ARN = Variable.get('redshift_default_role_arn')
BIGQUERY_DATASET_NAME = Variable.get('atlas_bigquery_ims_dataset_name')

#######################################################################################################
# 前提チェック
#######################################################################################################

# シリアルIDテーブルデータロード 

check_s3_to_redshift_m_is_nx_user_serial_id = ExternalTaskSensor(
    task_id='check_s3_to_redshift_m_is_nx_user_serial_id',
    external_dag_id='impr_is_to_ims_1',
    external_task_id='s3_to_redshift_m_is_nx_user_serial_id',
    execution_delta=timedelta(minutes=130), # 06時40分(JST)
    allowed_states=['success'],
    mode='reschedule',
    poke_interval=180, #3分
    timeout=3600,      #60分
    retries=0,
    dag=dag
)


#######################################################################################################
# BigQueryデータ連携処理
#######################################################################################################
with dag:
    redshift_to_bigquery_t_bj_event_participant_cl = redshift_to_bigquery(
        dag=dag,
        group_id='redshift_to_bigquery_t_bj_event_participant_cl',
        aws_conn_id='aws_default',
        gcp_conn_id='google_cloud_default',
        s3_bucket_name=DATASTORE_S3_BUCKET_NAME,
        redshift_conn_id='redshift_default',
        redshift_role_arn=REDSHIFT_DEFAULT_ROLE_ARN,
        redshift_select_sql='sql/unload/t_bj_event_participant_cl.sql',
        bigquery_dataset=BIGQUERY_DATASET_NAME,
        bigquery_table='T_BJ_EVENT_PARTICIPANT_CL'
    )

"""
DAGの全タスク完了
"""

done_all_task_for_check = DummyOperator(
    task_id='done_all_task_for_check',
    dag=dag,
)


#######################################################################################################
# 依存関係
#######################################################################################################

check_s3_to_redshift_m_is_nx_user_serial_id >> redshift_to_bigquery_t_bj_event_participant_cl >> done_all_task_for_check
